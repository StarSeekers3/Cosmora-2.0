/**
 * Thin, allow-listed proxy for the NASA Technical Reports Server (NTRS) citation search.
 *
 * The client in src/utils/nasaApi.ts calls NTRS directly first; this endpoint exists for browsers or
 * networks where that is blocked (for example by CORS). It only forwards a text query and a small
 * page size, caches responses, and trims each record to the fields the app displays, so it cannot be
 * used as an open relay.
 *
 * Data provided by NASA Scientific and Technical Information Program (https://ntrs.nasa.gov/api/openapi/)
 * NTRS limit: 500 requests per 15 minutes, which the 6 h cache below keeps well clear of.
 */

type RequestLike = { url?: string; method?: string };
type ResponseLike = {
  statusCode: number;
  setHeader: (name: string, value: string) => void;
  end: (body?: string) => void;
};

type CacheEntry = { expiresAt: number; status: number; body: string };
const CACHE_MS = 6 * 60 * 60 * 1000;
const MAX_CACHE_ENTRIES = 300;
const cache = new Map<string, CacheEntry>();

function send(res: ResponseLike, status: number, body: string, cacheable = false) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', cacheable ? 'public, max-age=300, s-maxage=21600, stale-while-revalidate=3600' : 'no-store');
  res.end(body);
}

export default async function handler(req: RequestLike, res: ResponseLike) {
  if (req.method && req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    send(res, 405, JSON.stringify({ error: 'GET required' }));
    return;
  }

  const url = new URL(req.url ?? '/', 'http://localhost');
  const q = (url.searchParams.get('q') ?? '').trim();
  const size = Math.min(10, Math.max(1, Math.floor(Number(url.searchParams.get('size') ?? 3)) || 3));
  if (!q || q.length > 200) {
    send(res, 400, JSON.stringify({ error: 'Provide q (1-200 characters)' }));
    return;
  }

  const key = `${q.toLowerCase()}|${size}`;
  const now = Date.now();
  const hit = cache.get(key);
  if (hit && hit.expiresAt > now) {
    send(res, hit.status, hit.body, hit.status === 200);
    return;
  }

  try {
    const upstream = await fetch(
      `https://ntrs.nasa.gov/api/citations/search?q=${encodeURIComponent(q)}&page.size=${size}`,
      { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(9000) },
    );
    if (!upstream.ok) {
      send(res, upstream.status, JSON.stringify({ error: `NTRS returned HTTP ${upstream.status}` }));
      return;
    }
    const json = (await upstream.json()) as { stats?: { total?: number }; results?: Record<string, any>[] };
    const payload = JSON.stringify({
      stats: { total: json.stats?.total ?? 0 },
      results: (json.results ?? []).map(r => ({
        id: r.id,
        title: r.title,
        abstract: typeof r.abstract === 'string' ? r.abstract.slice(0, 600) : undefined,
        center: r.center ? { name: r.center.name } : undefined,
        authorAffiliations: r.authorAffiliations,
        publications: Array.isArray(r.publications) ? r.publications.slice(0, 1) : undefined,
        distributionDate: r.distributionDate,
        otherReportNumbers: r.otherReportNumbers,
      })),
    });
    if (cache.size >= MAX_CACHE_ENTRIES) cache.delete(cache.keys().next().value as string);
    cache.set(key, { expiresAt: now + CACHE_MS, status: 200, body: payload });
    send(res, 200, payload, true);
  } catch (error) {
    const detail = error instanceof Error ? error.message : 'Network error';
    send(res, 502, JSON.stringify({ error: 'Unable to reach NTRS', detail }));
  }
}
