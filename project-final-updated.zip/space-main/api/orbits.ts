type OmmRecord = {
  OBJECT_NAME?: string;
  OBJECT_ID?: string;
  EPOCH?: string;
  MEAN_MOTION?: number;
  ECCENTRICITY?: number;
  INCLINATION?: number;
  RA_OF_ASC_NODE?: number;
  ARG_OF_PERICENTER?: number;
  MEAN_ANOMALY?: number;
  EPHEMERIS_TYPE?: number;
  CLASSIFICATION_TYPE?: string;
  NORAD_CAT_ID?: number;
  ELEMENT_SET_NO?: number;
  REV_AT_EPOCH?: number;
  BSTAR?: number;
  MEAN_MOTION_DOT?: number;
  MEAN_MOTION_DDOT?: number;
};

type RequestLike = { url?: string; method?: string };
type ResponseLike = {
  statusCode: number;
  setHeader: (name: string, value: string) => void;
  end: (body?: string) => void;
};

type CacheEntry = { expiresAt: number; status: number; body: string };
const CACHE_MS = 2 * 60 * 60 * 1000;
const MAX_STARLINK_SAMPLES = 320;
/** CelesTrak GP groups the app may request (allow-list keeps the proxy from being an open relay). */
const GROUPS: Record<string, { query: string; cap: number }> = {
  STARLINK: { query: 'GROUP=STARLINK', cap: MAX_STARLINK_SAMPLES },
  HUBBLE: { query: 'CATNR=20580', cap: 1 },
  STATIONS: { query: 'GROUP=STATIONS', cap: 40 },
  GPS: { query: 'GROUP=GPS-OPS', cap: 40 },
  GALILEO: { query: 'GROUP=GALILEO', cap: 40 },
  GLONASS: { query: 'GROUP=GLO-OPS', cap: 40 },
  BEIDOU: { query: 'GROUP=BEIDOU', cap: 70 },
  ONEWEB: { query: 'GROUP=ONEWEB', cap: 260 },
  IRIDIUM: { query: 'GROUP=IRIDIUM-NEXT', cap: 90 },
  WEATHER: { query: 'GROUP=WEATHER', cap: 80 },
  GEO: { query: 'GROUP=GEO', cap: 450 },
  DEBRIS: { query: 'GROUP=COSMOS-2251-DEBRIS', cap: 300 },
};
const cache = new Map<string, CacheEntry>();

function send(res: ResponseLike, status: number, body: string, cacheable = false) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', cacheable ? 'public, max-age=300, s-maxage=7200, stale-while-revalidate=3600' : 'no-store');
  res.end(body);
}

export default async function handler(req: RequestLike, res: ResponseLike) {
  if (req.method && req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    send(res, 405, JSON.stringify({ error: 'GET required' }));
    return;
  }

  const url = new URL(req.url ?? '/', 'http://localhost');
  const requested = (url.searchParams.get('group') ?? '').toUpperCase();
  const spec = GROUPS[requested];
  if (!spec) {
    send(res, 400, JSON.stringify({ error: `Use group=${Object.keys(GROUPS).join('|')}` }));
    return;
  }

  const now = Date.now();
  const cached = cache.get(requested);
  if (cached && cached.expiresAt > now) {
    send(res, cached.status, cached.body, cached.status === 200);
    return;
  }

  const query = spec.query;
  const endpoint = `https://celestrak.org/NORAD/elements/gp.php?${query}&FORMAT=JSON`;
  try {
    const upstream = await fetch(endpoint, { headers: { Accept: 'application/json' } });
    if (!upstream.ok) {
      // Respect CelesTrak's policy: do not retry failed responses automatically.
      const message = (await upstream.text()).slice(0, 600);
      const body = JSON.stringify({ error: `CelesTrak returned HTTP ${upstream.status}`, detail: message });
      cache.set(requested, { expiresAt: now + CACHE_MS, status: upstream.status, body });
      send(res, upstream.status, body);
      return;
    }
    const incoming = await upstream.json() as OmmRecord[];
    if (!Array.isArray(incoming) || incoming.length === 0) {
      send(res, 502, JSON.stringify({ error: 'CelesTrak returned no orbital elements' }));
      return;
    }

    const elements = requested === 'HUBBLE'
      ? incoming.filter(item => Number(item.NORAD_CAT_ID) === 20580).slice(0, 1)
      : (() => {
          const sorted = incoming.filter(item => item.EPOCH && item.MEAN_MOTION && item.NORAD_CAT_ID !== undefined)
            .sort((a, b) => Number(a.NORAD_CAT_ID) - Number(b.NORAD_CAT_ID));
          const stride = Math.max(1, Math.ceil(sorted.length / spec.cap));
          return sorted.filter((_, index) => index % stride === 0).slice(0, spec.cap);
        })();

    if (!elements.length) {
      send(res, 502, JSON.stringify({ error: 'No usable OMM elements found in the CelesTrak response' }));
      return;
    }
    const fetchedAt = new Date().toISOString();
    const payload = JSON.stringify({
      group: requested,
      source: 'CelesTrak GP / OMM JSON',
      fetchedAt,
      total: incoming.length,
      plotted: elements.length,
      sampled: elements.length < incoming.length,
      elements,
    });
    cache.set(requested, { expiresAt: now + CACHE_MS, status: 200, body: payload });
    send(res, 200, payload, true);
  } catch (error) {
    const detail = error instanceof Error ? error.message : 'Network error';
    send(res, 502, JSON.stringify({ error: 'Unable to retrieve live orbital elements', detail }));
  }
}
