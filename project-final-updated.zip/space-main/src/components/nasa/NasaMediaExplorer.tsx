import React, { useState, useEffect } from 'react';
import { Camera, Search, ExternalLink, Image as ImageIcon, Sparkles, RefreshCw, ZoomIn } from 'lucide-react';
import { playUiClick } from '../../utils/audio';

interface NasaMediaItem {
  nasaId: string;
  title: string;
  description: string;
  dateCreated: string;
  center: string;
  thumbUrl: string;
  fullUrl: string;
  keywords: string[];
}

const CURATED_NASA_MEDIA: NasaMediaItem[] = [
  {
    nasaId: 'PIA25440',
    title: 'James Webb Space Telescope: Carina Nebula "Cosmic Cliffs"',
    description: 'This landscape of "mountains" and "valleys" speckled with glittering stars is actually the edge of a nearby, young, star-forming region NGC 3324 in the Carina Nebula.',
    dateCreated: '2022-07-12',
    center: 'STScI / GSFC',
    thumbUrl: 'https://images-assets.nasa.gov/image/PIA25440/PIA25440~thumb.jpg',
    fullUrl: 'https://images-assets.nasa.gov/image/PIA25440/PIA25440~orig.jpg',
    keywords: ['JWST', 'Nebula', 'Carina', 'Infrared'],
  },
  {
    nasaId: 'PIA24424',
    title: 'Perseverance Rover Mastcam-Z 360 Panorama of Jezero Crater',
    description: 'NASA’s Mars 2020 Perseverance rover captured this high-definition panoramic mosaic of the Jezero Crater delta and Van Zyl Overlook.',
    dateCreated: '2021-03-05',
    center: 'JPL',
    thumbUrl: 'https://images-assets.nasa.gov/image/PIA24424/PIA24424~thumb.jpg',
    fullUrl: 'https://images-assets.nasa.gov/image/PIA24424/PIA24424~orig.jpg',
    keywords: ['Mars', 'Perseverance', 'Rover', 'Jezero'],
  },
  {
    nasaId: 'as11-40-5875',
    title: 'Apollo 11 Buzz Aldrin on the Moon: The Visor Reflection',
    description: 'Astronaut Buzz Aldrin walks on the lunar surface during the Apollo 11 mission. Neil Armstrong and the Lunar Module Eagle are reflected in his gold visor.',
    dateCreated: '1969-07-20',
    center: 'JSC',
    thumbUrl: 'https://images-assets.nasa.gov/image/as11-40-5875/as11-40-5875~thumb.jpg',
    fullUrl: 'https://images-assets.nasa.gov/image/as11-40-5875/as11-40-5875~orig.jpg',
    keywords: ['Apollo 11', 'Moon', 'Aldrin', 'Astronaut'],
  },
  {
    nasaId: 'PIA18033',
    title: 'Curiosity Rover 1.8-Billion-Pixel Mars Panorama',
    description: 'NASA’s Curiosity rover photographed this stunning billion-pixel view of Glen Torridon in Gale Crater, featuring layered sulfate mudstones and Mount Sharp.',
    dateCreated: '2020-03-04',
    center: 'JPL',
    thumbUrl: 'https://images-assets.nasa.gov/image/PIA18033/PIA18033~thumb.jpg',
    fullUrl: 'https://images-assets.nasa.gov/image/PIA18033/PIA18033~orig.jpg',
    keywords: ['Curiosity', 'Mars', 'Gale Crater'],
  },
];

export const NasaMediaExplorer: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [mediaList, setMediaList] = useState<NasaMediaItem[]>(CURATED_NASA_MEDIA);
  const [selectedItem, setSelectedItem] = useState<NasaMediaItem | null>(CURATED_NASA_MEDIA[0]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchStatus, setSearchStatus] = useState<string>('NASA Curated Deep Space Archive');

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchTerm.trim()) {
      setMediaList(CURATED_NASA_MEDIA);
      setSearchStatus('NASA Curated Deep Space Archive');
      return;
    }

    setIsSearching(true);
    playUiClick();
    setSearchStatus(`Querying NASA Images API for "${searchTerm}"…`);

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4500);
      const res = await fetch(
        `https://images-api.nasa.gov/search?q=${encodeURIComponent(
          searchTerm
        )}&media_type=image`,
        { signal: controller.signal }
      );
      clearTimeout(timeoutId);

      if (res.ok) {
        const data = await res.json();
        const items = data.collection?.items || [];
        if (items.length > 0) {
          const mapped: NasaMediaItem[] = items.slice(0, 8).map((it: any) => {
            const d = it.data?.[0] || {};
            const thumb = it.links?.find((l: any) => l.rel === 'preview')?.href || '';
            return {
              nasaId: d.nasa_id || 'NASA-IMG',
              title: d.title || 'NASA Space Observation',
              description: d.description || 'Observation from NASA open scientific data archives.',
              dateCreated: d.date_created?.slice(0, 10) || 'Recent',
              center: d.center || 'NASA',
              thumbUrl: thumb,
              fullUrl: thumb.replace('~thumb.jpg', '~orig.jpg'),
              keywords: d.keywords?.slice(0, 4) || ['NASA', 'Space'],
            };
          });
          setMediaList(mapped);
          setSelectedItem(mapped[0]);
          setSearchStatus(`Found ${items.length} NASA Open Archive matches`);
        } else {
          setSearchStatus('No exact matches found in NASA API · showing curated archive');
          setMediaList(CURATED_NASA_MEDIA);
        }
      } else {
        setSearchStatus('NASA API rate-limit · showing verified offline archive');
        setMediaList(CURATED_NASA_MEDIA);
      }
    } catch {
      setSearchStatus('Offline fallback active · showing verified NASA archive');
      setMediaList(CURATED_NASA_MEDIA);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Info & Search Input */}
      <div className="p-4 sm:p-5 rounded-xl bg-gradient-to-r from-[#0b1c20] via-[#0e272c] to-[#0b1c20] border border-[#66d17a]/30 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#66d17a]/20 border border-[#66d17a]/40 grid place-items-center text-[#66d17a]">
              <Camera size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-base sm:text-lg text-[#eef4e6]">
                  NASA Images &amp; Deep-Space Media Archive
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#66d17a]/20 text-[#66d17a] font-bold">
                  NASA IMAGES API
                </span>
              </div>
              <p className="text-xs text-[#9fb1a6]">
                Access over 140,000 public scientific astronomy images from James Webb, Hubble, Apollo, and planetary rovers.
              </p>
            </div>
          </div>

          <div className="text-[10px] font-mono text-[#9fb1a6]">{searchStatus}</div>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="relative flex-1">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#9fb1a6]" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search NASA archive (e.g., 'James Webb', 'Mars Delta', 'Apollo 11', 'Jupiter Aurora')…"
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/50 border border-white/10 text-xs text-[#eef4e6] placeholder-[#9fb1a6]/60 focus:border-[#66d17a] focus:outline-none font-mono"
            />
          </div>
          <button
            type="submit"
            disabled={isSearching}
            className="px-4 py-2.5 rounded-xl bg-[#66d17a] hover:bg-[#7ce08f] text-[#061211] font-mono font-bold text-xs uppercase flex items-center gap-2 transition cursor-pointer"
          >
            {isSearching ? <RefreshCw size={14} className="animate-spin" /> : <Search size={14} />}
            <span className="hidden sm:inline">Search NASA</span>
          </button>
        </form>
      </div>

      {/* Grid: Selected Item Inspector + Media Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Selected Item Feature */}
        {selectedItem && (
          <div className="lg:col-span-7 rounded-2xl bg-black/60 border border-white/10 overflow-hidden flex flex-col justify-between">
            <div className="relative max-h-96 bg-black flex items-center justify-center overflow-hidden">
              <img
                src={selectedItem.thumbUrl || selectedItem.fullUrl}
                alt={selectedItem.title}
                className="w-full h-auto max-h-96 object-contain"
                onError={e => {
                  // Fallback placeholder if image load fails
                  (e.target as HTMLImageElement).src = 'https://images-assets.nasa.gov/image/PIA25440/PIA25440~thumb.jpg';
                }}
              />
              <a
                href={selectedItem.fullUrl}
                target="_blank"
                rel="noreferrer"
                className="absolute top-3 right-3 px-3 py-1.5 rounded-lg bg-black/70 hover:bg-black text-[#d9f36a] text-xs font-mono font-bold flex items-center gap-1.5 backdrop-blur-sm border border-white/10 transition"
              >
                <ZoomIn size={13} />
                <span>Original NASA Resolution</span>
              </a>
            </div>

            <div className="p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] font-mono text-[#66d17a]">
                <span>NASA ID: {selectedItem.nasaId}</span>
                <span>CENTER: {selectedItem.center} · {selectedItem.dateCreated}</span>
              </div>
              <h4 className="font-display font-bold text-lg text-white">
                {selectedItem.title}
              </h4>
              <p className="text-xs text-[#bdc9c0] leading-relaxed max-h-28 overflow-y-auto pr-2">
                {selectedItem.description}
              </p>
              <div className="flex flex-wrap gap-1.5 pt-2 border-t border-white/5">
                {selectedItem.keywords.map((kw, i) => (
                  <span
                    key={i}
                    className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-[#9fb1a6] border border-white/5"
                  >
                    #{kw}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Thumbnails List */}
        <div className={`space-y-3 ${selectedItem ? 'lg:col-span-5' : 'lg:col-span-12'}`}>
          <div className="text-xs font-mono text-[#9fb1a6] uppercase tracking-wider flex items-center justify-between">
            <span>NASA OBSERVATION RESULTS</span>
            <span>{mediaList.length} ASSETS</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[580px] overflow-y-auto pr-1">
            {mediaList.map(item => (
              <div
                key={item.nasaId}
                onClick={() => { playUiClick(); setSelectedItem(item); }}
                className={`p-3 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  selectedItem?.nasaId === item.nasaId
                    ? 'border-[#66d17a] bg-[#0c2620]'
                    : 'border-white/10 bg-black/40 hover:border-white/20'
                }`}
              >
                <div className="h-28 rounded-lg bg-black/60 overflow-hidden mb-2 relative">
                  <img
                    src={item.thumbUrl}
                    alt={item.title}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                  <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-black/60 text-[9px] font-mono text-white">
                    {item.center}
                  </div>
                </div>
                <div>
                  <h5 className="font-display font-bold text-xs text-[#eef4e6] line-clamp-1">
                    {item.title}
                  </h5>
                  <span className="text-[10px] font-mono text-[#9fb1a6] mt-0.5 block">
                    {item.dateCreated}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
