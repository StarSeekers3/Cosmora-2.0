import React, { useEffect, useState } from 'react';
import { ExternalLink, Gift, ImageOff, Loader2 } from 'lucide-react';
import { apodImageSrc, fetchApod, IS_DEMO_KEY, type ApodResult } from '../../utils/nasaApi';

const COLLECTION_KEY = 'cosmora_apod_rewards';

/** Record today's picture in the cadet's reward collection (one per APOD date). */
function collectReward(date: string): number {
  try {
    const list: string[] = JSON.parse(localStorage.getItem(COLLECTION_KEY) || '[]');
    if (date && !list.includes(date)) {
      list.push(date);
      localStorage.setItem(COLLECTION_KEY, JSON.stringify(list.slice(-365)));
    }
    return list.length;
  } catch {
    return 0;
  }
}

interface ApodRewardProps {
  /** Short label for the mission that just ended, e.g. "MISSION 4". */
  missionLabel: string;
}

type Status = 'loading' | 'ready' | 'error';

/**
 * Daily image reward from NASA's Astronomy Picture of the Day, shown when a mission ends.
 * It never blocks or alters mission credits: if APOD cannot be reached the card says so and links out.
 */
export const ApodReward: React.FC<ApodRewardProps> = ({ missionLabel }) => {
  const [status, setStatus] = useState<Status>('loading');
  const [apod, setApod] = useState<ApodResult | null>(null);
  const [collected, setCollected] = useState(0);
  const [expanded, setExpanded] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);

  useEffect(() => {
    let alive = true;
    fetchApod()
      .then(result => {
        if (!alive) return;
        setApod(result);
        setCollected(collectReward(result.date));
        setStatus('ready');
      })
      .catch(() => alive && setStatus('error'));
    return () => {
      alive = false;
    };
  }, []);

  const src = apod ? apodImageSrc(apod) : undefined;
  const isVideo = apod?.media_type === 'video';
  const long = (apod?.explanation.length ?? 0) > 260;

  return (
    <section
      aria-label="Daily image reward from NASA Astronomy Picture of the Day"
      className="rounded-xl border border-[#ffc93c]/30 bg-gradient-to-br from-[#1a1a0c]/70 via-[#0b2025] to-[#0b2025] overflow-hidden"
    >
      <div className="flex items-center justify-between gap-3 px-4 py-2.5 border-b border-white/10 text-[10px] font-mono tracking-widest">
        <span className="flex items-center gap-2 text-[#ffc93c] font-bold">
          <Gift size={13} />
          DAILY IMAGE REWARD · {missionLabel}
        </span>
        <span className="text-[#9fb1a6]">NASA APOD</span>
      </div>

      <div aria-live="polite">
        {status === 'loading' && (
          <div className="flex items-center gap-2 p-5 text-xs font-mono text-[#9fb1a6]">
            <Loader2 size={14} className="animate-spin" />
            Unsealing today&rsquo;s NASA picture…
          </div>
        )}

        {status === 'error' && (
          <div className="p-5 text-xs font-mono text-[#bdc9c0] space-y-2">
            <div className="flex items-center gap-2 text-[#ffc93c]">
              <ImageOff size={14} />
              Today&rsquo;s picture isn&rsquo;t available right now.
            </div>
            <p className="text-[#9fb1a6] leading-relaxed">
              NASA&rsquo;s feed couldn&rsquo;t be reached
              {IS_DEMO_KEY ? ' (the shared demo key is often rate-limited)' : ''}. Your mission credits are not affected.
            </p>
            <a
              href="https://apod.nasa.gov/apod/astropix.html"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-[#72d1d6] hover:underline"
            >
              View it on apod.nasa.gov <ExternalLink size={11} />
            </a>
          </div>
        )}

        {status === 'ready' && apod && (
          <div className="grid grid-cols-1 sm:grid-cols-5">
            <div className="sm:col-span-2 bg-black/40 grid place-items-center min-h-[160px]">
              {src && !imageFailed ? (
                <a href={apod.pageUrl} target="_blank" rel="noopener noreferrer" className="block w-full h-full">
                  <img
                    src={src}
                    alt={apod.title}
                    loading="lazy"
                    onError={() => setImageFailed(true)}
                    className="w-full h-full max-h-72 object-cover"
                  />
                </a>
              ) : (
                <div className="p-4 text-center text-[11px] font-mono text-[#9fb1a6]">
                  {isVideo ? 'Today’s APOD is a video.' : 'Image unavailable.'}
                </div>
              )}
            </div>

            <div className="sm:col-span-3 p-4 space-y-2.5 text-xs font-mono">
              <div className="text-[10px] text-[#9fb1a6]">{apod.date}</div>
              <h4 className="font-display font-bold text-base text-[#eef4e6] leading-snug">{apod.title}</h4>
              <p className="text-[#bdc9c0] leading-relaxed">
                {expanded || !long ? apod.explanation : `${apod.explanation.slice(0, 260).trimEnd()}…`}
              </p>
              {long && (
                <button
                  onClick={() => setExpanded(e => !e)}
                  className="text-[#d9f36a] hover:underline cursor-pointer"
                >
                  {expanded ? 'Show less' : 'Read more'}
                </button>
              )}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/10 text-[10px] text-[#9fb1a6]">
                <span>{apod.copyright ? `Image credit: ${apod.copyright}` : 'Credit: NASA'}</span>
                <span className="flex items-center gap-3">
                  {collected > 0 && <span className="text-[#ffc93c]">REWARDS COLLECTED: {collected}</span>}
                  <a
                    href={isVideo ? apod.url : apod.pageUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[#72d1d6] hover:underline"
                  >
                    {isVideo ? 'Watch video' : 'APOD page'} <ExternalLink size={10} />
                  </a>
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
