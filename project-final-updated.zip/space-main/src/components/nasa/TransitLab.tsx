import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Telescope, Play, Pause, RotateCcw } from 'lucide-react';
import { playTone } from '../../utils/audio';

interface System {
  id: string;
  tab: string;
  star: string;
  planet: string;
  k: number; // Rp / Rs
  b: number; // impact parameter
  aRs: number; // a / Rs
  periodD: number;
  u1: number;
  u2: number;
  color: [number, number, number];
  noisePpm: number;
  rStarRsun: number;
  spots: boolean;
  gasGiant: boolean;
  blurb: string;
}

const SYSTEMS: System[] = [
  {
    id: 'hd209458', tab: 'HD 209458 b', star: 'HD 209458 · Sun-like star (G0V) · 159 ly', planet: 'HD 209458 b “Osiris” – a hot Jupiter',
    k: 0.1207, b: 0.5, aRs: 8.76, periodD: 3.5247, u1: 0.42, u2: 0.22, color: [255, 233, 168], noisePpm: 700, rStarRsun: 1.16, spots: false, gasGiant: true,
    blurb: 'The first exoplanet ever seen crossing its star (1999). Its atmosphere is boiling away, and a 3.5-day year means a transit every few days.',
  },
  {
    id: 'trappist1e', tab: 'TRAPPIST-1 e', star: 'TRAPPIST-1 · Ultracool red dwarf (M8V) · 40 ly', planet: 'TRAPPIST-1 e – a temperate, Earth-size world',
    k: 0.0708, b: 0.1, aRs: 52.8, periodD: 6.1018, u1: 0.66, u2: 0.1, color: [255, 128, 78], noisePpm: 1200, rStarRsun: 0.1192, spots: true, gasGiant: false,
    blurb: 'One of seven rocky planets in a single system, in the star’s habitable zone. The star is barely larger than Jupiter, so even an Earth-sized planet blocks 0.5%.',
  },
  {
    id: 'earth', tab: 'Earth → Sun', star: 'Our Sun (G2V) · seen from afar', planet: 'Earth, as an alien astronomer would see it',
    k: 0.00917, b: 0.0, aRs: 215, periodD: 365.25, u1: 0.4, u2: 0.25, color: [255, 238, 190], noisePpm: 22, rStarRsun: 1.0, spots: true, gasGiant: false,
    blurb: 'A planet like ours dims its star by just 0.008% and takes 13 hours to cross. Detecting it needs an extraordinarily stable space telescope.',
  },
];

const R_EARTH_PER_RSUN = 109.1;
const R_JUP_PER_RSUN = 9.955;

const limb = (mu: number, u1: number, u2: number) => 1 - u1 * (1 - mu) - u2 * (1 - mu) * (1 - mu);

function fluxAt(sys: System, x: number) {
  // numerical integration of limb-darkened light blocked by the planet disk
  const N = 16;
  const k = sys.k;
  let blocked = 0;
  for (let i = 0; i < N; i++) {
    for (let j = 0; j < N; j++) {
      const px = -k + ((i + 0.5) / N) * 2 * k;
      const py = -k + ((j + 0.5) / N) * 2 * k;
      if (px * px + py * py > k * k) continue;
      const sx = x + px, sy = sys.b + py;
      const r2 = sx * sx + sy * sy;
      if (r2 >= 1) continue;
      blocked += limb(Math.sqrt(1 - r2), sys.u1, sys.u2);
    }
  }
  const dA = Math.pow((2 * k) / N, 2);
  const total = Math.PI * (1 - sys.u1 / 3 - sys.u2 / 6);
  return 1 - (blocked * dA) / total;
}

function rng(seed: number) {
  let a = seed;
  return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const gauss = (r: () => number) => Math.sqrt(-2 * Math.log(Math.max(r(), 1e-9))) * Math.cos(2 * Math.PI * r());

function buildStar(sys: System, R: number, dpr: number) {
  const size = Math.ceil((R * 2 + 24) * dpr);
  const cv = document.createElement('canvas');
  cv.width = size; cv.height = size;
  const ctx = cv.getContext('2d')!;
  const img = ctx.createImageData(size, size);
  const c = size / 2, Rp = R * dpr;
  const rnd = rng(sys.tab.length * 97 + 3);
  const spots = sys.spots ? Array.from({ length: 4 }, () => ({ a: rnd() * 6.28, r: Math.sqrt(rnd()) * 0.65, s: 0.015 + rnd() * 0.03 })) : [];
  const n2 = (x: number, y: number) => { const s = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453; return s - Math.floor(s); };
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const dx = (x - c) / Rp, dy = (y - c) / Rp;
      const r2 = dx * dx + dy * dy;
      const i = (y * size + x) * 4;
      if (r2 > 1.2) { img.data[i + 3] = 0; continue; }
      const edge = Math.max(0, Math.min(1, (1 - Math.sqrt(r2)) * Rp * 0.5 + 0.5));
      const mu = Math.sqrt(Math.max(0, 1 - Math.min(r2, 1)));
      let I = limb(mu, sys.u1, sys.u2);
      // granulation
      const g = n2(Math.floor(x / (3 * dpr)), Math.floor(y / (3 * dpr))) * 0.06 + n2(Math.floor(x / (7 * dpr)), Math.floor(y / (7 * dpr))) * 0.05;
      I *= 0.95 + g;
      spots.forEach(sp => {
        const sx = Math.cos(sp.a) * sp.r, sy = Math.sin(sp.a) * sp.r;
        const d = Math.hypot(dx - sx, dy - sy);
        if (d < sp.s * 2) I *= d < sp.s ? 0.35 : 0.7;
      });
      img.data[i] = Math.min(255, sys.color[0] * I * 1.08);
      img.data[i + 1] = Math.min(255, sys.color[1] * I * 1.08);
      img.data[i + 2] = Math.min(255, sys.color[2] * I * 1.08);
      img.data[i + 3] = 255 * edge;
    }
  }
  ctx.putImageData(img, 0, 0);
  return cv;
}

export const TransitLab: React.FC = () => {
  const [sysIdx, setSysIdx] = useState(0);
  const [s, setS] = useState(0.5); // 0..1 progress through the plotted window
  const [playing, setPlaying] = useState(false);
  const sys = SYSTEMS[sysIdx];
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);

  const geo = useMemo(() => {
    const L = Math.sqrt(Math.pow(1 + sys.k, 2) - sys.b * sys.b);
    const durH = ((sys.periodD * 24) / (Math.PI * sys.aRs)) * L;
    const win = durH * 1.5; // hours plotted
    const xAt = (sNorm: number) => ((sNorm - 0.5) * win) / (durH / 2) * L; // stellar radii
    const model = Array.from({ length: 181 }, (_, i) => { const sn = i / 180; return { sn, f: fluxAt(sys, xAt(sn)) }; });
    const minF = Math.min(...model.map(m => m.f));
    const rnd = rng(sysIdx * 31 + 11);
    const data = Array.from({ length: 96 }, (_, i) => { const sn = i / 95; return { sn, f: fluxAt(sys, xAt(sn)) + (gauss(rnd) * sys.noisePpm) / 1e6 }; });
    return { L, durH, win, xAt, model, minF, depth: 1 - minF, data };
  }, [sys, sysIdx]);

  const x = geo.xAt(s);
  const flux = useMemo(() => fluxAt(sys, x), [sys, x]);

  /* playback */
  useEffect(() => {
    if (!playing) return;
    let raf = 0, last = performance.now();
    const loop = (n: number) => {
      const dt = (n - last) / 1000; last = n;
      setS(prev => {
        const nx = prev + dt / 11;
        if (nx >= 1) { setPlaying(false); return 1; }
        return nx;
      });
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [playing]);

  /* star & planet canvas */
  useEffect(() => {
    const cv = canvasRef.current, wrap = wrapRef.current;
    if (!cv || !wrap) return;
    const W = wrap.clientWidth, H = wrap.clientHeight;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    cv.width = W * dpr; cv.height = H * dpr;
    const ctx = cv.getContext('2d')!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const R = Math.min(H * 0.4, W * 0.2);
    const cx = W / 2, cy = H / 2;
    const bg = ctx.createRadialGradient(cx, cy, R * 0.5, cx, cy, Math.max(W, H) * 0.7);
    bg.addColorStop(0, '#07101a'); bg.addColorStop(1, '#010306');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
    // background stars
    const r = rng(5);
    for (let i = 0; i < 90; i++) { ctx.fillStyle = `rgba(255,255,255,${0.15 + r() * 0.5})`; ctx.fillRect(r() * W, r() * H, 1, 1); }
    // corona glow
    const col = sys.color;
    const glow = ctx.createRadialGradient(cx, cy, R * 0.9, cx, cy, R * 2.3);
    glow.addColorStop(0, `rgba(${col[0]},${col[1]},${col[2]},0.45)`); glow.addColorStop(0.4, `rgba(${col[0]},${col[1]},${col[2]},0.1)`); glow.addColorStop(1, `rgba(${col[0]},${col[1]},${col[2]},0)`);
    ctx.fillStyle = glow; ctx.fillRect(0, 0, W, H);
    const star = buildStar(sys, R, dpr);
    ctx.drawImage(star, cx - star.width / 2 / dpr, cy - star.height / 2 / dpr, star.width / dpr, star.height / dpr);
    // planet
    const px = cx + x * R, py = cy + sys.b * R;
    const pr = Math.max(sys.k * R, 1.3);
    if (sys.gasGiant) {
      const ag = ctx.createRadialGradient(px, py, pr * 0.95, px, py, pr * 1.35);
      ag.addColorStop(0, 'rgba(120,180,255,0.5)'); ag.addColorStop(1, 'rgba(120,180,255,0)');
      ctx.fillStyle = ag; ctx.beginPath(); ctx.arc(px, py, pr * 1.35, 0, 6.2832); ctx.fill();
    }
    ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(px, py, pr, 0, 6.2832); ctx.fill();
    ctx.strokeStyle = 'rgba(114,209,214,0.45)'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.arc(px, py, pr + 0.4, 0, 6.2832); ctx.stroke();
    // chord guide
    ctx.setLineDash([3, 5]); ctx.strokeStyle = 'rgba(217,243,106,0.25)'; ctx.beginPath(); ctx.moveTo(cx - R * 1.8, py); ctx.lineTo(cx + R * 1.8, py); ctx.stroke(); ctx.setLineDash([]);
    ctx.font = '10px ui-monospace, monospace'; ctx.fillStyle = 'rgba(207,227,234,0.8)';
    ctx.fillText(sys.k < 0.02 ? 'planet shown to true scale (a speck!)' : 'planet shown to true scale', 12, H - 12);
  }, [sys, x]);

  /* chart geometry */
  const CW = 640, CH = 230, ML = 54, MR = 14, MT = 16, MB = 34;
  const pw = CW - ML - MR, ph = CH - MT - MB;
  const yMax = 1 + geo.depth * 0.45, yMin = 1 - geo.depth * 1.75;
  const X = (sn: number) => ML + sn * pw;
  const Y = (f: number) => MT + ((yMax - f) / (yMax - yMin)) * ph;
  const tHours = (sn: number) => (sn - 0.5) * geo.win;
  const yTicks = [yMax - (yMax - 1) * 0 , 1, 1 - geo.depth, 1 - geo.depth * 1.5];
  const pct = (f: number) => `${((f - 1) * 100).toFixed(geo.depth < 0.001 ? 3 : 2)}%`;
  const visibleData = geo.data.filter(d => d.sn <= s);
  const depthPct = geo.depth * 100;

  const ldFactor = limb(Math.sqrt(1 - sys.b * sys.b), sys.u1, sys.u2) / (1 - sys.u1 / 3 - sys.u2 / 6);
  const kEst = Math.sqrt(geo.depth / ldFactor);
  const rPlanetRsun = kEst * sys.rStarRsun;
  const radiusText = rPlanetRsun * R_JUP_PER_RSUN > 0.6
    ? `${(rPlanetRsun * R_JUP_PER_RSUN).toFixed(2)} Jupiter radii`
    : `${(rPlanetRsun * R_EARTH_PER_RSUN).toFixed(2)} Earth radii`;
  const durText = geo.durH >= 1 ? `${geo.durH.toFixed(1)} hours` : `${Math.round(geo.durH * 60)} min`;

  return (
    <div className="rounded-2xl border border-[#ffc93c]/40 bg-[#07191e] p-4 sm:p-6 space-y-5 shadow-2xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-widest text-[#ffc93c]">
            <Telescope size={14} />
            <span>EXOPLANET DETECTION LAB (KEPLER / TESS TRANSIT METHOD)</span>
          </div>
          <h3 className="font-display font-bold text-2xl sm:text-3xl text-white mt-1">Photometric Light Curve Scanner</h3>
        </div>
        <div className="flex gap-2 flex-wrap">
          {SYSTEMS.map((sy, i) => (
            <button key={sy.id} onClick={() => { playTone(520 + i * 70, 0.08); setSysIdx(i); setS(0); setPlaying(false); }}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-bold cursor-pointer transition-all ${sysIdx === i ? 'bg-[#3a2c08] border-[#ffc93c] text-[#ffc93c]' : 'bg-[#040e12] border-white/10 text-[#9fb1a6] hover:border-white/30'}`}>
              {sy.tab}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-5 space-y-2">
          <div ref={wrapRef} className="relative h-56 sm:h-64 rounded-xl border border-[#1b3834] overflow-hidden bg-black">
            <canvas ref={canvasRef} className="block w-full h-full" role="img" aria-label={`${sys.planet} crossing the face of its star`} />
            <div className="absolute top-2 left-3 text-[10px] font-mono text-[#cfe3ea]/85 tracking-wider">{sys.star}</div>
            <div className="absolute top-2 right-3 bg-black/70 px-2 py-1 rounded text-[10px] font-mono text-[#d9f36a] border border-white/10">
              FLUX <strong className="text-white">{(flux * 100).toFixed(sys.k < 0.02 ? 4 : 3)}%</strong>
            </div>
          </div>
          <p className="text-[11px] text-[#bdc9c0] leading-relaxed">{sys.blurb}</p>
        </div>

        <div className="lg:col-span-7 space-y-2">
          <div className="rounded-xl bg-[#030d12] border border-[#1b3834] p-2">
            <svg viewBox={`0 0 ${CW} ${CH}`} className="w-full h-auto" role="img" aria-label="Light curve: relative brightness of the star over time">
              {yTicks.map((f, i) => (
                <g key={i}>
                  <line x1={ML} x2={CW - MR} y1={Y(f)} y2={Y(f)} stroke="rgba(255,255,255,0.07)" />
                  <text x={ML - 6} y={Y(f) + 3} textAnchor="end" fontSize="9" fill="#9fb1a6" fontFamily="ui-monospace,monospace">{i === 1 ? '100%' : pct(f)}</text>
                </g>
              ))}
              {[0, 0.25, 0.5, 0.75, 1].map(sn => (
                <g key={sn}>
                  <line x1={X(sn)} x2={X(sn)} y1={MT} y2={CH - MB} stroke="rgba(255,255,255,0.05)" />
                  <text x={X(sn)} y={CH - MB + 14} textAnchor={sn === 1 ? 'end' : sn === 0 ? 'start' : 'middle'} fontSize="9" fill="#9fb1a6" fontFamily="ui-monospace,monospace">{tHours(sn) >= 0 ? '+' : ''}{tHours(sn).toFixed(Math.abs(tHours(sn)) < 10 ? 1 : 0)} h</text>
                </g>
              ))}
              <text x={ML + pw / 2} y={CH - 4} textAnchor="middle" fontSize="9" fill="#72d1d6" fontFamily="ui-monospace,monospace">TIME FROM MID-TRANSIT</text>
              <text transform={`translate(11 ${MT + ph / 2}) rotate(-90)`} textAnchor="middle" fontSize="9" fill="#72d1d6" fontFamily="ui-monospace,monospace">STAR BRIGHTNESS</text>
              <path d={geo.model.map((m, i) => `${i ? 'L' : 'M'}${X(m.sn).toFixed(1)} ${Y(m.f).toFixed(1)}`).join('')} fill="none" stroke="rgba(217,243,106,0.35)" strokeWidth="1.4" strokeDasharray="4 3" />
              {visibleData.map((d, i) => <circle key={i} cx={X(d.sn)} cy={Y(d.f)} r="2" fill="#72d1d6" opacity="0.9" />)}
              <line x1={X(s)} x2={X(s)} y1={MT} y2={CH - MB} stroke="#ffc93c" strokeWidth="1" opacity="0.8" />
              <circle cx={X(s)} cy={Y(flux)} r="4" fill="#ffc93c" />
            </svg>
          </div>

          <div className="flex items-center gap-3">
            <button onClick={() => { playTone(600, 0.1); if (s >= 1) setS(0); setPlaying(p => !p); }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#ffc93c] hover:bg-[#ffda66] text-[#061211] font-display font-bold text-xs uppercase tracking-wider cursor-pointer shadow-md">
              {playing ? <Pause size={14} /> : <Play size={14} />}{playing ? 'Pause' : s >= 1 ? 'Replay transit' : 'Simulate transit'}
            </button>
            <button onClick={() => { setPlaying(false); setS(0); }} aria-label="Reset" className="p-2 rounded-lg border border-white/10 text-[#9fb1a6] hover:text-white cursor-pointer"><RotateCcw size={14} /></button>
            <input type="range" min={0} max={1000} value={Math.round(s * 1000)} onChange={e => { setPlaying(false); setS(Number(e.target.value) / 1000); }}
              className="min-w-0 w-full max-w-full flex-1 accent-[#ffc93c]" aria-label="Scrub through the transit" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
        <div className="p-3 rounded-lg bg-[#040e12] border border-white/5"><div className="text-[10px] text-[#9fb1a6]">MEASURED DIP</div><div className="text-base font-bold text-[#ffc93c] mt-0.5">{depthPct.toFixed(depthPct < 0.1 ? 4 : 2)}%</div></div>
        <div className="p-3 rounded-lg bg-[#040e12] border border-white/5"><div className="text-[10px] text-[#9fb1a6]">TRANSIT DURATION</div><div className="text-base font-bold text-white mt-0.5">{durText}</div></div>
        <div className="p-3 rounded-lg bg-[#040e12] border border-white/5"><div className="text-[10px] text-[#9fb1a6]">DERIVED PLANET SIZE</div><div className="text-base font-bold text-[#72d1d6] mt-0.5">≈ {radiusText}</div></div>
        <div className="p-3 rounded-lg bg-[#040e12] border border-white/5"><div className="text-[10px] text-[#9fb1a6]">ORBITAL PERIOD</div><div className="text-base font-bold text-white mt-0.5">{sys.periodD.toLocaleString(undefined, { maximumFractionDigits: 2 })} days</div></div>
      </div>
      <p className="text-xs text-[#bdc9c0] leading-relaxed">
        When a planet crosses between its star and our telescope, it blocks a sliver of starlight. The dip depth is roughly (planet radius ÷ star radius)², so measuring it reveals the planet’s size; the
        rounded floor of the curve comes from <em>limb darkening</em> – the star’s edge is dimmer than its centre. Dots are simulated measurements with realistic noise.
      </p>
    </div>
  );
};
