import React, { useEffect, useMemo, useRef, useState } from 'react';
import { CheckCircle2, ExternalLink, Pause, Play, Radio, SkipBack, SkipForward, XCircle } from 'lucide-react';
import { feature } from 'topojson-client';
import { epicArchivedSample, fetchEpic, IS_DEMO_KEY, type EpicResult } from '../../utils/nasaApi';
import {
  earthDistanceKm,
  formatKm,
  formatLatLon,
  formatUtc,
  lightTimeSeconds,
  measureRotation,
  moonDistanceKm,
  rangeChoices,
  rotationChoices,
  sunDistanceAu,
  type Choice,
} from '../../utils/epic';
import { centreChoices, locateCentre, type CountryFeature, type Located } from '../../utils/epicGeo';
import { playSuccessChime, playTone, playUiClick } from '../../utils/audio';

interface EpicObservationProps {
  /** Called once when every observation task has been answered correctly. */
  onSurveyComplete?: () => void;
}

interface Task {
  id: 'centre' | 'range' | 'rotation';
  title: string;
  prompt: string;
  choices: Choice[];
  /** Frame the question is about (the cadet is taken to it). */
  frameIndex?: number;
  explain: string;
}

const SOURCE_LABEL: Record<EpicResult['source'], string> = {
  'api.nasa.gov': 'LIVE · api.nasa.gov EPIC',
  'epic.gsfc.nasa.gov': 'LIVE · EPIC archive',
  'archived-sample': 'ARCHIVED SAMPLE',
};

export const EpicObservation: React.FC<EpicObservationProps> = ({ onSurveyComplete }) => {
  const [data, setData] = useState<EpicResult | null>(null);
  const [countries, setCountries] = useState<CountryFeature[] | null>(null);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [imageStage, setImageStage] = useState(0); // 0 = EPIC archive, 1 = api.nasa.gov mirror, 2 = unavailable
  const [picked, setPicked] = useState<Record<string, string>>({});
  const [solved, setSolved] = useState<Record<string, boolean>>({});
  const reported = useRef(false);

  // Frames: live if reachable, otherwise a real archived sample, so the mission always has genuine data.
  useEffect(() => {
    let alive = true;
    fetchEpic()
      .then(result => alive && setData(result))
      .catch(() => alive && setData(epicArchivedSample()));
    return () => {
      alive = false;
    };
  }, []);

  // Country outlines (already a project dependency), loaded lazily because only this stage needs them.
  useEffect(() => {
    let alive = true;
    import('world-atlas/countries-110m.json')
      .then(mod => {
        const topo: any = (mod as any).default ?? mod;
        const fc = feature(topo, topo.objects.countries) as unknown as { features: CountryFeature[] };
        if (alive) setCountries(fc.features);
      })
      .catch(() => alive && setCountries([]));
    return () => {
      alive = false;
    };
  }, []);

  const frames = data?.frames ?? [];

  // Start on the newest frame once data arrives.
  useEffect(() => {
    if (frames.length) setIndex(frames.length - 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  useEffect(() => setImageStage(0), [index, data]);

  // Time-lapse
  useEffect(() => {
    if (!playing) return;
    const timer = setInterval(() => {
      setIndex(i => {
        if (i >= frames.length - 1) {
          setPlaying(false);
          return i;
        }
        return i + 1;
      });
    }, 800);
    return () => clearInterval(timer);
  }, [playing, frames.length]);

  // Warm the next frame so scrubbing feels immediate.
  useEffect(() => {
    const next = frames[index + 1];
    if (next) new Image().src = next.imageUrl;
  }, [index, frames]);

  const frame = frames[index];
  const rotation = useMemo(() => measureRotation(frames), [frames]);

  // ---- Tasks, generated from the frames actually returned -------------------------------------
  const tasks = useMemo<Task[]>(() => {
    if (!frames.length) return [];
    const list: Task[] = [];
    const mid = Math.floor(frames.length / 2);
    const order = frames.map((_, i) => i).sort((a, b) => Math.abs(a - mid) - Math.abs(b - mid));

    let target = order[0];
    let located: Located | null = null;
    if (countries && countries.length) {
      for (const i of order) {
        located = locateCentre(frames[i].lat, frames[i].lon, countries);
        if (located) {
          target = i;
          break;
        }
      }
    }

    if (located && countries) {
      const f = frames[target];
      list.push({
        id: 'centre',
        title: 'Locate the centre of the disc',
        prompt: `Go to the frame captured at ${formatUtc(f.capturedMs).slice(11, 19)} UTC. Its centre is at ${formatLatLon(f.lat, f.lon)}. What lies directly under the centre of the disc?`,
        choices: centreChoices(f.lat, f.lon, located, countries, f.identifier),
        frameIndex: target,
        explain: `The disc centre in this frame is ${formatLatLon(f.lat, f.lon)}, which lies over ${located.label}.`,
      });
    }

    const ref = frames[target];
    const km = earthDistanceKm(ref);
    list.push({
      id: 'range',
      title: 'Range check from the spacecraft vector',
      prompt: 'DSCOVR reports its position as a vector from the centre of the Earth. How far from Earth is the spacecraft that took these images?',
      choices: rangeChoices(km, ref.identifier),
      frameIndex: target,
      explain: `Length of this frame's DSCOVR position vector: ${formatKm(km)} km. Radio signals need ${lightTimeSeconds(km).toFixed(1)} s to cross it. DSCOVR sits near the Sun-Earth L1 point, where it always sees Earth's sunlit face.`,
    });

    if (rotation) {
      list.push({
        id: 'rotation',
        title: 'Measure Earth\u2019s rotation',
        prompt: `Over ${rotation.baselineHours.toFixed(1)} hours of frames, the longitude at the centre of the disc drifts ${rotation.direction}. Scrub the time-lapse to see it. How fast does Earth turn?`,
        choices: rotationChoices(frames[0].identifier),
        explain: `Measured from these frames: the disc centre drifts ${rotation.direction} at ${rotation.degPerHour.toFixed(1)}\u00b0 per hour over ${rotation.baselineHours.toFixed(1)} h. That is about 360\u00b0 in 24 hours: one full rotation per day.`,
      });
    }
    return list;
  }, [frames, countries, rotation]);

  const allSolved = tasks.length > 0 && tasks.every(t => solved[t.id]);
  useEffect(() => {
    if (allSolved && !reported.current) {
      reported.current = true;
      onSurveyComplete?.();
    }
  }, [allSolved, onSurveyComplete]);

  const answer = (task: Task, choice: Choice) => {
    if (solved[task.id]) return;
    setPicked(p => ({ ...p, [task.id]: choice.id }));
    if (choice.correct) {
      playSuccessChime();
      setSolved(s => ({ ...s, [task.id]: true }));
    } else {
      playTone(320, 0.15, 'sawtooth');
    }
  };

  if (!data || !frame) {
    return (
      <div className="rounded-2xl border border-[#1b3834] bg-[#0b2025] p-6 text-xs font-mono text-[#9fb1a6]" aria-live="polite">
        Acquiring DSCOVR/EPIC frames…
      </div>
    );
  }

  const isSample = data.source === 'archived-sample';
  const distance = earthDistanceKm(frame);
  const imgSrc = imageStage === 0 ? frame.imageUrl : imageStage === 1 ? frame.mirrorUrl : null;

  return (
    <div className="space-y-5">
      {/* Source banner */}
      <div className="rounded-xl border border-[#72d1d6]/25 bg-gradient-to-r from-[#0a2327] to-[#0b1c20] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-[11px] font-mono font-bold tracking-widest text-[#72d1d6]">
            <Radio size={13} className={isSample ? '' : 'animate-pulse'} />
            PART B · LIVE EARTH DISC · DSCOVR / EPIC
          </div>
          <p className="text-xs text-[#9fb1a6] max-w-2xl leading-relaxed">
            From 1.5 million km away, NASA&rsquo;s EPIC camera sees the whole sunlit Earth. Every frame carries a real
            timestamp and the spacecraft&rsquo;s real position. Use them to complete three observations.
          </p>
        </div>
        <div className="text-[10px] font-mono text-right shrink-0 space-y-0.5">
          <div className={`inline-block px-2 py-1 rounded font-bold ${isSample ? 'bg-[#ffc93c]/15 text-[#ffc93c]' : 'bg-[#66d17a]/15 text-[#66d17a]'}`}>
            {SOURCE_LABEL[data.source]}
            {isSample ? ` · ${frames[0].capturedAt.slice(0, 10)}` : ''}
          </div>
          <div className="text-[#6f8579]">
            {isSample
              ? 'Live feed unreachable; using real archived frames.'
              : `${frames.length} frames · ${frames[0].capturedAt.slice(0, 10)}${IS_DEMO_KEY ? ' · shared demo key' : ''}`}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Viewer */}
        <div className="lg:col-span-2 space-y-3">
          <div className="relative mx-auto w-full max-w-[560px] aspect-square rounded-2xl border-2 border-[#1b3834] bg-black overflow-hidden">
            {imgSrc ? (
              <img
                key={`${frame.identifier}-${imageStage}`}
                src={imgSrc}
                alt={`Full-disc Earth from DSCOVR EPIC, ${formatUtc(frame.capturedMs)}, centred near ${formatLatLon(frame.lat, frame.lon)}`}
                onError={() => setImageStage(s => s + 1)}
                className="w-full h-full object-contain"
              />
            ) : (
              <div className="absolute inset-0 grid place-items-center p-6 text-center text-xs font-mono text-[#9fb1a6]">
                This frame&rsquo;s image couldn&rsquo;t be loaded. Its telemetry on the right is still real.
              </div>
            )}
            <div className="absolute top-3 left-3 rounded-lg bg-[#061211]/80 backdrop-blur px-2.5 py-1.5 border border-white/10 text-[10px] font-mono text-[#eef4e6] pointer-events-none">
              <div>{formatUtc(frame.capturedMs)}</div>
              <div className="text-[#d9f36a]">CENTRE {formatLatLon(frame.lat, frame.lon)}</div>
            </div>
            <div className="absolute bottom-3 right-3 rounded bg-[#061211]/80 px-2 py-1 text-[10px] font-mono text-[#9fb1a6] pointer-events-none">
              FRAME {index + 1} / {frames.length}
            </div>
          </div>

          {/* Scrubber */}
          <div className="rounded-xl border border-[#1b3834] bg-[#0b2025] p-3 flex items-center gap-3">
            <button
              onClick={() => { playUiClick(); setPlaying(false); setIndex(i => Math.max(0, i - 1)); }}
              aria-label="Previous frame"
              disabled={index === 0}
              className="p-1.5 rounded border border-white/10 text-[#bdc9c0] disabled:opacity-30 cursor-pointer"
            >
              <SkipBack size={14} />
            </button>
            <button
              onClick={() => { playUiClick(); if (!playing && index >= frames.length - 1) setIndex(0); setPlaying(p => !p); }}
              aria-label={playing ? 'Pause time-lapse' : 'Play time-lapse'}
              className="p-1.5 rounded bg-[#d9f36a] text-[#061211] cursor-pointer"
            >
              {playing ? <Pause size={14} /> : <Play size={14} />}
            </button>
            <button
              onClick={() => { playUiClick(); setPlaying(false); setIndex(i => Math.min(frames.length - 1, i + 1)); }}
              aria-label="Next frame"
              disabled={index >= frames.length - 1}
              className="p-1.5 rounded border border-white/10 text-[#bdc9c0] disabled:opacity-30 cursor-pointer"
            >
              <SkipForward size={14} />
            </button>
            <input
              type="range"
              min={0}
              max={frames.length - 1}
              value={index}
              onChange={e => { setPlaying(false); setIndex(Number(e.target.value)); }}
              aria-label="Select frame by capture time"
              className="flex-1 accent-[#d9f36a]"
            />
          </div>
        </div>

        {/* Telemetry */}
        <div className="rounded-2xl border border-[#1b3834] bg-[#0b2025] p-4 space-y-3 text-xs font-mono">
          <div className="text-[10px] tracking-widest font-bold text-[#d9f36a]">FRAME TELEMETRY</div>
          {[
            ['CAPTURED', formatUtc(frame.capturedMs)],
            ['DISC CENTRE', formatLatLon(frame.lat, frame.lon)],
            ['DSCOVR → EARTH', `${formatKm(distance)} km`],
            ['LIGHT TIME', `${lightTimeSeconds(distance).toFixed(2)} s`],
            ['EARTH → MOON', `${formatKm(moonDistanceKm(frame))} km`],
            ['EARTH → SUN', `${sunDistanceAu(frame).toFixed(4)} AU`],
          ].map(([k, v]) => (
            <div key={k} className="flex items-baseline justify-between gap-3 border-b border-white/5 pb-1.5">
              <span className="text-[#9fb1a6]">{k}</span>
              <span className="text-[#eef4e6] tabular-nums text-right">{v}</span>
            </div>
          ))}
          {rotation && (
            <div className="rounded-lg bg-[#051113] border border-white/5 p-2.5 text-[#bdc9c0] leading-relaxed">
              <span className="text-[#72d1d6] font-bold">MEASURED ROTATION</span>
              <br />
              {rotation.degPerHour.toFixed(1)}°/h {rotation.direction} over {rotation.baselineHours.toFixed(1)} h
            </div>
          )}
          <a
            href="https://epic.gsfc.nasa.gov/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-[10px] text-[#72d1d6] hover:underline"
          >
            NASA EPIC · image credit NASA / NOAA DSCOVR <ExternalLink size={10} />
          </a>
        </div>
      </div>

      {/* Tasks */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-[11px] font-mono">
          <span className="font-bold tracking-widest text-[#66d17a]">OBSERVATION TASKS</span>
          <span className="text-[#9fb1a6]">
            {tasks.filter(t => solved[t.id]).length} / {tasks.length} LOGGED
          </span>
        </div>

        {tasks.map((task, n) => {
          const done = !!solved[task.id];
          const pickedId = picked[task.id];
          return (
            <div key={task.id} className={`rounded-xl border p-4 space-y-3 ${done ? 'border-[#66d17a]/50 bg-[#0c2a1e]/40' : 'border-[#1b3834] bg-[#0b2025]'}`}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-[10px] font-mono tracking-widest text-[#ef7144] font-bold">TASK {n + 1}</div>
                  <h4 className="font-display font-bold text-sm text-[#eef4e6]">{task.title}</h4>
                </div>
                {done && <CheckCircle2 size={18} className="text-[#66d17a] shrink-0" />}
              </div>
              <p className="text-xs text-[#bdc9c0] leading-relaxed">{task.prompt}</p>
              {task.frameIndex !== undefined && index !== task.frameIndex && !done && (
                <button
                  onClick={() => { playUiClick(); setPlaying(false); setIndex(task.frameIndex!); }}
                  className="text-[11px] font-mono text-[#72d1d6] hover:underline cursor-pointer"
                >
                  → Show me that frame
                </button>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2" role="group" aria-label={`Answers for task ${n + 1}`}>
                {task.choices.map(choice => {
                  const isPicked = pickedId === choice.id;
                  const wrong = isPicked && !choice.correct;
                  const right = done && choice.correct;
                  return (
                    <button
                      key={choice.id}
                      disabled={done}
                      onClick={() => answer(task, choice)}
                      className={`text-left text-xs rounded-lg border px-3 py-2.5 transition-colors cursor-pointer ${
                        right
                          ? 'border-emerald-500 bg-emerald-950/60 text-emerald-200 font-bold'
                          : wrong
                          ? 'border-red-500 bg-red-950/50 text-red-200'
                          : done
                          ? 'border-[#1b3834] bg-[#07191e] text-[#6b7280] opacity-50'
                          : 'border-[#1b3834] bg-[#07191e] text-[#bdc9c0] hover:border-white/25'
                      }`}
                    >
                      <span className="flex items-center justify-between gap-2">
                        <span>{choice.label}</span>
                        {wrong && <XCircle size={14} className="text-red-400 shrink-0" />}
                      </span>
                    </button>
                  );
                })}
              </div>
              <div aria-live="polite" className="text-[11px] font-mono leading-relaxed">
                {done && <p className="text-[#d9f36a]">✓ LOGGED. {task.explain}</p>}
                {!done && pickedId && <p className="text-[#ff9838]">Not quite. Check the telemetry panel and try again.</p>}
              </div>
            </div>
          );
        })}

        {allSolved && (
          <div className="rounded-xl border border-[#d9f36a]/50 bg-[#d9f36a]/10 p-4 text-xs font-mono text-[#d9f36a]" role="status">
            ✓ EARTH DISC SURVEY COMPLETE. You read a real spacecraft&rsquo;s position, located the disc centre, and measured
            Earth&rsquo;s rotation from timestamps.
          </div>
        )}
      </div>
    </div>
  );
};
