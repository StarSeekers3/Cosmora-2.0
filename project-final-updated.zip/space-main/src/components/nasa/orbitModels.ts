/** Mean Earth radius used by the 3D globe projection for satellite altitudes. */
export const EARTH_RADIUS_KM = 6371;
