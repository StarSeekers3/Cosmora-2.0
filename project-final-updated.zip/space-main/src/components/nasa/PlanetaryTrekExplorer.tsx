import React, { useState } from 'react';
import { Moon, Compass, MapPin, Layers, ExternalLink, Activity, Info, Mountain, Eye } from 'lucide-react';
import { playUiClick } from '../../utils/audio';

interface TrekSite {
  id: string;
  body: 'Moon' | 'Mars';
  name: string;
  coords: string;
  elevation: string;
  illumination: string;
  significance: string;
  scientificGoal: string;
  nasaMission: string;
  previewColor: string;
}

const TREK_SITES: TrekSite[] = [
  {
    id: 'shackleton',
    body: 'Moon',
    name: 'Shackleton Crater Rim (Lunar South Pole)',
    coords: '89.9° S, 0.0° E',
    elevation: '+4,200 m (Connecting Ridge)',
    illumination: '86% annual sunlight on peaks (Peaks of Eternal Light)',
    significance: 'Permanently Shadowed Regions (PSRs) at -240°C harboring cold-trapped water ice volatile reservoirs.',
    scientificGoal: 'In-situ Resource Utilization (ISRU): Extract water ice to manufacture cryogenic LOX/LH2 rocket fuel.',
    nasaMission: 'Artemis III / VIPER / Lunar Trailblazer',
    previewColor: '#72d1d6',
  },
  {
    id: 'malapert',
    body: 'Moon',
    name: 'Malapert Mountain (Lunar South Pole)',
    coords: '84.9° S, 12.9° E',
    elevation: '+5,000 m above surrounding terrain',
    illumination: 'High continuous line-of-sight to Earth for direct radio communications.',
    significance: 'Prime location for the Artemis Base Camp high-gain communication relay tower.',
    scientificGoal: 'Long-baseline radio astronomy and continuous solar photovoltaic power collection.',
    nasaMission: 'Artemis Base Camp Surface Assets',
    previewColor: '#d9f36a',
  },
  {
    id: 'jezero-delta',
    body: 'Mars',
    name: 'Jezero Crater Western Fan Delta',
    coords: '18.38° N, 77.58° E',
    elevation: '-2,500 m below Martian datum',
    illumination: '590 W/m² peak equatorial solar flux',
    significance: 'Ancient river delta lakebed deposits with smectite clay and carbonate minerals.',
    scientificGoal: 'Search for preserved micro-fossil biosignatures from Mars’s warm, wet Noachian era (~3.8 Ga).',
    nasaMission: 'Mars 2020 Perseverance Rover',
    previewColor: '#ef7144',
  },
  {
    id: 'olympus-mons',
    body: 'Mars',
    name: 'Olympus Mons Caldera Rim',
    coords: '18.65° N, 226.2° E',
    elevation: '21.9 km above datum (3x Mt. Everest)',
    illumination: 'Above 80% of Martian atmosphere; atmospheric pressure ~0.7 mbar',
    significance: 'The largest shield volcano in the Solar System, spanning 600 km wide.',
    scientificGoal: 'Comparative planetology of planetary heat loss and shield volcanic mantle plumes.',
    nasaMission: 'Mars Reconnaissance Orbiter (HiRISE)',
    previewColor: '#ff9838',
  },
];

export const PlanetaryTrekExplorer: React.FC = () => {
  const [selectedSite, setSelectedSite] = useState<TrekSite>(TREK_SITES[0]);
  const [filterBody, setFilterBody] = useState<'All' | 'Moon' | 'Mars'>('All');

  const filtered = filterBody === 'All' ? TREK_SITES : TREK_SITES.filter(s => s.body === filterBody);

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl bg-gradient-to-r from-[#07191e] via-[#0b242a] to-[#07191e] border border-[#d9f36a]/30">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#d9f36a]/20 border border-[#d9f36a]/40 grid place-items-center text-[#d9f36a]">
            <Compass size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-display font-bold text-base sm:text-lg text-[#eef4e6]">
                NASA Solar System Treks Planetary Cartography
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#d9f36a]/20 text-[#d9f36a] font-bold">
                JPL / MOON &amp; MARS TREK
              </span>
            </div>
            <p className="text-xs text-[#9fb1a6]">
              Interactive terrain elevation, landing site hazards, and mineralogy from Lunar Reconnaissance Orbiter (LRO) and Mars HiRISE.
            </p>
          </div>
        </div>

        {/* Filter controls */}
        <div className="flex items-center gap-1.5 self-end sm:self-center bg-black/40 p-1 rounded-xl border border-white/10">
          {(['All', 'Moon', 'Mars'] as const).map(b => (
            <button
              key={b}
              onClick={() => { playUiClick(); setFilterBody(b); }}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition cursor-pointer ${
                filterBody === b ? 'bg-[#d9f36a] text-[#061211]' : 'text-[#9fb1a6] hover:text-white'
              }`}
            >
              {b}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Sites list on left, detail viewer on right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Sites */}
        <div className="lg:col-span-5 space-y-3">
          {filtered.map(site => {
            const isSelected = selectedSite.id === site.id;
            return (
              <div
                key={site.id}
                onClick={() => { playUiClick(); setSelectedSite(site); }}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'border-[#d9f36a] bg-[#0c2428] shadow-[0_0_20px_rgba(217,243,106,0.15)]'
                    : 'border-white/10 bg-black/30 hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-[10px] px-2 py-0.5 rounded font-bold" style={{ backgroundColor: `${site.previewColor}22`, color: site.previewColor }}>
                    {site.body.toUpperCase()}
                  </span>
                  <span className="text-[#9fb1a6]">{site.coords}</span>
                </div>
                <h4 className="font-display font-bold text-sm sm:text-base text-[#eef4e6] mt-2">
                  {site.name}
                </h4>
                <div className="mt-2 text-xs font-mono text-[#9fb1a6] line-clamp-2">
                  {site.significance}
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Detailed GIS Inspector */}
        <div className="lg:col-span-7 p-6 rounded-2xl bg-black/50 border border-white/10 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-4">
            <div>
              <div className="text-[10px] font-mono text-[#d9f36a] uppercase tracking-wider">
                {selectedSite.body} SURFACE TARGET DOSSIER
              </div>
              <h3 className="font-display font-bold text-xl text-white mt-1">
                {selectedSite.name}
              </h3>
            </div>
            <div className="text-right">
              <span className="text-xs font-mono text-[#72d1d6] font-bold block">
                {selectedSite.coords}
              </span>
              <span className="text-[10px] font-mono text-[#9fb1a6]">
                ELEVATION: {selectedSite.elevation}
              </span>
            </div>
          </div>

          {/* Simulated Planetary Elevation & Thermal Scan Visualizer */}
          <div className="relative h-44 rounded-xl bg-[#040e12] border border-white/10 overflow-hidden flex flex-col justify-between p-4">
            <div className="flex justify-between items-center text-[10px] font-mono text-[#9fb1a6] z-10">
              <span className="flex items-center gap-1 text-[#d9f36a]">
                <Layers size={12} />
                LOLA / HiRISE DTM DIGITAL TERRAIN ELEVATION
              </span>
              <span className="text-white font-bold">1.5m / PIXEL RESOLUTION</span>
            </div>

            {/* Stylized topography elevation contours */}
            <svg viewBox="0 0 400 80" className="w-full h-24 my-auto opacity-75">
              <path
                d="M 0 60 Q 70 30 140 55 T 260 20 T 400 65"
                fill="none"
                stroke={selectedSite.previewColor}
                strokeWidth="2.5"
              />
              <path
                d="M 0 70 Q 60 45 130 65 T 280 40 T 400 75"
                fill="none"
                stroke={selectedSite.previewColor}
                strokeWidth="1.5"
                strokeDasharray="4 4"
                opacity="0.5"
              />
              <circle cx="260" cy="20" r="4" fill="#ffffff" className="animate-ping" />
              <circle cx="260" cy="20" r="3" fill={selectedSite.previewColor} />
            </svg>

            <div className="flex justify-between items-center text-[10px] font-mono text-[#bdc9c0] z-10">
              <span>SOLAR ILLUMINATION: {selectedSite.illumination}</span>
              <span className="text-[#72d1d6]">MISSION: {selectedSite.nasaMission}</span>
            </div>
          </div>

          {/* Details breakdown */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
            <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1">
              <span className="text-[10px] text-[#d9f36a] uppercase font-bold block">
                GEOLOGICAL SIGNIFICANCE
              </span>
              <p className="text-[#bdc9c0] leading-relaxed">
                {selectedSite.significance}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1">
              <span className="text-[10px] text-[#72d1d6] uppercase font-bold block">
                SCIENTIFIC &amp; ISRU OBJECTIVES
              </span>
              <p className="text-[#bdc9c0] leading-relaxed">
                {selectedSite.scientificGoal}
              </p>
            </div>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] font-mono">
            <span className="text-[#9fb1a6]">
              Verified against NASA Moon Trek &amp; Mars Trek GIS standards.
            </span>
            <a
              href={
                selectedSite.body === 'Moon'
                  ? 'https://trek.nasa.gov/moon/'
                  : 'https://trek.nasa.gov/mars/'
              }
              target="_blank"
              rel="noreferrer"
              className="text-[#d9f36a] hover:underline flex items-center gap-1 font-bold"
            >
              <span>LAUNCH OFFICIAL NASA {selectedSite.body.toUpperCase()} TREK GIS</span>
              <ExternalLink size={12} />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
