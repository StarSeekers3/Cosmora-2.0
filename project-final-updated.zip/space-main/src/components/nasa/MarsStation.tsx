import React, { useEffect, useRef, useState } from 'react';
import { Thermometer, Clock } from 'lucide-react';
import { marsEarth, marsLs, marsSeasonNorth, marsTime, perseveranceSol } from '../../utils/astro';
import { playUiClick } from '../../utils/audio';

const LAT = 18.44, LON = 77.45; // Jezero Crater
const OBLIQ = 25.19;
const D2R = Math.PI / 180;
const mix = (a: number[], b: number[], t: number) => a.map((v, i) => v + (b[i] - v) * t);
const sm = (a: number, b: number, x: number) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const rgb = (c: number[], a = 1) => `rgba(${Math.round(c[0])},${Math.round(c[1])},${Math.round(c[2])},${a})`;

function sunGeometry(lmst: number, ls: number) {
  const dec = Math.asin(Math.sin(OBLIQ * D2R) * Math.sin(ls * D2R));
  const h = (lmst - 12) * 15 * D2R;
  const el = Math.asin(Math.sin(LAT * D2R) * Math.sin(dec) + Math.cos(LAT * D2R) * Math.cos(dec) * Math.cos(h));
  return { elev: el / D2R, h, dec };
}

function climate(ls: number, lmst: number) {
  const tmax = -12 + 14 * Math.cos((ls - 150) * D2R);
  const tmin = tmax - 62;
  const mean = (tmax + tmin) / 2, amp = (tmax - tmin) / 2;
  const temp = mean + amp * Math.sin(((lmst - 7.5) / 24) * 2 * Math.PI);
  const pressure = 740 + 38 * Math.cos((ls - 270) * D2R);
  const dust = 0.5 + 0.5 * Math.cos((ls - 250) * D2R);
  const tau = 0.45 + 0.55 * dust;
  const wind = 8 + 16 * Math.max(0, Math.sin(((lmst - 8) / 24) * 2 * Math.PI));
  return { tmax, tmin, temp, pressure, tau, wind };
}

const terrain = (x: number, seed: number, amp: number) =>
  Math.sin(x * 0.011 + seed) * amp + Math.sin(x * 0.027 + seed * 2.1) * amp * 0.5 + Math.sin(x * 0.071 + seed * 3.3) * amp * 0.22;

function drawScene(ctx: CanvasRenderingContext2D, W: number, H: number, lmst: number, ls: number, t: number, tau: number) {
  const { elev, h } = sunGeometry(lmst, ls);
  const hor = H * 0.66;
  // sky palette
  const dayTop = [150, 108, 82], dayHor = [222, 176, 132];
  const twiTop = [44, 52, 86], twiHor = [150, 96, 84];
  const nightTop = [9, 12, 26], nightHor = [40, 30, 42];
  const dust = Math.min(1, tau / 1.2);
  const dTop = mix(dayTop, [168, 124, 96], dust * 0.4), dHor = mix(dayHor, [226, 182, 140], dust * 0.4);
  const k1 = sm(-14, -2, elev), k2 = sm(0, 16, elev);
  const top = mix(mix(nightTop, twiTop, k1), dTop, k2);
  const hz = mix(mix(nightHor, twiHor, k1), dHor, k2);
  const sky = ctx.createLinearGradient(0, 0, 0, hor);
  sky.addColorStop(0, rgb(top)); sky.addColorStop(1, rgb(hz));
  ctx.fillStyle = sky; ctx.fillRect(0, 0, W, hor + 2);

  // stars
  const dark = sm(-3, -14, elev);
  if (dark > 0.02) {
    for (let i = 0; i < 160; i++) {
      const sx = (Math.sin(i * 91.7) * 0.5 + 0.5) * W, sy = (Math.sin(i * 37.3 + 1) * 0.5 + 0.5) * hor * 0.95;
      const tw = 0.6 + 0.4 * Math.sin(t * 1.3 + i);
      ctx.fillStyle = `rgba(255,255,255,${dark * (0.25 + (i % 5) * 0.12) * tw})`;
      ctx.fillRect(sx, sy, 1 + (i % 7 === 0 ? 1 : 0), 1 + (i % 7 === 0 ? 1 : 0));
    }
  }

  // sun
  const sunX = W / 2 + Math.sin(h) * W * 0.46;
  const sunY = hor - (Math.max(elev, -12) / 90) * hor * 0.92 * 1.15;
  if (elev > -10) {
    const twi = sm(12, 0, elev) * sm(-10, -1, elev); // strongest near horizon
    const blueHalo = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, 150 + 120 * twi);
    blueHalo.addColorStop(0, `rgba(120,170,240,${0.55 * twi + 0.05})`); blueHalo.addColorStop(0.4, `rgba(90,130,210,${0.25 * twi})`); blueHalo.addColorStop(1, 'rgba(90,130,210,0)');
    ctx.fillStyle = blueHalo; ctx.fillRect(0, 0, W, hor);
    const warm = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, 110);
    warm.addColorStop(0, `rgba(255,244,214,${0.65 * sm(-4, 8, elev)})`); warm.addColorStop(1, 'rgba(255,230,180,0)');
    ctx.fillStyle = warm; ctx.fillRect(0, 0, W, hor);
    ctx.fillStyle = twi > 0.3 ? 'rgba(220,235,255,0.97)' : 'rgba(255,248,228,0.98)';
    ctx.beginPath(); ctx.arc(sunX, sunY, 6.5, 0, 6.2832); ctx.fill();
  }

  // light amount for terrain
  const light = 0.24 + 0.76 * sm(-8, 24, elev);
  const ground = [150, 84, 52];
  const shade = (c: number[], f: number) => c.map(v => v * f);
  const haze = (c: number[], a: number) => mix(c, hz, a);

  // far crater rim
  ctx.fillStyle = rgb(haze(shade([128, 80, 60], light), 0.55));
  ctx.beginPath(); ctx.moveTo(0, hor + 4);
  for (let x = 0; x <= W; x += 6) ctx.lineTo(x, hor - 6 - Math.abs(terrain(x, 1.3, 16)) - 4 * Math.sin(x * 0.2));
  ctx.lineTo(W, hor + 6); ctx.closePath(); ctx.fill();
  // delta scarp / mid hills
  ctx.fillStyle = rgb(haze(shade([140, 86, 58], light), 0.3));
  ctx.beginPath(); ctx.moveTo(0, hor + 30);
  for (let x = 0; x <= W; x += 5) ctx.lineTo(x, hor + 12 - Math.abs(terrain(x, 4.1, 12)) - 2 + Math.sin(x * 0.4) * 1.2);
  ctx.lineTo(W, hor + 40); ctx.closePath(); ctx.fill();
  // plains
  const pg = ctx.createLinearGradient(0, hor, 0, H);
  pg.addColorStop(0, rgb(haze(shade(ground, light), 0.15))); pg.addColorStop(1, rgb(shade([112, 62, 40], light * 0.95)));
  ctx.fillStyle = pg; ctx.fillRect(0, hor + 8, W, H - hor);

  // dust devil
  if (elev > 12) {
    const cyc = t % 70;
    if (cyc < 36) {
      const dx = ((cyc / 36) * (W + 260)) - 130;
      const base = hor + 34;
      for (let i = 0; i < 22; i++) {
        const f = i / 21;
        const y = base - f * 70;
        const sway = Math.sin(t * 2.2 + f * 5) * 5 * f + f * 14;
        ctx.fillStyle = `rgba(210,160,120,${0.2 * (1 - f * 0.7)})`;
        ctx.beginPath(); ctx.ellipse(dx + sway, y, 4 + f * 16, 3 + f * 5, 0, 0, 6.2832); ctx.fill();
      }
    }
  }

  // rocks + shadows
  const sunSide = Math.sign(sunX - W / 2) || 1;
  const shadowLen = elev > 2 ? Math.min(46, 70 / Math.tan(Math.max(elev, 5) * D2R) * 0.35) : 0;
  for (let i = 0; i < 46; i++) {
    const rx = (Math.sin(i * 12.9) * 0.5 + 0.5) * W, f = (Math.sin(i * 7.7 + 2) * 0.5 + 0.5);
    const ry = hor + 46 + f * (H - hor - 52);
    const size = 2 + f * 11;
    if (shadowLen > 0) { ctx.fillStyle = `rgba(30,12,8,${0.35 * light})`; ctx.beginPath(); ctx.ellipse(rx - sunSide * shadowLen * (size / 12), ry + size * 0.45, size * 1.6 + shadowLen * 0.5 * (size / 12), size * 0.35, 0, 0, 6.2832); ctx.fill(); }
    ctx.fillStyle = rgb(shade([96 + (i % 5) * 8, 58 + (i % 4) * 6, 42], light * (0.8 + f * 0.3)));
    ctx.beginPath(); ctx.ellipse(rx, ry, size, size * 0.62, 0, 0, 6.2832); ctx.fill();
    ctx.fillStyle = `rgba(255,214,170,${0.18 * light * (elev > 0 ? 1 : 0)})`;
    ctx.beginPath(); ctx.ellipse(rx + sunSide * size * 0.25, ry - size * 0.2, size * 0.5, size * 0.22, 0, 0, 6.2832); ctx.fill();
  }

  // Perseverance silhouette
  const rx = W * 0.18, ry = H * 0.9, sc = Math.max(0.8, W / 900);
  ctx.save(); ctx.translate(rx, ry); ctx.scale(sc, sc);
  const body = rgb(shade([60, 52, 50], 0.35 + light * 0.65)), rim = `rgba(255,220,180,${0.55 * light})`;
  ctx.fillStyle = 'rgba(20,8,5,0.35)'; ctx.beginPath(); ctx.ellipse(0, 6, 62, 6, 0, 0, 6.2832); ctx.fill();
  ctx.fillStyle = body;
  ctx.fillRect(-34, -34, 68, 24);                     // chassis
  ctx.fillRect(-48, -26, 14, 12);                     // RTG
  ctx.fillRect(34, -30, 18, 8);                       // arm turret
  ctx.fillRect(14, -66, 3, 34);                       // mast
  ctx.fillRect(6, -76, 20, 10);                       // camera head
  ctx.fillRect(-18, -50, 22, 4);                      // high-gain antenna
  [-34, -18, 0, 18, 34].forEach((wx, i) => { ctx.beginPath(); ctx.arc(wx + (i === 0 ? -2 : i === 4 ? 2 : 0), -4, 9, 0, 6.2832); ctx.fill(); });
  ctx.strokeStyle = body; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-34, -14); ctx.lineTo(-30, -4); ctx.moveTo(34, -14); ctx.lineTo(32, -4); ctx.stroke();
  ctx.strokeStyle = rim; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-34, -34); ctx.lineTo(34, -34); ctx.moveTo(6, -76); ctx.lineTo(26, -76); ctx.stroke();
  ctx.restore();

  // foreground haze + vignette
  const v = ctx.createRadialGradient(W / 2, H / 2, H * 0.4, W / 2, H / 2, W * 0.65);
  v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.5)');
  ctx.fillStyle = v; ctx.fillRect(0, 0, W, H);
  return elev;
}

const fmtClock = (h: number) => { const hh = Math.floor(h) % 24, mm = Math.floor((h - Math.floor(h)) * 60); return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`; };

export const MarsStation: React.FC = () => {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [timelapse, setTimelapse] = useState(false);
  const tlRef = useRef(false);
  const [hud, setHud] = useState(() => {
    const d = new Date();
    return { lmst: marsTime(d, LON).lmst, elev: 0, ls: marsLs(d), sol: perseveranceSol(d) };
  });
  tlRef.current = timelapse;

  useEffect(() => {
    const wrap = wrapRef.current, canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    const ctx = canvas.getContext('2d')!;
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    let raf = 0, last = 0, visible = true, lastHud = 0;
    let tlOffset = 0, tlStart = 0;
    const baseDate = new Date();
    const ls = marsLs(baseDate);
    const tau = climate(ls, 12).tau;
    const frame = (now: number) => {
      raf = 0;
      if (!reduce && now - last < 45) { raf = requestAnimationFrame(frame); return; }
      last = now;
      const W = wrap.clientWidth, H = wrap.clientHeight, dpr = Math.min(window.devicePixelRatio || 1, 2);
      if (canvas.width !== Math.round(W * dpr)) { canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr); }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      let lmst = marsTime(new Date(), LON).lmst;
      if (tlRef.current) { if (!tlStart) { tlStart = now; tlOffset = lmst; } lmst = (tlOffset + ((now - tlStart) / 1000) * 0.8) % 24; } else tlStart = 0;
      const elev = drawScene(ctx, W, H, lmst, ls, now / 1000, tau);
      if (now - lastHud > 500) { lastHud = now; setHud({ lmst, elev, ls, sol: perseveranceSol(new Date()) }); }
      if (!reduce && visible && !document.hidden) raf = requestAnimationFrame(frame);
    };
    const kick = () => { if (!raf) raf = requestAnimationFrame(frame); };
    kick();
    const ro = new ResizeObserver(() => { if (reduce) { cancelAnimationFrame(raf); raf = 0; } kick(); });
    ro.observe(wrap);
    const io = new IntersectionObserver(e => { visible = e[0]?.isIntersecting ?? true; if (visible) kick(); });
    io.observe(wrap);
    const vis = () => { if (!document.hidden) kick(); };
    document.addEventListener('visibilitychange', vis);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); io.disconnect(); document.removeEventListener('visibilitychange', vis); };
  }, []);

  const c = climate(hud.ls, hud.lmst);
  const me = marsEarth(new Date());
  const uvi = Math.max(0, 11 * Math.sin(Math.max(hud.elev, 0) * D2R) * (1 - 0.25 * Math.min(1, c.tau / 1.2)));
  const uvLabel = uvi < 0.5 ? 'NONE (night)' : uvi < 3 ? 'LOW' : uvi < 6 ? 'MODERATE' : uvi < 8 ? 'HIGH' : 'VERY HIGH';
  const phase = hud.elev > 6 ? 'Daytime' : hud.elev > -6 ? (hud.lmst < 12 ? 'Sunrise' : 'Sunset') : 'Night';
  const clarity = c.tau < 0.6 ? 'Clear, butterscotch sky with high water-ice clouds possible' : c.tau < 0.9 ? 'Moderately dusty sky with a hazy horizon' : 'Dusty season – reduced visibility and a strongly hazy sky';

  return (
    <div className="rounded-2xl border border-[#ef7144]/40 bg-[#07191e] p-4 sm:p-6 space-y-5 shadow-2xl">
      <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-widest text-[#ef7144]">
            <Thermometer size={14} />
            <span>JEZERO CRATER · MARS PERSEVERANCE ROVER</span>
          </div>
          <h3 className="font-display font-bold text-xl sm:text-2xl text-white mt-1">Mars Surface Weather Station</h3>
        </div>
        <span className="text-xs font-mono bg-[#ef7144]/20 text-[#ef7144] px-2.5 py-1 rounded font-bold whitespace-nowrap">SOL {hud.sol.toLocaleString()}</span>
      </div>

      <div ref={wrapRef} className="relative h-[240px] sm:h-[300px] rounded-xl overflow-hidden border border-[#3a2418] bg-black">
        <canvas ref={canvasRef} className="block w-full h-full" role="img" aria-label="Illustration of the Martian sky and horizon at Jezero Crater for the current local time" />
        <div className="pointer-events-none absolute top-3 left-3 text-[10px] font-mono tracking-widest text-white/90 space-y-0.5">
          <div className="flex items-center gap-1.5"><Clock size={11} className="text-[#ffc93c]" />LOCAL MEAN SOLAR TIME {fmtClock(hud.lmst)}</div>
          <div className="text-[#e8c9b0]/85">{phase.toUpperCase()} · SUN {hud.elev.toFixed(0)}° {hud.elev >= 0 ? 'ABOVE' : 'BELOW'} HORIZON</div>
        </div>
        <button onClick={() => { playUiClick(); setTimelapse(v => !v); }}
          className={`absolute top-3 right-3 px-2.5 py-1.5 rounded-lg border text-[10px] font-mono font-bold cursor-pointer ${timelapse ? 'border-[#ffc93c] bg-[#3a2c08]/90 text-[#ffc93c]' : 'border-white/20 bg-black/60 text-[#cfe3ea] hover:border-white/40'}`}>
          {timelapse ? '■ LIVE TIME' : '▶ SOL TIME-LAPSE'}
        </button>
        <div className="pointer-events-none absolute bottom-3 right-3 text-[9px] font-mono text-[#e8c9b0]/80 bg-black/50 px-2 py-1 rounded border border-white/10">
          EARTH {me.au.toFixed(2)} AU · {me.lightMinutes.toFixed(1)} LIGHT-MIN AWAY
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 text-xs font-mono">
        <div className="p-3.5 rounded-xl bg-[#040e12] border border-white/5">
          <div className="text-[10px] text-[#9fb1a6]">AIR TEMPERATURE NOW</div>
          <div className="text-xl font-bold text-[#ffc93c] mt-1">{c.temp.toFixed(0)}°C</div>
          <div className="text-[10px] text-[#bdc9c0] mt-0.5">today ≈ {c.tmin.toFixed(0)}° to {c.tmax.toFixed(0)}°C</div>
        </div>
        <div className="p-3.5 rounded-xl bg-[#040e12] border border-white/5">
          <div className="text-[10px] text-[#9fb1a6]">ATMOSPHERIC PRESSURE</div>
          <div className="text-xl font-bold text-[#d9f36a] mt-1">≈ {Math.round(c.pressure)} Pa</div>
          <div className="text-[10px] text-[#bdc9c0] mt-0.5">&lt; 1% of Earth sea level</div>
        </div>
        <div className="p-3.5 rounded-xl bg-[#040e12] border border-white/5">
          <div className="text-[10px] text-[#9fb1a6]">SURFACE WIND</div>
          <div className="text-xl font-bold text-white mt-1">≈ {Math.round(c.wind)} km/h</div>
          <div className="text-[10px] text-[#bdc9c0] mt-0.5">afternoon gusts and dust devils</div>
        </div>
        <div className="p-3.5 rounded-xl bg-[#040e12] border border-white/5">
          <div className="text-[10px] text-[#9fb1a6]">UV INDEX (OPEN SKY)</div>
          <div className="text-xl font-bold text-[#72d1d6] mt-1">{uvi.toFixed(1)} · {uvLabel}</div>
          <div className="text-[10px] text-[#bdc9c0] mt-0.5">no ozone layer to filter UV</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 text-xs font-mono">
        <div className="p-3 rounded-xl bg-[#12252a] border border-[#ef7144]/30">
          <div className="text-[#ef7144] font-bold text-[10px]">SEASON · SOLAR LONGITUDE</div>
          <div className="text-white mt-0.5">{marsSeasonNorth(hud.ls)} · Ls {hud.ls.toFixed(0)}°</div>
        </div>
        <div className="p-3 rounded-xl bg-[#12252a] border border-[#ef7144]/30">
          <div className="text-[#ef7144] font-bold text-[10px]">DUST OPTICAL DEPTH (τ)</div>
          <div className="text-white mt-0.5">{c.tau.toFixed(2)}</div>
        </div>
      </div>
      <p className="text-xs text-[#bdc9c0] leading-relaxed">
        <span className="text-[#ef7144] font-bold">ATMOSPHERIC OPTICAL DENSITY:</span> {clarity}. Sol number, season and local time are calculated from Mars orbital mechanics for Jezero (18.4°N, 77.5°E);
        temperature, pressure, wind and dust are a <em>seasonal climatology model</em> in the range reported by the rover’s MEDA instrument – not live rover data. On Mars the sky turns blue around the setting Sun.
      </p>
    </div>
  );
};
