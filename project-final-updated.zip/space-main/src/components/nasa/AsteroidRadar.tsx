import React, { useEffect, useMemo, useState } from 'react';
import { ShieldAlert } from 'lucide-react';

interface Neo {
  id: string;
  name: string;
  dMin: number;
  dMax: number;
  when: string;
  velKmh: number | null;
  missKm: number;
  pha: boolean;
  note?: string;
}

const LD_KM = 384400;

const CURATED: Neo[] = [
  { id: 'apophis', name: '99942 Apophis', dMin: 310, dMax: 340, when: '13 Apr 2029', velKmh: 26700, missKm: 38000, pha: true, note: 'Passes ~32,000 km above Earth’s surface – closer than geostationary satellites. NASA: no impact risk for at least 100 years.' },
  { id: 'bennu', name: '101955 Bennu', dMin: 480, dMax: 500, when: 'Sep 2060', velKmh: null, missKm: 750000, pha: true, note: 'Sampled by OSIRIS-REx. Closest known approach this century is ~1.9 lunar distances.' },
  { id: 'florence', name: '3122 Florence', dMin: 4000, dMax: 4900, when: '1 Sep 2017 (past)', velKmh: 48700, missKm: 7060000, pha: true, note: 'Among the largest near-Earth asteroids to pass this close.' },
  { id: 'duende', name: '367943 Duende (2012 DA14)', dMin: 30, dMax: 40, when: '15 Feb 2013 (past)', velKmh: 28100, missKm: 34100, pha: false, note: 'Passed inside the geostationary belt the same day the Chelyabinsk meteor struck.' },
];

const hashAngle = (s: string) => { let h = 7; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 3600; return (h / 3600) * Math.PI * 2; };
const fmtMiss = (km: number) => `${km.toLocaleString(undefined, { maximumFractionDigits: 0 })} km · ${(km / LD_KM).toFixed(km < LD_KM ? 2 : 1)} LD`;

export const AsteroidRadar: React.FC = () => {
  const [neos, setNeos] = useState<Neo[]>(CURATED);
  const [live, setLive] = useState<'loading' | 'live' | 'curated'>('loading');
  const [hover, setHover] = useState<string | null>(null);

  useEffect(() => {
    let stop = false;
    const ctl = new AbortController();
    const to = setTimeout(() => ctl.abort(), 6000);
    const start = new Date();
    const end = new Date(start.getTime() + 6 * 86400000);
    const f = (d: Date) => d.toISOString().substring(0, 10);
    fetch(`https://api.nasa.gov/neo/rest/v1/feed?start_date=${f(start)}&end_date=${f(end)}&api_key=DEMO_KEY`, { signal: ctl.signal })
      .then(r => { if (!r.ok) throw new Error(String(r.status)); return r.json(); })
      .then(j => {
        if (stop) return;
        const list: Neo[] = [];
        Object.values(j.near_earth_objects as Record<string, any[]>).forEach(day => day.forEach(o => {
          const ca = o.close_approach_data?.[0];
          if (!ca) return;
          list.push({
            id: String(o.id),
            name: String(o.name).replace(/[()]/g, '').trim(),
            dMin: o.estimated_diameter.meters.estimated_diameter_min,
            dMax: o.estimated_diameter.meters.estimated_diameter_max,
            when: String(ca.close_approach_date_full ?? ca.close_approach_date),
            velKmh: Number(ca.relative_velocity.kilometers_per_hour),
            missKm: Number(ca.miss_distance.kilometers),
            pha: !!o.is_potentially_hazardous_asteroid,
          });
        }));
        if (list.length) { list.sort((a, b) => a.missKm - b.missKm); setNeos(list.slice(0, 7)); setLive('live'); } else setLive('curated');
      })
      .catch(() => { if (!stop) setLive('curated'); })
      .finally(() => clearTimeout(to));
    return () => { stop = true; ctl.abort(); clearTimeout(to); };
  }, []);

  const S = 360, C = S / 2, Rmax = 160;
  const dMinLd = 0.05, dMaxLd = 200;
  const rOf = (km: number) => Rmax * Math.log((Math.max(km / LD_KM, dMinLd)) / dMinLd) / Math.log(dMaxLd / dMinLd);
  const rings = [{ ld: 0.11, label: 'GEO' }, { ld: 1, label: 'MOON' }, { ld: 10, label: '10 LD' }, { ld: 100, label: '100 LD' }];
  const dots = useMemo(() => neos.map(n => {
    const r = Math.min(Rmax - 4, rOf(n.missKm));
    const a = hashAngle(n.id + n.name);
    return { n, x: C + Math.cos(a) * r, y: C + Math.sin(a) * r, sz: 3 + Math.min(7, Math.log10(Math.max(n.dMax, 10)) * 1.7) };
  }), [neos]);

  return (
    <div className="rounded-2xl border border-[#ffc93c]/40 bg-[#07191e] p-4 sm:p-6 space-y-4 shadow-2xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-widest text-[#ffc93c]">
            <ShieldAlert size={14} />
            <span>NASA JPL CENTER FOR NEAR EARTH OBJECT STUDIES</span>
          </div>
          <h3 className="font-display font-bold text-xl sm:text-2xl text-white mt-1">Asteroid Watch & Planetary Defense</h3>
        </div>
        <span className={`text-[10px] font-mono font-bold px-2.5 py-1.5 rounded-lg border whitespace-nowrap ${live === 'live' ? 'text-[#66a75e] border-[#66a75e]/50 bg-[#0d2418]' : live === 'loading' ? 'text-[#9fb1a6] border-white/10' : 'text-[#ffc93c] border-[#ffc93c]/40 bg-[#2a2208]'}`}>
          {live === 'live' ? '● LIVE · NASA NeoWs · NEXT 7 DAYS' : live === 'loading' ? 'CONTACTING NASA…' : 'CURATED HIGHLIGHTS · live feed unreachable'}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
        <div className="md:col-span-5 relative rounded-xl bg-[#020910] border border-[#1b3834] overflow-hidden">
          <svg viewBox={`0 0 ${S} ${S}`} className="w-full h-auto" role="img" aria-label="Radar chart of asteroid close-approach distances on a logarithmic scale">
            <defs>
              <radialGradient id="radarBg"><stop offset="0%" stopColor="#0c2b2f" /><stop offset="100%" stopColor="#020910" /></radialGradient>
              <linearGradient id="sweep" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="#d9f36a" stopOpacity="0" /><stop offset="100%" stopColor="#d9f36a" stopOpacity="0.35" /></linearGradient>
              <style>{`@keyframes radarSweep{to{transform:rotate(360deg)}} .rsw{transform-origin:${C}px ${C}px;animation:radarSweep 7s linear infinite} @media (prefers-reduced-motion: reduce){.rsw{animation:none}}`}</style>
            </defs>
            <circle cx={C} cy={C} r={Rmax + 10} fill="url(#radarBg)" />
            {rings.map(r => (
              <g key={r.label}>
                <circle cx={C} cy={C} r={rOf(r.ld * LD_KM)} fill="none" stroke={r.label === 'MOON' ? 'rgba(200,210,220,0.5)' : 'rgba(114,209,214,0.22)'} strokeDasharray={r.label === 'GEO' ? '2 3' : undefined} />
                <text x={C + 4} y={C - rOf(r.ld * LD_KM) - 3} fontSize="8" fill="#9fb1a6" fontFamily="ui-monospace,monospace">{r.label}</text>
              </g>
            ))}
            <line x1={C} y1={C - Rmax - 8} x2={C} y2={C + Rmax + 8} stroke="rgba(114,209,214,0.12)" />
            <line x1={C - Rmax - 8} y1={C} x2={C + Rmax + 8} y2={C} stroke="rgba(114,209,214,0.12)" />
            <g className="rsw"><path d={`M${C} ${C} L${C + Rmax + 8} ${C} A${Rmax + 8} ${Rmax + 8} 0 0 0 ${C + (Rmax + 8) * Math.cos(-0.7)} ${C + (Rmax + 8) * Math.sin(-0.7)} Z`} fill="url(#sweep)" /></g>
            <circle cx={C} cy={C} r="7" fill="#2f7fd0" /><circle cx={C} cy={C} r="7" fill="none" stroke="#9fd0ff" strokeOpacity="0.6" />
            <circle cx={C + rOf(LD_KM)} cy={C} r="2.5" fill="#cfd6dc" />
            {dots.map(d => (
              <g key={d.n.id} onMouseEnter={() => setHover(d.n.id)} onMouseLeave={() => setHover(null)} style={{ cursor: 'pointer' }}>
                <circle cx={d.x} cy={d.y} r={d.sz + 5} fill={d.n.pha ? 'rgba(239,113,68,0.15)' : 'rgba(217,243,106,0.12)'} />
                <circle cx={d.x} cy={d.y} r={hover === d.n.id ? d.sz + 2 : d.sz} fill={d.n.pha ? '#ef7144' : '#d9f36a'} stroke="#fff" strokeOpacity={hover === d.n.id ? 0.9 : 0.3} />
              </g>
            ))}
          </svg>
          <div className="absolute bottom-2 left-3 text-[9px] font-mono text-[#9fb1a6]">LOG SCALE · 1 LD = Earth–Moon distance (384,400 km)</div>
        </div>

        <div className="md:col-span-7 space-y-2 md:max-h-[560px] md:overflow-y-auto pr-1">
          {neos.map(n => (
            <div key={n.id} onMouseEnter={() => setHover(n.id)} onMouseLeave={() => setHover(null)}
              className={`p-3 rounded-xl bg-[#040e12] border transition-colors space-y-1 text-xs font-mono ${hover === n.id ? 'border-[#ffc93c]/70' : 'border-white/5'}`}>
              <div className="flex items-center justify-between gap-2">
                <span className="font-display font-bold text-sm text-white">{n.name}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded font-bold whitespace-nowrap ${n.pha ? 'bg-orange-950/60 text-orange-300 border border-orange-800' : 'bg-green-950/60 text-green-400 border border-green-800'}`} title="PHA = Potentially Hazardous Asteroid: large enough and passes close enough to be monitored. It is not a prediction of impact.">
                  {n.pha ? 'MONITORED · PHA' : 'NO CONCERN'}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[11px] text-[#bdc9c0] pt-1">
                <div>Approach: <span className="text-white">{n.when}</span></div>
                <div>Diameter: <span className="text-[#ffc93c]">{Math.round(n.dMin).toLocaleString()}–{Math.round(n.dMax).toLocaleString()} m</span></div>
                <div>Miss distance: <span className="text-[#72d1d6]">{fmtMiss(n.missKm)}</span></div>
                <div>Velocity: <span className="text-white">{n.velKmh ? `${Math.round(n.velKmh).toLocaleString()} km/h` : '—'}</span></div>
              </div>
              {n.note && <p className="text-[11px] text-[#9fb1a6] font-sans leading-snug pt-0.5">{n.note}</p>}
            </div>
          ))}
        </div>
      </div>
      <p className="text-[11px] text-[#9fb1a6] leading-relaxed">
        Distances are measured from Earth’s centre. “PHA” means an asteroid is big and close enough to be tracked carefully – it does <strong className="text-white">not</strong> mean an impact is predicted. NASA’s planetary-defence mission DART proved in 2022 that a spacecraft can nudge an asteroid’s orbit.
      </p>
    </div>
  );
};
