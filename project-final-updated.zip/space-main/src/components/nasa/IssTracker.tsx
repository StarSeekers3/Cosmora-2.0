import React, { useEffect, useRef, useState } from 'react';
import { Satellite, Globe, Map as MapIcon, Orbit } from 'lucide-react';
import { geoPath, geoNaturalEarth1, geoOrthographic, geoCircle, geoGraticule10, geoDistance } from 'd3-geo';
import { feature, mesh } from 'topojson-client';
import world from 'world-atlas/countries-50m.json';
import { IssAnchor, issPropagate, simulatedIssAnchor, subsolarPoint, ISS_PERIOD_S } from '../../utils/astro';
import { degreesLat, degreesLong, eciToGeodetic, gstime, json2satrec, propagate, type OMMJsonObject, type SatRec } from 'satellite.js';
import { EARTH_RADIUS_KM } from './orbitModels';
import { playUiClick } from '../../utils/audio';

/* eslint-disable @typescript-eslint/no-explicit-any */
const topo: any = world;
const LAND: any = feature(topo, topo.objects.land);
const BORDERS: any = mesh(topo, topo.objects.countries, (a: any, b: any) => a !== b);
const GRATICULE: any = geoGraticule10();
const INCLINATION_LIMITS: any = {
  type: 'MultiLineString',
  coordinates: [51.6, -51.6].map(lat => Array.from({ length: 73 }, (_, i) => [-180 + i * 5, lat])),
};

const D2R = Math.PI / 180;
const R2D = 180 / Math.PI;
function bearingBetween(from: { lat: number; lon: number }, to: { lat: number; lon: number }) {
  const p1 = from.lat * D2R, p2 = to.lat * D2R;
  const dLon = (((to.lon - from.lon + 540) % 360) - 180) * D2R;
  const y = Math.sin(dLon) * Math.cos(p2);
  const x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dLon);
  return (Math.atan2(y, x) * R2D + 360) % 360;
}
const compassLabel = (heading: number) => ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.round(heading / 45) % 8];

const CITIES: [number, number][] = [
  [40.7, -74.0], [34.05, -118.2], [19.4, -99.1], [-23.55, -46.6], [-34.6, -58.4], [-12.05, -77.0], [4.7, -74.1], [43.7, -79.4], [41.9, -87.6],
  [51.5, -0.13], [48.85, 2.35], [40.4, -3.7], [52.5, 13.4], [41.9, 12.5], [55.75, 37.6], [41.0, 28.97], [30.04, 31.24], [6.5, 3.4], [-1.29, 36.8],
  [-26.2, 28.05], [-4.3, 15.3], [24.7, 46.7], [35.7, 51.4], [24.86, 67.0], [28.6, 77.2], [19.07, 72.9], [22.57, 88.36], [23.8, 90.4], [13.75, 100.5],
  [-6.2, 106.8], [1.35, 103.8], [14.6, 121.0], [22.3, 114.2], [31.2, 121.5], [39.9, 116.4], [37.57, 126.98], [35.7, 139.7], [-33.9, 151.2],
  [-37.8, 145.0], [-36.85, 174.76], [31.5, 74.3], [49.3, -123.1], [32.8, -96.8], [25.8, -80.2], [29.8, -95.4], [-33.45, -70.67], [33.6, -7.6],
  [9.0, 38.7], [25.2, 55.3], [33.3, 44.4], [50.45, 30.5], [59.3, 18.07], [45.5, -73.6], [6.9, 79.9], [-1.3, 36.8], [5.6, -0.2], [35.2, -80.8],
];

const STATIONS = [
  { name: 'GOLDSTONE', lat: 35.43, lon: -116.89 },
  { name: 'MADRID', lat: 40.43, lon: -4.25 },
  { name: 'CANBERRA', lat: -35.4, lon: 148.98 },
];

type Source = 'live' | 'stale' | 'simulated';
type Mode = 'map' | 'globe';
type LiveTelemetry = { alt: number; vel: number; vis: string; heading: number | null; direction: 'NORTHBOUND' | 'SOUTHBOUND' };
type OrbitFeed = { group: 'STARLINK' | 'HUBBLE'; source: string; fetchedAt: string; total: number; plotted: number; elements: OMMJsonObject[] };
type LiveSatellite = { name: string; satrec: SatRec; periodMinutes: number };
type GroundPosition = { lat: number; lon: number; altKm: number };

const orbitFeedCacheKey = (group: OrbitFeed['group']) => `cosmora:gp:${group}:v1`;
function makeLiveSatellite(omm: OMMJsonObject): LiveSatellite | null {
  try {
    const satrec = json2satrec(omm);
    const periodMinutes = 1440 / Number(omm.MEAN_MOTION);
    if (!Number.isFinite(periodMinutes) || periodMinutes <= 0) return null;
    return { name: omm.OBJECT_NAME, satrec, periodMinutes };
  } catch {
    return null;
  }
}

function propagateGroundPosition(satrec: SatRec, timeMs: number): GroundPosition | null {
  const date = new Date(timeMs);
  const state = propagate(satrec, date);
  if (!state?.position || !Number.isFinite(state.position.x)) return null;
  const geodetic = eciToGeodetic(state.position, gstime(date));
  return {
    lat: degreesLat(geodetic.latitude),
    lon: degreesLong(geodetic.longitude),
    altKm: geodetic.height,
  };
}

const sunlitAt = (lat: number, lon: number, t: number) => {
  const sun = subsolarPoint(new Date(t));
  const theta = geoDistance([lon, lat], [sun.lon, sun.lat]) * R2D;
  return theta < 110.3; // cylindrical Earth-shadow test for a ~420 km orbit
};

/** Minutes until the ISS next crosses into/out of sunlight (orbital sunrise/sunset). */
function nextTerminator(anchor: IssAnchor, now: number) {
  const p0 = issPropagate(anchor, now);
  const start = sunlitAt(p0.lat, p0.lon, now);
  for (let m = 1; m <= 100; m++) {
    const t = now + m * 60000;
    const p = issPropagate(anchor, t);
    if (sunlitAt(p.lat, p.lon, t) !== start) return { minutes: m, sunrise: !start, sunlit: start };
  }
  return { minutes: 0, sunrise: false, sunlit: start };
}

function mulberry(seed: number) {
  let a = seed;
  return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

export const IssTracker: React.FC = () => {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mode, setMode] = useState<Mode>('map');
  const [showHubble, setShowHubble] = useState(true);
  const [showStarlink, setShowStarlink] = useState(true);
  const [hubbleRecords, setHubbleRecords] = useState<LiveSatellite[]>([]);
  const [starlinkRecords, setStarlinkRecords] = useState<LiveSatellite[]>([]);
  const [orbitFeedStatus, setOrbitFeedStatus] = useState({ hubble: 'loading', starlink: 'loading' });
  const [orbitFeedMeta, setOrbitFeedMeta] = useState({ hubble: '', starlink: '' });
  const modeRef = useRef<Mode>('map');
  const satelliteLayersRef = useRef({ hubble: true, starlink: true, hubbleRecords: [] as LiveSatellite[], starlinkRecords: [] as LiveSatellite[] });
  const [source, setSource] = useState<Source>('simulated');
  const anchorRef = useRef<IssAnchor>(simulatedIssAnchor(Date.now()));
  const liveRef = useRef<LiveTelemetry | null>(null);
  const [ro, setRo] = useState({ lat: 0, lon: 0, alt: 419, vel: 27600, vis: '—', mins: 0, sunrise: false, utc: '', heading: 0, direction: 'NORTHBOUND', age: 0 });
  modeRef.current = mode;
  satelliteLayersRef.current = { hubble: showHubble, starlink: showStarlink, hubbleRecords, starlinkRecords };

  /* ---- live position feed (graceful fallback) ---- */
  useEffect(() => {
    let stop = false;
    let prev: { lat: number; lon: number; t: number } | null = null;
    let asc = true;
    let fails = 0;
    let everLive = false;
    const pull = async () => {
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 4500);
      try {
        const r = await fetch('https://api.wheretheiss.at/v1/satellites/25544', { signal: ctl.signal });
        if (!r.ok) throw new Error(String(r.status));
        const j = await r.json();
        if (stop) return;
        const lat = Number(j.latitude), lon = Number(j.longitude), t = Number(j.timestamp) * 1000;
        if (!isFinite(lat) || !isFinite(lon)) throw new Error('bad payload');
        const sample = { lat, lon, t };
        if (prev && t > prev.t && Math.abs(lat - prev.lat) > 0.0008) asc = lat > prev.lat;
        const heading = prev && t > prev.t ? bearingBetween(prev, sample) : liveRef.current?.heading ?? null;
        prev = sample;
        anchorRef.current = { lat, lon, ascending: asc, t };
        liveRef.current = { alt: Number(j.altitude), vel: Number(j.velocity), vis: String(j.visibility), heading, direction: asc ? 'NORTHBOUND' : 'SOUTHBOUND' };
        fails = 0;
        everLive = true;
        setSource('live');
      } catch {
        if (stop) return;
        fails++;
        if (everLive) setSource(fails > 2 ? 'stale' : 'live');
        else { liveRef.current = null; setSource('simulated'); }
      } finally {
        clearTimeout(to);
      }
    };
    pull();
    const t2 = setTimeout(pull, 2200);
    const iv = setInterval(pull, 10000);
    return () => { stop = true; clearTimeout(t2); clearInterval(iv); };
  }, []);

  /* ---- current CelesTrak OMM elements; never substitute a fabricated satellite shell ---- */
  useEffect(() => {
    let stopped = false;
    const loadGroup = async (group: OrbitFeed['group']) => {
      const statusKey = group === 'HUBBLE' ? 'hubble' : 'starlink';
      let cached: OrbitFeed | null = null;
      try {
        const raw = localStorage.getItem(orbitFeedCacheKey(group));
        if (raw) cached = JSON.parse(raw) as OrbitFeed;
      } catch { /* Storage may be disabled; continue with the network request. */ }

      const apply = (feed: OrbitFeed) => {
        const records = feed.elements.map(makeLiveSatellite).filter((item): item is LiveSatellite => item !== null);
        if (group === 'HUBBLE') setHubbleRecords(records);
        else setStarlinkRecords(records);
        const ageMinutes = Math.max(0, Math.floor((Date.now() - new Date(feed.fetchedAt).getTime()) / 60000));
        setOrbitFeedMeta(meta => ({ ...meta, [statusKey]: `${feed.plotted.toLocaleString()} plotted · ${feed.total.toLocaleString()} catalog · ${ageMinutes}m old` }));
      };

      if (cached?.elements?.length) {
        apply(cached);
        const fetchedAt = new Date(cached.fetchedAt).getTime();
        if (Number.isFinite(fetchedAt) && Date.now() - fetchedAt < 2 * 60 * 60 * 1000) {
          if (!stopped) setOrbitFeedStatus(s => ({ ...s, [statusKey]: 'current' }));
          return;
        }
      }

      try {
        const response = await fetch(`/api/orbits?group=${group}`, { cache: 'no-store' });
        if (!response.ok) {
          const failure = await response.json().catch(() => null) as { detail?: string; error?: string } | null;
          throw new Error(failure?.detail || failure?.error || `HTTP ${response.status}`);
        }
        const feed = await response.json() as OrbitFeed;
        if (!Array.isArray(feed.elements) || !feed.elements.length || !feed.fetchedAt) throw new Error('Invalid OMM response');
        try { localStorage.setItem(orbitFeedCacheKey(group), JSON.stringify(feed)); } catch { /* Keep it in memory if storage is full. */ }
        if (stopped) return;
        apply(feed);
        setOrbitFeedStatus(s => ({ ...s, [statusKey]: 'current' }));
      } catch (error) {
        if (stopped) return;
        const detail = error instanceof Error ? error.message.replace(/\s+/g, ' ').trim() : 'Feed request failed';
        setOrbitFeedMeta(meta => ({ ...meta, [statusKey]: cached?.elements?.length ? meta[statusKey] : detail.slice(0, 180) }));
        setOrbitFeedStatus(s => ({ ...s, [statusKey]: cached?.elements?.length ? 'stale' : 'unavailable' }));
      }
    };
    void loadGroup('HUBBLE');
    void loadGroup('STARLINK');
    const refresh = window.setInterval(() => {
      void loadGroup('HUBBLE');
      void loadGroup('STARLINK');
    }, 2 * 60 * 60 * 1000);
    return () => { stopped = true; window.clearInterval(refresh); };
  }, []);

  /* ---- renderer ---- */
  useEffect(() => {
    const wrap = wrapRef.current, canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    const ctx = canvas.getContext('2d')!;
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    let raf = 0, last = 0, lastReadout = 0, disposed = false, visible = true;
    let W = 0, H = 0, dpr = 1;
    const rot = { lon: anchorRef.current.lon, lat: anchorRef.current.lat * 0.6 };
    const track = { at: 0, pts: [] as { t: number; lat: number; lon: number }[] };
    const tleTracks = new Map<LiveSatellite, GroundPosition[]>();
    let tleTracksAt = 0;
    let tleTrackSignature = '';
    const rnd = mulberry(77);
    const stars = Array.from({ length: 170 }, () => ({ x: rnd(), y: rnd(), r: 0.3 + rnd() * 1.1, a: 0.2 + rnd() * 0.7 }));

    const size = () => {
      W = wrap.clientWidth; H = wrap.clientHeight; dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    };

    const frame = (now: number) => {
      if (disposed) return;
      raf = 0;
      if (!reduce && now - last < 40) { raf = requestAnimationFrame(frame); return; }
      last = now;
      if (!W || !H) { size(); }
      const tms = Date.now();
      const anchor = anchorRef.current;
      const pos = issPropagate(anchor, tms);
      const ahead = issPropagate(anchor, tms + 10000);
      const sun = subsolarPoint(new Date(tms));
      const anti: [number, number] = [sun.lon + 180, -sun.lat];

      if (tms - track.at > 4000) {
        track.at = tms;
        track.pts = [];
        for (let s = -50 * 60; s <= 100 * 60; s += 30) {
          const p = issPropagate(anchor, tms + s * 1000);
          track.pts.push({ t: s, lat: p.lat, lon: p.lon });
        }
      }

      const isMap = modeRef.current === 'map';
      let proj: any;
      if (isMap) {
        proj = geoNaturalEarth1().fitExtent([[12, 12], [W - 12, H - 12]], LAND);
      } else {
        let dLon = pos.lon - rot.lon;
        dLon = ((dLon + 540) % 360) - 180;
        rot.lon += dLon * 0.08;
        rot.lat += (pos.lat * 0.7 - rot.lat) * 0.08;
        proj = geoOrthographic().scale(Math.min(W, H) * 0.43).translate([W / 2, H / 2]).rotate([-rot.lon, -rot.lat, 0]).clipAngle(90);
      }
      const path = geoPath(proj, ctx);

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      const R = isMap ? 0 : Math.min(W, H) * 0.43;
      const satelliteProjection = isMap ? proj : geoOrthographic().scale(R).translate([W / 2, H / 2]).rotate([-rot.lon, -rot.lat, 0]).clipAngle(113);
      const projectSatellite = (p: { lat: number; lon: number; altKm: number }): [number, number] | null => {
        const q = satelliteProjection([p.lon, p.lat]);
        if (!q) return null;
        if (isMap) return q as [number, number];
        const scale = (EARTH_RADIUS_KM + p.altKm) / EARTH_RADIUS_KM;
        return [W / 2 + (q[0] - W / 2) * scale, H / 2 + (q[1] - H / 2) * scale];
      };

      /* background */
      if (isMap) {
        const g = ctx.createLinearGradient(0, 0, 0, H);
        g.addColorStop(0, '#0a3550'); g.addColorStop(0.5, '#0c4262'); g.addColorStop(1, '#0a3550');
        ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      } else {
        ctx.fillStyle = '#01040a'; ctx.fillRect(0, 0, W, H);
        stars.forEach(s => { ctx.fillStyle = `rgba(220,235,255,${s.a})`; ctx.beginPath(); ctx.arc(s.x * W, s.y * H, s.r, 0, 6.2832); ctx.fill(); });
        const halo = ctx.createRadialGradient(W / 2, H / 2, R * 0.96, W / 2, H / 2, R * 1.2);
        halo.addColorStop(0, 'rgba(90,170,255,0.55)'); halo.addColorStop(0.35, 'rgba(60,130,255,0.18)'); halo.addColorStop(1, 'rgba(60,130,255,0)');
        ctx.fillStyle = halo; ctx.fillRect(0, 0, W, H);
        const og = ctx.createRadialGradient(W / 2 - R * 0.3, H / 2 - R * 0.3, R * 0.1, W / 2, H / 2, R);
        og.addColorStop(0, '#12618a'); og.addColorStop(0.7, '#0a3f60'); og.addColorStop(1, '#06243a');
        ctx.beginPath(); path({ type: 'Sphere' } as any); ctx.fillStyle = og; ctx.fill();
      }

      /* graticule + land */
      ctx.beginPath(); path(GRATICULE); ctx.strokeStyle = 'rgba(160,220,255,0.07)'; ctx.lineWidth = 0.6; ctx.stroke();
      ctx.beginPath(); path(LAND);
      const lg = ctx.createLinearGradient(0, 0, 0, H);
      lg.addColorStop(0, '#47794f'); lg.addColorStop(0.5, '#4e7f4a'); lg.addColorStop(1, '#40694a');
      ctx.fillStyle = lg; ctx.fill();
      ctx.strokeStyle = 'rgba(210,235,200,0.35)'; ctx.lineWidth = 0.7; ctx.stroke();
      ctx.beginPath(); path(BORDERS); ctx.strokeStyle = 'rgba(20,50,35,0.45)'; ctx.lineWidth = 0.5; ctx.stroke();
      ctx.beginPath(); path(INCLINATION_LIMITS);
      ctx.setLineDash([3, 6]); ctx.strokeStyle = 'rgba(114,209,214,0.22)'; ctx.lineWidth = 0.8; ctx.stroke(); ctx.setLineDash([]);

      /* Earth shadow and twilight penumbra, matched to the 110.3° sunlight test above. */
      ctx.beginPath(); path(geoCircle().center(anti).radius(76).precision(1.5)() as any);
      ctx.fillStyle = 'rgba(4,12,28,0.12)'; ctx.fill();
      ctx.beginPath(); path(geoCircle().center(anti).radius(69.7).precision(1.5)() as any);
      ctx.fillStyle = 'rgba(2,7,20,0.30)'; ctx.fill();
      ctx.beginPath(); path(geoCircle().center(anti).radius(69.7).precision(1.5)() as any);
      ctx.strokeStyle = 'rgba(255,190,110,0.34)'; ctx.lineWidth = 1.1; ctx.stroke();

      /* city lights */
      const cen: [number, number] = isMap ? [0, 0] : [rot.lon, rot.lat];
      CITIES.forEach(([la, lo]) => {
        const d = geoDistance([lo, la], anti) * R2D;
        if (d > 92) return;
        if (!isMap && geoDistance([lo, la], cen) > Math.PI / 2 - 0.03) return;
        const p = proj([lo, la]);
        if (!p) return;
        const a = Math.max(0, Math.min(1, (92 - d) / 14));
        const g = ctx.createRadialGradient(p[0], p[1], 0, p[0], p[1], 7);
        g.addColorStop(0, `rgba(255,222,150,${0.95 * a})`); g.addColorStop(0.3, `rgba(255,190,100,${0.4 * a})`); g.addColorStop(1, 'rgba(255,170,80,0)');
        ctx.fillStyle = g; ctx.fillRect(p[0] - 7, p[1] - 7, 14, 14);
      });

      /* orbit ground track */
      const drawTrack = (from: number, to: number, style: string, dash: number[], lw: number) => {
        const seg = track.pts.filter(p => p.t >= from && p.t <= to).map(p => [p.lon, p.lat]);
        if (seg.length < 2) return;
        ctx.beginPath(); path({ type: 'LineString', coordinates: seg } as any);
        ctx.setLineDash(dash); ctx.strokeStyle = style; ctx.lineWidth = lw; ctx.stroke(); ctx.setLineDash([]);
      };
      drawTrack(-50 * 60, 0, 'rgba(255,255,255,0.35)', [2, 4], 1.2);
      drawTrack(0, 100 * 60, 'rgba(217,243,106,0.12)', [], 7);
      drawTrack(0, 100 * 60, 'rgba(217,243,106,0.9)', [], 1.8);
      ctx.save(); ctx.lineDashOffset = -(now / 90) % 24;
      drawTrack(0, 100 * 60, 'rgba(245,255,184,0.8)', [8, 16], 1.2);
      ctx.restore();

      /* footprint (visibility circle, ~22 deg radius at 420 km) */
      ctx.beginPath(); path(geoCircle().center([pos.lon, pos.lat]).radius(22).precision(2)() as any);
      ctx.fillStyle = 'rgba(217,243,106,0.07)'; ctx.fill(); ctx.strokeStyle = 'rgba(217,243,106,0.4)'; ctx.lineWidth = 0.8; ctx.stroke();

      /* ground stations */
      STATIONS.forEach(s => {
        if (!isMap && geoDistance([s.lon, s.lat], cen) > Math.PI / 2 - 0.03) return;
        const p = proj([s.lon, s.lat]); if (!p) return;
        ctx.fillStyle = '#ffc93c'; ctx.beginPath(); ctx.moveTo(p[0], p[1] - 4.5); ctx.lineTo(p[0] + 4, p[1] + 3); ctx.lineTo(p[0] - 4, p[1] + 3); ctx.closePath(); ctx.fill();
        ctx.font = '9px ui-monospace, monospace'; ctx.fillStyle = 'rgba(255,201,60,0.85)'; ctx.fillText(s.name, p[0] + 7, p[1] + 3);
      });

      /* sun marker */
      if (isMap || geoDistance([sun.lon, sun.lat], cen) < Math.PI / 2) {
        const sp = proj([sun.lon, sun.lat]);
        if (sp) {
          const g = ctx.createRadialGradient(sp[0], sp[1], 0, sp[0], sp[1], 26);
          g.addColorStop(0, 'rgba(255,240,170,0.95)'); g.addColorStop(0.25, 'rgba(255,200,80,0.45)'); g.addColorStop(1, 'rgba(255,190,60,0)');
          ctx.fillStyle = g; ctx.fillRect(sp[0] - 26, sp[1] - 26, 52, 52);
          ctx.fillStyle = '#fff6c8'; ctx.beginPath(); ctx.arc(sp[0], sp[1], 4, 0, 6.2832); ctx.fill();
        }
      }

      /* Hubble and Starlink positions are SGP4-propagated from CelesTrak OMM elements. */
      const layers = satelliteLayersRef.current;
      const plottedStarlinks = layers.starlinkRecords;
      const lineStep = Math.max(1, Math.ceil(plottedStarlinks.length / 8));
      const trackSatellites = [
        ...(layers.hubble && layers.hubbleRecords[0] ? layers.hubbleRecords.slice(0, 1) : []),
        ...(layers.starlink ? plottedStarlinks.filter((_, index) => index % lineStep === 0) : []),
      ];
      const trackSignature = trackSatellites.map(satellite => satellite.name).join('|');
      if (trackSignature !== tleTrackSignature || tms - tleTracksAt > 15000) {
        tleTrackSignature = trackSignature;
        tleTracksAt = tms;
        tleTracks.clear();
        trackSatellites.forEach(satellite => {
          const points: GroundPosition[] = [];
          const periodMs = satellite.periodMinutes * 60000;
          for (let sample = 0; sample <= 72; sample++) {
            const point = propagateGroundPosition(satellite.satrec, tms + (sample / 72) * periodMs);
            if (point) points.push(point);
          }
          tleTracks.set(satellite, points);
        });
      }
      const drawTleTrack = (satellite: LiveSatellite, core: string) => {
        const points = tleTracks.get(satellite);
        if (!points || points.length < 2) return;
        ctx.save();
        ctx.setLineDash([3, 8]); ctx.lineDashOffset = -(now / 55) % 22;
        if (isMap) {
          ctx.beginPath(); path({ type: 'LineString', coordinates: points.map(point => [point.lon, point.lat]) } as any);
        } else {
          let drawing = false;
          ctx.beginPath();
          points.forEach(point => {
            const projected = projectSatellite(point);
            if (!projected) { drawing = false; return; }
            if (drawing) ctx.lineTo(projected[0], projected[1]); else ctx.moveTo(projected[0], projected[1]);
            drawing = true;
          });
        }
        ctx.strokeStyle = core.replace(/,0\.\d+\)$/, ',0.12)'); ctx.lineWidth = 4; ctx.stroke();
        ctx.strokeStyle = core; ctx.lineWidth = 1; ctx.stroke();
        ctx.restore();
      };

      if (layers.hubble) {
        const hubbleSat = layers.hubbleRecords[0];
        if (hubbleSat) {
          drawTleTrack(hubbleSat, 'rgba(139,229,245,0.68)');
          const hubble = propagateGroundPosition(hubbleSat.satrec, tms);
          const hubbleNext = propagateGroundPosition(hubbleSat.satrec, tms + 8000);
          const hp = hubble && projectSatellite(hubble), hn = hubbleNext && projectSatellite(hubbleNext);
          if (hp) {
            const pulse = 0.72 + 0.28 * Math.sin(now / 250);
            ctx.fillStyle = `rgba(114,209,214,${0.18 * pulse})`; ctx.beginPath(); ctx.arc(hp[0], hp[1], 10, 0, 6.2832); ctx.fill();
            ctx.save(); ctx.translate(hp[0], hp[1]);
            if (hn) ctx.rotate(Math.atan2(hn[1] - hp[1], hn[0] - hp[0]));
            ctx.fillStyle = '#286c91'; ctx.strokeStyle = '#b5f5ff'; ctx.lineWidth = 0.8;
            ctx.fillRect(-11, -3, 7, 6); ctx.strokeRect(-11, -3, 7, 6);
            ctx.fillRect(4, -3, 7, 6); ctx.strokeRect(4, -3, 7, 6);
            ctx.fillStyle = '#f4fbff'; ctx.fillRect(-3.5, -3.5, 7, 7);
            ctx.strokeStyle = '#d8f7ff'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(-4, 0); ctx.lineTo(4, 0); ctx.stroke();
            ctx.restore();
            ctx.font = '600 9px ui-monospace, monospace'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(2,8,14,0.9)'; ctx.strokeText('HUBBLE', hp[0] + 13, hp[1] - 8);
            ctx.fillStyle = '#b5f5ff'; ctx.fillText('HUBBLE', hp[0] + 13, hp[1] - 8);
          }
        }
      }

      if (layers.starlink) {
        trackSatellites.filter(satellite => plottedStarlinks.includes(satellite)).forEach(satellite => drawTleTrack(satellite, 'rgba(201,152,255,0.48)'));
        plottedStarlinks.forEach(satellite => {
          const position = propagateGroundPosition(satellite.satrec, tms);
          const point = position && projectSatellite(position);
          if (!point) return;
          ctx.fillStyle = 'rgba(201,152,255,0.22)'; ctx.beginPath(); ctx.arc(point[0], point[1], 3.8, 0, 6.2832); ctx.fill();
          ctx.fillStyle = '#e4c8ff'; ctx.beginPath(); ctx.arc(point[0], point[1], 1.45, 0, 6.2832); ctx.fill();
        });
      }

      /* ISS */
      const ip = proj([pos.lon, pos.lat]);
      if (ip) {
        const ap = proj([ahead.lon, ahead.lat]);
        let heading = 0;
        if (ap) {
          let dx = ap[0] - ip[0];
          if (isMap && Math.abs(dx) > W / 2) dx -= Math.sign(dx) * W;
          heading = Math.atan2(ap[1] - ip[1], dx);
        }
        const pulse = (now / 1000) % 2;
        ctx.strokeStyle = `rgba(217,243,106,${1 - pulse / 2})`; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.arc(ip[0], ip[1], 8 + pulse * 14, 0, 6.2832); ctx.stroke();
        const gg = ctx.createRadialGradient(ip[0], ip[1], 0, ip[0], ip[1], 16);
        gg.addColorStop(0, 'rgba(217,243,106,0.7)'); gg.addColorStop(1, 'rgba(217,243,106,0)');
        ctx.fillStyle = gg; ctx.fillRect(ip[0] - 16, ip[1] - 16, 32, 32);
        ctx.save(); ctx.translate(ip[0], ip[1]); ctx.rotate(heading);
        const drawSolarWing = (x: number) => {
          ctx.fillStyle = '#174f78'; ctx.strokeStyle = '#8bc9f1'; ctx.lineWidth = 0.65;
          ctx.fillRect(x, -5, 10, 10); ctx.strokeRect(x, -5, 10, 10);
          ctx.beginPath(); ctx.moveTo(x + 3.3, -5); ctx.lineTo(x + 3.3, 5); ctx.moveTo(x + 6.6, -5); ctx.lineTo(x + 6.6, 5);
          ctx.moveTo(x, 0); ctx.lineTo(x + 10, 0); ctx.stroke();
        };
        drawSolarWing(-19); drawSolarWing(9);
        ctx.strokeStyle = '#dce7ee'; ctx.lineWidth = 1.8; ctx.beginPath(); ctx.moveTo(-9, 0); ctx.lineTo(9, 0); ctx.stroke();
        ctx.fillStyle = '#edf3f7'; ctx.fillRect(-4, -3.5, 8, 7);
        ctx.strokeStyle = '#dce7ee'; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(-1, -3); ctx.lineTo(-5, -7); ctx.moveTo(1, 3); ctx.lineTo(5, 7); ctx.stroke();
        ctx.restore();
        ctx.font = '600 10px ui-monospace, monospace';
        ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(2,8,14,0.9)'; ctx.strokeText('ISS', ip[0] + 14, ip[1] - 10);
        ctx.fillStyle = '#d9f36a'; ctx.fillText('ISS', ip[0] + 14, ip[1] - 10);
      }

      /* edge shading */
      if (!isMap) {
        const e = ctx.createRadialGradient(W / 2, H / 2, R * 0.82, W / 2, H / 2, R);
        e.addColorStop(0, 'rgba(0,0,0,0)'); e.addColorStop(1, 'rgba(0,10,25,0.5)');
        ctx.beginPath(); path({ type: 'Sphere' } as any); ctx.fillStyle = e; ctx.fill();
      } else {
        const v = ctx.createRadialGradient(W / 2, H / 2, H * 0.4, W / 2, H / 2, W * 0.65);
        v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,6,12,0.55)');
        ctx.fillStyle = v; ctx.fillRect(0, 0, W, H);
      }

      /* readouts (1 Hz) */
      if (tms - lastReadout > 900) {
        lastReadout = tms;
        const live = liveRef.current;
        const nt = nextTerminator(anchor, tms);
        const d = new Date(anchor.t);
        setRo({
          lat: pos.lat, lon: pos.lon,
          alt: live?.alt ?? 419 + Math.sin(tms / 400000) * 1.5,
          vel: live?.vel ?? 27580 + Math.round(Math.sin(tms / 9000) * 20),
          vis: live?.vis ?? (nt.sunlit ? 'daylight' : 'eclipsed'),
          mins: nt.minutes, sunrise: nt.sunrise,
          utc: d.toISOString().substring(11, 19),
          heading: live?.heading ?? bearingBetween(pos, ahead),
          direction: live?.direction ?? (ahead.lat >= pos.lat ? 'NORTHBOUND' : 'SOUTHBOUND'),
          age: Math.max(0, Math.floor((tms - anchor.t) / 1000)),
        });
      }

      if (!reduce && visible && !document.hidden) raf = requestAnimationFrame(frame);
    };

    const kick = () => { if (!raf) raf = requestAnimationFrame(frame); };
    size(); kick();
    const obs = new ResizeObserver(() => { size(); if (reduce) { cancelAnimationFrame(raf); raf = 0; kick(); } });
    obs.observe(wrap);
    const io = new IntersectionObserver(e => { visible = e[0]?.isIntersecting ?? true; if (visible) kick(); });
    io.observe(wrap);
    const vis = () => { if (!document.hidden) kick(); };
    document.addEventListener('visibilitychange', vis);
    const interval = reduce ? window.setInterval(() => { raf = 0; kick(); }, 1000) : 0;
    return () => { disposed = true; cancelAnimationFrame(raf); obs.disconnect(); io.disconnect(); document.removeEventListener('visibilitychange', vis); if (interval) clearInterval(interval); };
  }, []);

  const badge =
    source === 'live'
      ? { t: 'LIVE FEED · wheretheiss.at', c: 'text-[#66a75e] border-[#66a75e]/50 bg-[#0d2418]', dot: 'bg-[#66a75e] animate-ping' }
      : source === 'stale'
        ? { t: 'LIVE FEED RECONNECTING · MODEL PROPAGATION', c: 'text-[#ffc93c] border-[#ffc93c]/50 bg-[#2a2208]', dot: 'bg-[#ffc93c]' }
        : { t: 'SIMULATED ORBIT · live feed unreachable', c: 'text-[#ef7144] border-[#ef7144]/50 bg-[#2a1409]', dot: 'bg-[#ef7144]' };

  const fmtLat = (v: number) => `${Math.abs(v).toFixed(2)}° ${v >= 0 ? 'N' : 'S'}`;
  const fmtLon = (v: number) => `${Math.abs(v).toFixed(2)}° ${v >= 0 ? 'E' : 'W'}`;

  return (
    <div className="rounded-2xl border border-[#72d1d6]/40 bg-[#07191e] p-4 sm:p-6 space-y-4 shadow-2xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-widest text-[#72d1d6]">
            <Satellite size={14} />
            <span>INTERNATIONAL SPACE STATION (ZARYA) · NORAD 25544</span>
          </div>
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-white mt-1">Live Orbital Ground Track</h2>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border text-[10px] font-mono font-bold ${badge.c}`}>
            <i className={`w-2 h-2 rounded-full inline-block ${badge.dot}`} />
            {badge.t}
          </span>
          {(['map', 'globe'] as Mode[]).map(m => (
            <button
              key={m}
              onClick={() => { playUiClick(); setMode(m); }}
              aria-pressed={mode === m}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[10px] font-mono font-bold cursor-pointer transition-all ${
                mode === m ? 'border-[#d9f36a] bg-[#12362f] text-[#d9f36a]' : 'border-white/10 bg-black/40 text-gray-400 hover:border-white/30'
              }`}
            >
              {m === 'map' ? <MapIcon size={12} /> : <Globe size={12} />}
              {m === 'map' ? 'FLAT MAP' : '3D GLOBE'}
            </button>
          ))}
          <button onClick={() => { playUiClick(); setShowHubble(v => !v); }} aria-pressed={showHubble}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[10px] font-mono font-bold cursor-pointer transition-all ${showHubble ? 'border-[#72d1d6]/60 bg-[#0b2933] text-[#a7f3f7]' : 'border-white/10 bg-black/40 text-gray-500'}`}>
            <Satellite size={12} /> HUBBLE
          </button>
          <button onClick={() => { playUiClick(); setShowStarlink(v => !v); }} aria-pressed={showStarlink}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[10px] font-mono font-bold cursor-pointer transition-all ${showStarlink ? 'border-[#c998ff]/60 bg-[#211334] text-[#d9b8ff]' : 'border-white/10 bg-black/40 text-gray-500'}`}>
            <Orbit size={12} /> STARLINK
          </button>
        </div>
      </div>

      <div ref={wrapRef} className="relative h-[300px] sm:h-[440px] rounded-xl border border-[#1b3834] overflow-hidden bg-[#02070c]">
        <canvas ref={canvasRef} className="block w-full h-full" role="img" aria-label="Orbital map showing the ISS and selectable Hubble and Starlink satellite-orbit layers" />
        <div className="pointer-events-none absolute top-3 left-3 text-[10px] font-mono tracking-widest text-white/85 space-y-0.5">
          <div>UTC {ro.utc || '--:--:--'} · FEED AGE {source === 'simulated' ? 'MODEL' : `${ro.age}s`}</div>
          <div className="text-[#9fb1a6]">LAT {fmtLat(ro.lat)} · LON {fmtLon(ro.lon)}</div>
        </div>
        <div className="pointer-events-none absolute bottom-3 left-3 flex items-center gap-3 text-[9px] font-mono text-[#cfe3ea] bg-black/55 border border-white/10 rounded-md px-2 py-1">
          <span className="flex items-center gap-1"><i className="inline-block w-4 border-t border-dashed border-white/60" /> PAST 50 MIN</span>
          <span className="flex items-center gap-1"><i className="inline-block w-4 border-t-2 border-[#d9f36a]" /> NEXT 100 MIN</span>
          <span className="flex items-center gap-1"><i className="inline-block w-4 border-t border-dashed border-[#72d1d6]" /> ±51.6° LIMIT</span>
          {showHubble && <span className="flex items-center gap-1"><i className="inline-block w-4 border-t border-[#72d1d6]" /> HUBBLE · SGP4</span>}
          {showStarlink && <span className="flex items-center gap-1"><i className="inline-block w-4 border-t border-[#c998ff]" /> STARLINK · SGP4</span>}
          <span className="flex items-center gap-1"><i className="inline-block w-2 h-2 rounded-full bg-[#ffc93c]" /> DSN SITES</span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3 text-xs font-mono">
        <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
          <div className="text-[10px] text-[#9fb1a6]">ORBITAL ALTITUDE</div>
          <div className="text-base font-bold text-[#d9f36a] mt-0.5">{ro.alt.toFixed(1)} km</div>
        </div>
        <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
          <div className="text-[10px] text-[#9fb1a6]">ORBITAL VELOCITY</div>
          <div className="text-base font-bold text-[#72d1d6] mt-0.5">{Math.round(ro.vel).toLocaleString()} km/h</div>
        </div>
        <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
          <div className="text-[10px] text-[#9fb1a6]">GROUND TRACK HEADING</div>
          <div className="text-base font-bold text-[#72d1d6] mt-0.5">{Math.round(ro.heading)}° {compassLabel(ro.heading)}</div>
          <div className="text-[9px] text-[#9fb1a6] mt-0.5">{ro.direction}</div>
        </div>
        <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
          <div className="text-[10px] text-[#9fb1a6]">ORBIT DURATION</div>
          <div className="text-base font-bold text-white mt-0.5">{(ISS_PERIOD_S / 60).toFixed(1)} min · 15.5 / day</div>
        </div>
        <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
          <div className="text-[10px] text-[#9fb1a6]">LIVE ILLUMINATION</div>
          <div className="text-base font-bold text-[#ffc93c] mt-0.5 uppercase">{ro.vis}</div>
        </div>
        <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
          <div className="text-[10px] text-[#9fb1a6]">NEXT ORBITAL {ro.sunrise ? 'SUNRISE' : 'SUNSET'}</div>
          <div className="text-base font-bold text-[#ffc93c] mt-0.5">{ro.mins > 0 ? `~${ro.mins} min` : '—'}</div>
        </div>
      </div>
      <div className="text-[10px] font-mono text-[#9fb1a6] flex flex-wrap gap-x-4 gap-y-1">
        <span>STATUS: <span className="text-white uppercase">{ro.vis}</span></span>
        <span>The ISS circles Earth at 51.6° inclination, so it never flies above 51.6° N or S. The shaded side is night; city lights glow there.</span>
        <span>Hubble and Starlink use CelesTrak GP elements propagated with SGP4. Starlink points are a 320-satellite sample from the current catalog; the feed cache refreshes every 2 hours.</span>
        <span className={orbitFeedStatus.hubble === 'unavailable' || orbitFeedStatus.starlink === 'unavailable' ? 'text-[#ef7144]' : 'text-[#72d1d6]'}>
          CelesTrak · Hubble {orbitFeedStatus.hubble}{orbitFeedMeta.hubble ? ` (${orbitFeedMeta.hubble})` : ''} · Starlink {orbitFeedStatus.starlink}{orbitFeedMeta.starlink ? ` (${orbitFeedMeta.starlink})` : ''}
        </span>
      </div>
    </div>
  );
};
