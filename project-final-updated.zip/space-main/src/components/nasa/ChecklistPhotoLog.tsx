import React, { useEffect, useState } from 'react';
import { Camera, ExternalLink, Lock, X } from 'lucide-react';
import { searchNasaImages } from '../../utils/nasaApi';
import type { NasaImageItem } from '../../types';

interface SystemState {
  label: string;
  go: boolean;
}

interface ChecklistPhotoLogProps {
  /** The checklist subsystems in order; each one that turns GO unlocks one photo. */
  systems: SystemState[];
}

type Kind = 'TRAINING' | 'ISS';
interface Tile extends NasaImageItem {
  kind: Kind;
}

const TRAINING_QUERY = 'astronaut training';
const ISS_QUERY = 'International Space Station interior';

/** Alternate training and ISS photos so the log reads as "how we prepare" and "where we're going". */
function interleave(training: NasaImageItem[], iss: NasaImageItem[], count: number): Tile[] {
  const out: Tile[] = [];
  const seen = new Set<string>();
  for (let i = 0; out.length < count && (i < training.length || i < iss.length); i++) {
    for (const [kind, list] of [['TRAINING', training], ['ISS', iss]] as [Kind, NasaImageItem[]][]) {
      const item = list[i];
      if (item && !seen.has(item.nasaId) && out.length < count) {
        seen.add(item.nasaId);
        out.push({ ...item, kind });
      }
    }
  }
  return out;
}

/**
 * Reference photo log for the pre-launch checklist mission. Photos come from the NASA Image and Video
 * Library (astronaut training and International Space Station photography); each verified system
 * unlocks the next photo, so progress through the checklist has a tangible payoff.
 */
export const ChecklistPhotoLog: React.FC<ChecklistPhotoLogProps> = ({ systems }) => {
  const [tiles, setTiles] = useState<Tile[]>([]);
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [open, setOpen] = useState<Tile | null>(null);

  useEffect(() => {
    let alive = true;
    Promise.allSettled([searchNasaImages(TRAINING_QUERY, 3), searchNasaImages(ISS_QUERY, 3)]).then(([t, i]) => {
      if (!alive) return;
      const training = t.status === 'fulfilled' ? t.value : [];
      const iss = i.status === 'fulfilled' ? i.value : [];
      const merged = interleave(training, iss, systems.length);
      setTiles(merged);
      setState(merged.length ? 'ready' : 'error');
    });
    return () => {
      alive = false;
    };
    // The set of photos is fixed per mission; only unlock state changes after load.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(null);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  const unlockedCount = systems.filter(s => s.go).length;

  return (
    <section aria-label="Mission photo log from the NASA Image Library" className="rounded-xl border border-[#1b3834] bg-[#0b2025] p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] font-mono tracking-widest">
        <span className="flex items-center gap-2 text-[#66d17a] font-bold">
          <Camera size={13} /> MISSION PHOTO LOG · NASA IMAGE LIBRARY
        </span>
        <span className="text-[#9fb1a6]">
          {unlockedCount} / {systems.length} UNLOCKED
        </span>
      </div>

      {state === 'loading' && <div className="text-xs font-mono text-[#9fb1a6]">Retrieving reference photography…</div>}
      {state === 'error' && (
        <div className="text-xs font-mono text-[#9fb1a6]">
          The NASA Image Library couldn&rsquo;t be reached, so the photo log is unavailable. The checklist itself is
          unaffected.
        </div>
      )}

      {state === 'ready' && (
        <ul className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {systems.map((system, idx) => {
            const tile = tiles[idx];
            const unlocked = system.go && !!tile;
            return (
              <li key={system.label}>
                {unlocked ? (
                  <button
                    onClick={() => setOpen(tile)}
                    aria-label={`Open photo: ${tile.title}`}
                    className="group relative block w-full aspect-square rounded-lg overflow-hidden border border-[#66d17a]/40 cursor-pointer"
                  >
                    <img src={tile.thumbUrl} alt={tile.title} loading="lazy" className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                    <span className="absolute left-1 top-1 px-1.5 py-0.5 rounded bg-[#061211]/85 text-[8px] font-mono font-bold tracking-wider text-[#d9f36a]">
                      {tile.kind}
                    </span>
                  </button>
                ) : (
                  <div
                    className="w-full aspect-square rounded-lg border border-dashed border-white/15 bg-[#07191e] flex flex-col items-center justify-center gap-1 text-center p-1"
                    title={`Unlocks when ${system.label} is GO`}
                  >
                    <Lock size={14} className="text-[#6f8579]" />
                    <span className="text-[8px] font-mono leading-tight text-[#6f8579]">{system.label}</span>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}

      {open && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={open.title}
          className="fixed inset-0 z-[100] grid place-items-center bg-black/80 p-4"
          onClick={() => setOpen(null)}
        >
          <div
            className="relative max-w-3xl w-full max-h-[90vh] overflow-auto rounded-2xl border border-[#1b3834] bg-[#0b2025]"
            onClick={e => e.stopPropagation()}
          >
            <button
              onClick={() => setOpen(null)}
              aria-label="Close photo"
              className="absolute right-3 top-3 z-10 grid h-8 w-8 place-items-center rounded-full bg-black/60 text-white cursor-pointer"
            >
              <X size={16} />
            </button>
            <img src={open.mediumUrl} onError={e => ((e.target as HTMLImageElement).src = open.thumbUrl)} alt={open.title} className="w-full max-h-[55vh] object-contain bg-black" />
            <div className="p-4 space-y-2 text-xs font-mono">
              <div className="text-[10px] tracking-widest text-[#66d17a] font-bold">{open.kind} PHOTOGRAPHY</div>
              <h4 className="font-display font-bold text-base text-[#eef4e6]">{open.title}</h4>
              {open.description && (
                <p className="text-[#bdc9c0] leading-relaxed">
                  {open.description.length > 420 ? `${open.description.slice(0, 420).trimEnd()}…` : open.description}
                </p>
              )}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/10 text-[10px] text-[#9fb1a6]">
                <span>
                  NASA · {open.center}
                  {open.dateCreated ? ` · ${open.dateCreated}` : ''} · ID {open.nasaId}
                </span>
                <a href={open.detailsUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-[#72d1d6] hover:underline">
                  NASA Image Library <ExternalLink size={10} />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
