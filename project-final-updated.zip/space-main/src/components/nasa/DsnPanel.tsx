import React, { useEffect, useState } from 'react';
import { Wifi } from 'lucide-react';
import { playTone } from '../../utils/audio';
import { C_KM_S, AU_KM, fmtDuration, marsEarth, voyager1 } from '../../utils/astro';
import { DsnDishAsset3D } from './DsnDishAsset3D';

interface Link {
  complex: string;
  short: string;
  dish: string;
  target: string;
  sub: string;
  freq: string;
  rate: string;
  color: string;
  oneWayS: (now: Date) => number;
  rangeKm: (now: Date) => number;
  lat: string;
}

const LINKS: Link[] = [
  {
    complex: 'Goldstone (California, USA)', short: 'Goldstone', dish: 'DSS-14 · 70-m antenna', target: 'Voyager 1', sub: 'Interstellar space', freq: '8.42 GHz (X-band)', rate: '160 bits / s', color: '#d9f36a', lat: '35.4° N',
    oneWayS: n => voyager1(n).oneWayS, rangeKm: n => voyager1(n).km,
  },
  {
    complex: 'Madrid (Robledo de Chavela, Spain)', short: 'Madrid', dish: 'DSS-63 · 70-m antenna', target: 'James Webb Space Telescope', sub: 'Sun–Earth L2 point', freq: '25.9 GHz (Ka-band)', rate: 'up to 28 Mbps', color: '#72d1d6', lat: '40.4° N',
    oneWayS: () => 1_500_000 / C_KM_S, rangeKm: () => 1_500_000,
  },
  {
    complex: 'Canberra (Tidbinbilla, Australia)', short: 'Canberra', dish: 'DSS-43 · 70-m antenna', target: 'Mars relay (MRO) · Perseverance', sub: 'Orbiter & rover at Mars', freq: '8.4 GHz (X-band)', rate: 'up to ~6 Mbps', color: '#ef7144', lat: '35.4° S',
    oneWayS: n => marsEarth(n).km / C_KM_S, rangeKm: n => marsEarth(n).km,
  },
];

const LADDER: { label: string; s: number; live?: (n: Date) => number }[] = [
  { label: 'Moon', s: 1.28 },
  { label: 'JWST (L2)', s: 5 },
  { label: 'Sun', s: 499 },
  { label: 'Mars (now)', s: 0, live: n => marsEarth(n).km / C_KM_S },
  { label: 'Jupiter (avg)', s: 2600 },
  { label: 'Voyager 1', s: 0, live: n => voyager1(n).oneWayS },
];

const fmtKm = (km: number) => (km >= 1e9 ? `${(km / 1e9).toFixed(3)} billion km` : km >= 1e6 ? `${(km / 1e6).toFixed(2)} million km` : `${Math.round(km).toLocaleString()} km`);

export const DsnPanel: React.FC = () => {
  const [idx, setIdx] = useState(0);
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(iv);
  }, []);
  const link = LINKS[idx];
  const one = link.oneWayS(now);
  const rangeKm = link.rangeKm(now);
  const v1 = voyager1(now);

  const ladder = LADDER.map(l => ({ ...l, s: l.live ? l.live(now) : l.s }));
  const lo = Math.log10(1), hi = Math.log10(200000);
  const pos = (s: number) => ((Math.log10(Math.max(s, 1)) - lo) / (hi - lo)) * 100;

  return (
    <div className="rounded-2xl border border-[#d9f36a]/40 bg-[#07191e] p-4 sm:p-6 space-y-5 shadow-2xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-widest text-[#d9f36a]">
            <Wifi size={14} />
            <span>NASA DEEP SPACE NETWORK · REPRESENTATIVE LINKS</span>
          </div>
          <h3 className="font-display font-bold text-2xl sm:text-3xl text-white mt-1">70-Meter Deep Space Dishes</h3>
        </div>
        <div className="flex gap-2">
          {LINKS.map((st, i) => (
            <button
              key={st.short}
              onClick={() => { playTone(550 + i * 80, 0.08); setIdx(i); }}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-bold transition-all cursor-pointer ${
                idx === i ? 'bg-[#153e39] border-[#d9f36a] text-[#d9f36a]' : 'bg-[#040e12] border-white/10 text-[#9fb1a6] hover:border-white/30'
              }`}
            >
              {st.short}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        <div className="md:col-span-4 rounded-xl overflow-hidden border border-white/10 bg-[#030a10] relative min-h-[210px]">
          <DsnDishAsset3D key={idx} color={link.color} station={link.short} />
          <div className="absolute top-2 left-3 right-3 flex justify-between pointer-events-none">
            <span className="rounded bg-black/45 px-2 py-1 text-[9px] font-mono tracking-widest text-white/65">70 M · REFLECTOR MODEL</span>
            <span className="rounded bg-black/45 px-2 py-1 text-[9px] font-mono text-white/55">DRAG TO INSPECT</span>
          </div>
          <div className="absolute bottom-2 left-3 right-3 text-center">
            <div className="font-display font-bold text-sm text-white">{link.dish}</div>
            <div className="text-[10px] font-mono text-[#72d1d6]">{link.complex} · {link.lat}</div>
          </div>
        </div>

        <div className="md:col-span-8 grid grid-cols-2 gap-3 text-xs font-mono">
          <div className="p-3 rounded-lg bg-[#040e12] border border-white/5 col-span-2">
            <div className="text-[10px] text-[#9fb1a6]">ACTIVE COMM TARGET</div>
            <div className="text-lg font-bold mt-0.5" style={{ color: link.color }}>{link.target}</div>
            <div className="text-[#9fb1a6]">{link.sub}</div>
          </div>
          <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
            <div className="text-[10px] text-[#9fb1a6]">COMMUNICATION RANGE</div>
            <div className="text-base font-bold text-white mt-0.5 tabular-nums">{fmtKm(rangeKm)}</div>
            <div className="text-[10px] text-[#9fb1a6]">{(rangeKm / AU_KM).toFixed(rangeKm > 5e8 ? 3 : 4)} AU</div>
          </div>
          <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
            <div className="text-[10px] text-[#9fb1a6]">ROUND-TRIP LIGHT DELAY</div>
            <div className="text-base font-bold text-[#ffc93c] mt-0.5 tabular-nums">{fmtDuration(one * 2)}</div>
            <div className="text-[10px] text-[#9fb1a6]">one-way {fmtDuration(one)}</div>
          </div>
          <div className="p-3 rounded-lg bg-[#040e12] border border-white/5 col-span-2">
            <div className="text-[10px] text-[#9fb1a6]">RADIO LINK</div>
            <div className="text-base font-bold text-[#72d1d6] mt-0.5">{link.freq} · {link.rate}</div>
          </div>
        </div>
      </div>

      {/* Light-time ladder */}
      <div className="rounded-xl bg-[#040e12] border border-white/5 p-4 space-y-3">
        <div className="text-[10px] font-mono tracking-widest text-[#9fb1a6]">LIGHT-TIME LADDER · ONE-WAY SIGNAL DELAY (LOG SCALE)</div>
        <div className="relative h-28 mx-3">
          <div className="absolute left-0 right-0 top-14 h-[2px] bg-gradient-to-r from-[#72d1d6] via-[#ffc93c] to-[#ef7144] opacity-70" />
          {[1, 10, 60, 600, 3600, 86400].map((s, i) => (
            <div key={s} className="absolute top-[52px]" style={{ left: `${pos(s)}%` }}>
              <i className="block w-px h-3 bg-white/50 -translate-x-1/2" />
              <span className="absolute top-4 -translate-x-1/2 text-[9px] font-mono text-[#9fb1a6] whitespace-nowrap">{['1 s', '10 s', '1 min', '10 min', '1 h', '1 day'][i]}</span>
            </div>
          ))}
          {[...ladder].sort((p, q) => p.s - q.s).map((l, i) => {
            const active = (idx === 0 && l.label === 'Voyager 1') || (idx === 1 && l.label.startsWith('JWST')) || (idx === 2 && l.label.startsWith('Mars'));
            const up = i % 2 === 0;
            return (
              <div key={l.label} className="absolute -translate-x-1/2 flex flex-col items-center" style={{ left: `${pos(l.s)}%`, top: up ? 2 : 74 - 0, ...(up ? {} : { top: 'auto', bottom: 0, flexDirection: 'column-reverse' }) }}>
                <span className={`text-[10px] font-mono whitespace-nowrap px-1.5 py-0.5 rounded ${active ? 'bg-[#d9f36a] text-[#061211] font-bold' : 'bg-[#0a1c22] text-[#cfe3ea] border border-white/10'}`}>{l.label}</span>
                <i className={`block w-px bg-white/30 ${up ? 'h-9' : 'h-3'}`} />
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-[11px] font-mono">
        <div className="p-3 rounded-lg bg-[#12252a] border border-[#d9f36a]/25">
          <div className="text-[#d9f36a] font-bold">VOYAGER 1 · RANGE (ESTIMATE)</div>
          <div className="text-white text-sm mt-0.5 tabular-nums">{v1.au.toFixed(3)} AU</div>
          <div className="text-[#9fb1a6]">growing {v1.speedKmS.toFixed(2)} km every second</div>
        </div>
        <div className="p-3 rounded-lg bg-[#12252a] border border-[#ef7144]/25">
          <div className="text-[#ef7144] font-bold">EARTH–MARS (COMPUTED)</div>
          <div className="text-white text-sm mt-0.5 tabular-nums">{marsEarth(now).au.toFixed(3)} AU</div>
          <div className="text-[#9fb1a6]">{marsEarth(now).lightMinutes.toFixed(1)} light-minutes one way</div>
        </div>
        <div className="p-3 rounded-lg bg-[#12252a] border border-white/10 text-[#9fb1a6] leading-relaxed">
          Ranges are computed from orbital models (Voyager 1 anchored to NASA’s Nov 2026 “one light-day” milestone). Dish assignments are typical examples, not the live DSN schedule.
        </div>
      </div>
    </div>
  );
};
