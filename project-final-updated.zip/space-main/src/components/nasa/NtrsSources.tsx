import React, { useCallback, useEffect, useState } from 'react';
import { BadgeCheck, BookOpen, ExternalLink, Loader2, Search } from 'lucide-react';
import { deriveNtrsQuery, NTRS_ATTRIBUTION, ntrsSearchUrl, pinnedFor } from '../../data/ntrsSources';
import { searchNtrs } from '../../utils/nasaApi';
import type { NtrsRecord } from '../../types';

interface NtrsSourcesProps {
  /** The question or topic whose factual claim needs a source. */
  prompt: string;
  /** Quiz position, used to look up pinned (verified) records. Omit for free-standing topics. */
  missionId?: number;
  questionIndex?: number;
  /** Override the keyword query derived from the prompt. */
  ntrsQuery?: string;
  /** Wait for a click before searching (use where many panels render at once). */
  onDemand?: boolean;
}

type Status = 'idle' | 'loading' | 'done' | 'error';

const byline = (r: Pick<NtrsRecord, 'authors' | 'year' | 'reportNumber' | 'center'>) =>
  [
    r.authors.length ? (r.authors.length > 2 ? `${r.authors[0]} et al.` : r.authors.join('; ')) : null,
    r.year ?? null,
    r.reportNumber ?? null,
    r.center ?? null,
  ]
    .filter(Boolean)
    .join(' · ');

/**
 * Cites NASA Technical Reports Server records for a quiz claim.
 *  - Pinned records are human-checked against the claim and say what they do and do not support.
 *  - Everything else gets a live NTRS keyword search, clearly labelled as "related" so a keyword match
 *    is never presented as proof. If NTRS can't be reached, the panel links to the NTRS search page.
 */
export const NtrsSources: React.FC<NtrsSourcesProps> = ({ prompt, missionId, questionIndex, ntrsQuery, onDemand }) => {
  const pinned = missionId !== undefined && questionIndex !== undefined ? pinnedFor(missionId, questionIndex) : [];
  const query = deriveNtrsQuery(prompt, ntrsQuery);
  const [status, setStatus] = useState<Status>('idle');
  const [records, setRecords] = useState<NtrsRecord[]>([]);
  const [total, setTotal] = useState(0);

  const lookup = useCallback(() => {
    setStatus('loading');
    let alive = true;
    searchNtrs(query, 3)
      .then(res => {
        if (!alive) return;
        // Don't repeat records that are already pinned above.
        const shown = new Set(pinned.map(p => p.id));
        setRecords(res.records.filter(r => !shown.has(r.id)));
        setTotal(res.total);
        setStatus('done');
      })
      .catch(() => alive && setStatus('error'));
    return () => {
      alive = false;
    };
    // `pinned` is derived from missionId/questionIndex, so those (with the query) are the real inputs.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, missionId, questionIndex]);

  // Unpinned questions look their source up automatically; pinned ones offer it on demand.
  useEffect(() => {
    if (pinned.length === 0 && !onDemand) return lookup();
  }, [pinned.length, onDemand, lookup]);

  return (
    <div className="rounded-lg border border-[#72d1d6]/20 bg-[#061a1f] p-3 space-y-2.5 text-[11px] font-mono">
      <div className="flex items-center gap-2 text-[10px] tracking-widest font-bold text-[#72d1d6]">
        <BookOpen size={12} />
        SOURCE · NASA TECHNICAL REPORTS SERVER
      </div>

      {pinned.map(p => (
        <div key={p.id} className="space-y-0.5 border-l-2 border-[#66d17a]/60 pl-2.5">
          <div className="flex items-center gap-1 text-[9px] tracking-widest text-[#66d17a] font-bold">
            <BadgeCheck size={11} /> VERIFIED NTRS RECORD
          </div>
          <a
            href={p.url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#eef4e6] hover:text-[#d9f36a] underline-offset-2 hover:underline font-bold leading-snug inline-flex gap-1"
          >
            <span>{p.title}</span>
            <ExternalLink size={10} className="mt-0.5 shrink-0" />
          </a>
          <div className="text-[#9fb1a6]">{byline(p)} · NTRS {p.id}</div>
          <div className="text-[#bdc9c0] leading-relaxed">{p.supports}</div>
        </div>
      ))}

      {(pinned.length > 0 || onDemand) && status === 'idle' && (
        <button
          onClick={lookup}
          className="inline-flex items-center gap-1.5 text-[#72d1d6] hover:underline cursor-pointer"
        >
          <Search size={11} /> {pinned.length > 0 ? 'Find more related NTRS records' : 'Look up on NTRS'}
        </button>
      )}

      <div aria-live="polite" className="space-y-2">
        {status === 'loading' && (
          <div className="flex items-center gap-2 text-[#9fb1a6]">
            <Loader2 size={12} className="animate-spin" /> Searching NTRS for &ldquo;{query}&rdquo;…
          </div>
        )}

        {status === 'done' && (
          <>
            {records.length > 0 ? (
              <>
                <div className="text-[#9fb1a6]">
                  Related records (keyword match, {total.toLocaleString('en-US')} total). Open one and confirm it
                  supports the claim.
                </div>
                {records.map(r => (
                  <div key={r.id} className="space-y-0.5 border-l-2 border-[#72d1d6]/40 pl-2.5">
                    <a
                      href={r.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#eef4e6] hover:text-[#d9f36a] hover:underline underline-offset-2 leading-snug inline-flex gap-1"
                    >
                      <span>{r.title}</span>
                      <ExternalLink size={10} className="mt-0.5 shrink-0" />
                    </a>
                    <div className="text-[#9fb1a6]">{byline(r) || 'NASA'} · NTRS {r.id}</div>
                  </div>
                ))}
              </>
            ) : (
              pinned.length === 0 && <div className="text-[#9fb1a6]">No close NTRS matches for &ldquo;{query}&rdquo;.</div>
            )}
          </>
        )}

        {status === 'error' && (
          <div className="text-[#9fb1a6]">Live NTRS lookup isn&rsquo;t reachable from here.</div>
        )}
      </div>

      {(status === 'error' || (status === 'done' && records.length === 0)) && (
        <a
          href={ntrsSearchUrl(query)}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-[#72d1d6] hover:underline"
        >
          Search NTRS for &ldquo;{query}&rdquo; <ExternalLink size={10} />
        </a>
      )}

      <div className="text-[9px] text-[#6f8579] leading-snug">{NTRS_ATTRIBUTION}</div>
    </div>
  );
};
