import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

interface DsnDishAsset3DProps {
  color: string;
  station: string;
}

export const DsnDishAsset3D: React.FC<DsnDishAsset3DProps> = ({ color, station }) => {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const [assetError, setAssetError] = useState(false);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'low-power' });
    } catch (error) {
      console.error('[DsnDishAsset3D] Unable to initialize WebGL rendering.', error);
      setAssetError(true);
      return;
    }

    let disposed = false;
    let model: THREE.Group | null = null;
    let frameId = 0;
    let visible = !document.hidden;
    let reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    setAssetError(false);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.domElement.style.cssText = 'display:block;width:100%;height:100%;cursor:grab;touch-action:none;';
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(39, 1, 0.1, 100);
    camera.position.set(9.8, 5.2, 6.6);
    camera.lookAt(0, 2.45, 0);

    scene.add(new THREE.HemisphereLight(0xa6d7ef, 0x18202a, 1.45));
    const keyLight = new THREE.DirectionalLight(0xffe6c6, 3.2);
    keyLight.position.set(-5, 9, 7);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.left = -8;
    keyLight.shadow.camera.right = 8;
    keyLight.shadow.camera.top = 10;
    keyLight.shadow.camera.bottom = -6;
    keyLight.shadow.bias = -0.0004;
    scene.add(keyLight);

    const accent = new THREE.Color(color);
    const fillLight = new THREE.PointLight(accent, 20, 20, 2);
    fillLight.position.set(5, 4, -4);
    scene.add(fillLight);

    const ground = new THREE.Mesh(
      new THREE.CircleGeometry(6.5, 64),
      new THREE.MeshStandardMaterial({ color: 0x111c21, roughness: 0.94, metalness: 0.05 }),
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.08;
    ground.receiveShadow = true;
    scene.add(ground);

    const starsData = new Float32Array(420 * 3);
    for (let i = 0; i < 420; i += 1) {
      const theta = Math.random() * Math.PI * 2;
      const radius = 18 + Math.random() * 18;
      starsData[i * 3] = Math.cos(theta) * radius;
      starsData[i * 3 + 1] = 3 + Math.random() * 16;
      starsData[i * 3 + 2] = -12 - Math.random() * 20;
    }
    const starsGeometry = new THREE.BufferGeometry();
    starsGeometry.setAttribute('position', new THREE.BufferAttribute(starsData, 3));
    scene.add(new THREE.Points(
      starsGeometry,
      new THREE.PointsMaterial({ color: 0xd9e9f2, size: 0.065, transparent: true, opacity: 0.72 }),
    ));

    const azimuth = new THREE.Group();
    scene.add(azimuth);

    const signal = new THREE.Group();
    azimuth.add(signal);
    const signalMaterial = new THREE.MeshBasicMaterial({
      color: accent,
      transparent: true,
      opacity: 0.62,
      depthWrite: false,
    });
    for (let i = 0; i < 3; i += 1) {
      const wave = new THREE.Mesh(new THREE.TorusGeometry(0.15 + i * 0.11, 0.008, 6, 40), signalMaterial);
      wave.position.z = i * 0.035;
      signal.add(wave);
    }
    const receiverLight = new THREE.PointLight(accent, 2.5, 1.8, 2);
    receiverLight.position.copy(signal.position);
    azimuth.add(receiverLight);

    const pointer = new THREE.Vector2();
    const target = new THREE.Vector2();
    let fitSphere: THREE.Sphere | null = null;
    let viewTarget: THREE.Vector3 | null = null;
    const viewDirection = camera.position.clone().sub(new THREE.Vector3(0, 2.45, 0)).normalize();
    let dragging = false;
    const onPointerDown = (event: PointerEvent) => {
      dragging = true;
      pointer.set(event.clientX, event.clientY);
      renderer.domElement.setPointerCapture(event.pointerId);
      renderer.domElement.style.cursor = 'grabbing';
    };
    const onPointerMove = (event: PointerEvent) => {
      if (!dragging) return;
      target.x += (event.clientX - pointer.x) * 0.006;
      target.y = THREE.MathUtils.clamp(target.y + (event.clientY - pointer.y) * 0.004, -0.22, 0.34);
      pointer.set(event.clientX, event.clientY);
    };
    const onPointerUp = () => {
      dragging = false;
      renderer.domElement.style.cursor = 'grab';
    };
    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerup', onPointerUp);
    renderer.domElement.addEventListener('pointercancel', onPointerUp);

    const resize = () => {
      const width = host.clientWidth || 280;
      const height = host.clientHeight || 220;
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.fov = width / height < 1 ? 44 : 39;
      if (fitSphere && viewTarget) {
        const verticalFov = THREE.MathUtils.degToRad(camera.fov);
        const horizontalFov = 2 * Math.atan(Math.tan(verticalFov / 2) * camera.aspect);
        const limitingFov = Math.min(verticalFov, horizontalFov);
        const distance = fitSphere.radius / Math.sin(limitingFov / 2) * 1.02;
        camera.position.copy(viewTarget).addScaledVector(viewDirection, distance);
        camera.lookAt(viewTarget);
      }
      camera.updateProjectionMatrix();
    };
    resize();
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(host);

    const disposeObject = (root: THREE.Object3D) => {
      root.traverse(object => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Line || object instanceof THREE.Points) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach(material => material.dispose());
        }
      });
    };
    const loader = new GLTFLoader();
    loader.load(
      `${import.meta.env.BASE_URL}models/COSMORA_DSN70.glb`,
      gltf => {
        if (disposed) {
          disposeObject(gltf.scene);
          return;
        }

        model = new THREE.Group();
        model.scale.setScalar(0.095);
        model.rotation.x = -Math.PI / 2 + 0.7;
        model.add(gltf.scene);
        model.updateMatrixWorld(true);

        const bounds = new THREE.Box3().setFromObject(model);
        const center = bounds.getCenter(new THREE.Vector3());
        model.position.set(-center.x, -bounds.min.y, -center.z);
        const modelCenter = new THREE.Vector3(0, center.y - bounds.min.y, 0);
        fitSphere = new THREE.Sphere(modelCenter, bounds.getBoundingSphere(new THREE.Sphere()).radius);
        viewTarget = modelCenter;
        const feedPoint = new THREE.Vector3(0, 0, 60.5)
          .multiplyScalar(0.095)
          .applyEuler(model.rotation);
        feedPoint.add(model.position);
        signal.position.copy(feedPoint);
        signal.quaternion.setFromUnitVectors(
          new THREE.Vector3(0, 0, 1),
          new THREE.Vector3(0, 0, 1).applyEuler(model.rotation).normalize(),
        );
        receiverLight.position.copy(feedPoint);
        model.traverse(object => {
          if (object instanceof THREE.Mesh) {
            object.castShadow = true;
            object.receiveShadow = true;
          }
        });
        azimuth.add(model);
        resize();
      },
      undefined,
      error => {
        if (disposed) return;
        console.error('[DsnDishAsset3D] Failed to load the 70-meter antenna model.', error);
        setAssetError(true);
      },
    );

    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    const onMotionChange = (event: MediaQueryListEvent) => { reducedMotion = event.matches; };
    motionQuery.addEventListener('change', onMotionChange);

    const timer = new THREE.Timer();
    timer.connect(document);
    const render = () => {
      if (!visible || disposed) return;
      frameId = requestAnimationFrame(render);
      timer.update();
      const elapsed = timer.getElapsed();
      const delta = Math.min(timer.getDelta(), 0.05);
      target.x = THREE.MathUtils.damp(target.x, 0, 0.09, delta);
      target.y = THREE.MathUtils.damp(target.y, 0, 0.09, delta);
      if (!dragging && !reducedMotion) azimuth.rotation.y += delta * 0.035;
      azimuth.rotation.y += target.x * delta * 0.22;
      azimuth.rotation.x = THREE.MathUtils.damp(azimuth.rotation.x, target.y, 0.12, delta);
      signal.rotation.z = elapsed * 0.34;
      receiverLight.intensity = 2.1 + Math.sin(elapsed * 2.2) * 0.45;
      renderer.render(scene, camera);
    };
    const onVisibilityChange = () => {
      visible = !document.hidden;
      if (visible) {
        timer.reset();
        render();
      } else {
        cancelAnimationFrame(frameId);
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);
    render();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      document.removeEventListener('visibilitychange', onVisibilityChange);
      motionQuery.removeEventListener('change', onMotionChange);
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerup', onPointerUp);
      renderer.domElement.removeEventListener('pointercancel', onPointerUp);
      resizeObserver.disconnect();
      timer.dispose();
      disposeObject(scene);
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [color, station]);

  return (
    <div
      ref={hostRef}
      role="img"
      aria-label={`Interactive 3D 70-meter Deep Space Network antenna at ${station}`}
      className="absolute inset-0"
    >
      {assetError && (
        <div className="absolute inset-0 grid place-items-center bg-[radial-gradient(ellipse_at_50%_35%,#1b3444,#030a10_75%)] text-center font-mono text-[10px] tracking-wider text-[#9fb1a6]">
          DSN 70-METER ANTENNA · {station.toUpperCase()}
        </div>
      )}
    </div>
  );
};
