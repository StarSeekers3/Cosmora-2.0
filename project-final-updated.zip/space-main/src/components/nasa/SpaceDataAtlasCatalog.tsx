import React, { useState } from 'react';
import { Database, ExternalLink, Globe, Sparkles, Filter, CheckCircle2, BookOpen, Layers } from 'lucide-react';
import { playUiClick } from '../../utils/audio';

interface AtlasDataset {
  id: string;
  category: 'Orbital & Ephemeris' | 'Heliophysics' | 'Planetary Geology' | 'Astrophysics & Spectra';
  title: string;
  provider: string;
  description: string;
  updateFrequency: string;
  url: string;
  openAccess: boolean;
  scientificUse: string;
}

const ATLAS_DATASETS: AtlasDataset[] = [
  {
    id: 'sgp4-celestrak',
    category: 'Orbital & Ephemeris',
    title: 'CelesTrak SGP4 NORAD Satellite Two-Line Element (TLE) Sets',
    provider: 'Dr. T.S. Kelso / CelesTrak & US Space Command',
    description: 'High-precision orbital elements for over 25,000 active and defunct satellites, including the ISS, Hubble, Tiangong, and Starlink constellations.',
    updateFrequency: 'Updated every 2–4 hours',
    url: 'https://celestrak.org/',
    openAccess: true,
    scientificUse: 'Real-time satellite ground track propagation, collision conjunction risk screening, and orbital decay tracking.',
  },
  {
    id: 'jpl-horizons',
    category: 'Orbital & Ephemeris',
    title: 'NASA JPL Horizons On-Line Solar System Ephemeris',
    provider: 'NASA Solar System Dynamics Group / Jet Propulsion Laboratory',
    description: 'Computation of high-accuracy positions, velocities, and orbital states for all planets, 1.3 million asteroids, comets, and interplanetary spacecraft.',
    updateFrequency: 'Continuously updated with radar telemetry',
    url: 'https://ssd.jpl.nasa.gov/horizons/',
    openAccess: true,
    scientificUse: 'Deep space trajectory design, planetary flyby guidance, and asteroid impact risk monitoring (Sentry).',
  },
  {
    id: 'nasa-donki',
    category: 'Heliophysics',
    title: 'NASA CCMC Space Weather Database of Notifications, Knowledge, Information (DONKI)',
    provider: 'NASA Goddard Space Flight Center',
    description: 'Chronological catalog of solar flares, coronal mass ejections (CMEs), solar energetic particle (SEP) events, and planetary magnetosphere disturbances.',
    updateFrequency: 'Near real-time (minutes after detection)',
    url: 'https://kauai.ccmc.gsfc.nasa.gov/DONKI/',
    openAccess: true,
    scientificUse: 'Astronaut radiation alert forecasting and power-grid geomagnetic storm warning systems.',
  },
  {
    id: 'nasa-treks',
    category: 'Planetary Geology',
    title: 'NASA Solar System Treks (Moon Trek, Mars Trek, Vesta Trek)',
    provider: 'NASA / Jet Propulsion Laboratory',
    description: 'Interactive GIS cartography suite visualizing digital elevation models, slope hazard layers, and spectrometry across multiple celestial bodies.',
    updateFrequency: 'Quarterly instrument releases',
    url: 'https://trek.nasa.gov/',
    openAccess: true,
    scientificUse: 'Artemis landing candidate site selection and rover traverse route planning.',
  },
  {
    id: 'nasa-pds',
    category: 'Planetary Geology',
    title: 'NASA Planetary Data System (PDS)',
    provider: 'NASA Science Mission Directorate',
    description: 'The primary permanent archive of all digital data returned by NASA planetary exploration missions since Apollo.',
    updateFrequency: 'Peer-reviewed mission archive releases',
    url: 'https://pds.nasa.gov/',
    openAccess: true,
    scientificUse: 'Planetary surface geochemistry, seismology, and atmospheric composition research.',
  },
  {
    id: 'jwst-mast',
    category: 'Astrophysics & Spectra',
    title: 'MAST: Mikulski Archive for Space Telescopes (JWST, Hubble, Kepler, TESS)',
    provider: 'Space Telescope Science Institute (STScI) / NASA',
    description: 'Multi-mission astronomical archive providing calibrated science data products, raw FITS files, and high-level science products.',
    updateFrequency: 'Immediate public domain release',
    url: 'https://mast.stsci.edu/',
    openAccess: true,
    scientificUse: 'Exoplanet transmission spectroscopy, cosmological redshift analysis, and stellar evolution studies.',
  },
];

export const SpaceDataAtlasCatalog: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Orbital & Ephemeris', 'Heliophysics', 'Planetary Geology', 'Astrophysics & Spectra'];

  const filtered = selectedCategory === 'All'
    ? ATLAS_DATASETS
    : ATLAS_DATASETS.filter(d => d.category === selectedCategory);

  return (
    <div className="min-w-0 space-y-4 sm:space-y-6">
      {/* Header Info */}
      <div className="atlas-liquid-panel min-w-0 rounded-2xl border border-[#eef4e6]/20 bg-gradient-to-br from-[#06181d] via-[#0b2830] to-[#06181d] p-3.5 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        <div className="flex min-w-0 items-start gap-3 sm:items-center">
          <div className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl sm:mt-0 sm:h-10 sm:w-10 bg-[#eef4e6]/20 border border-[#eef4e6]/40 grid place-items-center text-white">
            <Database size={19} className="sm:h-[22px] sm:w-[22px]" />
          </div>
          <div>
            <div className="flex min-w-0 flex-wrap items-center gap-2">
              <h3 className="min-w-0 break-words font-display font-bold text-sm leading-snug sm:text-lg text-[#eef4e6]">
                Space Data Atlas: Curated Open Science Directory
              </h3>
              <span className="shrink-0 text-[9px] sm:text-[10px] font-mono px-2 py-0.5 rounded bg-white/20 text-white font-bold">
                NASA SPACE APPS
              </span>
            </div>
            <p className="mt-1 text-[11px] leading-relaxed sm:text-xs text-[#9fb1a6]">
              Curated catalog of authentic NASA, JPL, NOAA, and international open space science datasets.
            </p>
          </div>
        </div>

        <a
          href="https://spacedata.swapniltamse.com/"
          target="_blank"
          rel="noreferrer"
          className="atlas-star-btn w-full sm:w-auto sm:min-w-[13rem]"
        >
          <span className="atlas-star-btn__stars" aria-hidden="true" />
          <span className="atlas-star-btn__orbit" aria-hidden="true" />
          <span className="atlas-star-btn__content">
            <span>Swapnil Tamse Atlas</span>
            <ExternalLink size={13} />
          </span>
        </a>
      </div>

      {/* Filter Chips */}
      <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => { playUiClick(); setSelectedCategory(cat); }}
            aria-pressed={selectedCategory === cat}
            className="atlas-filter-pill min-h-9 px-2.5 sm:px-3 py-1.5 rounded-full text-[10px] sm:text-xs font-mono font-bold transition cursor-pointer"
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Datasets Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map(dataset => (
          <div
            key={dataset.id}
            className="atlas-data-card"
          >
            <div className="atlas-data-card__surface min-w-0 p-3.5 sm:p-5 space-y-3 flex flex-col justify-between">
            <div className="space-y-2">
              <div className="flex flex-wrap items-start justify-between gap-2 text-xs font-mono">
                <span className="max-w-full rounded bg-[#72d1d6]/20 px-2 py-1 text-[9px] leading-snug font-bold text-[#72d1d6] sm:text-[10px]">
                  {dataset.category}
                </span>
                <span className="text-[#66d17a] flex items-center gap-1 text-[11px]">
                  <CheckCircle2 size={12} />
                  Open Access
                </span>
              </div>
              <h4 className="break-words font-display font-bold text-sm leading-snug text-white sm:text-base">
                {dataset.title}
              </h4>
              <div className="break-words text-[10px] leading-relaxed font-mono text-[#d9f36a] sm:text-[11px]">
                Provider: {dataset.provider}
              </div>
              <p className="text-xs text-[#bdc9c0] leading-relaxed">
                {dataset.description}
              </p>
              <div className="p-2.5 rounded-lg bg-white/5 border border-white/5 text-[11px] font-mono text-[#9fb1a6]">
                <strong className="text-white block mb-0.5">Primary Scientific Application:</strong>
                {dataset.scientificUse}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/10 pt-3 text-xs font-mono">
              <span className="text-[10px] text-[#9fb1a6]">{dataset.updateFrequency}</span>
              <a
                href={dataset.url}
                target="_blank"
                rel="noreferrer"
                className="min-h-9 shrink-0 text-[10px] text-[#72d1d6] hover:underline flex items-center gap-1 font-bold sm:text-xs"
              >
                <span>VISIT DATA PORTAL</span>
                <ExternalLink size={12} />
              </a>
            </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
