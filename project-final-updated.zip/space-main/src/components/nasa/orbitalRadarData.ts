import { json2satrec, type OMMJsonObject, type SatRec } from 'satellite.js';

/* -------------------------------------------------------------------------- */
/*  Orbital Radar – constellation catalogue, classification and offline model   */
/* -------------------------------------------------------------------------- */

export const MU = 398600.4418; // km^3 / s^2
export const RE = 6378.137; // equatorial radius, km

export type OrbitClass = 'LEO' | 'MEO' | 'GEO' | 'HEO';
export const ORBIT_CLASSES: OrbitClass[] = ['LEO', 'MEO', 'GEO', 'HEO'];
export const CLASS_META: Record<OrbitClass, { color: string; label: string; range: string }> = {
  LEO: { color: '#4fd8ff', label: 'Low Earth Orbit', range: '< 2,000 km' },
  MEO: { color: '#d9f36a', label: 'Medium Earth Orbit', range: '2,000 – 34,000 km' },
  GEO: { color: '#ffc93c', label: 'Geostationary', range: '≈ 35,786 km' },
  HEO: { color: '#ff7ab8', label: 'Highly Elliptical', range: 'e > 0.25 or beyond GEO' },
};
export const DEFAULT_CLASSES: Record<OrbitClass, boolean> = { LEO: true, MEO: true, GEO: true, HEO: false };

export type GroupId =
  | 'STATIONS' | 'STARLINK' | 'ONEWEB' | 'IRIDIUM' | 'WEATHER'
  | 'GPS' | 'GALILEO' | 'GLONASS' | 'BEIDOU' | 'GEO' | 'DEBRIS';

export interface GroupDef { id: GroupId; label: string; blurb: string; defaultOn: boolean }
export const GROUPS: GroupDef[] = [
  { id: 'STATIONS', label: 'Space Stations', blurb: 'ISS, Tiangong & crewed outposts', defaultOn: true },
  { id: 'STARLINK', label: 'Starlink', blurb: 'SpaceX broadband shells', defaultOn: true },
  { id: 'ONEWEB', label: 'OneWeb', blurb: 'Polar broadband at 1,200 km', defaultOn: true },
  { id: 'IRIDIUM', label: 'Iridium NEXT', blurb: 'Global voice & data', defaultOn: false },
  { id: 'WEATHER', label: 'Weather', blurb: 'NOAA, MetOp, Meteosat…', defaultOn: true },
  { id: 'GPS', label: 'GPS', blurb: 'US navigation (MEO)', defaultOn: true },
  { id: 'GALILEO', label: 'Galileo', blurb: 'European navigation', defaultOn: true },
  { id: 'GLONASS', label: 'GLONASS', blurb: 'Russian navigation', defaultOn: false },
  { id: 'BEIDOU', label: 'BeiDou', blurb: 'Chinese navigation', defaultOn: false },
  { id: 'GEO', label: 'Geostationary Belt', blurb: 'Comms & weather at 35,786 km', defaultOn: true },
  { id: 'DEBRIS', label: 'Debris', blurb: 'Cosmos-2251 collision cloud', defaultOn: false },
];

export interface Sat {
  uid: string;
  name: string;
  norad: number;
  group: GroupId;
  cls: OrbitClass;
  satrec: SatRec;
  incl: number; // deg
  ecc: number;
  periodMin: number;
  sim: boolean;
  // propagated state (ECEF km) – refreshed by the radar tick
  x: number; y: number; z: number;
  lat: number; lon: number; alt: number; speed: number;
  ok: boolean;
}

export function classifyOrbit(meanMotionRevDay: number, ecc: number): OrbitClass {
  const nRad = (meanMotionRevDay * 2 * Math.PI) / 86400;
  const a = Math.cbrt(MU / (nRad * nRad));
  const meanAlt = a - RE;
  if (ecc > 0.25 || meanAlt > 38000) return 'HEO';
  if (meanAlt < 2000) return 'LEO';
  if (meanAlt < 34000) return 'MEO';
  return 'GEO';
}

export function makeSat(omm: OMMJsonObject, group: GroupId, sim: boolean, index: number): Sat | null {
  try {
    const n = Number(omm.MEAN_MOTION);
    const ecc = Number(omm.ECCENTRICITY);
    if (!Number.isFinite(n) || n <= 0) return null;
    const satrec = json2satrec(omm);
    return {
      uid: `${group}:${omm.NORAD_CAT_ID ?? index}`,
      name: String(omm.OBJECT_NAME ?? `OBJECT ${omm.NORAD_CAT_ID}`),
      norad: Number(omm.NORAD_CAT_ID ?? 0),
      group,
      cls: classifyOrbit(n, ecc),
      satrec,
      incl: Number(omm.INCLINATION),
      ecc,
      periodMin: 1440 / n,
      sim,
      x: 0, y: 0, z: 0, lat: 0, lon: 0, alt: 0, speed: 0, ok: false,
    };
  } catch {
    return null;
  }
}

/* ------------------------ deterministic offline model ----------------------- */
function mulberry(seed: number) {
  let a = seed;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const nFromAlt = (altKm: number) => 86400 / (2 * Math.PI * Math.sqrt(Math.pow(RE + altKm, 3) / MU));

interface Plane {
  planes: number; perPlane: number; incl: number; n: number; ecc?: number; argp?: number; label: string; jitter?: number;
}
const PLANE_SPECS: Partial<Record<GroupId, Plane[]>> = {
  STARLINK: [{ planes: 22, perPlane: 14, incl: 53.05, n: nFromAlt(550), label: 'STARLINK' }, { planes: 6, perPlane: 10, incl: 97.6, n: nFromAlt(560), label: 'STARLINK' }],
  ONEWEB: [{ planes: 12, perPlane: 20, incl: 87.9, n: nFromAlt(1200), label: 'ONEWEB' }],
  IRIDIUM: [{ planes: 6, perPlane: 11, incl: 86.4, n: nFromAlt(780), label: 'IRIDIUM' }],
  WEATHER: [{ planes: 4, perPlane: 8, incl: 98.7, n: nFromAlt(830), label: 'WX-LEO' }],
  GPS: [{ planes: 6, perPlane: 5, incl: 55, n: 2.00565, ecc: 0.005, label: 'GPS' }],
  GALILEO: [{ planes: 3, perPlane: 8, incl: 56, n: 1.70475, ecc: 0.0005, label: 'GALILEO' }],
  GLONASS: [{ planes: 3, perPlane: 8, incl: 64.8, n: 2.13103, ecc: 0.001, label: 'GLONASS' }],
  BEIDOU: [
    { planes: 3, perPlane: 8, incl: 55, n: 1.86232, ecc: 0.001, label: 'BEIDOU-MEO' },
    { planes: 3, perPlane: 1, incl: 55, n: 1.0027, ecc: 0.002, label: 'BEIDOU-IGSO' },
  ],
};

export function simulatedElements(group: GroupId, nowMs: number): OMMJsonObject[] {
  const epoch = new Date(nowMs).toISOString().replace('Z', '');
  const rnd = mulberry(group.split('').reduce((s, c) => s * 31 + c.charCodeAt(0), 7));
  const out: OMMJsonObject[] = [];
  let id = 0;
  const base = 900000 + GROUPS.findIndex(g => g.id === group) * 1000;
  const push = (name: string, n: number, ecc: number, incl: number, raan: number, argp: number, ma: number) => {
    id += 1;
    out.push({
      OBJECT_NAME: `${name} (SIM)`, OBJECT_ID: `SIM-${base + id}`, EPOCH: epoch, MEAN_MOTION: n, ECCENTRICITY: ecc,
      INCLINATION: incl, RA_OF_ASC_NODE: raan % 360, ARG_OF_PERICENTER: argp % 360, MEAN_ANOMALY: ma % 360,
      EPHEMERIS_TYPE: 0, CLASSIFICATION_TYPE: 'U', NORAD_CAT_ID: base + id, ELEMENT_SET_NO: 999, REV_AT_EPOCH: 1,
      BSTAR: 0, MEAN_MOTION_DOT: 0, MEAN_MOTION_DDOT: 0,
    } as unknown as OMMJsonObject);
  };

  const specs = PLANE_SPECS[group];
  if (specs) {
    for (const sp of specs) {
      for (let p = 0; p < sp.planes; p++) {
        for (let s = 0; s < sp.perPlane; s++) {
          push(`${sp.label}-${id + 1}`, sp.n, sp.ecc ?? 0.0002, sp.incl, (360 * p) / sp.planes, 0, (360 * s) / sp.perPlane + (p % 2) * (180 / sp.perPlane));
        }
      }
    }
  } else if (group === 'STATIONS') {
    push('ISS (ZARYA)', 15.5, 0.0004, 51.64, 120, 80, 40);
    push('CSS (TIANHE)', 15.6, 0.0006, 41.47, 210, 100, 200);
    push('PROGRESS-SIM', 15.5, 0.0004, 51.64, 121, 80, 46);
  } else if (group === 'GEO') {
    for (let i = 0; i < 110; i++) push(`GEOSAT-${i + 1}`, 1.00273, 0.0002, rnd() * 4, 0, 0, (360 * i) / 110 + rnd());
    for (let i = 0; i < 3; i++) push(`MOLNIYA-${i + 1}`, 2.0058, 0.74, 63.4, 40 + i * 120, 270, i * 90); // HEO examples
  } else if (group === 'DEBRIS') {
    for (let i = 0; i < 220; i++) push(`DEB-${i + 1}`, nFromAlt(760 + rnd() * 70), 0.002, 74 + rnd() * 0.5, rnd() * 360, rnd() * 360, rnd() * 360);
  }
  return out;
}
