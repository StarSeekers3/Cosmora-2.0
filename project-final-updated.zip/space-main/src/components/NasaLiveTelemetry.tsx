import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Radio,
  Sun,
  Moon,
  Camera,
  Database,
  Globe,
  Satellite,
  Activity,
  Layers,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { playUiClick } from '../utils/audio';
import { marsEarth, marsLs, marsSeasonNorth, perseveranceSol, voyager1 } from '../utils/astro';
import { DsnPanel } from './nasa/DsnPanel';
import { TransitLab } from './nasa/TransitLab';
import { MarsStation } from './nasa/MarsStation';
import { AsteroidRadar } from './nasa/AsteroidRadar';
import { SpaceWeatherRadar } from './nasa/SpaceWeatherRadar';
import { PlanetaryTrekExplorer } from './nasa/PlanetaryTrekExplorer';
import { NasaMediaExplorer } from './nasa/NasaMediaExplorer';
import { SpaceDataAtlasCatalog } from './nasa/SpaceDataAtlasCatalog';
import { NasaLiveTelemetry3D } from './NasaLiveTelemetry3D';
import { OrbitalRadar3D } from './OrbitalRadar3D';

interface NasaLiveTelemetryProps {
  onBackToDeck: () => void;
  initialTab?: 'orbits' | 'radar' | 'weather' | 'trek' | 'media' | 'atlas';
}

const Chip: React.FC<{ label: string; value: string; accent: string }> = ({ label, value, accent }) => (
  <div className="min-w-0 rounded-xl border border-white/10 bg-[#040e12]/90 px-2.5 py-2 sm:px-3">
    <div className="truncate text-[8px] sm:text-[9px] font-mono tracking-[0.12em] text-[#9fb1a6]">{label}</div>
    <div className="mt-0.5 truncate text-xs sm:text-sm font-mono font-bold tabular-nums" style={{ color: accent }}>{value}</div>
  </div>
);

export const NasaLiveTelemetry: React.FC<NasaLiveTelemetryProps> = ({ onBackToDeck, initialTab = 'orbits' }) => {
  const [activeTab, setActiveTab] = useState<'orbits' | 'radar' | 'weather' | 'trek' | 'media' | 'atlas'>(initialTab);
  const [show3dTelemetry, setShow3dTelemetry] = useState(false);
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(iv);
  }, []);

  const v1 = voyager1(now);
  const mars = marsEarth(now);

  if (show3dTelemetry) {
    return (
      <NasaLiveTelemetry3D
        onBackToDeck={() => setShow3dTelemetry(false)}
      />
    );
  }

  return (
    <div className="relative z-10 max-w-6xl mx-auto px-3 sm:px-6 py-4 sm:py-6 md:py-10 space-y-5 sm:space-y-6 md:space-y-8 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <button
          onClick={() => { playUiClick(); onBackToDeck(); }}
          className="flex items-center gap-1.5 text-xs font-mono text-[#9fb1a6] hover:text-[#d9f36a] transition-colors cursor-pointer self-start"
        >
          <ArrowLeft size={14} />
          <span>RETURN TO FLIGHT PLAN</span>
        </button>

        <div className="flex w-full flex-wrap items-center justify-between gap-2 sm:w-auto sm:justify-end sm:gap-3">
          <button
            onClick={() => { playUiClick(); setShow3dTelemetry(true); }}
            className="mission-glass-button flex min-h-10 items-center gap-2 rounded-xl border border-[#72d1d6]/40 bg-[#0b1c20] px-3 text-xs font-mono font-bold text-[#72d1d6] transition-colors hover:border-[#72d1d6] hover:bg-[#0f262c] cursor-pointer"
          >
            <Globe size={14} />
            <span>OPEN 3D TELEMETRY</span>
          </button>
          <div className="mission-glass-status flex min-h-10 min-w-0 items-center gap-2 rounded-xl border border-white/10 bg-white/[0.035] px-3 text-[10px] sm:text-xs font-mono font-bold text-[#72d1d6]">
            <Radio size={14} className="shrink-0" />
            <span className="truncate sm:hidden">NASA LIVE · SPACE DATA</span>
            <span className="hidden truncate sm:inline">NASA MISSION CONTROL · SPACE DATA ATLAS</span>
            <span className="ml-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[#d9f36a] shadow-[0_0_8px_#d9f36a]" />
          </div>
        </div>
      </div>

      {/* Mission control real-time ribbon */}
      <div className="mission-glass-ribbon grid grid-cols-2 gap-2 rounded-2xl border border-white/10 bg-gradient-to-r from-[#06151a] via-[#0a2127] to-[#06151a] p-2.5 shadow-xl sm:grid-cols-3 sm:p-3 xl:grid-cols-5">
        <Chip label="UTC" value={now.toISOString().substring(11, 19)} accent="#ffffff" />
        <Chip label="PERSEVERANCE" value={`SOL ${perseveranceSol(now).toLocaleString()}`} accent="#ef7144" />
        <Chip label="MARS SEASON" value={`${marsSeasonNorth(marsLs(now)).replace('Northern ', 'N. ')} · Ls ${marsLs(now).toFixed(0)}°`} accent="#ffc93c" />
        <Chip label="EARTH → MARS" value={`${mars.lightMinutes.toFixed(1)} light-min`} accent="#72d1d6" />
        <Chip label="VOYAGER 1" value={`${v1.au.toFixed(2)} AU`} accent="#d9f36a" />
      </div>

      {/* Premium Telemetry & Space Data Atlas Navigation Sub-Tabs */}
      <div role="tablist" aria-label="NASA Live and Space Data sections" className="telemetry-tab-rail -mx-3 flex items-center gap-2 overflow-x-auto border-b border-white/10 px-3 pb-3 sm:mx-0 sm:flex-wrap sm:overflow-visible sm:px-0 sm:pb-4">
        <button
          onClick={() => { playUiClick(); setActiveTab('orbits'); }}
          role="tab" aria-selected={activeTab === 'orbits'} className={`min-h-10 shrink-0 whitespace-nowrap px-3 sm:px-4 py-2.5 rounded-xl text-[10px] sm:text-xs font-mono font-bold tracking-wide transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'orbits'
              ? 'bg-[#72d1d6] text-[#061211] shadow-[0_0_20px_rgba(114,209,214,0.35)]'
              : 'bg-[#0b1c20] hover:bg-[#0f262c] text-[#9fb1a6] border border-white/10'
          }`}
        >
          <Satellite size={15} />
          <span>DEEP SPACE &amp; SATELLITES</span>
        </button>

        <button
          onClick={() => { playUiClick(); setActiveTab('radar'); }}
          role="tab" aria-selected={activeTab === 'radar'} className={`min-h-10 shrink-0 whitespace-nowrap px-3 sm:px-4 py-2.5 rounded-xl text-[10px] sm:text-xs font-mono font-bold tracking-wide transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'radar'
              ? 'bg-[#4fd8ff] text-[#061211] shadow-[0_0_20px_rgba(79,216,255,0.35)]'
              : 'bg-[#0b1c20] hover:bg-[#0f262c] text-[#9fb1a6] border border-white/10'
          }`}
        >
          <Globe size={15} />
          <span>ORBITAL RADAR · 3D</span>
        </button>
        <button
          onClick={() => { playUiClick(); setActiveTab('weather'); }}
          role="tab" aria-selected={activeTab === 'weather'} className={`min-h-10 shrink-0 whitespace-nowrap px-3 sm:px-4 py-2.5 rounded-xl text-[10px] sm:text-xs font-mono font-bold tracking-wide transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'weather'
              ? 'bg-[#ff9838] text-[#061211] shadow-[0_0_20px_rgba(255,152,56,0.35)]'
              : 'bg-[#0b1c20] hover:bg-[#0f262c] text-[#9fb1a6] border border-white/10'
          }`}
        >
          <Sun size={15} />
          <span>DONKI SPACE WEATHER</span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#ff9838] animate-ping" />
        </button>

        <button
          onClick={() => { playUiClick(); setActiveTab('trek'); }}
          role="tab" aria-selected={activeTab === 'trek'} className={`min-h-10 shrink-0 whitespace-nowrap px-3 sm:px-4 py-2.5 rounded-xl text-[10px] sm:text-xs font-mono font-bold tracking-wide transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'trek'
              ? 'bg-[#d9f36a] text-[#061211] shadow-[0_0_20px_rgba(217,243,106,0.35)]'
              : 'bg-[#0b1c20] hover:bg-[#0f262c] text-[#9fb1a6] border border-white/10'
          }`}
        >
          <Moon size={15} />
          <span>MOON &amp; MARS TREK</span>
        </button>

        <button
          onClick={() => { playUiClick(); setActiveTab('media'); }}
          role="tab" aria-selected={activeTab === 'media'} className={`min-h-10 shrink-0 whitespace-nowrap px-3 sm:px-4 py-2.5 rounded-xl text-[10px] sm:text-xs font-mono font-bold tracking-wide transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'media'
              ? 'bg-[#66d17a] text-[#061211] shadow-[0_0_20px_rgba(102,209,122,0.35)]'
              : 'bg-[#0b1c20] hover:bg-[#0f262c] text-[#9fb1a6] border border-white/10'
          }`}
        >
          <Camera size={15} />
          <span>NASA MEDIA ARCHIVE</span>
        </button>

        <button
          onClick={() => { playUiClick(); setActiveTab('atlas'); }}
          role="tab" aria-selected={activeTab === 'atlas'} className={`min-h-10 shrink-0 whitespace-nowrap px-3 sm:px-4 py-2.5 rounded-xl text-[10px] sm:text-xs font-mono font-bold tracking-wide transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'atlas'
              ? 'bg-[#eef4e6] text-[#061211] shadow-[0_0_20px_rgba(255,255,255,0.35)]'
              : 'bg-[#0b1c20] hover:bg-[#0f262c] text-[#9fb1a6] border border-white/10'
          }`}
        >
          <Database size={15} />
          <span>SPACE DATA ATLAS</span>
        </button>
      </div>

      {/* Tab 1: Deep Space & Orbits */}
      {activeTab === 'orbits' && (
        <div className="space-y-5 sm:space-y-8 animate-in fade-in duration-200">
          <DsnPanel />
          <div className="grid grid-cols-1 xl:grid-cols-1 gap-8">
            <TransitLab />
            <MarsStation />
            <AsteroidRadar />
          </div>
        </div>
      )}

      {activeTab === 'radar' && (
        <div className="-mx-3 overflow-hidden rounded-none border-y border-[#4fd8ff]/20 shadow-2xl animate-in fade-in duration-200 sm:mx-0 sm:rounded-2xl sm:border">
          <OrbitalRadar3D onBackToDeck={() => setActiveTab('orbits')} />
        </div>
      )}
      {/* Tab 2: DONKI Space Weather & Radiation */}
      {activeTab === 'weather' && (
        <div className="animate-in fade-in duration-200">
          <SpaceWeatherRadar />
        </div>
      )}

      {/* Tab 3: Moon & Mars Trek Surface Explorer */}
      {activeTab === 'trek' && (
        <div className="animate-in fade-in duration-200">
          <PlanetaryTrekExplorer />
        </div>
      )}

      {/* Tab 4: NASA Media Library */}
      {activeTab === 'media' && (
        <div className="animate-in fade-in duration-200">
          <NasaMediaExplorer />
        </div>
      )}

      {/* Tab 5: Space Data Atlas Catalog */}
      {activeTab === 'atlas' && (
        <div className="animate-in fade-in duration-200">
          <SpaceDataAtlasCatalog />
        </div>
      )}

      <footer className="text-[11px] text-[#9fb1a6] font-mono leading-relaxed text-center pt-4 border-t border-white/5 space-y-1">
        <div>
          Real-time telemetry powered by <strong>NASA CCMC DONKI</strong>, <strong>NASA Solar System Treks</strong>, <strong>NASA Images API</strong>, and <strong>CelesTrak SGP4</strong>.
        </div>
        <div>
          Curated and inspired by the <a href="https://spacedata.swapniltamse.com/" target="_blank" rel="noreferrer" className="text-[#d9f36a] hover:underline font-bold">Space Data Atlas by Swapnil Tamse</a> for the NASA Space Apps Challenge.
        </div>
      </footer>
    </div>
  );
};
