import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

type OutpostPlanet = 'moon' | 'mars';
type OutpostHabitat = 'inflatable' | 'regolith' | 'lavatube';
type SceneView = 'exterior' | 'interior';

interface OutpostSceneProps {
  planet: OutpostPlanet;
  habitat: OutpostHabitat;
  sol: number;
  sunlight: number;
  compact?: boolean;
}

const PLANET_LABEL: Record<OutpostPlanet, string> = {
  moon: 'SHACKLETON CRATER · LUNAR SOUTH POLE',
  mars: 'JEZERO CRATER · MARS',
};

const HABITAT_LABEL: Record<OutpostHabitat, string> = {
  inflatable: 'INFLATABLE TRANS-HAB',
  regolith: 'SINTERED REGOLITH DOME',
  lavatube: 'LAVA TUBE SHELTER',
};

function seededNoise(x: number, z: number) {
  return (
    Math.sin(x * 0.42 + Math.sin(z * 0.16)) * 0.34 +
    Math.sin(z * 0.75 + Math.cos(x * 0.22)) * 0.2 +
    Math.sin((x + z) * 1.8) * 0.055
  );
}

export const OutpostScene: React.FC<OutpostSceneProps> = ({
  planet,
  habitat,
  sol,
  sunlight,
  compact = false,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [view, setView] = useState<SceneView>('exterior');
  const [webglError, setWebglError] = useState(false);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: 'low-power',
      });
    } catch (error) {
      console.error('[OutpostScene] Unable to initialize WebGL rendering.', error);
      setWebglError(true);
      return;
    }

    setWebglError(false);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.18;
    mount.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(planet === 'mars' ? 0x321a14 : 0x080e19, 24, 84);

    const camera = new THREE.PerspectiveCamera(38, mount.clientWidth / mount.clientHeight, 0.1, 120);
    if (view === 'exterior') {
      camera.position.set(0, 7.5, 18);
      camera.lookAt(0, 1.1, 0);
    } else {
      camera.position.set(0, 5.2, 10.4);
      camera.lookAt(0, 2.2, 0);
    }

    const hemisphere = new THREE.HemisphereLight(
      planet === 'mars' ? 0xe9a17c : 0xc3d5ec,
      planet === 'mars' ? 0x39211a : 0x171b23,
      0.55
    );
    scene.add(hemisphere);

    const sunlightValue = THREE.MathUtils.clamp(sunlight / 100, 0.08, 1);
    const sun = new THREE.DirectionalLight(planet === 'mars' ? 0xffc28a : 0xffe6bc, 0.35 + sunlightValue * 2.15);
    sun.position.set(-12, 14, 8);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.camera.left = -18;
    sun.shadow.camera.right = 18;
    sun.shadow.camera.top = 18;
    sun.shadow.camera.bottom = -18;
    sun.shadow.bias = -0.0002;
    scene.add(sun);
    scene.add(sun.target);

    const starGeometry = new THREE.BufferGeometry();
    const starPositions = new Float32Array(1500 * 3);
    for (let i = 0; i < starPositions.length; i += 3) {
      const theta = Math.random() * Math.PI * 2;
      const y = Math.random() * 38 + 4;
      const radius = 72 + Math.random() * 12;
      starPositions[i] = Math.cos(theta) * radius;
      starPositions[i + 1] = y;
      starPositions[i + 2] = Math.sin(theta) * radius - 24;
    }
    starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    scene.add(new THREE.Points(
      starGeometry,
      new THREE.PointsMaterial({ color: 0xd9e8ff, size: 0.12, sizeAttenuation: true, transparent: true, opacity: 0.82 })
    ));

    const exterior = new THREE.Group();
    const interior = new THREE.Group();
    scene.add(exterior, interior);
    exterior.visible = view === 'exterior';
    interior.visible = view === 'interior';

    const standardMaterial = (color: THREE.ColorRepresentation, roughness = 0.85, metalness = 0) =>
      new THREE.MeshStandardMaterial({ color, roughness, metalness });

    const addBox = (
      parent: THREE.Object3D,
      size: [number, number, number],
      position: [number, number, number],
      material: THREE.Material,
      castShadow = true
    ) => {
      const object = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
      object.position.set(...position);
      object.castShadow = castShadow;
      object.receiveShadow = true;
      parent.add(object);
      return object;
    };

    const addSphere = (
      parent: THREE.Object3D,
      radius: number,
      position: [number, number, number],
      material: THREE.Material,
      scale: [number, number, number] = [1, 1, 1],
      segments = 18
    ) => {
      const object = new THREE.Mesh(new THREE.SphereGeometry(radius, segments, Math.max(8, segments >> 1)), material);
      object.position.set(...position);
      object.scale.set(...scale);
      object.castShadow = true;
      object.receiveShadow = true;
      parent.add(object);
      return object;
    };

    const addCylinder = (
      parent: THREE.Object3D,
      radiusTop: number,
      radiusBottom: number,
      height: number,
      position: [number, number, number],
      material: THREE.Material,
      radialSegments = 16
    ) => {
      const object = new THREE.Mesh(
        new THREE.CylinderGeometry(radiusTop, radiusBottom, height, radialSegments),
        material
      );
      object.position.set(...position);
      object.castShadow = true;
      object.receiveShadow = true;
      parent.add(object);
      return object;
    };

    const terrainGeometry = new THREE.PlaneGeometry(90, 72, 140, 110);
    const terrainPositions = terrainGeometry.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < terrainPositions.count; i += 1) {
      const x = terrainPositions.getX(i);
      const z = terrainPositions.getY(i);
      let relief = seededNoise(x, z) * (planet === 'mars' ? 1.35 : 0.9);
      for (const crater of [[-12, -9, 3.3], [8, -14, 2.1], [15, 5, 2.6], [-19, 9, 2.4]] as const) {
        const distance = Math.hypot(x - crater[0], z - crater[1]);
        const rim = Math.exp(-Math.pow((distance - crater[2]) / 0.7, 2)) * 0.42;
        const basin = Math.exp(-Math.pow(distance / crater[2], 4)) * 0.55;
        relief += rim - basin;
      }
      terrainPositions.setZ(i, relief);
    }
    terrainGeometry.computeVertexNormals();
    terrainGeometry.rotateX(-Math.PI / 2);
    const terrain = new THREE.Mesh(
      terrainGeometry,
      standardMaterial(planet === 'mars' ? 0x8c4330 : 0x666a70, 1)
    );
    terrain.position.y = -0.42;
    terrain.receiveShadow = true;
    exterior.add(terrain);

    const horizonMaterial = standardMaterial(planet === 'mars' ? 0x682f26 : 0x41454e, 1);
    for (let ridge = 0; ridge < 3; ridge += 1) {
      const points: THREE.Vector3[] = [];
      for (let i = 0; i <= 42; i += 1) {
        const x = -46 + i * 2.2;
        const z = -22 - ridge * 7;
        const y = 0.5 + Math.sin(i * 0.48 + ridge) * (1.3 + ridge * 0.35) + Math.sin(i * 0.17) * 2.2;
        points.push(new THREE.Vector3(x, y, z));
      }
      const shape = new THREE.Shape();
      shape.moveTo(points[0].x, -1.5);
      points.forEach(point => shape.lineTo(point.x, point.y));
      shape.lineTo(points[points.length - 1].x, -1.5);
      shape.closePath();
      const ridgeMesh = new THREE.Mesh(
        new THREE.ShapeGeometry(shape, 32),
        horizonMaterial.clone()
      );
      ridgeMesh.position.z = -22 - ridge * 7;
      ridgeMesh.receiveShadow = true;
      exterior.add(ridgeMesh);
    }

    const rockMaterial = standardMaterial(planet === 'mars' ? 0x633327 : 0x42464c, 1);
    for (let i = 0; i < 54; i += 1) {
      const angle = i * 2.399;
      const radius = 4 + ((i * 13) % 17) * 0.48;
      const rock = addSphere(
        exterior,
        0.3 + (i % 5) * 0.08,
        [Math.cos(angle) * radius, -0.02, Math.sin(angle) * radius * 0.62],
        rockMaterial,
        [1.3, 0.65 + (i % 3) * 0.12, 0.9],
        8
      );
      rock.rotation.set(i * 0.27, i * 0.61, i * 0.13);
    }

    const hull = standardMaterial(habitat === 'lavatube' ? 0x4b4d50 : 0xc7c8bd, 0.68, 0.12);
    const trim = standardMaterial(0x263645, 0.4, 0.72);
    const darkGlass = new THREE.MeshStandardMaterial({
      color: 0x142a37,
      roughness: 0.2,
      metalness: 0.55,
      emissive: 0x0b2533,
      emissiveIntensity: 0.45,
    });
    const habitatGroup = new THREE.Group();
    habitatGroup.position.set(-3.8, 0, -2.6);
    exterior.add(habitatGroup);

    if (habitat === 'inflatable') {
      const module = addSphere(habitatGroup, 1, [0, 1.3, 0], hull, [2.4, 1.22, 1.2], 32);
      module.scale.z = 1;
      addCylinder(habitatGroup, 0.52, 0.52, 1.4, [-2.4, 0.7, 0], trim, 18).rotation.z = Math.PI / 2;
      addCylinder(habitatGroup, 0.52, 0.52, 1.2, [2.1, 0.68, 0], trim, 18).rotation.z = Math.PI / 2;
    } else if (habitat === 'lavatube') {
      const arch = addSphere(habitatGroup, 1, [0, 0.95, -0.2], rockMaterial, [2.7, 1.55, 1.55], 28);
      arch.material = rockMaterial;
      addSphere(habitatGroup, 1, [0.25, 0.78, 0.78], darkGlass, [0.9, 0.75, 0.12], 24);
      addCylinder(habitatGroup, 0.55, 0.75, 0.8, [2.35, 0.38, 0.2], trim, 16).rotation.z = Math.PI / 2;
    } else {
      addCylinder(habitatGroup, 1.55, 1.7, 1.3, [0, 0.7, 0], hull, 32);
      addSphere(habitatGroup, 1.55, [0, 1.35, 0], hull, [1, 0.76, 1], 32);
      addCylinder(habitatGroup, 0.68, 0.7, 0.85, [2.25, 0.42, 0.05], trim, 20).rotation.z = Math.PI / 2;
      addSphere(habitatGroup, 0.36, [0, 1.32, 1.49], darkGlass, [1.1, 0.88, 0.16], 24);
      addSphere(habitatGroup, 0.36, [-1.03, 1.32, 1.08], darkGlass, [0.9, 0.88, 0.14], 24);
      addSphere(habitatGroup, 0.36, [1.03, 1.32, 1.08], darkGlass, [0.9, 0.88, 0.14], 24);
    }

    addBox(habitatGroup, [0.55, 0.18, 0.8], [-0.95, 0.12, 0.1], trim);
    const antenna = addCylinder(habitatGroup, 0.035, 0.055, 2.1, [0, 2.65, -0.55], trim, 8);
    antenna.rotation.z = -0.08;
    addSphere(habitatGroup, 0.45, [0, 3.68, -0.55], standardMaterial(0xe4e8e4, 0.45, 0.4), [1, 0.48, 0.55], 16);
    addCylinder(habitatGroup, 0.025, 0.025, 1.3, [0, 3.68, -0.55], trim, 8).rotation.z = Math.PI / 2;

    const solarArray = new THREE.Group();
    solarArray.position.set(4.5, 0, -2.1);
    exterior.add(solarArray);
    const solarMaterial = new THREE.MeshStandardMaterial({
      color: 0x174c78,
      roughness: 0.32,
      metalness: 0.5,
      emissive: 0x082847,
      emissiveIntensity: 0.35,
    });
    const panelGroup = new THREE.Group();
    panelGroup.position.y = 1.55;
    panelGroup.rotation.x = -0.42;
    solarArray.add(panelGroup);
    for (let row = 0; row < 2; row += 1) {
      for (let col = 0; col < 3; col += 1) {
        const panel = addBox(panelGroup, [1.45, 0.06, 1.12], [(col - 1) * 1.53, 0, (row - 0.5) * 1.2], solarMaterial);
        const frame = standardMaterial(0x9ab5bd, 0.4, 0.8);
        for (let line = -1; line <= 1; line += 1) {
          addBox(panelGroup, [0.018, 0.018, 1.08], [(col - 1) * 1.53 + line * 0.36, 0.042, (row - 0.5) * 1.2], frame, false);
        }
        addBox(panelGroup, [1.42, 0.018, 0.018], [(col - 1) * 1.53, 0.045, row * 1.2], frame, false);
        panel.castShadow = true;
      }
    }
    addCylinder(solarArray, 0.055, 0.08, 1.55, [0, 0.75, 0], trim, 10);
    addCylinder(solarArray, 0.035, 0.055, 3.5, [-2.6, 0.78, 0], trim, 8).rotation.z = -Math.PI / 2;
    addCylinder(solarArray, 0.035, 0.055, 3.5, [2.6, 0.78, 0], trim, 8).rotation.z = -Math.PI / 2;

    const rover = new THREE.Group();
    rover.position.set(0.35, 0, 2.5);
    exterior.add(rover);
    const roverBody = standardMaterial(planet === 'mars' ? 0xd7d0bc : 0xbfc6c1, 0.55, 0.28);
    addBox(rover, [1.55, 0.5, 1.05], [0, 0.92, 0], roverBody);
    addBox(rover, [0.76, 0.55, 0.86], [0.05, 1.42, -0.04], darkGlass);
    addBox(rover, [0.9, 0.08, 0.95], [0, 1.72, 0], trim);
    for (const x of [-0.62, 0.62]) {
      for (const z of [-0.58, 0.58]) {
        const wheel = addCylinder(rover, 0.35, 0.35, 0.2, [x, 0.45, z], standardMaterial(0x22272b, 1), 12);
        wheel.rotation.x = Math.PI / 2;
        for (let spoke = 0; spoke < 6; spoke += 1) {
          const angle = (spoke / 6) * Math.PI * 2;
          addBox(rover, [0.045, 0.045, 0.22], [x + Math.sin(angle) * 0.31, 0.45 + Math.cos(angle) * 0.31, z], trim, false);
        }
      }
    }
    const mast = addCylinder(rover, 0.045, 0.055, 1.4, [0, 2.35, -0.14], trim, 8);
    mast.rotation.z = -0.18;
    addBox(rover, [0.52, 0.28, 0.18], [0, 2.95, -0.04], standardMaterial(0x182b35, 0.35, 0.45));

    const astronautMaterial = standardMaterial(0xe0ded4, 0.66, 0.08);
    const helmetMaterial = new THREE.MeshStandardMaterial({
      color: 0xdbe8e9,
      roughness: 0.18,
      metalness: 0.45,
      emissive: 0x23414c,
      emissiveIntensity: 0.18,
    });
    for (let i = 0; i < 2; i += 1) {
      const crew = new THREE.Group();
      crew.position.set(2.15 + i * 0.8, 0, 1.6 - i * 0.55);
      exterior.add(crew);
      addSphere(crew, 0.32, [0, 1.25, 0], astronautMaterial, [0.82, 1.2, 0.62], 14);
      addSphere(crew, 0.22, [0, 1.85, 0], helmetMaterial, [1, 1.02, 0.92], 16);
      addBox(crew, [0.54, 0.13, 0.42], [0, 1.1, 0], standardMaterial(0xc87839, 0.7, 0.1));
      for (const side of [-1, 1]) {
        const leg = addCylinder(crew, 0.12, 0.14, 0.52, [side * 0.13, 0.68, 0], astronautMaterial, 8);
        leg.rotation.z = side * -0.08;
        const arm = addCylinder(crew, 0.09, 0.12, 0.48, [side * 0.34, 1.18, 0.02], astronautMaterial, 8);
        arm.rotation.z = side * -0.38;
      }
      addBox(crew, [0.27, 0.11, 0.31], [-0.04, 0.38, 0.05], trim);
    }

    const antennaMast = addCylinder(exterior, 0.04, 0.06, 3.8, [7.6, 1.2, -4.1], trim, 8);
    antennaMast.rotation.z = -0.07;
    const dish = addSphere(exterior, 0.7, [7.6, 3.2, -4.1], standardMaterial(0xb9c3c0, 0.35, 0.72), [1, 0.16, 0.78], 18);
    dish.rotation.z = -0.35;

    const interiorWall = standardMaterial(planet === 'mars' ? 0xb9a797 : 0xaab5b6, 0.72, 0.08);
    const interiorFloor = standardMaterial(planet === 'mars' ? 0x55403a : 0x384750, 0.9, 0.04);
    const interiorGlow = new THREE.MeshStandardMaterial({
      color: 0xb8e6e9,
      roughness: 0.4,
      emissive: 0x5ca8b8,
      emissiveIntensity: 1.15,
    });
    addBox(interior, [13, 0.28, 8], [0, 0, 0], interiorFloor);
    addBox(interior, [13, 5.6, 0.26], [0, 2.8, -3.8], interiorWall);
    addBox(interior, [0.26, 5.6, 8], [-6.4, 2.8, 0], interiorWall);
    addBox(interior, [0.26, 5.6, 8], [6.4, 2.8, 0], interiorWall);
    for (let i = 0; i < 4; i += 1) {
      addBox(interior, [2.45, 0.12, 0.12], [-4.6 + i * 3.05, 4.65, -3.6], trim);
      addBox(interior, [2.1, 1.05, 0.12], [-4.6 + i * 3.05, 3.55, -3.58], darkGlass, false);
    }
    for (let level = 0; level < 3; level += 1) {
      for (let side = 0; side < 2; side += 1) {
        const x = side === 0 ? -4.55 : 4.55;
        addBox(interior, [2.1, 0.13, 2.1], [x, 1.25 + level * 0.8, -0.6], trim);
        for (let plant = 0; plant < 4; plant += 1) {
          const leaf = addSphere(
            interior,
            0.2,
            [x - 0.72 + plant * 0.48, 1.48 + level * 0.8, -0.6 + (plant % 2) * 0.38],
            standardMaterial(plant % 2 ? 0x59a86a : 0x82bd70, 0.92),
            [0.64, 1.2, 0.64],
            9
          );
          leaf.castShadow = false;
        }
      }
    }
    addBox(interior, [2.2, 0.12, 1.15], [0, 1.2, 1.8], trim);
    addBox(interior, [2.2, 0.85, 0.12], [0, 1.68, 2.28], darkGlass, false);
    addBox(interior, [1.1, 1.35, 0.72], [-2.1, 0.85, 1.2], interiorWall);
    addBox(interior, [1.1, 1.35, 0.72], [-2.1, 2.32, 1.2], standardMaterial(0x93aeb3, 0.8));
    addBox(interior, [0.08, 0.6, 0.46], [-2.1, 1.73, 1.6], standardMaterial(0x233640, 0.3, 0.4), false);
    const interiorLamp = new THREE.PointLight(0xbde9ef, 32, 18, 2);
    interiorLamp.position.set(0, 4.65, 0);
    interior.add(interiorLamp);
    const warmLamp = new THREE.PointLight(0xffbf73, 8, 10, 2);
    warmLamp.position.set(0, 2.9, 2.5);
    interior.add(warmLamp);

    const dustCount = planet === 'mars' ? 700 : 120;
    const dustPositions = new Float32Array(dustCount * 3);
    const dustVelocities = new Float32Array(dustCount);
    for (let i = 0; i < dustCount; i += 1) {
      dustPositions[i * 3] = (Math.random() - 0.5) * 36;
      dustPositions[i * 3 + 1] = Math.random() * 7;
      dustPositions[i * 3 + 2] = (Math.random() - 0.5) * 24;
      dustVelocities[i] = 0.12 + Math.random() * 0.38;
    }
    const dustGeometry = new THREE.BufferGeometry();
    dustGeometry.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
    const dust = new THREE.Points(
      dustGeometry,
      new THREE.PointsMaterial({
        color: planet === 'mars' ? 0xffb27a : 0xc2cbd7,
        size: planet === 'mars' ? 0.075 : 0.035,
        transparent: true,
        opacity: planet === 'mars' ? (sunlight < 45 ? 0.82 : 0.42) : 0.2,
        depthWrite: false,
      })
    );
    exterior.add(dust);
    dust.visible = view === 'exterior';

    const resizeObserver = new ResizeObserver(() => {
      if (!mount.clientWidth || !mount.clientHeight) return;
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    });
    resizeObserver.observe(mount);

    const timer = new THREE.Timer();
    timer.connect(document);
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let frameId = 0;
    const animate = () => {
      frameId = window.requestAnimationFrame(animate);
      timer.update();
      const delta = Math.min(timer.getDelta(), 0.05);
      const elapsed = timer.getElapsed();
      if (!reducedMotion) {
        sun.position.set(-12 + Math.sin(elapsed * 0.08) * 1.5, 12 + Math.sin(elapsed * 0.11) * 0.6, 8);
        panelGroup.rotation.y = Math.sin(elapsed * 0.12) * 0.08;
        rover.rotation.y = Math.sin(elapsed * 0.18) * 0.025;
        rover.position.x = 0.35 + Math.sin(elapsed * 0.08) * 0.12;
        if (planet === 'mars' && view === 'exterior') {
          const positions = dustGeometry.attributes.position as THREE.BufferAttribute;
          for (let i = 0; i < dustCount; i += 1) {
            positions.array[i * 3] += dustVelocities[i] * delta;
            if (positions.array[i * 3] > 18) positions.array[i * 3] = -18;
          }
          positions.needsUpdate = true;
        }
      }
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      window.cancelAnimationFrame(frameId);
      timer.dispose();
      resizeObserver.disconnect();
      scene.traverse(object => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Points) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach(material => material.dispose());
        }
      });
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [planet, habitat, sunlight, view]);

  return (
    <section className={`outpost-scene ${compact ? 'outpost-scene--compact' : ''}`} aria-label={`${planet} outpost environment`}>
      <div className="outpost-scene__canvas" ref={mountRef} />
      {webglError && (
        <div className="outpost-scene__fallback" role="status">
          This 3D scene needs WebGL support enabled in your browser.
        </div>
      )}
      {!webglError && (
        <>
          <div className="outpost-scene__topline">
            <span className="outpost-scene__live"><i /> LIVE SURFACE FEED</span>
            <span>{PLANET_LABEL[planet]}</span>
          </div>
          <div className="outpost-scene__readout">
            <strong>{view === 'exterior' ? HABITAT_LABEL[habitat] : 'HABITAT INTERIOR · ECLSS ONLINE'}</strong>
            <span>{view === 'exterior'
              ? planet === 'mars' && sunlight < 45
                ? 'DUST FRONT · LOW SOLAR FLUX · EVA CAUTION'
                : planet === 'moon' && sunlight < 40
                  ? 'LUNAR NIGHT · ARRAY SHADOW · EVA CAUTION'
                  : 'SOLAR ARRAY · PRESSURIZED ROVER · EVA CREW'
              : 'HYDROPONICS · SLEEP QUARTERS · FLIGHT CONTROL'}</span>
          </div>
          <div className="outpost-scene__metrics">
            <span>SOL {String(sol).padStart(2, '0')}</span>
            <span><i className="outpost-scene__sun" /> SUNLIGHT {sunlight}%</span>
          </div>
          <div className="outpost-scene__views" role="group" aria-label="Outpost camera view">
            <button type="button" aria-pressed={view === 'exterior'} onClick={() => setView('exterior')}>EXTERIOR</button>
            <button type="button" aria-pressed={view === 'interior'} onClick={() => setView('interior')}>HABITAT INTERIOR</button>
          </div>
        </>
      )}
    </section>
  );
};
