import React, { useState, useRef } from 'react';
import { Download, Printer, Sparkles, Star, Award, Orbit, X, Check, RefreshCw } from 'lucide-react';
import { AstronautProfile } from '../types';
import { playUiClick, playSuccessChime } from '../utils/audio';

interface MissionPatchGeneratorProps {
  isOpen: boolean;
  onClose: () => void;
  profile: AstronautProfile | null;
}

export const MissionPatchGenerator: React.FC<MissionPatchGeneratorProps> = ({
  isOpen,
  onClose,
  profile,
}) => {
  const [callsign, setCallsign] = useState(profile?.name || 'CADET NOVA');
  const [designation, setDesignation] = useState('COSMORA · EXPEDITION 72');
  const [shape, setShape] = useState<'circle' | 'shield'>('circle');
  const [theme, setTheme] = useState<'apollo' | 'artemis' | 'celestial'>('apollo');
  const [centerIcon, setCenterIcon] = useState<'rocket' | 'moon' | 'iss' | 'earth'>('rocket');

  const patchRef = useRef<SVGSVGElement | null>(null);

  if (!isOpen) return null;

  // Theme palettes
  const palettes = {
    apollo: {
      outerRing: '#ffc93c',
      innerRing: '#09273c',
      bgCenter: '#041624',
      chevron: '#ef7144',
      text: '#eef4e6',
      borderStitch: '#ffd700',
    },
    artemis: {
      outerRing: '#ef7144',
      innerRing: '#1a1d20',
      bgCenter: '#090b0d',
      chevron: '#38bdf8',
      text: '#ffffff',
      borderStitch: '#ff865c',
    },
    celestial: {
      outerRing: '#72d1d6',
      innerRing: '#062628',
      bgCenter: '#021213',
      chevron: '#d9f36a',
      text: '#eef4e6',
      borderStitch: '#93ecef',
    },
  }[theme];

  const handleDownload = () => {
    playUiClick();
    const svg = patchRef.current;
    if (!svg) return;

    const svgData = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 800;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.setAttribute('src', 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData))));
    img.onload = () => {
      ctx.drawImage(img, 0, 0, 800, 800);
      const url = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.download = `NASA-PATCH-${callsign.replace(/\s+/g, '_')}.png`;
      a.href = url;
      a.click();
      playSuccessChime();
    };
  };

  const handlePrint = () => {
    playUiClick();
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#07181c] border-2 border-[#ffc93c]/50 rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden relative">
        {/* Top Header */}
        <div className="p-5 sm:p-6 border-b border-white/10 bg-[#092227] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#ffc93c]/20 text-[#ffc93c] border border-[#ffc93c]/40">
              <Award size={22} />
            </div>
            <div>
              <div className="text-[10px] font-mono tracking-widest text-[#d9f36a] uppercase font-bold">
                NASA EMBROIDERED CREW PATCH STUDIO
              </div>
              <h2 className="text-xl sm:text-2xl font-display font-bold text-[#eef4e6]">
                Custom Astronaut Flight Patch
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              playUiClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-[#9fb1a6] hover:text-white transition cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Studio Body: Split View (Controls on Left, Live Patch Rendering on Right) */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-y-auto">
          {/* Left Controls */}
          <div className="md:col-span-6 p-6 border-r border-white/10 space-y-5 bg-[#051316]">
            <div>
              <label className="text-xs font-mono font-bold text-[#9fb1a6] uppercase block mb-1">
                Astronaut Callsign:
              </label>
              <input
                type="text"
                value={callsign}
                onChange={e => setCallsign(e.target.value.toUpperCase())}
                maxLength={20}
                className="w-full bg-[#030d0f] border border-white/10 rounded-xl px-4 py-2.5 text-sm font-mono text-[#eef4e6] font-bold focus:outline-none focus:border-[#ffc93c]"
              />
            </div>

            <div>
              <label className="text-xs font-mono font-bold text-[#9fb1a6] uppercase block mb-1">
                Mission Designation:
              </label>
              <input
                type="text"
                value={designation}
                onChange={e => setDesignation(e.target.value.toUpperCase())}
                maxLength={28}
                className="w-full bg-[#030d0f] border border-white/10 rounded-xl px-4 py-2.5 text-sm font-mono text-[#eef4e6] font-bold focus:outline-none focus:border-[#ffc93c]"
              />
            </div>

            {/* Color Palette Theme */}
            <div>
              <label className="text-xs font-mono font-bold text-[#9fb1a6] uppercase block mb-2">
                Color Palette Scheme:
              </label>
              <div className="grid grid-cols-3 gap-2 text-xs font-mono">
                <button
                  onClick={() => setTheme('apollo')}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    theme === 'apollo'
                      ? 'bg-[#ffc93c] text-[#061211] font-bold border-[#ffc93c] shadow-md'
                      : 'bg-white/5 border-white/10 text-[#9fb1a6]'
                  }`}
                >
                  Apollo Gold
                </button>
                <button
                  onClick={() => setTheme('artemis')}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    theme === 'artemis'
                      ? 'bg-[#ef7144] text-white font-bold border-[#ef7144] shadow-md'
                      : 'bg-white/5 border-white/10 text-[#9fb1a6]'
                  }`}
                >
                  Artemis Core
                </button>
                <button
                  onClick={() => setTheme('celestial')}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    theme === 'celestial'
                      ? 'bg-[#72d1d6] text-[#061211] font-bold border-[#72d1d6] shadow-md'
                      : 'bg-white/5 border-white/10 text-[#9fb1a6]'
                  }`}
                >
                  Celestial Cyan
                </button>
              </div>
            </div>

            {/* Center Vehicle Icon */}
            <div>
              <label className="text-xs font-mono font-bold text-[#9fb1a6] uppercase block mb-2">
                Center Mission Emblem:
              </label>
              <div className="grid grid-cols-4 gap-2 text-xs font-mono">
                <button
                  onClick={() => setCenterIcon('rocket')}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    centerIcon === 'rocket'
                      ? 'bg-white/20 border-white text-white font-bold'
                      : 'bg-white/5 border-white/10 text-[#9fb1a6]'
                  }`}
                >
                  🚀 Rocket
                </button>
                <button
                  onClick={() => setCenterIcon('moon')}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    centerIcon === 'moon'
                      ? 'bg-white/20 border-white text-white font-bold'
                      : 'bg-white/5 border-white/10 text-[#9fb1a6]'
                  }`}
                >
                  🌕 Moon
                </button>
                <button
                  onClick={() => setCenterIcon('iss')}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    centerIcon === 'iss'
                      ? 'bg-white/20 border-white text-white font-bold'
                      : 'bg-white/5 border-white/10 text-[#9fb1a6]'
                  }`}
                >
                  🛰️ ISS
                </button>
                <button
                  onClick={() => setCenterIcon('earth')}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    centerIcon === 'earth'
                      ? 'bg-white/20 border-white text-white font-bold'
                      : 'bg-white/5 border-white/10 text-[#9fb1a6]'
                  }`}
                >
                  🌍 Earth
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-3 border-t border-white/10 flex gap-3">
              <button
                onClick={handleDownload}
                className="flex-1 py-3 rounded-xl bg-[#d9f36a] hover:bg-[#e4f788] text-[#061211] font-mono font-bold text-xs uppercase flex items-center justify-center gap-2 shadow-lg transition cursor-pointer"
              >
                <Download size={15} />
                <span>Export Patch (PNG)</span>
              </button>
              <button
                onClick={handlePrint}
                className="px-4 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono font-bold text-xs uppercase flex items-center gap-1.5 transition cursor-pointer"
              >
                <Printer size={15} />
              </button>
            </div>
          </div>

          {/* Right Live Patch Preview */}
          <div className="md:col-span-6 p-6 flex flex-col items-center justify-center bg-[#030a0c] relative">
            <div className="relative p-6 drop-shadow-[0_20px_50px_rgba(0,0,0,0.8)]">
              <svg
                ref={patchRef}
                viewBox="0 0 400 400"
                className="w-72 h-72 sm:w-80 sm:h-80 select-none"
              >
                <defs>
                  {/* Embroidered Thread Texture Filter */}
                  <filter id="thread-texture">
                    <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="3" result="noise" />
                    <feDisplacementMap in="SourceGraphic" in2="noise" scale="2" />
                  </filter>
                  <linearGradient id="patch-glow" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor={palettes.outerRing} stopOpacity="0.8" />
                    <stop offset="100%" stopColor={palettes.chevron} stopOpacity="0.9" />
                  </linearGradient>
                  {/* Circular text paths */}
                  <path id="top-curve" d="M 50,200 A 150,150 0 1,1 350,200" fill="none" />
                  <path id="bottom-curve" d="M 350,200 A 150,150 0 0,1 50,200" fill="none" />
                </defs>

                {/* Outer Embroidered Edge (Thick stitch ring) */}
                <circle cx="200" cy="200" r="195" fill={palettes.outerRing} stroke="#000" strokeWidth="3" />
                {/* Stitch dashes */}
                <circle cx="200" cy="200" r="190" fill="none" stroke={palettes.borderStitch} strokeWidth="3" strokeDasharray="4,3" />

                {/* Inner Dark Patch Field */}
                <circle cx="200" cy="200" r="172" fill={palettes.innerRing} stroke="#000" strokeWidth="2" />

                {/* Central Space Dome */}
                <circle cx="200" cy="200" r="125" fill={palettes.bgCenter} />

                {/* Constellation Starfield in background */}
                <g fill="#fff" opacity="0.7">
                  <circle cx="160" cy="140" r="1.5" />
                  <circle cx="180" cy="110" r="2" />
                  <circle cx="230" cy="130" r="1.8" />
                  <circle cx="250" cy="160" r="1.5" />
                  <circle cx="140" cy="190" r="2" />
                  <circle cx="260" cy="220" r="1.5" />
                  <circle cx="170" cy="260" r="1.8" />
                  <circle cx="220" cy="270" r="2" />
                </g>

                {/* NASA Vector Chevron Wing */}
                <path
                  d="M 120,240 L 200,90 L 280,240 L 200,205 Z"
                  fill={palettes.chevron}
                  opacity="0.95"
                  stroke="#fff"
                  strokeWidth="1.5"
                />

                {/* Earth Orbit Arc */}
                <ellipse cx="200" cy="200" rx="110" ry="45" fill="none" stroke="#fff" strokeWidth="1.5" opacity="0.6" strokeDasharray="6,4" />

                {/* Center Icon */}
                <text
                  x="200"
                  y="215"
                  fontSize="44"
                  textAnchor="middle"
                  dominantBaseline="middle"
                >
                  {centerIcon === 'rocket' ? '🚀' : centerIcon === 'moon' ? '🌕' : centerIcon === 'iss' ? '🛰️' : '🌍'}
                </text>

                {/* Top Embroidered Text (Callsign) */}
                <text fill="#ffffff" fontSize="15" fontWeight="900" fontFamily="IBM Plex Mono, monospace" letterSpacing="3">
                  <textPath href="#top-curve" startOffset="50%" textAnchor="middle">
                    ✦ {callsign} ✦
                  </textPath>
                </text>

                {/* Bottom Embroidered Text (Mission Designation) */}
                <text fill={palettes.outerRing} fontSize="12" fontWeight="800" fontFamily="IBM Plex Mono, monospace" letterSpacing="2">
                  <textPath href="#bottom-curve" startOffset="50%" textAnchor="middle">
                    ★ {designation} ★
                  </textPath>
                </text>

                {/* Star Honors Accent on sides */}
                <g fill={palettes.outerRing}>
                  <circle cx="28" cy="200" r="4" />
                  <circle cx="372" cy="200" r="4" />
                </g>
              </svg>
            </div>

            <div className="text-center space-y-1">
              <span className="text-[11px] font-mono text-[#d9f36a] font-bold block">
                AUTHENTIC EMBROIDERED SPECIFICATION
              </span>
              <p className="text-[10px] text-[#9fb1a6]">
                Ready for flight suit attachment, mission binders, and digital display.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
