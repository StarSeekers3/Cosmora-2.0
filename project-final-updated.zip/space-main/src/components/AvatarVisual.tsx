import React from 'react';

interface AvatarVisualProps {
  avatar: string;
  className?: string;
  alt?: string;
}

export const AvatarVisual: React.FC<AvatarVisualProps> = ({ avatar, className = '', alt = 'Astronaut avatar' }) => {
  const isPortrait = avatar.startsWith('/avatars/');

  if (isPortrait) {
    return <img src={avatar} alt={alt} className={`object-cover object-center ${className}`} />;
  }

  return <span className={className} aria-hidden="true">{avatar}</span>;
};
