import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface SolarSystemBackground3DProps {
  theme?: 'dark' | 'light';
  reduceMotion?: boolean;
  /** Speed multiplier for orbital motion. */
  speed?: number;
  /** Pixel-ratio cap. */
  maxPixelRatio?: number;
  /** Let the pointer gently shift the camera. */
  interactive?: boolean;
  className?: string;
}

/**
 * Ultra-realistic 3D solar system background (three.js, fully procedural, no network assets).
 *
 * - Animated granulated Sun with corona glow and real point-light illumination
 * - Procedural planet surfaces (rocky, cloud-banded gas giants, Earth with oceans/continents/ice/clouds)
 * - Fresnel atmospheres, Saturn's ringed system with shadow-friendly transparency, Moon
 * - Axial tilt, spin and Keplerian-ish orbital speeds, asteroid belt, faint orbit trails
 * - Deep-space sky sphere with nebula dust and tens of thousands of coloured stars
 */

// ───────────────────────── Procedural noise helpers (CPU) ─────────────────────────
function makeRng(seed: number) {
  let s = seed >>> 0;
  return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296);
}

class Noise3 {
  private perm = new Uint8Array(512);
  constructor(seed: number) {
    const rnd = makeRng(seed);
    const p = Array.from({ length: 256 }, (_, i) => i);
    for (let i = 255; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [p[i], p[j]] = [p[j], p[i]]; }
    for (let i = 0; i < 512; i++) this.perm[i] = p[i & 255];
  }
  private fade(t: number) { return t * t * t * (t * (t * 6 - 15) + 10); }
  private grad(h: number, x: number, y: number, z: number) {
    const u = (h & 15) < 8 ? x : y;
    const v = (h & 15) < 4 ? y : (h & 15) === 12 || (h & 15) === 14 ? x : z;
    return (h & 1 ? -u : u) + (h & 2 ? -v : v);
  }
  noise(x: number, y: number, z: number) {
    const X = Math.floor(x) & 255, Y = Math.floor(y) & 255, Z = Math.floor(z) & 255;
    x -= Math.floor(x); y -= Math.floor(y); z -= Math.floor(z);
    const u = this.fade(x), v = this.fade(y), w = this.fade(z);
    const P = this.perm;
    const A = P[X] + Y, AA = P[A] + Z, AB = P[A + 1] + Z, B = P[X + 1] + Y, BA = P[B] + Z, BB = P[B + 1] + Z;
    const l = (a: number, b: number, t: number) => a + t * (b - a);
    return l(
      l(l(this.grad(P[AA], x, y, z), this.grad(P[BA], x - 1, y, z), u),
        l(this.grad(P[AB], x, y - 1, z), this.grad(P[BB], x - 1, y - 1, z), u), v),
      l(l(this.grad(P[AA + 1], x, y, z - 1), this.grad(P[BA + 1], x - 1, y, z - 1), u),
        l(this.grad(P[AB + 1], x, y - 1, z - 1), this.grad(P[BB + 1], x - 1, y - 1, z - 1), u), v), w);
  }
  fbm(x: number, y: number, z: number, oct = 5, lac = 2.0, gain = 0.5) {
    let a = 0.5, s = 0, f = 1;
    for (let i = 0; i < oct; i++) { s += a * this.noise(x * f, y * f, z * f); f *= lac; a *= gain; }
    return s; // roughly -0.5..0.5
  }
  ridged(x: number, y: number, z: number, oct = 5) {
    let a = 0.5, s = 0, f = 1;
    for (let i = 0; i < oct; i++) { s += a * (1 - Math.abs(this.noise(x * f, y * f, z * f)) * 2); f *= 2.1; a *= 0.5; }
    return s;
  }
}

type RGB = [number, number, number];
const hex = (h: string): RGB => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const mix = (a: RGB, b: RGB, t: number): RGB => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
const smooth = (a: number, b: number, x: number) => { const t = clamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); };

/** Paint an equirectangular texture by evaluating fn at each texel's 3D unit-sphere point (seamless). */
function paintSphere(
  w: number, h: number,
  fn: (x: number, y: number, z: number, lat: number) => RGB | [number, number, number, number],
): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d')!;
  const img = ctx.createImageData(w, h);
  for (let j = 0; j < h; j++) {
    const lat = (0.5 - (j + 0.5) / h) * Math.PI;
    const cy = Math.cos(lat), sy = Math.sin(lat);
    for (let i = 0; i < w; i++) {
      const lon = ((i + 0.5) / w) * Math.PI * 2;
      const x = cy * Math.cos(lon), z = cy * Math.sin(lon), y = sy;
      const r = fn(x, y, z, lat) as number[];
      const k = (j * w + i) * 4;
      img.data[k] = r[0]; img.data[k + 1] = r[1]; img.data[k + 2] = r[2]; img.data[k + 3] = r[3] ?? 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

const tex = (c: HTMLCanvasElement, srgb = true) => {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  t.anisotropy = 8;
  t.wrapS = THREE.RepeatWrapping;
  t.needsUpdate = true;
  return t;
};

// ───────────────────────── Planet texture factories ─────────────────────────
const TW = 1024, TH = 512;

function rockyTexture(seed: number, base: RGB, dark: RGB, light: RGB, craters = 1) {
  const n = new Noise3(seed);
  const col = paintSphere(TW, TH, (x, y, z) => {
    const f = n.fbm(x * 2.2, y * 2.2, z * 2.2, 6);
    const r = n.ridged(x * 5, y * 5, z * 5, 4);
    const fine = n.fbm(x * 30, y * 30, z * 30, 2);
    let t = clamp01(0.5 + f * 1.4 + (r - 0.5) * 0.25 * craters);
    let c = t < 0.5 ? mix(dark, base, t * 2) : mix(base, light, (t - 0.5) * 2);
    const k = 1 + fine * 0.25;
    return [c[0] * k, c[1] * k, c[2] * k];
  });
  const bump = paintSphere(TW, TH, (x, y, z) => {
    const v = clamp01(0.5 + n.fbm(x * 3, y * 3, z * 3, 6) + n.ridged(x * 8, y * 8, z * 8, 3) * 0.2 + n.fbm(x * 40, y * 40, z * 40, 2) * 0.15);
    const g = v * 255; return [g, g, g];
  });
  return { map: tex(col), bump: tex(bump, false) };
}

function earthTextures() {
  const n = new Noise3(1337), cl = new Noise3(77);
  const deep = hex('#04183a'), shallow = hex('#0d4f8a'), sand = hex('#b9a46a'), green = hex('#2f5d2a'), forest = hex('#1d3f1d'), rock = hex('#6a5f55'), snow = hex('#f4f8ff');
  const landFn = (x: number, y: number, z: number) => n.fbm(x * 1.6, y * 1.6, z * 1.6, 7, 2.05, 0.52) + n.fbm(x * 0.7 + 9, y * 0.7, z * 0.7, 3) * 0.25;
  const SEA = 0.03;
  const col = paintSphere(TW, TH, (x, y, z, lat) => {
    const h = landFn(x, y, z);
    const polar = smooth(0.9, 1.15, Math.abs(y) * 1.2 + n.fbm(x * 6, y * 6, z * 6, 3) * 0.35);
    let c: RGB;
    if (h < SEA) {
      c = mix(deep, shallow, smooth(-0.22, SEA, h));
      c = mix(c, hex('#3aa0c8'), smooth(SEA - 0.03, SEA, h) * 0.5); // coastal shelf
    } else {
      const alt = h - SEA;
      const dry = clamp01(0.5 + n.fbm(x * 3 + 4, y * 3, z * 3, 4) * 1.6 - Math.abs(y) * 0.5 + (Math.abs(Math.sin(lat * 2)) - 0.5) * 0.4);
      const lush = mix(forest, green, clamp01(dry * 1.6));
      c = mix(lush, sand, smooth(0.5, 0.95, 1 - dry + 0.0) * 0.8);
      c = mix(c, rock, smooth(0.18, 0.34, alt));
      c = mix(c, snow, smooth(0.3, 0.42, alt));
    }
    c = mix(c, snow, polar);
    return c;
  });
  const bump = paintSphere(TW, TH, (x, y, z) => {
    const h = Math.max(landFn(x, y, z), SEA); const g = clamp01((h - SEA) * 3 + 0.05) * 255; return [g, g, g];
  });
  const spec = paintSphere(TW, TH, (x, y, z) => {
    const g = landFn(x, y, z) < SEA ? 255 : 18; return [g, g, g];
  });
  const clouds = paintSphere(TW, TH, (x, y, z) => {
    const v = cl.fbm(x * 2.4 + 5, y * 3.2, z * 2.4, 7, 2.1, 0.55) + cl.fbm(x * 0.9, y * 0.9 + 3, z * 0.9, 3) * 0.5;
    const a = smooth(0.02, 0.34, v) * 255;
    return [255, 255, 255, a];
  });
  return { map: tex(col), bump: tex(bump, false), spec: tex(spec, false), clouds: tex(clouds) };
}

function gasTexture(seed: number, palette: RGB[], bandFreq: number, turb: number, storm?: { lat: number; lon: number; size: number; color: RGB }) {
  const n = new Noise3(seed);
  return tex(paintSphere(TW, TH, (x, y, z, lat) => {
    const wob = n.fbm(x * 3, y * 9, z * 3, 5) * turb;
    const fine = n.fbm(x * 8, y * 40, z * 8, 4) * 0.5;
    let b = Math.sin((y + wob * 0.35) * bandFreq + fine * 1.4) * 0.5 + 0.5;
    b = clamp01(b + n.fbm(x * 16, y * 16, z * 16, 3) * 0.12);
    const idx = b * (palette.length - 1);
    const i0 = Math.floor(idx), i1 = Math.min(palette.length - 1, i0 + 1);
    let c = mix(palette[i0], palette[i1], idx - i0);
    if (storm) {
      const lon = Math.atan2(z, x);
      let dl = lon - storm.lon; dl = Math.atan2(Math.sin(dl), Math.cos(dl));
      const d = Math.hypot(dl * Math.cos(lat) * 1.0, (lat - storm.lat) * 1.9) / storm.size;
      const swirl = n.fbm(x * 14 + dl * 3, y * 14, z * 14, 3) * 0.25;
      c = mix(c, storm.color, smooth(1.0, 0.55, d + swirl));
    }
    const polar = 1 - Math.abs(y) * 0.28;
    return [c[0] * polar, c[1] * polar, c[2] * polar];
  }));
}

function venusTexture() {
  const n = new Noise3(909);
  return tex(paintSphere(TW, TH, (x, y, z) => {
    const w = n.fbm(x * 2 + n.fbm(x * 4, y * 4, z * 4, 3) * 0.8, y * 3.5, z * 2, 6);
    const t = clamp01(0.5 + w * 1.3);
    return mix(hex('#b8884a'), hex('#f0dcaa'), t);
  }));
}

function ringTexture(inner: number, outer: number, seed: number, tint: RGB) {
  const W = 2048, c = document.createElement('canvas');
  c.width = W; c.height = 4;
  const ctx = c.getContext('2d')!;
  const img = ctx.createImageData(W, 4);
  const n = new Noise3(seed);
  for (let i = 0; i < W; i++) {
    const t = i / (W - 1);
    const r = inner + (outer - inner) * t;
    const v = n.fbm(r * 70, 0.5, 0.5, 5) * 1.4 + n.noise(r * 400, 1, 1) * 0.3 + 0.5;
    let a = clamp01(v);
    const rel = (r - 1.24) / (2.27 - 1.24); // normalised to Saturn ring extents (C/B/A)
    const cring = smooth(0.0, 0.1, rel) * (rel < 0.18 ? 0.35 : 1);
    const bring = rel > 0.18 && rel < 0.6 ? 1 : 0.0;
    const cassini = rel > 0.6 && rel < 0.66 ? 0.06 : 1;
    const aring = rel >= 0.66 ? 0.85 * smooth(1.0, 0.93, rel) : 1;
    const enckeGap = Math.abs(rel - 0.93) < 0.008 ? 0.1 : 1;
    const dens = clamp01((rel < 0.18 ? cring : rel < 0.6 ? 1 : rel < 0.66 ? 0.05 : aring) * cassini * enckeGap * (0.35 + a * 0.85));
    const shade = 0.72 + n.fbm(r * 55, 2, 2, 3) * 0.5;
    for (let j = 0; j < 4; j++) {
      const k = (j * W + i) * 4;
      img.data[k] = Math.min(255, tint[0] * shade); img.data[k + 1] = Math.min(255, tint[1] * shade); img.data[k + 2] = Math.min(255, tint[2] * shade);
      img.data[k + 3] = dens * 255 * (bring ? 1 : 1);
    }
  }
  ctx.putImageData(img, 0, 0);
  return tex(c);
}

function glowSprite(inner: string, mid: string, outer = 'rgba(0,0,0,0)') {
  const c = document.createElement('canvas'); c.width = c.height = 512;
  const g = c.getContext('2d')!; const gr = g.createRadialGradient(256, 256, 0, 256, 256, 256);
  gr.addColorStop(0, inner); gr.addColorStop(0.18, mid); gr.addColorStop(0.5, 'rgba(255,140,40,0.06)'); gr.addColorStop(1, outer);
  g.fillStyle = gr; g.fillRect(0, 0, 512, 512);
  return tex(c);
}

function skyTexture() {
  const W = 2048, H = 1024, n = new Noise3(4242);
  return tex(paintSphere(W, H, (x, y, z) => {
    const band = Math.exp(-Math.pow((y * 0.9 + 0.25 * x) * 3.5, 2));
    const d = n.fbm(x * 3 + 7, y * 3, z * 3, 6);
    const neb = clamp01(d * 2.2 + 0.1) * (0.35 + band * 0.9);
    const dark = smooth(0.1, 0.35, n.fbm(x * 5, y * 5 + 2, z * 5, 5)) * band;
    const r = (14 + 38 * neb + 22 * band) * (1 - dark * 0.55);
    const g = (14 + 26 * neb + 17 * band) * (1 - dark * 0.55);
    const b = (26 + 52 * neb + 22 * band) * (1 - dark * 0.55);
    return [r * 0.8, g * 0.8, b * 0.85];
  }));
}

// ───────────────────────── Shaders ─────────────────────────
const SUN_VERT = /* glsl */ `
  varying vec3 vP; varying vec3 vN; varying vec3 vView;
  void main(){ vP = position; vN = normalize(normalMatrix * normal);
    vec4 mv = modelViewMatrix * vec4(position,1.0); vView = normalize(-mv.xyz);
    gl_Position = projectionMatrix * mv; }
`;
const SUN_FRAG = /* glsl */ `
  precision highp float; varying vec3 vP; varying vec3 vN; varying vec3 vView; uniform float uTime;
  float h(vec3 p){ p = fract(p*0.3183099+.1); p*=17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
  float n(vec3 x){ vec3 i=floor(x), f=fract(x); f=f*f*(3.0-2.0*f);
    return mix(mix(mix(h(i),h(i+vec3(1,0,0)),f.x),mix(h(i+vec3(0,1,0)),h(i+vec3(1,1,0)),f.x),f.y),
               mix(mix(h(i+vec3(0,0,1)),h(i+vec3(1,0,1)),f.x),mix(h(i+vec3(0,1,1)),h(i+vec3(1,1,1)),f.x),f.y),f.z); }
  float fbm(vec3 p){ float a=.5,s=0.; for(int i=0;i<6;i++){ s+=a*n(p); p=p*2.1+3.3; a*=.5;} return s; }
  void main(){
    vec3 p = normalize(vP);
    float t = uTime*0.05;
    float gran = fbm(p*9.0 + vec3(t, -t*0.7, t*0.5));
    float cells = fbm(p*28.0 + vec3(-t*2.0, t, t));
    float spots = smoothstep(0.62, 0.78, fbm(p*3.0 + vec3(t*0.2)));
    float v = gran*0.75 + cells*0.35;
    vec3 hot  = vec3(1.0, 0.93, 0.62);
    vec3 mid  = vec3(1.0, 0.58, 0.16);
    vec3 cool = vec3(0.78, 0.20, 0.03);
    vec3 col = mix(cool, mid, smoothstep(0.25, 0.65, v));
    col = mix(col, hot, smoothstep(0.55, 0.95, v));
    col *= 1.0 - spots*0.55;
    float mu = clamp(dot(normalize(vN), vView), 0.0, 1.0);
    col *= 0.55 + 0.75*pow(mu, 0.45);          // limb darkening
    gl_FragColor = vec4(col*1.7, 1.0);
  }
`;
const ATMO_VERT = /* glsl */ `
  varying vec3 vN; varying vec3 vView; varying vec3 vWorldN;
  void main(){ vN = normalize(normalMatrix * normal); vWorldN = normalize(mat3(modelMatrix)*normal);
    vec4 mv = modelViewMatrix * vec4(position,1.0); vView = normalize(-mv.xyz);
    gl_Position = projectionMatrix * mv; }
`;
const ATMO_FRAG = /* glsl */ `
  precision highp float; varying vec3 vN; varying vec3 vView; varying vec3 vWorldN;
  uniform vec3 uColor; uniform vec3 uSunDir; uniform float uPower; uniform float uIntensity;
  void main(){
    float f = pow(1.0 - abs(dot(normalize(vN), vView)), uPower);
    float lit = smoothstep(-0.35, 0.5, dot(normalize(vWorldN), uSunDir));
    gl_FragColor = vec4(uColor * f * uIntensity * (0.15 + 0.85*lit), f * lit);
  }
`;

// ───────────────────────── Scene definition ─────────────────────────
interface PlanetDef {
  name: string; radius: number; orbit: number; period: number; spin: number; tilt: number; ecc?: number;
}
// Distances and sizes compressed for legibility; speeds follow real ratios (log-compressed).
const SIZE_BOOST = 1.5; // planets are drawn larger than true scale so they read on screen
const PLANETS: PlanetDef[] = ([
  { name: 'Mercury', radius: 0.55, orbit: 11, period: 0.24, spin: 0.2, tilt: 0.03 },
  { name: 'Venus',   radius: 1.0,  orbit: 16, period: 0.62, spin: -0.05, tilt: 3.09 },
  { name: 'Earth',   radius: 1.1,  orbit: 22, period: 1.0, spin: 1.2, tilt: 0.41 },
  { name: 'Mars',    radius: 0.75, orbit: 29, period: 1.88, spin: 1.1, tilt: 0.44 },
  { name: 'Jupiter', radius: 3.6,  orbit: 46, period: 4.2, spin: 2.4, tilt: 0.05 },
  { name: 'Saturn',  radius: 3.0,  orbit: 66, period: 6.5, spin: 2.2, tilt: 0.47 },
  { name: 'Uranus',  radius: 1.9,  orbit: 84, period: 9.0, spin: -1.4, tilt: 1.71 },
  { name: 'Neptune', radius: 1.85, orbit: 100, period: 12.0, spin: 1.5, tilt: 0.49 },
] as PlanetDef[]).map((d) => ({ ...d, radius: d.radius * SIZE_BOOST }));

export const SolarSystemBackground3D: React.FC<SolarSystemBackground3DProps> = ({
  theme = 'dark',
  reduceMotion = false,
  speed = 1,
  maxPixelRatio = 2,
  interactive = true,
  className,
}) => {
  const hostRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    } catch {
      host.style.background = 'radial-gradient(circle at 30% 40%, #101a3a, #000 70%)';
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, maxPixelRatio));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = theme === 'light' ? 1.25 : 1.0;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.domElement.style.cssText = 'width:100%;height:100%;display:block;';
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x000000);
    const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 4000);

    const disposables: Array<{ dispose: () => void }> = [];
    const track = <T extends { dispose: () => void }>(o: T) => { disposables.push(o); return o; };

    // Sky sphere + stars
    const sky = new THREE.Mesh(
      track(new THREE.SphereGeometry(1800, 48, 32)),
      track(new THREE.MeshBasicMaterial({ map: track(skyTexture()), side: THREE.BackSide, depthWrite: false, fog: false })),
    );
    scene.add(sky);

    {
      const N = 22000; const pos = new Float32Array(N * 3), colr = new Float32Array(N * 3), size = new Float32Array(N);
      const rnd = makeRng(99);
      for (let i = 0; i < N; i++) {
        const u = rnd() * 2 - 1, a = rnd() * Math.PI * 2, s = Math.sqrt(1 - u * u), R = 1500;
        // denser toward a galactic band
        const bandPull = rnd() < 0.5 ? u * 0.35 : u;
        const uu = bandPull, ss = Math.sqrt(1 - uu * uu);
        pos[i * 3] = Math.cos(a) * ss * R; pos[i * 3 + 1] = uu * R; pos[i * 3 + 2] = Math.sin(a) * ss * R; void s;
        const t = rnd(); const c = new THREE.Color().setHSL(t < 0.2 ? 0.58 : t < 0.8 ? 0.12 : 0.04, 0.35 + rnd() * 0.4, 0.75 + rnd() * 0.25);
        const b = Math.pow(rnd(), 3) * 0.9 + 0.1;
        colr[i * 3] = c.r * b; colr[i * 3 + 1] = c.g * b; colr[i * 3 + 2] = c.b * b;
        size[i] = 1 + Math.pow(rnd(), 6) * 3.2;
      }
      const g = track(new THREE.BufferGeometry());
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      g.setAttribute('color', new THREE.BufferAttribute(colr, 3));
      g.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
      const m = track(new THREE.ShaderMaterial({
        transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, vertexColors: true,
        uniforms: { uPR: { value: renderer.getPixelRatio() } },
        vertexShader: `attribute float aSize; varying vec3 vC; uniform float uPR; void main(){ vC = color; gl_PointSize = aSize*uPR; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
        fragmentShader: `varying vec3 vC; void main(){ float d = length(gl_PointCoord-0.5); float a = smoothstep(0.5,0.0,d); gl_FragColor = vec4(vC*a*1.4, a); }`,
      }));
      scene.add(new THREE.Points(g, m));
    }

    // Lighting
    const sunLight = new THREE.PointLight(0xfff2dd, 4.2, 0, 0.0);
    sunLight.decay = 0;
    scene.add(sunLight);
    // Soft camera-side fill so night sides stay readable (earthshine / starlight feel)
    const fill = new THREE.DirectionalLight(0x9db4ff, 0.55);
    scene.add(fill, fill.target);
    scene.add(new THREE.AmbientLight(0x1a2036, theme === 'light' ? 1.6 : 0.9));

    // Sun
    const sunUniforms = { uTime: { value: 0 } };
    const sunR = 5.2;
    const sun = new THREE.Mesh(
      track(new THREE.SphereGeometry(sunR, 96, 64)),
      track(new THREE.ShaderMaterial({ vertexShader: SUN_VERT, fragmentShader: SUN_FRAG, uniforms: sunUniforms })),
    );
    scene.add(sun);
    const glowTex = track(glowSprite('rgba(255,248,220,1)', 'rgba(255,190,90,0.55)'));
    const glow1 = new THREE.Sprite(track(new THREE.SpriteMaterial({ map: glowTex, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, color: 0xffffff })));
    glow1.scale.setScalar(sunR * 7);
    const glow2 = new THREE.Sprite(track(new THREE.SpriteMaterial({ map: glowTex, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, color: 0xff9a40, opacity: 0.55 })));
    glow2.scale.setScalar(sunR * 17);
    scene.add(glow1, glow2);

    // Planets
    interface Live { def: PlanetDef; pivot: THREE.Object3D; body: THREE.Mesh; angle: number; clouds?: THREE.Mesh; moon?: THREE.Mesh; moonPivot?: THREE.Object3D }
    const live: Live[] = [];
    const sunDir = new THREE.Vector3();
    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    void maxAniso;

    const atmosphere = (r: number, color: number, power = 3.0, intensity = 1.6) => {
      const uni = { uColor: { value: new THREE.Color(color) }, uSunDir: { value: new THREE.Vector3(1, 0, 0) }, uPower: { value: power }, uIntensity: { value: intensity } };
      const m = new THREE.Mesh(
        track(new THREE.SphereGeometry(r, 64, 48)),
        track(new THREE.ShaderMaterial({ vertexShader: ATMO_VERT, fragmentShader: ATMO_FRAG, uniforms: uni, transparent: true, blending: THREE.AdditiveBlending, side: THREE.FrontSide, depthWrite: false })),
      );
      return { mesh: m, uni };
    };
    const atmos: Array<ReturnType<typeof atmosphere> & { host: THREE.Object3D }> = [];

    PLANETS.forEach((def, idx) => {
      const pivot = new THREE.Object3D();
      const holder = new THREE.Object3D();
      holder.position.x = def.orbit;
      pivot.add(holder);
      const tilted = new THREE.Object3D();
      tilted.rotation.z = def.tilt;
      holder.add(tilted);

      const geo = track(new THREE.SphereGeometry(def.radius, 128, 96));
      let mat: THREE.Material;
      let clouds: THREE.Mesh | undefined;
      let atmoCfg: { color: number; power: number; intensity: number; scale: number } | null = null;

      switch (def.name) {
        case 'Mercury': {
          const t = rockyTexture(11, hex('#8c8884'), hex('#4a4745'), hex('#c9c4bc'));
          mat = new THREE.MeshStandardMaterial({ map: t.map, bumpMap: t.bump, bumpScale: 2.2, roughness: 0.95, metalness: 0 });
          disposables.push(t.map, t.bump);
          break;
        }
        case 'Venus': {
          const m = venusTexture(); disposables.push(m);
          mat = new THREE.MeshStandardMaterial({ map: m, roughness: 0.85, metalness: 0 });
          atmoCfg = { color: 0xffd9a0, power: 2.4, intensity: 1.2, scale: 1.045 };
          break;
        }
        case 'Earth': {
          const e = earthTextures(); disposables.push(e.map, e.bump, e.spec, e.clouds);
          mat = new THREE.MeshStandardMaterial({ map: e.map, bumpMap: e.bump, bumpScale: 1.6, roughnessMap: e.spec, roughness: 1, metalness: 0.0 });
          (mat as THREE.MeshStandardMaterial).onBeforeCompile = (sh) => {
            // oceans glossy, land matte: invert spec map into roughness
            sh.fragmentShader = sh.fragmentShader.replace('roughnessFactor *= texelRoughness.g;', 'roughnessFactor = mix(0.9, 0.18, texelRoughness.g);');
          };
          clouds = new THREE.Mesh(
            track(new THREE.SphereGeometry(def.radius * 1.012, 96, 64)),
            track(new THREE.MeshStandardMaterial({ map: e.clouds, transparent: true, depthWrite: false, roughness: 1, metalness: 0, opacity: 0.92 })),
          );
          atmoCfg = { color: 0x4d9bff, power: 2.6, intensity: 2.0, scale: 1.065 };
          break;
        }
        case 'Mars': {
          const t = rockyTexture(5, hex('#b5532c'), hex('#5e2a17'), hex('#e3a06c'), 1.4);
          mat = new THREE.MeshStandardMaterial({ map: t.map, bumpMap: t.bump, bumpScale: 2.0, roughness: 0.92, metalness: 0 });
          disposables.push(t.map, t.bump);
          atmoCfg = { color: 0xff9a6a, power: 4.0, intensity: 0.7, scale: 1.035 };
          break;
        }
        case 'Jupiter': {
          const t = gasTexture(21, [hex('#caa57a'), hex('#8a5a3a'), hex('#e6d2ae'), hex('#a8643f'), hex('#efe2c6'), hex('#b98456'), hex('#d9c19a')], 34, 1.0,
            { lat: -0.3, lon: 1.2, size: 0.09, color: hex('#b1441f') });
          disposables.push(t);
          mat = new THREE.MeshStandardMaterial({ map: t, roughness: 1, metalness: 0 });
          atmoCfg = { color: 0xffd7a8, power: 3.2, intensity: 0.7, scale: 1.03 };
          break;
        }
        case 'Saturn': {
          const t = gasTexture(31, [hex('#e3cf9f'), hex('#caa96a'), hex('#efe0b3'), hex('#bfa070'), hex('#e8d6a6')], 22, 0.5);
          disposables.push(t);
          mat = new THREE.MeshStandardMaterial({ map: t, roughness: 1, metalness: 0 });
          atmoCfg = { color: 0xffe6b0, power: 3.2, intensity: 0.6, scale: 1.03 };
          break;
        }
        case 'Uranus': {
          const t = gasTexture(41, [hex('#a6dfe3'), hex('#8fd1d9'), hex('#b4e6e8')], 6, 0.25);
          disposables.push(t);
          mat = new THREE.MeshStandardMaterial({ map: t, roughness: 0.9, metalness: 0 });
          atmoCfg = { color: 0x9ff0f2, power: 2.6, intensity: 1.2, scale: 1.05 };
          break;
        }
        default: { // Neptune
          const t = gasTexture(51, [hex('#2a4fd0'), hex('#3a68ec'), hex('#1f3aa8'), hex('#4f80ff')], 12, 0.9,
            { lat: -0.35, lon: 2.2, size: 0.07, color: hex('#14257a') });
          disposables.push(t);
          mat = new THREE.MeshStandardMaterial({ map: t, roughness: 0.9, metalness: 0 });
          atmoCfg = { color: 0x5f8bff, power: 2.6, intensity: 1.5, scale: 1.05 };
        }
      }
      track(mat);
      const body = new THREE.Mesh(geo, mat);
      tilted.add(body);
      if (clouds) tilted.add(clouds);

      if (atmoCfg) {
        const a = atmosphere(def.radius * atmoCfg.scale, atmoCfg.color, atmoCfg.power, atmoCfg.intensity);
        holder.add(a.mesh);
        atmos.push({ ...a, host: holder });
      }

      // Saturn rings
      if (def.name === 'Saturn') {
        const rIn = def.radius * 1.24, rOut = def.radius * 2.27;
        const rg = track(new THREE.RingGeometry(rIn, rOut, 256, 1));
        const p = rg.attributes.position, uv = rg.attributes.uv;
        for (let i = 0; i < p.count; i++) {
          const r = Math.hypot(p.getX(i), p.getY(i)); uv.setXY(i, (r - rIn) / (rOut - rIn), 0.5);
        }
        const rm = track(new THREE.MeshStandardMaterial({
          map: track(ringTexture(1.24, 2.27, 7, [226, 204, 160])), transparent: true, side: THREE.DoubleSide, roughness: 0.9, metalness: 0, depthWrite: false,
        }));
        const ring = new THREE.Mesh(rg, rm);
        ring.rotation.x = -Math.PI / 2;
        tilted.add(ring);
      }

      // Orbit trail
      const pts: THREE.Vector3[] = [];
      for (let i = 0; i <= 256; i++) { const a = (i / 256) * Math.PI * 2; pts.push(new THREE.Vector3(Math.cos(a) * def.orbit, 0, Math.sin(a) * def.orbit)); }
      const ol = new THREE.Line(
        track(new THREE.BufferGeometry().setFromPoints(pts)),
        track(new THREE.LineBasicMaterial({ color: 0x6f86c0, transparent: true, opacity: 0.16 })),
      );
      scene.add(ol);

      // Earth's Moon
      let moon: THREE.Mesh | undefined, moonPivot: THREE.Object3D | undefined;
      if (def.name === 'Earth') {
        const mt = rockyTexture(222, hex('#9a9a9a'), hex('#55555a'), hex('#d8d8d8'), 1.8);
        disposables.push(mt.map, mt.bump);
        moon = new THREE.Mesh(track(new THREE.SphereGeometry(0.42, 64, 48)), track(new THREE.MeshStandardMaterial({ map: mt.map, bumpMap: mt.bump, bumpScale: 1.6, roughness: 1 })));
        moonPivot = new THREE.Object3D();
        moon.position.x = 3.7;
        moonPivot.add(moon);
        moonPivot.rotation.x = 0.09;
        holder.add(moonPivot);
      }

      scene.add(pivot);
      live.push({ def, pivot, body, angle: (idx * 2.399) % (Math.PI * 2), clouds, moon, moonPivot });
      void idx;
    });

    // Asteroid belt (between Mars and Jupiter)
    const belt = (() => {
      const N = 4500; const geo = track(new THREE.IcosahedronGeometry(0.09, 0));
      const mat = track(new THREE.MeshStandardMaterial({ color: 0x8a8278, roughness: 1, flatShading: true }));
      const mesh = new THREE.InstancedMesh(geo, mat, N);
      const rnd = makeRng(2024), d = new THREE.Object3D();
      for (let i = 0; i < N; i++) {
        const a = rnd() * Math.PI * 2, r = 35 + rnd() * 8 + (rnd() - 0.5) * 2;
        d.position.set(Math.cos(a) * r, (rnd() - 0.5) * 1.6, Math.sin(a) * r);
        d.rotation.set(rnd() * 6, rnd() * 6, rnd() * 6);
        d.scale.setScalar(0.4 + Math.pow(rnd(), 3) * 2.2);
        d.updateMatrix(); mesh.setMatrixAt(i, d.matrix);
      }
      scene.add(mesh); return mesh;
    })();

    // Camera rig
    const camTarget = new THREE.Vector3(0, 0, 0);
    const pointer = new THREE.Vector2(0, 0), smoothPtr = new THREE.Vector2(0, 0);
    const onMove = (e: PointerEvent) => { pointer.set((e.clientX / window.innerWidth - 0.5) * 2, (e.clientY / window.innerHeight - 0.5) * 2); };
    if (interactive && !reduceMotion) window.addEventListener('pointermove', onMove, { passive: true });

    const resize = () => {
      const w = host.clientWidth || window.innerWidth, h = host.clientHeight || window.innerHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.fov = w / h < 1 ? 60 : 42;
      camera.updateProjectionMatrix();
    };
    resize();
    const ro = new ResizeObserver(resize); ro.observe(host);

    // Loop
    const timer = new THREE.Timer();
    timer.connect(document);
    let t = reduceMotion ? 40 : 0;
    let raf = 0; let visible = true;
    const frame = () => {
      if (!visible) return;
      raf = requestAnimationFrame(frame);
      timer.update();
      const dt = Math.min(timer.getDelta(), 0.05);
      if (!reduceMotion) t += dt * speed;
      smoothPtr.lerp(pointer, 0.03);

      sunUniforms.uTime.value = t * 6;
      sun.rotation.y = t * 0.02;
      glow1.material.rotation = t * 0.02;

      for (const L of live) {
        const w = (Math.PI * 2) / (L.def.period * 90); // radians/sec (Earth ~90s per orbit)
        const a = L.angle + t * w * 3.0;
        L.pivot.rotation.y = -a;
        L.body.rotation.y = t * L.def.spin * 0.35;
        if (L.clouds) L.clouds.rotation.y = t * L.def.spin * 0.42;
        if (L.moonPivot) L.moonPivot.rotation.y = t * 1.4;
      }
      belt.rotation.y = t * 0.012;

      // Update atmosphere sun directions (world space)
      for (const a of atmos) {
        a.host.getWorldPosition(sunDir); sunDir.negate().normalize();
        a.uni.uSunDir.value.copy(sunDir);
      }

      // Slow cinematic orbit around the system, low angle for dramatic perspective
      const ang = reduceMotion ? 0.6 : t * 0.018 + 0.6;
      const dist = 125, elev = 0.28 + smoothPtr.y * -0.05;
      camera.position.set(Math.cos(ang + smoothPtr.x * 0.12) * dist * Math.cos(elev), dist * Math.sin(elev) + 8, Math.sin(ang + smoothPtr.x * 0.12) * dist * Math.cos(elev));
      camera.lookAt(camTarget);
      fill.position.copy(camera.position);
      sky.position.copy(camera.position);

      renderer.render(scene, camera);
    };
    const onVis = () => { visible = !document.hidden; if (visible) { timer.reset(); frame(); } };
    document.addEventListener('visibilitychange', onVis);
    frame();

    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('pointermove', onMove);
      ro.disconnect();
      timer.dispose();
      disposables.forEach((d) => { try { d.dispose(); } catch { /* noop */ } });
      belt.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [theme, reduceMotion, speed, maxPixelRatio, interactive]);

  return (
    <div
      ref={hostRef}
      className={className}
      style={{ position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none', background: '#000' }}
      aria-hidden="true"
    />
  );
};

export default SolarSystemBackground3D;
