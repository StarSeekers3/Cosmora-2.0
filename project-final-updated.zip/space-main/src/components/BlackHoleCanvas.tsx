import React, { useEffect, useRef, useState } from 'react';
import { Sliders, Pause, Play } from 'lucide-react';

interface BlackHoleCanvasProps {
  interactive?: boolean;
  theme?: 'dark' | 'light';
}

/**
 * NASA Goddard Space Flight Center Simulation Architecture
 * Based on Dr. Jeremy Schnittman's General Relativistic Ray-Tracing Model (NASA GSFC, 2019)
 *
 * Characteristics:
 * - Smooth, continuous, luminous plasma fluid disk (no frantic noisy particle swarms).
 * - Authentic dual-arc gravitational lensing (top halo + underside halo).
 * - Smooth relativistic Doppler beaming (approaching side is brighter & hotter).
 * - Razor-sharp innermost photon sphere ring at 1.5 Schwarzschild radii (ISCO).
 * - Velvety, calm gravitational abyss with smooth, majestic rotation.
 */
export const BlackHoleCanvas: React.FC<BlackHoleCanvasProps> = ({
  interactive = false,
  theme = 'dark',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [speedMultiplier, setSpeedMultiplier] = useState(0.65); // Gentle, majestic default
  const [isPaused, setIsPaused] = useState(false);
  const [showControls, setShowControls] = useState(false);

  const isLight = theme === 'light';

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = 0;
    let height = 0;
    let centerX = 0;
    let centerY = 0;
    let bhRadius = 0;
    let dpr = 1;

    // Calm background stars with gravitational deflection
    interface Star {
      x: number;
      y: number;
      baseRadius: number;
      color: string;
    }

    let stars: Star[] = [];

    function setup() {
      if (!canvas) return;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = canvas.width = window.innerWidth * dpr;
      height = canvas.height = window.innerHeight * dpr;
      centerX = width / 2;
      centerY = height / 2;
      // Event horizon scale
      bhRadius = Math.min(width, height) * 0.125;

      // Seed clean, serene background starfield
      stars = [];
      const starCount = window.innerWidth < 768 ? 60 : 130;
      for (let i = 0; i < starCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const dist = bhRadius * 1.5 + Math.random() * Math.max(width, height) * 0.55;
        stars.push({
          x: centerX + Math.cos(angle) * dist,
          y: centerY + Math.sin(angle) * dist,
          baseRadius: (0.7 + Math.random() * 1.3) * dpr,
          color: isLight
            ? 'rgba(23, 60, 50, 0.28)'
            : i % 3 === 0
            ? 'rgba(240, 246, 255, 0.7)'
            : 'rgba(255, 245, 225, 0.6)',
        });
      }
    }

    let simTime = 0;
    let lastStamp = performance.now();

    function render() {
      if (!ctx) return;

      const tilt = 0.32; // ~18.5 deg viewing inclination (NASA benchmark)
      const now = performance.now();
      const dt = Math.min((now - lastStamp) / 1000, 0.05);
      lastStamp = now;

      if (!isPaused) {
        simTime += dt * speedMultiplier * 0.45; // Smooth, slow, hypnotic flow
      }

      // 1. CLEAR FRAME
      if (isLight) {
        ctx.clearRect(0, 0, width, height);
      } else {
        ctx.fillStyle = '#030509';
        ctx.fillRect(0, 0, width, height);
      }

      // 2. GRAVITATIONALLY DEFLECTED STARS (Schwarzschild Lens)
      ctx.globalCompositeOperation = 'source-over';
      stars.forEach(st => {
        const dx = st.x - centerX;
        const dy = st.y - centerY;
        const dist = Math.sqrt(dx * dx + dy * dy);

        // Einstein deflection angle pushes background stars outward
        const deflection = (bhRadius * bhRadius * 1.5) / Math.max(dist, bhRadius * 1.15);
        const lensedDist = dist + deflection;
        const lx = centerX + (dx / dist) * lensedDist;
        const ly = centerY + (dy / dist) * lensedDist;

        if (lx < 0 || lx > width || ly < 0 || ly > height) return;

        ctx.fillStyle = st.color;
        ctx.beginPath();
        ctx.arc(lx, ly, st.baseRadius, 0, Math.PI * 2);
        ctx.fill();
      });

      // 3. REAR GRAVITATIONAL LENSING HALO (TOP & BOTTOM ARCS)
      // Light from the accretion disk behind the black hole bent over the top and under the bottom
      ctx.save();
      ctx.globalCompositeOperation = isLight ? 'source-over' : 'lighter';

      // Top Lensed Arc (NASA Goddard signature arch)
      const topHaloGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        bhRadius * 0.95,
        centerX,
        centerY,
        bhRadius * 2.3
      );
      if (isLight) {
        topHaloGrad.addColorStop(0, 'rgba(217, 119, 6, 0.40)');
        topHaloGrad.addColorStop(0.3, 'rgba(234, 88, 12, 0.22)');
        topHaloGrad.addColorStop(0.7, 'rgba(180, 83, 9, 0.08)');
        topHaloGrad.addColorStop(1, 'rgba(180, 83, 9, 0)');
      } else {
        topHaloGrad.addColorStop(0, 'rgba(255, 245, 215, 0.85)');
        topHaloGrad.addColorStop(0.25, 'rgba(255, 180, 50, 0.60)');
        topHaloGrad.addColorStop(0.6, 'rgba(235, 95, 25, 0.28)');
        topHaloGrad.addColorStop(0.85, 'rgba(180, 35, 15, 0.10)');
        topHaloGrad.addColorStop(1, 'rgba(120, 20, 10, 0)');
      }

      ctx.fillStyle = topHaloGrad;
      ctx.beginPath();
      ctx.ellipse(centerX, centerY, bhRadius * 2.15, bhRadius * 1.5, 0, Math.PI, Math.PI * 2);
      ctx.fill();

      // Bottom Lensed Arc (under the shadow)
      const bottomHaloGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        bhRadius * 0.95,
        centerX,
        centerY,
        bhRadius * 1.55
      );
      if (isLight) {
        bottomHaloGrad.addColorStop(0, 'rgba(234, 88, 12, 0.18)');
        bottomHaloGrad.addColorStop(1, 'rgba(234, 88, 12, 0)');
      } else {
        bottomHaloGrad.addColorStop(0, 'rgba(255, 175, 45, 0.40)');
        bottomHaloGrad.addColorStop(0.5, 'rgba(220, 75, 20, 0.16)');
        bottomHaloGrad.addColorStop(1, 'rgba(140, 20, 10, 0)');
      }

      ctx.fillStyle = bottomHaloGrad;
      ctx.beginPath();
      ctx.ellipse(centerX, centerY, bhRadius * 1.7, bhRadius * 0.82, 0, 0, Math.PI);
      ctx.fill();
      ctx.restore();

      // 4. SMOOTH CONTINUOUS ACCRETION DISK (LAMINAR FLUID FLOW)
      // We render concentric smooth fluid bands with Keplerian shear rotation
      // Back half first (behind the shadow)
      const numBands = 36;
      const minR = bhRadius * 1.25;
      const maxR = bhRadius * 3.8;

      ctx.save();
      ctx.globalCompositeOperation = isLight ? 'source-over' : 'lighter';

      for (let i = 0; i < numBands; i++) {
        const frac = i / numBands;
        const r = minR + frac * (maxR - minR);
        // Keplerian differential rotation: inner disk rotates faster than outer disk
        const shear = Math.pow(minR / r, 1.35) * simTime;

        // Render back-half arc of this fluid band
        ctx.lineWidth = ((maxR - minR) / numBands) * 1.15;

        // Color based on temperature and distance
        let bandAlpha = isLight
          ? (1 - frac * 0.6) * 0.45
          : (1 - frac * 0.65) * 0.65;

        // Doppler modulation: approaching (left) is brighter, receding (right) is dimmer
        const grad = ctx.createLinearGradient(
          centerX - r,
          centerY,
          centerX + r,
          centerY
        );

        if (isLight) {
          grad.addColorStop(0, `rgba(234, 88, 12, ${bandAlpha * 1.2})`); // Left (Doppler boosted)
          grad.addColorStop(0.5, `rgba(217, 119, 6, ${bandAlpha * 0.9})`);
          grad.addColorStop(1, `rgba(180, 83, 9, ${bandAlpha * 0.5})`); // Right (Redshifted)
        } else {
          if (frac < 0.2) {
            // White-hot inner disk
            grad.addColorStop(0, `rgba(255, 250, 230, ${bandAlpha * 1.3})`);
            grad.addColorStop(0.5, `rgba(255, 210, 100, ${bandAlpha * 0.95})`);
            grad.addColorStop(1, `rgba(255, 140, 40, ${bandAlpha * 0.5})`);
          } else if (frac < 0.55) {
            // Golden mid disk
            grad.addColorStop(0, `rgba(255, 195, 60, ${bandAlpha * 1.2})`);
            grad.addColorStop(0.5, `rgba(245, 120, 30, ${bandAlpha * 0.85})`);
            grad.addColorStop(1, `rgba(200, 60, 20, ${bandAlpha * 0.45})`);
          } else {
            // Deep garnet outer fringe
            grad.addColorStop(0, `rgba(230, 80, 30, ${bandAlpha * 1.1})`);
            grad.addColorStop(0.5, `rgba(180, 40, 20, ${bandAlpha * 0.75})`);
            grad.addColorStop(1, `rgba(120, 20, 10, ${bandAlpha * 0.35})`);
          }
        }

        ctx.strokeStyle = grad;

        // Draw back arc (theta from Math.PI to Math.PI * 2)
        ctx.beginPath();
        ctx.ellipse(centerX, centerY, r, r * tilt, 0, Math.PI, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();

      // 5. VELVETY GRAVITATIONAL SHADOW (VELVET ABYSS - NO HARD STILL CIRCLE)
      // Soft, infinite gravitational well with deep radial optical absorption
      ctx.save();
      ctx.globalCompositeOperation = 'source-over';

      const shadowGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        0,
        centerX,
        centerY,
        bhRadius * 1.04
      );
      if (isLight) {
        shadowGrad.addColorStop(0, '#0a1916');
        shadowGrad.addColorStop(0.75, '#0d221e');
        shadowGrad.addColorStop(0.95, '#122c27');
        shadowGrad.addColorStop(1, 'rgba(18, 44, 39, 0.4)');
      } else {
        shadowGrad.addColorStop(0, '#000000');
        shadowGrad.addColorStop(0.8, '#000000');
        shadowGrad.addColorStop(0.96, '#030508');
        shadowGrad.addColorStop(1, 'rgba(3, 5, 8, 0.2)');
      }

      ctx.fillStyle = shadowGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, bhRadius * 1.04, 0, Math.PI * 2);
      ctx.fill();

      // 6. RAZOR-SHARP INNERMOST PHOTON SPHERE RING (NASA GSFC 1.5 Rs)
      // Thin, elegant, serene starlight boundary
      ctx.lineWidth = 1.6 * dpr;
      ctx.strokeStyle = isLight
        ? 'rgba(217, 119, 6, 0.90)'
        : 'rgba(255, 248, 225, 0.95)';
      ctx.shadowColor = isLight
        ? 'rgba(234, 88, 12, 0.85)'
        : 'rgba(255, 180, 50, 0.90)';
      ctx.shadowBlur = 10 * dpr;

      ctx.beginPath();
      ctx.arc(centerX, centerY, bhRadius * 1.01, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.restore();

      // 7. FRONT HALF OF ACCRETION DISK (CROSSING IN FRONT OF SHADOW)
      ctx.save();
      ctx.globalCompositeOperation = isLight ? 'source-over' : 'lighter';

      for (let i = 0; i < numBands; i++) {
        const frac = i / numBands;
        const r = minR + frac * (maxR - minR);
        ctx.lineWidth = ((maxR - minR) / numBands) * 1.15;

        let bandAlpha = isLight
          ? (1 - frac * 0.55) * 0.55
          : (1 - frac * 0.6) * 0.75;

        const grad = ctx.createLinearGradient(
          centerX - r,
          centerY,
          centerX + r,
          centerY
        );

        if (isLight) {
          grad.addColorStop(0, `rgba(234, 88, 12, ${bandAlpha * 1.25})`);
          grad.addColorStop(0.5, `rgba(217, 119, 6, ${bandAlpha * 0.95})`);
          grad.addColorStop(1, `rgba(180, 83, 9, ${bandAlpha * 0.55})`);
        } else {
          if (frac < 0.2) {
            grad.addColorStop(0, `rgba(255, 252, 235, ${bandAlpha * 1.35})`);
            grad.addColorStop(0.5, `rgba(255, 215, 110, ${bandAlpha * 1.0})`);
            grad.addColorStop(1, `rgba(255, 145, 45, ${bandAlpha * 0.55})`);
          } else if (frac < 0.55) {
            grad.addColorStop(0, `rgba(255, 200, 65, ${bandAlpha * 1.25})`);
            grad.addColorStop(0.5, `rgba(245, 125, 35, ${bandAlpha * 0.9})`);
            grad.addColorStop(1, `rgba(200, 65, 25, ${bandAlpha * 0.5})`);
          } else {
            grad.addColorStop(0, `rgba(230, 85, 35, ${bandAlpha * 1.15})`);
            grad.addColorStop(0.5, `rgba(185, 45, 25, ${bandAlpha * 0.8})`);
            grad.addColorStop(1, `rgba(125, 25, 15, ${bandAlpha * 0.4})`);
          }
        }

        ctx.strokeStyle = grad;

        // Draw front arc (theta from 0 to Math.PI)
        ctx.beginPath();
        ctx.ellipse(centerX, centerY, r, r * tilt, 0, 0, Math.PI);
        ctx.stroke();
      }
      ctx.restore();

      // 8. SUBTLE GENTLE RELATIVISTIC GAS FILAMENTS (Smooth, laminar stream lanes)
      ctx.save();
      ctx.globalCompositeOperation = isLight ? 'source-over' : 'lighter';
      const numStreams = 8;
      for (let s = 0; s < numStreams; s++) {
        const streamFrac = s / numStreams;
        const streamR = minR * 1.08 + streamFrac * (maxR - minR) * 0.75;
        const streamAngle = simTime * Math.pow(minR / streamR, 1.2) + s * 1.4;

        const sx = centerX + Math.cos(streamAngle) * streamR;
        const sy = centerY + Math.sin(streamAngle) * streamR * tilt;

        // Only draw when on front or upper lensed arc for clean visual serenity
        const streamAlpha = isLight ? 0.35 : 0.55;
        ctx.fillStyle = isLight
          ? `rgba(234, 88, 12, ${streamAlpha})`
          : `rgba(255, 240, 200, ${streamAlpha})`;
        ctx.beginPath();
        ctx.arc(sx, sy, 1.6 * dpr, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    setup();
    const loop = () => {
      render();
      animId = requestAnimationFrame(loop);
    };
    animId = requestAnimationFrame(loop);

    const handleResize = () => {
      setup();
    };

    window.addEventListener('resize', handleResize);
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
    };
  }, [speedMultiplier, isPaused, isLight]);

  return (
    <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
      <canvas
        ref={canvasRef}
        className="w-full h-full block"
        style={{ background: isLight ? 'transparent' : '#030509' }}
      />

      {interactive && (
        <div
          className={`absolute bottom-6 right-6 z-20 pointer-events-auto rounded-xl p-3.5 text-xs shadow-2xl border ${
            isLight
              ? 'bg-white/95 border-[#173c32]/30 text-[#17251f]'
              : 'bg-[#0b2025]/95 border-[#d9f36a]/40 text-[#eef4e6]'
          } backdrop-blur-md space-y-2.5 min-w-[260px]`}
        >
          <div className="flex items-center justify-between">
            <button
              onClick={() => setShowControls(!showControls)}
              className={`flex items-center gap-2 font-display font-bold hover:underline cursor-pointer ${
                isLight ? 'text-[#1e6f3d]' : 'text-[#d9f36a]'
              }`}
            >
              <Sliders size={14} />
              <span>NASA GSFC RELATIVITY HUD</span>
            </button>
            <span
              className={`text-[9px] font-mono px-2 py-0.5 rounded font-bold ${
                isLight ? 'bg-amber-100 text-amber-900' : 'bg-[#d9f36a]/20 text-[#d9f36a]'
              }`}
            >
              LAMINAR RELATIVISTIC
            </span>
          </div>

          {showControls && (
            <div className="space-y-2.5 border-t border-current/10 pt-2 font-mono text-[11px]">
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span>Accretion Flow Velocity:</span>
                  <strong className={isLight ? 'text-[#1e6f3d]' : 'text-[#d9f36a]'}>
                    {isPaused ? 'PAUSED' : `${speedMultiplier.toFixed(2)}x`}
                  </strong>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="1.8"
                  step="0.05"
                  value={speedMultiplier}
                  onChange={e => {
                    setSpeedMultiplier(parseFloat(e.target.value));
                    setIsPaused(false);
                  }}
                  className={`w-full cursor-pointer ${
                    isLight ? 'accent-[#1e6f3d]' : 'accent-[#d9f36a]'
                  }`}
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <span>Motion State:</span>
                <button
                  onClick={() => setIsPaused(!isPaused)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-bold transition-all cursor-pointer ${
                    isPaused
                      ? 'bg-amber-600 text-white'
                      : isLight
                      ? 'bg-[#1e6f3d] text-white'
                      : 'bg-[#d9f36a] text-[#061211]'
                  }`}
                >
                  {isPaused ? <Play size={11} /> : <Pause size={11} />}
                  <span>{isPaused ? 'RESUME FLOW' : 'PAUSE ANIMATION'}</span>
                </button>
              </div>

              <div className="text-[10px] text-gray-500 italic leading-snug">
                Grounded in NASA Goddard Space Flight Center supermassive black hole relativistic
                ray-tracing (smooth laminar plasma disk, 1.5 $R_s$ photon sphere).
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
