import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface BlackHoleBackground3DProps {
  theme?: 'dark' | 'light';
  reduceMotion?: boolean;
  /** Pixel-ratio cap. Lower = faster on weak GPUs. */
  maxPixelRatio?: number;
  /** Let the pointer gently tilt the camera. */
  interactive?: boolean;
  viewingAngle?: number;
  rotationSpeed?: number;
  dopplerBeaming?: boolean;
  className?: string;
}

/**
 * Ultra-realistic Schwarzschild black hole, ray-traced per pixel on the GPU.
 *
 * - Photon paths are integrated through curved spacetime (a = -1.5 rs h^2 r / r^5),
 *   so the background starfield, the disk's far side (top halo) and its underside
 *   (bottom halo) are all genuinely gravitationally lensed.
 * - Volumetric-looking accretion disk: Novikov-Thorne style temperature falloff,
 *   turbulent spiral filaments, blackbody colour ramp.
 * - Relativistic Doppler beaming + gravitational redshift (approaching side is brighter/bluer).
 * - Sharp photon ring, event-horizon shadow, soft bloom.
 */

const VERT = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = vec4(position.xy, 0.0, 1.0);
  }
`;

const FRAG = /* glsl */ `
  precision highp float;
  varying vec2 vUv;
  uniform vec2  uRes;
  uniform float uTime;
  uniform vec2  uTilt;      // (yaw, pitch) offsets from pointer
  uniform float uLight;     // 1.0 = light theme
  uniform float uQuality;
  uniform float uViewAngle;
  uniform float uBeaming;

  #define PI 3.14159265359
  const float RS      = 1.0;      // Schwarzschild radius
  const float R_IN    = 3.0;      // ISCO = 3 rs
  const float R_OUT   = 13.0;
  const int   STEPS   = 220;

  float hash(vec3 p){
    p = fract(p * 0.3183099 + .1); p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
  }
  float noise(vec3 x){
    vec3 i = floor(x), f = fract(x);
    f = f*f*(3.0-2.0*f);
    return mix(mix(mix(hash(i+vec3(0,0,0)),hash(i+vec3(1,0,0)),f.x),
                   mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),
               mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),
                   mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);
  }
  float fbm(vec3 p){
    float a = 0.5, s = 0.0;
    for(int i=0;i<5;i++){ s += a*noise(p); p = p*2.03 + 17.1; a *= 0.5; }
    return s;
  }

  // Blackbody-style ramp: orange -> warm white -> blue-white
  vec3 bb(float T){
    T = clamp(T, 0.0, 2.0);
    vec3 a = vec3(1.0, 0.28, 0.04);
    vec3 b = vec3(1.0, 0.72, 0.38);
    vec3 c = vec3(1.0, 0.95, 0.88);
    vec3 d = vec3(0.70, 0.82, 1.0);
    if (T < 0.5) return mix(a, b, T*2.0);
    if (T < 1.0) return mix(b, c, (T-0.5)*2.0);
    return mix(c, d, clamp(T-1.0, 0.0, 1.0));
  }

  // Procedural starfield + faint Milky Way band sampled by direction
  vec3 sky(vec3 d){
    vec3 col = vec3(0.0);
    // stars at three scales
    for(int i=0;i<3;i++){
      float sc = 90.0 + float(i)*110.0;
      vec3 p = d * sc;
      vec3 id = floor(p);
      vec3 f = fract(p) - 0.5;
      float h = hash(id + float(i)*13.7);
      if (h > 0.965) {
        float size = 0.06 + 0.12 * hash(id + 4.2);
        float s = smoothstep(size, 0.0, length(f + (hash(id+9.1)-0.5)*0.3));
        float temp = hash(id + 2.0);
        vec3 sc3 = mix(vec3(1.0,0.7,0.5), vec3(0.7,0.8,1.0), temp);
        col += sc3 * s * (0.6 + 1.6*hash(id+7.7));
      }
    }
    // galactic band
    vec3 gn = normalize(vec3(0.25, 0.9, 0.35));
    float band = exp(-pow(dot(d, gn)*3.2, 2.0));
    float dust = fbm(d*6.0 + 3.0);
    col += vec3(0.55,0.5,0.7) * band * (0.04 + 0.10*dust) * smoothstep(0.35,0.75,dust+band*0.4);
    col += vec3(0.9,0.75,0.6) * band * 0.015;
    return col;
  }

  vec3 diskColor(vec3 p, vec3 rayDir, float t){
    float r = length(p.xz);
    float x = (r - R_IN) / (R_OUT - R_IN);
    if (x < 0.0 || x > 1.0) return vec3(-1.0);

    float ang = atan(p.z, p.x);
    // Keplerian rotation: inner flows faster -> spiral shearing
    float omega = 1.6 / pow(r, 1.5) * 9.0;
    float a = ang + t * omega;
    vec3 q = vec3(cos(a) * r, 0.0, sin(a) * r);
    float turb = fbm(vec3(q.x*0.9, q.z*0.9, r*1.7) + vec3(0.0, 0.0, 0.0));
    float fil  = fbm(vec3(a*6.0, r*3.2, 1.7));
    float density = (0.45 + 0.9*turb) * (0.55 + 0.9*fil);

    // radial emissivity (hot inner, falls off), soft edges
    float rad = pow(1.0 - x, 2.2) * 2.6 + 0.08;
    float edge = smoothstep(0.0, 0.03, x) * smoothstep(1.0, 0.55, x);

    // temperature ~ r^-3/4
    float T = pow(R_IN / r, 0.75) * 1.25;

    // disk orbital velocity (tangential), v = sqrt(rs/(2(r-rs)))
    float v = sqrt(RS / (2.0 * max(r - RS, 0.01)));
    vec3 tang = normalize(vec3(-p.z, 0.0, p.x));
    float beta = clamp(v, 0.0, 0.7);
    float cosA = dot(tang, -rayDir);          // toward observer => approaching
    float gamma = 1.0 / sqrt(1.0 - beta*beta);
    float doppler = mix(1.0, 1.0 / (gamma * (1.0 - beta * cosA)), uBeaming);
    float grav = sqrt(max(1.0 - RS / r, 0.02));
    float g = doppler * grav;

    vec3 col = bb(T * g * 0.95) * density * rad * edge;
    col *= pow(g, 3.2);                         // relativistic beaming
    return col;
  }

  void main(){
    vec2 uv = (vUv - 0.5) * vec2(uRes.x / uRes.y, 1.0);

    // Camera: slightly above the disk plane, slow cinematic drift
    float yaw   = uTilt.x + sin(uTime*0.05)*0.08;
    float pitch = radians(90.0 - uViewAngle) + uTilt.y + sin(uTime*0.037)*0.03;
    float camR  = 30.0;
    vec3 ro = camR * vec3(sin(yaw)*cos(pitch), sin(pitch), cos(yaw)*cos(pitch));
    vec3 fw = normalize(-ro);
    vec3 rt = normalize(cross(vec3(0,1,0), fw));
    vec3 up = cross(fw, rt);
    float fov = 1.55;
    vec3 rd = normalize(fw*fov + rt*uv.x*1.0 + up*uv.y*1.0);

    // Integrate photon
    vec3 pos = ro;
    vec3 vel = rd;
    float h2 = pow(length(cross(pos, vel)), 2.0);
    vec3 acc = vec3(0.0);
    vec3 col = vec3(0.0);
    float trans = 1.0;
    bool hitHorizon = false;
    float minR = 1e5;

    for (int i = 0; i < STEPS; i++){
      float r = length(pos);
      minR = min(minR, r);
      if (r < RS) { hitHorizon = true; break; }
      if (r > 60.0 && dot(pos, vel) > 0.0) break;

      float dt = clamp(0.045 * r * r / (r + 2.0), 0.02, 1.4);
      dt = max(dt * (0.55 + 0.45 / uQuality), 0.02);
      acc = -1.5 * RS * h2 * pos / pow(r, 5.0);
      vec3 nvel = normalize(vel + acc * dt);
      vec3 npos = pos + nvel * dt;

      // disk plane crossing
      if (pos.y * npos.y < 0.0) {
        float f = pos.y / (pos.y - npos.y);
        vec3 hit = mix(pos, npos, f);
        vec3 dc = diskColor(hit, nvel, uTime);
        if (dc.x >= 0.0) {
          col += dc * trans;
          trans *= 0.55;
          if (trans < 0.02) break;
        }
      }
      // thin glowing volume above/below the disk (adds thickness)
      float ry = abs(npos.y);
      float rr = length(npos.xz);
      if (ry < 0.7 && rr > R_IN && rr < R_OUT * 0.8) {
        float vol = exp(-ry*ry*7.0) * pow(1.0 - (rr-R_IN)/(R_OUT-R_IN), 2.5);
        float tb = fbm(vec3(npos.x*0.5, npos.z*0.5, uTime*0.05));
        col += bb(pow(R_IN/rr, 0.75)) * vol * tb * dt * 0.06 * trans;
      }
      // photon-ring glow concentrates near r = 1.5 rs
      float ring = exp(-pow((r - 1.5)*4.5, 2.0));
      col += vec3(1.0, 0.86, 0.68) * ring * dt * 0.05 * trans;

      pos = npos;
      vel = nvel;
    }

    if (!hitHorizon) {
      vec3 s = sky(normalize(vel));
      col += s * trans;
    }

    // Sharp photon ring from grazing rays
    float pr = exp(-pow((minR - 1.5) * 9.0, 2.0));
    if (!hitHorizon) col += vec3(1.0, 0.9, 0.75) * pr * 0.55;

    // Bloom-ish tone map
    col *= 1.15;
    col = 1.0 - exp(-col * 1.35);
    col = pow(col, vec3(0.92));

    // Vignette
    float vg = smoothstep(1.25, 0.25, length(uv));
    col *= mix(0.55, 1.0, vg);

    // Light-theme: keep image legible behind bright UI by lifting blacks slightly
    col = mix(col, col * 0.85 + vec3(0.02, 0.025, 0.04), uLight * 0.6);

    gl_FragColor = vec4(col, 1.0);
  }
`;

export const BlackHoleBackground3D: React.FC<BlackHoleBackground3DProps> = ({
  theme = 'dark',
  reduceMotion = false,
  maxPixelRatio = 1.5,
  interactive = true,
  viewingAngle = 78,
  rotationSpeed = 0.6,
  dopplerBeaming = true,
  className,
}) => {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const viewingAngleRef = useRef(viewingAngle);
  const rotationSpeedRef = useRef(rotationSpeed);
  const dopplerBeamingRef = useRef(dopplerBeaming);
  viewingAngleRef.current = viewingAngle;
  rotationSpeedRef.current = rotationSpeed;
  dopplerBeamingRef.current = dopplerBeaming;

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: false, alpha: false, powerPreference: 'high-performance' });
    } catch {
      host.style.background = 'radial-gradient(circle at 50% 50%, #000 0%, #05060d 60%, #000 100%)';
      return;
    }

    // Render at reduced internal resolution; the ray-marcher is per-pixel heavy.
    const dpr = Math.min(window.devicePixelRatio || 1, maxPixelRatio);
    const scale = 0.75;
    renderer.setPixelRatio(dpr * scale);
    renderer.domElement.style.cssText = 'width:100%;height:100%;display:block;';
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    const uniforms = {
      uRes: { value: new THREE.Vector2(1, 1) },
      uTime: { value: 0 },
      uTilt: { value: new THREE.Vector2(0, 0) },
      uLight: { value: theme === 'light' ? 1 : 0 },
      uQuality: { value: 1 },
      uViewAngle: { value: viewingAngle },
      uBeaming: { value: dopplerBeaming ? 1 : 0 },
    };
    const material = new THREE.ShaderMaterial({ vertexShader: VERT, fragmentShader: FRAG, uniforms, depthTest: false, depthWrite: false });
    const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material);
    quad.frustumCulled = false;
    scene.add(quad);

    const resize = () => {
      const w = host.clientWidth || window.innerWidth;
      const h = host.clientHeight || window.innerHeight;
      renderer.setSize(w, h, false);
      const size = renderer.getDrawingBufferSize(new THREE.Vector2());
      uniforms.uRes.value.copy(size);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(host);

    const target = new THREE.Vector2(0, 0);
    const onMove = (e: PointerEvent) => {
      target.set(((e.clientX / window.innerWidth) - 0.5) * 0.35, -((e.clientY / window.innerHeight) - 0.5) * 0.12);
    };
    if (interactive && !reduceMotion) window.addEventListener('pointermove', onMove, { passive: true });

    // Adaptive quality: drop step count if frames run slow.
    let raf = 0;
    let last = performance.now();
    let slow = 0;
    const timer = new THREE.Timer();
    timer.connect(document);
    let visible = true;
    const onVis = () => { visible = !document.hidden; if (visible) { last = performance.now(); loop(); } };
    document.addEventListener('visibilitychange', onVis);

    const loop = () => {
      if (!visible) return;
      raf = requestAnimationFrame(loop);
      const now = performance.now();
      const dt = now - last; last = now;
      if (dt > 40) slow++; else slow = Math.max(0, slow - 1);
      if (slow > 30 && uniforms.uQuality.value > 0.5) { uniforms.uQuality.value = 0.5; }

      timer.update();
      uniforms.uTilt.value.lerp(target, 0.04);
      uniforms.uViewAngle.value = viewingAngleRef.current;
      uniforms.uBeaming.value = dopplerBeamingRef.current ? 1 : 0;
      uniforms.uTime.value = reduceMotion ? 12.0 : timer.getElapsed() * rotationSpeedRef.current;
      renderer.render(scene, camera);
    };
    loop();

    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('pointermove', onMove);
      ro.disconnect();
      timer.dispose();
      quad.geometry.dispose();
      material.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [theme, reduceMotion, maxPixelRatio, interactive]);

  return (
    <div
      ref={hostRef}
      className={className}
      style={{ position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none', background: '#000' }}
      aria-hidden="true"
    />
  );
};

export default BlackHoleBackground3D;
