import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { SolarSystemBackground3D } from './SolarSystemBackground3D';

/**
 * Mission Control — glass HUD that sits on top of the 3D solar system.
 * Usage: <MissionControlUI onOpenMission={(planet) => …} onNavigate={(view) => …} />
 * Fonts: add to index.html
 *   <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
 */

interface Body {
  name: string; kind: string; blurb: string; color: string;
  distance: string; orbit: string; day: string; tilt: string;
}

export const BODIES: Body[] = [
  { name: 'Mercury', kind: 'ROCKY', color: '#9a9792', distance: '0.39 AU', orbit: '88 d', day: '58.6 d', tilt: '0.03°', blurb: 'The smallest planet and the closest to the Sun, with no real atmosphere.' },
  { name: 'Venus', kind: 'ROCKY', color: '#e0b46a', distance: '0.72 AU', orbit: '225 d', day: '243 d', tilt: '177.4°', blurb: 'Spins backwards, and its thick atmosphere makes it the hottest planet.' },
  { name: 'Earth', kind: 'ROCKY', color: '#3b82e0', distance: '1.00 AU', orbit: '365 d', day: '24 h', tilt: '23.4°', blurb: 'The only world known to host life, with liquid oceans covering most of its surface.' },
  { name: 'Mars', kind: 'ROCKY', color: '#c4502c', distance: '1.52 AU', orbit: '687 d', day: '24.6 h', tilt: '25.2°', blurb: 'A cold desert world with the tallest volcano in the solar system.' },
  { name: 'Jupiter', kind: 'GAS GIANT', color: '#c8935e', distance: '5.20 AU', orbit: '11.9 yr', day: '9.9 h', tilt: '3.1°', blurb: 'The largest planet, wrapped in storm bands and the centuries-old Great Red Spot.' },
  { name: 'Saturn', kind: 'GAS GIANT', color: '#e3cf9f', distance: '9.58 AU', orbit: '29.4 yr', day: '10.7 h', tilt: '26.7°', blurb: 'Less dense than water, wrapped in a ring system of ice and rock.' },
  { name: 'Uranus', kind: 'ICE GIANT', color: '#9fe0e6', distance: '19.2 AU', orbit: '84 yr', day: '17.2 h', tilt: '97.8°', blurb: 'Rolls around the Sun on its side, tilted almost flat to its orbit.' },
  { name: 'Neptune', kind: 'ICE GIANT', color: '#4f80ff', distance: '30.1 AU', orbit: '165 yr', day: '16.1 h', tilt: '28.3°', blurb: 'The windiest planet, the farthest from the Sun.' },
];

type View = 'orrery' | 'missions' | 'starmap' | 'observatory';

interface Props {
  theme?: 'dark' | 'light';
  reduceMotion?: boolean;
  cadetName?: string;
  cadetRank?: string;
  onNavigate?: (view: View) => void;
  onOpenMission?: (planet: string) => void;
}

const mono: React.CSSProperties = { fontFamily: "'JetBrains Mono', ui-monospace, monospace" };
const glass = 'bg-[rgba(10,14,28,0.62)] border border-white/10 backdrop-blur-xl';

export const MissionControlUI: React.FC<Props> = ({
  theme = 'dark', reduceMotion, onNavigate, onOpenMission,
}) => {
  const [selected, setSelected] = useState('Saturn');
  const body = BODIES.find((b) => b.name === selected)!;

  return (
    <div className="relative min-h-[calc(100vh-4rem)] min-h-[calc(100dvh-4rem)] overflow-hidden bg-[#05060d] text-[#e8ecf8]" style={{ fontFamily: "'Space Grotesk', system-ui, sans-serif" }}>
      <SolarSystemBackground3D theme={theme} reduceMotion={reduceMotion} />
      <div className="pointer-events-none fixed inset-0 z-[1] bg-gradient-to-r from-[#05060d]/90 via-[#05060d]/55 to-transparent lg:via-[#05060d]/40" />

      <div className="relative z-10 flex min-h-full flex-col px-5 pb-8 sm:px-12">
        {/* hero + planet panel */}
        <main className="flex flex-1 flex-wrap items-start justify-between gap-8 pt-8 sm:pt-12">
          <section className="flex max-w-[520px] flex-col gap-5">
            <span className="text-xs tracking-[0.22em] text-[#ffb454]" style={mono}>MISSION CONTROL · SOL SYSTEM</span>
            <h1 className="m-0 text-5xl font-bold leading-[1.02] tracking-tight sm:text-6xl">Fly the real<br />solar system.</h1>
            <p className="m-0 text-lg leading-relaxed text-[#b4bcd4]">
              Every orbit moves in proportion to its true period. Pick a world, read its telemetry, then launch a mission built around it.
            </p>
            <div className="flex flex-wrap gap-3">
              <button onClick={() => onOpenMission?.(selected)} className="inline-flex min-h-12 items-center gap-2.5 rounded-full bg-[#ffb454] px-6 text-base font-semibold text-[#1a1205] transition hover:bg-[#ffc47a]">
                Start a mission <ArrowRight size={18} />
              </button>
              <button onClick={() => onNavigate?.('observatory')} className="inline-flex min-h-12 items-center rounded-full border border-white/20 bg-[rgba(12,16,32,0.4)] px-6 text-base font-medium transition hover:bg-white/10">
                Visit the Observatory
              </button>
            </div>
          </section>

          <aside className={`w-full max-w-[340px] rounded-3xl p-6 ${glass} flex flex-col gap-4`} aria-live="polite">
            <div className="flex items-center justify-between">
              <span className="text-[11px] tracking-[0.2em] text-[#9aa3bd]" style={mono}>SELECTED BODY</span>
              <span className="rounded-full border border-[#ffb454]/50 px-2.5 py-0.5 text-[11px] text-[#ffb454]" style={mono}>{body.kind}</span>
            </div>
            <h2 className="m-0 text-4xl font-bold tracking-tight">{body.name}</h2>
            <p className="m-0 text-sm leading-relaxed text-[#b4bcd4]">{body.blurb}</p>
            <dl className="m-0 grid grid-cols-2 gap-3">
              {([['DISTANCE', body.distance], ['ORBIT', body.orbit], ['DAY', body.day], ['AXIAL TILT', body.tilt]] as const).map(([k, v]) => (
                <div key={k} className="rounded-2xl bg-white/5 p-3.5">
                  <dt className="text-[11px] text-[#9aa3bd]" style={mono}>{k}</dt>
                  <dd className="m-0 mt-1 text-[22px] font-semibold">{v}</dd>
                </div>
              ))}
            </dl>
            <button onClick={() => onOpenMission?.(selected)} className="min-h-12 rounded-2xl border border-[#ffb454]/55 bg-[#ffb454]/15 text-[15px] font-semibold text-[#ffcf8a] transition hover:bg-[#ffb454]/25">
              Open {body.name} mission
            </button>
          </aside>
        </main>

        {/* planet dock */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-2.5" role="tablist" aria-label="Planets">
          {BODIES.map((b) => {
            const on = b.name === selected;
            return (
              <button
                key={b.name} role="tab" aria-selected={on} onClick={() => setSelected(b.name)}
                className={`inline-flex min-h-12 items-center gap-2.5 rounded-full border px-4 text-sm transition ${on ? 'border-[#ffb454] bg-[#ffb454]/15 font-semibold text-[#ffe0b0]' : 'border-white/15 bg-[rgba(12,16,32,0.65)] font-medium hover:bg-white/10'}`}
              >
                <span className="h-3 w-3 rounded-full" style={{ background: b.color }} />
                {b.name}
                <span className={`text-[11px] ${on ? 'text-[#ffcf8a]' : 'text-[#9aa3bd]'}`} style={mono}>{b.distance}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default MissionControlUI;
