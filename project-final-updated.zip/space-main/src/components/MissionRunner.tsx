import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Flame,
  Gauge,
  Compass,
  Zap,
  Activity,
  Radio,
  Eye,
  Sliders,
  Play,
  Volume2,
} from 'lucide-react';
import { AstronautProfile, Mission, QuizQuestion } from '../types';
import { ApodReward } from './nasa/ApodReward';
import { NtrsSources } from './nasa/NtrsSources';
import { PLANETS } from '../data/planetsData';
import { PlanetCanvas } from './PlanetCanvas';
import { DockingSimulator } from './DockingSimulator';
import { LunarLander } from './LunarLander';
import { OutpostCommander } from './OutpostCommander';
import {
  playUiClick,
  playTone,
  playErrorAlert,
  playSuccessChime,
  playRocketLaunchSound,
} from '../utils/audio';
import { fireMissionConfetti, fireRocketSparks } from '../utils/confetti';
import { shuffleQuizOptionOrder } from '../utils/quizOptions';

const CORRECT_ANSWER_PARTICLES = [
  [-25, -6], [-20, -19], [-9, -27], [7, -29], [21, -19], [27, -4],
  [23, 14], [10, 26], [-7, 25], [-22, 15],
] as const;
const INCORRECT_ANSWER_PARTICLES = [
  [-20, -4], [-13, -17], [1, -22], [16, -14], [22, 2], [9, 16], [-11, 13],
] as const;

interface MissionRunnerProps {
  mission: Mission;
  profile: AstronautProfile;
  onComplete: (missionId: number, pointsEarned: number) => void;
  onBackToDeck: () => void;
  onNextMission?: (nextMissionId: number) => void;
}

export const MissionRunner: React.FC<MissionRunnerProps> = ({
  mission,
  profile,
  onComplete,
  onBackToDeck,
  onNextMission,
}) => {
  // Common Quiz State
  const [questionIndex, setQuestionIndex] = useState(0);
  const [optionOrder, setOptionOrder] = useState(() => shuffleQuizOptionOrder(mission.questions[0]));
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [correctCount, setCorrectCount] = useState(0);
  const [missionFinished, setMissionFinished] = useState(false);
  const [mascotMessage, setMascotMessage] = useState(
    `Welcome to Mission ${mission.id}: ${mission.title}. Review briefing telemetry carefully, Cadet ${profile.name}!`
  );

  // 1. Centrifuge Simulator State
  const [gLevel, setGLevel] = useState(1.0);
  const [heartRate, setHeartRate] = useState(72);
  const [agsmActive, setAgsmActive] = useState(false);
  const [centrifugePassed, setCentrifugePassed] = useState(false);

  // 2. Launch Console State
  const launchSteps = ['FUEL SYSTEMS', 'GUIDANCE COMPUTER', 'PRESSURE VALVES', 'ENGINE IGNITION'];
  const [activeLaunchStep, setActiveLaunchStep] = useState(0);
  const [launchTimer, setLaunchTimer] = useState(18);
  const [launchMisses, setLaunchMisses] = useState(0);
  const [launchStatusText, setLaunchStatusText] = useState('ALL SYSTEMS STANDBY · PRESS FUEL SYSTEMS');
  const [isLaunching, setIsLaunching] = useState(false);

  // 3. Max-Q Ascent State
  const [throttle, setThrottle] = useState(100);
  const [ascentAltitude, setAscentAltitude] = useState(12);
  const [staged, setStaged] = useState(false);
  const [maxQSurvived, setMaxQSurvived] = useState(false);

  // 4. Floating Zero-G Objects
  const [floatingItems, setFloatingItems] = useState([
    { id: 1, icon: '🔧', name: 'Wrench', x: 20, y: 35, vx: 0.35, vy: 0.25 },
    { id: 2, icon: '💧', name: 'Water Sphere', x: 60, y: 25, vx: -0.25, vy: 0.4 },
    { id: 3, icon: '🍎', name: 'Space Apple', x: 45, y: 70, vx: 0.4, vy: -0.3 },
    { id: 4, icon: '📷', name: 'Flight Camera', x: 75, y: 60, vx: -0.3, vy: -0.25 },
  ]);

  // 5. Spacewalk EVA State
  const [tetherLocked, setTetherLocked] = useState(true);
  const [visorGoldDown, setVisorGoldDown] = useState(true);

  // 8. Mars Perseverance & Ingenuity Helicopter State
  const [rotorRpm, setRotorRpm] = useState(0);
  const [heloAltitude, setHeloAltitude] = useState(0);
  const [laserZapped, setLaserZapped] = useState(false);

  // 9. Parker Solar Probe State
  const [shieldAngle, setShieldAngle] = useState(0); // 0 deg is direct sun facing
  const [shieldTemp, setShieldTemp] = useState(1380);

  // 10. DART Kinetic Impactor State
  const [dartImpacted, setDartImpacted] = useState(false);

  // 11. Planet Explorer State
  const [selectedPlanetIndex, setSelectedPlanetIndex] = useState(3); // Mars default
  const [userWeight, setUserWeight] = useState(70);

  // 12. Europa Clipper Radar Sounding State
  const [clipperPinging, setClipperPinging] = useState(false);
  const [oceanSounded, setOceanSounded] = useState(false);

  // 13. Titan Dragonfly State
  const [dragonflyFlight, setDragonflyFlight] = useState(false);
  const [tholinSampled, setTholinSampled] = useState(false);

  // 14. JWST Mirror Phasing State
  const [jwstAligned, setJwstAligned] = useState(6); // 6 out of 18 initially

  // 15. Exoplanet Transit State
  const [transitScanned, setTransitScanned] = useState(false);
  const [bioDetected, setBioDetected] = useState(false);

  // 16. Gravitational Waves State
  const [interferometerLocked, setInterferometerLocked] = useState(false);
  const [chirpPlaying, setChirpPlaying] = useState(false);

  // 17. Black Hole Relativity State
  const [dilationRatio, setDilationRatio] = useState(7.0);

  // 18. Voyager DSN Radio State
  const [dsnDish, setDsnDish] = useState('Goldstone DSS-14 (70m · California)');
  const [voyagerCarrierLocked, setVoyagerCarrierLocked] = useState(false);

  // Launch Timer for 'launch'
  useEffect(() => {
    if (mission.interactiveType !== 'launch' || missionFinished || isLaunching) return;

    const timer = setInterval(() => {
      setLaunchTimer(prev => {
        if (prev <= 1) {
          playErrorAlert();
          setLaunchStatusText('WINDOW MISSED · ABORT AND RECYCLE SEQUENCE');
          setLaunchMisses(m => m + 1);
          setActiveLaunchStep(0);
          return 18;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [mission.interactiveType, missionFinished, isLaunching]);

  // Zero-G Physics for 'gravity'
  useEffect(() => {
    if (mission.interactiveType !== 'gravity' || missionFinished) return;

    let animId: number;
    const updatePhysics = () => {
      setFloatingItems(prevItems =>
        prevItems.map(item => {
          let nx = item.x + item.vx;
          let ny = item.y + item.vy;
          let nvx = item.vx;
          let nvy = item.vy;

          if (nx < 5 || nx > 88) {
            nvx = -nvx;
            nx = Math.max(5, Math.min(88, nx));
          }
          if (ny < 5 || ny > 82) {
            nvy = -nvy;
            ny = Math.max(5, Math.min(82, ny));
          }
          return { ...item, x: nx, y: ny, vx: nvx, vy: nvy };
        })
      );
      animId = requestAnimationFrame(updatePhysics);
    };

    animId = requestAnimationFrame(updatePhysics);
    return () => cancelAnimationFrame(animId);
  }, [mission.interactiveType, missionFinished]);

  // Handle Launch Console
  const handleLaunchStepClick = (index: number) => {
    if (isLaunching) return;

    if (index !== activeLaunchStep) {
      playErrorAlert();
      setLaunchMisses(m => m + 1);
      setActiveLaunchStep(0);
      setLaunchStatusText('SEQUENCE ERROR · RETURN TO [01] FUEL SYSTEMS');
      setMascotMessage('Careful! Rocket stages must be activated in exact order.');
      return;
    }

    const nextStep = activeLaunchStep + 1;
    setActiveLaunchStep(nextStep);
    playTone(280 + activeLaunchStep * 110, 0.15, 'triangle');

    if (nextStep < launchSteps.length) {
      setLaunchStatusText(`SYSTEM 0${nextStep} GREEN · ENGAGE NEXT SYSTEM`);
      setMascotMessage('Telemetry verified. Keep the countdown moving!');
    } else {
      setIsLaunching(true);
      setLaunchStatusText('ALL SYSTEMS NOMINAL · MAIN ENGINE IGNITION · WE HAVE LIFTOFF!');
      setMascotMessage('Tremendous job! Maximum aerodynamic pressure cleared!');
      playRocketLaunchSound();
      fireRocketSparks(0.5, 0.6);

      setTimeout(() => {
        const points = Math.max(10, mission.points - launchMisses * 2);
        setMissionFinished(true);
        playSuccessChime();
        fireMissionConfetti();
        onComplete(mission.id, points);
      }, 2000);
    }
  };

  // Catching Zero-G items
  const handleCatchItem = (id: number) => {
    playTone(520, 0.1, 'sine');
    setFloatingItems(prev => prev.filter(item => item.id !== id));
    if (floatingItems.length <= 1) {
      playSuccessChime();
      fireMissionConfetti();
      setMascotMessage('All orbital tools secured! Microgravity cabin secured.');
      setTimeout(() => {
        setMissionFinished(true);
        onComplete(mission.id, mission.points);
      }, 800);
    }
  };

  // Common Quiz submission
  const currentQuestion: QuizQuestion | undefined = mission.questions[questionIndex];
  const displayedCorrectIndex = currentQuestion ? optionOrder.indexOf(currentQuestion.answer) : -1;

  const handleSelectAnswer = (index: number) => {
    if (answered) return;
    setSelectedAnswer(index);
    setAnswered(true);

    const isCorrect = index === displayedCorrectIndex;
    if (isCorrect) {
      playSuccessChime();
      setCorrectCount(c => c + 1);
      setMascotMessage('Outstanding, Cadet! Telemetry verified correct.');
    } else {
      playErrorAlert();
      setMascotMessage('Anomaly detected! Review the flight explanation below.');
    }
  };

  const handleNextQuestion = () => {
    setSelectedAnswer(null);
    setAnswered(false);
    playUiClick();

    if (questionIndex + 1 < mission.questions.length) {
      const nextQuestion = mission.questions[questionIndex + 1];
      setOptionOrder(shuffleQuizOptionOrder(nextQuestion, displayedCorrectIndex));
      setQuestionIndex(q => q + 1);
    } else {
      // Quiz complete
      setMissionFinished(true);
      const score = Math.round(((correctCount + (selectedAnswer === displayedCorrectIndex ? 1 : 0)) / mission.questions.length) * mission.points);
      playSuccessChime();
      fireMissionConfetti();
      onComplete(mission.id, Math.max(10, score));
    }
  };

  return (
    <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 py-6 md:py-10 space-y-6">
      {/* Top Header bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => {
            playUiClick();
            onBackToDeck();
          }}
          className="flex items-center gap-1.5 text-xs font-mono text-[#9fb1a6] hover:text-[#d9f36a] transition-colors cursor-pointer"
        >
          <ArrowLeft size={14} />
          <span>RETURN TO FLIGHT PLAN</span>
        </button>

        <div className="flex items-center gap-2 text-xs font-mono text-[#9fb1a6]">
          <span className="text-[#ef7144] font-bold">MISSION {mission.id} OF 19</span>
          <span>•</span>
          <span className="text-[#d9f36a] font-bold">{mission.points} ACADEMY CREDITS</span>
        </div>
      </div>

      {/* Main Mission Card */}
      <div className="rounded-2xl border border-[#1b3834] bg-[#0b2025]/95 backdrop-blur-md p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
        {/* Banner header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
          <div className="flex items-start gap-4">
            <span className="text-4xl p-3 rounded-xl bg-[#091f22] border border-[#1b3834]">
              {mission.icon}
            </span>
            <div>
              <span className="text-[10px] font-mono tracking-widest text-[#ef7144] uppercase font-bold">
                {mission.category}
              </span>
              <h1 className="font-display font-bold text-2xl sm:text-3xl text-[#eef4e6] mt-0.5">
                {mission.title}
              </h1>
              <p className="text-xs sm:text-sm text-[#72d1d6] italic mt-0.5">
                {mission.subtitle}
              </p>
            </div>
          </div>

          <div className="text-right sm:self-center font-mono text-xs text-[#9fb1a6] bg-[#07191e] px-4 py-2 rounded-lg border border-[#1b3834]">
            <div>OPERATOR: {profile.name}</div>
            <div className="text-[#d9f36a] font-bold">STATUS: IN-FLIGHT</div>
          </div>
        </div>

        {/* Mission Briefing and Objectives */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          <div className="p-4 rounded-xl bg-[#07191e] border border-white/5 space-y-1.5">
            <span className="text-[10px] text-[#ef7144] tracking-widest uppercase font-bold">
              FLIGHT BRIEFING
            </span>
            <p className="text-[#bdc9c0] leading-relaxed">{mission.briefing}</p>
          </div>
          <div className="p-4 rounded-xl bg-[#07191e] border border-white/5 space-y-1.5 flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-[#72d1d6] tracking-widest uppercase font-bold">
                PRIMARY OBJECTIVE &amp; SCIENCE PRINCIPLE
              </span>
              <p className="text-[#bdc9c0] leading-relaxed mt-1">{mission.objective}</p>
            </div>
            <div className="flex items-center gap-2 pt-2 border-t border-white/5 text-[11px]">
              <button
                onClick={() => {
                  playTone(480, 0.1, 'sine');
                  if (mission.interactiveType === 'centrifuge') {
                    setMascotMessage('Hold AGSM breath to tense your lower muscles, then increase centrifuge power to 4.0G+!');
                  } else if (mission.interactiveType === 'launch') {
                    setMascotMessage('Follow the numbered sequence 01 through 06 in exact order before T-0!');
                  } else if (mission.interactiveType === 'ascent') {
                    setMascotMessage('Throttle down into the green safety band (70%) to survive Max-Q aerodynamic pressure!');
                  } else if (mission.interactiveType === 'docking') {
                    setMascotMessage('Align roll, pitch, and yaw indicators to zero and keep approach speed under 0.1 m/s.');
                  } else if (mission.interactiveType === 'lunar') {
                    setMascotMessage('Puff descent thrusters gently to brake. Keep vertical touchdown speed under 2.0 m/s!');
                  } else if (mission.interactiveType === 'perseverance') {
                    setMascotMessage('Spin rotors to 2,400+ RPM to generate aerodynamic lift in Mars thin 1% atmosphere.');
                  } else {
                    setMascotMessage('Review the scientific briefing and execute nominal checklist telemetry.');
                  }
                }}
                className="text-[#d9f36a] hover:underline flex items-center gap-1 cursor-pointer font-bold"
              >
                <span>💡 Request CapCom Hint</span>
              </button>
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* INTERACTIVE SIMULATORS FOR ALL 18 MISSIONS                               */}
        {/* ========================================================================= */}
        <div className="pt-2">
          {/* 1. CENTRIFUGE G-FORCE TRAINING */}
          {mission.interactiveType === 'centrifuge' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-[#d9f36a]/40 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#d9f36a] font-bold">CENTRIFUGE ROTATIONAL ACCELERATOR</span>
                <span className={gLevel >= 4.0 ? 'text-red-400 font-bold animate-pulse' : 'text-white'}>
                  FORCE: {gLevel.toFixed(1)} G
                </span>
              </div>

              {/* Tunnel vision visualizer */}
              <div className="relative h-44 rounded-xl bg-[#020508] border border-[#1b3834] overflow-hidden flex items-center justify-center">
                {/* Visual vignetting based on G-level */}
                <div
                  className="absolute inset-0 transition-all duration-300 pointer-events-none"
                  style={{
                    background: agsmActive
                      ? 'transparent'
                      : `radial-gradient(circle, transparent ${Math.max(10, 100 - gLevel * 20)}%, rgba(0,0,0,${Math.min(0.95, (gLevel - 1) * 0.28)}) 95%)`,
                  }}
                />

                <div className="relative z-10 text-center space-y-2">
                  <div className="text-4xl animate-spin" style={{ animationDuration: `${Math.max(0.6, 4.0 / gLevel)}s` }}>
                    🌀
                  </div>
                  <div className="font-mono text-xs">
                    <span className="text-[#9fb1a6]">HEART RATE: </span>
                    <strong className={heartRate > 120 ? 'text-red-400' : 'text-[#d9f36a]'}>
                      {heartRate} BPM
                    </strong>
                  </div>
                </div>

                <div className="absolute bottom-2 left-3 text-[10px] font-mono text-[#9fb1a6]">
                  PERIPHERAL FIELD: {agsmActive ? '100% CLEAR (AGSM ACTIVE)' : gLevel > 3.5 ? 'GRAY-OUT RISK' : 'NOMINAL'}
                </div>
              </div>

              {/* Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono">
                    <span>Centrifuge Speed:</span>
                    <strong className="text-[#d9f36a]">{gLevel.toFixed(1)} G</strong>
                  </div>
                  <input
                    type="range"
                    min="1.0"
                    max="4.5"
                    step="0.1"
                    value={gLevel}
                    onChange={e => {
                      const val = parseFloat(e.target.value);
                      setGLevel(val);
                      setHeartRate(Math.round(72 + (val - 1) * 22));
                      if (val >= 4.0 && !agsmActive) {
                        playTone(180, 0.2, 'sawtooth');
                      }
                    }}
                    className="w-full accent-[#d9f36a] cursor-pointer"
                  />
                </div>

                <div className="flex gap-2">
                  <button
                    onMouseDown={() => {
                      setAgsmActive(true);
                      playTone(440, 0.15, 'sine');
                    }}
                    onMouseUp={() => setAgsmActive(false)}
                    onTouchStart={() => setAgsmActive(true)}
                    onTouchEnd={() => setAgsmActive(false)}
                    className="flex-1 px-4 py-2.5 rounded-lg bg-[#ef7144] hover:bg-[#ff7e54] text-white font-display font-bold text-xs uppercase cursor-pointer"
                  >
                    HOLD TO PERFORM AGSM BREATH (ANTI-G)
                  </button>
                  <button
                    onClick={() => {
                      if (gLevel >= 4.0) {
                        setCentrifugePassed(true);
                        playSuccessChime();
                        fireMissionConfetti();
                        setMascotMessage('Exceptional G-tolerance, Cadet! 4.5 G sustained without gray-out.');
                      } else {
                        playTone(220, 0.2, 'triangle');
                        setMascotMessage('Increase centrifuge power to 4.0+ G to complete training certification!');
                      }
                    }}
                    className="px-4 py-2.5 rounded-lg bg-[#d9f36a] text-[#061211] font-display font-bold text-xs uppercase cursor-pointer"
                  >
                    {centrifugePassed ? 'CERTIFIED ✓' : 'VERIFY G-LOCK'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 2. LAUNCH SEQUENCE */}
          {mission.interactiveType === 'launch' && (
            <div className="space-y-4">
              <div
                className={`relative h-64 sm:h-72 rounded-2xl bg-gradient-to-b from-[#020509] via-[#05141c] to-[#0a2328] border border-[#1b3834] overflow-hidden flex flex-col justify-end items-center p-4 transition-all duration-300 ${
                  isLaunching ? 'rocket-rumbling border-[#ef7144]/60 shadow-[0_0_30px_rgba(239,113,68,0.25)]' : ''
                }`}
              >
                <div className="absolute inset-0 bg-[radial-gradient(#ffffff15_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

                {/* Ambient ignition glow on launch pad */}
                {isLaunching && (
                  <div className="absolute inset-0 bg-gradient-to-t from-[#ef7144]/35 via-[#ffc93c]/15 to-transparent pointer-events-none animate-pulse" />
                )}

                {/* Pad exhaust smoke billow plume */}
                {isLaunching && (
                  <div className="absolute bottom-3 w-72 h-14 bg-gradient-to-t from-white/40 via-orange-500/30 to-transparent blur-lg rounded-full pointer-events-none" />
                )}

                <div
                  className={`relative z-10 flex flex-col items-center transition-all duration-[1400ms] ease-in ${
                    isLaunching ? '-translate-y-[450px] scale-90 opacity-0' : 'translate-y-0'
                  }`}
                >
                  <div className="w-10 h-12 rounded-t-full bg-gradient-to-b from-white via-slate-200 to-slate-300 border-2 border-slate-700 flex items-center justify-center shadow-lg">
                    <span className="text-xs select-none">👩‍🚀</span>
                  </div>
                  <div className="w-12 h-24 bg-gradient-to-r from-slate-200 via-white to-slate-200 border-x-2 border-slate-700 flex flex-col items-center justify-center">
                    <span className="text-[9px] font-mono font-bold tracking-widest text-slate-800 rotate-90 select-none">
                      STAR-1
                    </span>
                  </div>
                  <div className="w-10 h-6 bg-slate-700 rounded-b-md flex justify-center items-end relative">
                    {isLaunching && (
                      <div className="absolute top-full flex flex-col items-center">
                        <div className="w-10 h-28 bg-gradient-to-b from-yellow-100 via-orange-500 to-transparent rounded-full blur-[2px] animate-pulse" />
                        <Flame size={32} className="text-orange-400 -mt-16 animate-bounce" />
                        {/* Exhaust particles */}
                        <div className="w-2 h-10 bg-yellow-200/80 rounded-full blur-[1px] -mt-6 animate-ping" />
                      </div>
                    )}
                  </div>
                </div>

                <div className="w-48 h-3 bg-slate-800 rounded border-t border-slate-600 relative z-0" />

                <div className="absolute top-3 right-3 bg-black/70 border border-white/10 rounded px-3 py-1.5 font-mono text-[11px] text-right space-y-0.5 backdrop-blur-sm">
                  <div className="text-[#9fb1a6]">COUNTDOWN</div>
                  <div className={`text-lg font-bold ${launchTimer <= 5 ? 'text-red-400 animate-ping' : 'text-[#d9f36a]'}`}>
                    T-{String(launchTimer).padStart(2, '0')}s
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#07191e] border border-[#1b3834] flex items-center justify-between text-xs font-mono">
                <span className="text-[#9fb1a6]">STATUS:</span>
                <span className="text-[#d9f36a] font-bold truncate pl-2">{launchStatusText}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {launchSteps.map((step, idx) => {
                  const isPassed = idx < activeLaunchStep;
                  const isCurrent = idx === activeLaunchStep;
                  return (
                    <button
                      key={step}
                      onClick={() => handleLaunchStepClick(idx)}
                      disabled={isLaunching}
                      className={`p-3 rounded-xl border text-xs font-mono font-bold transition-all text-left flex items-center justify-between cursor-pointer ${
                        isPassed
                          ? 'border-[#d9f36a]/60 bg-[#163d39] text-[#d9f36a]'
                          : isCurrent
                          ? 'border-[#ef7144] bg-[#0d2a2c] text-[#eef4e6] shadow-[0_0_12px_rgba(239,113,68,0.4)] animate-pulse'
                          : 'border-[#1b3834] bg-[#091f22] text-[#9fb1a6] opacity-60'
                      }`}
                    >
                      <span>[0{idx + 1}] {step}</span>
                      {isPassed && <CheckCircle2 size={16} className="text-[#d9f36a]" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 3. ASCENT & MAX-Q STAGING */}
          {mission.interactiveType === 'ascent' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-[#72d1d6]/40 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#72d1d6] font-bold">ATMOSPHERIC ASCENT & AERODYNAMIC STRESS</span>
                <span className="text-[#d9f36a] font-bold">ALTITUDE: {ascentAltitude} KM</span>
              </div>

              {/* Ascent Telemetry Bar */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
                <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
                  <div className="text-[10px] text-[#9fb1a6]">DYNAMIC PRESSURE (Q)</div>
                  <div className="text-base font-bold text-orange-400 mt-1">
                    {throttle > 80 && ascentAltitude === 12 ? 'CRITICAL (MAX-Q!)' : 'NOMINAL (32 kPa)'}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
                  <div className="text-[10px] text-[#9fb1a6]">VELOCITY</div>
                  <div className="text-base font-bold text-[#d9f36a] mt-1">
                    {staged ? '28,000 KM/H (ORBITAL)' : '6,200 KM/H (MACH 5)'}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
                  <div className="text-[10px] text-[#9fb1a6]">STAGE STATUS</div>
                  <div className="text-base font-bold text-white mt-1">
                    {staged ? 'STAGE 2 VACUUM GREEN' : 'BOOSTER 1 ACTIVE'}
                  </div>
                </div>
              </div>

              {/* Throttle Controls */}
              <div className="space-y-3 pt-2">
                <div className="flex justify-between text-xs font-mono">
                  <span>Engine Throttle setting (Must reduce to 70% through Max-Q):</span>
                  <strong className={throttle <= 75 ? 'text-[#d9f36a]' : 'text-red-400'}>{throttle}%</strong>
                </div>
                <input
                  type="range"
                  min="50"
                  max="100"
                  value={throttle}
                  onChange={e => {
                    const val = parseInt(e.target.value);
                    setThrottle(val);
                    if (val <= 75) {
                      setMaxQSurvived(true);
                      setAscentAltitude(105);
                    }
                  }}
                  className="w-full accent-[#72d1d6] cursor-pointer"
                />

                <div className="flex flex-col sm:flex-row gap-3 pt-2">
                  <button
                    onClick={() => {
                      if (!maxQSurvived) {
                        playErrorAlert();
                        setMascotMessage('Throttle down to 70% first to avoid aerodynamic breakup at Max-Q!');
                        return;
                      }
                      setStaged(true);
                      playTone(340, 0.2, 'sawtooth');
                      playSuccessChime();
                      fireRocketSparks(0.5, 0.5);
                      setMascotMessage('Clean stage separation! Vacuum engine ignited above the Kármán line (105 km).');
                    }}
                    className={`flex-1 px-4 py-2.5 rounded-lg text-xs font-display font-bold uppercase transition-all cursor-pointer ${
                      maxQSurvived ? 'bg-[#72d1d6] text-[#061211]' : 'bg-gray-700 text-gray-400 opacity-60'
                    }`}
                  >
                    {staged ? 'STAGE 1 JETTISONED · VACUUM BURN ACTIVE ✓' : 'EXECUTE PNEUMATIC STAGE SEPARATION'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 4. ZERO-G ACROBATS */}
          {mission.interactiveType === 'gravity' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-mono text-[#9fb1a6]">
                <span>CABIN MICROGRAVITY FREE-FALL</span>
                <span className="text-[#d9f36a]">CLICK FLOATING ITEMS TO SECURE (REMAINING: {floatingItems.length})</span>
              </div>

              <div className="relative h-64 sm:h-72 rounded-2xl bg-[#040e12] border border-[#1b3834] overflow-hidden select-none">
                <div className="absolute inset-0 bg-[radial-gradient(#ffffff0c_1px,transparent_1px)] [background-size:20px_20px]" />

                {floatingItems.map(item => (
                  <button
                    key={item.id}
                    onClick={() => handleCatchItem(item.id)}
                    className="absolute p-3 rounded-full bg-[#091f22]/80 border border-[#72d1d6]/40 hover:border-[#d9f36a] text-2xl transition-transform hover:scale-125 cursor-pointer shadow-lg active:scale-95"
                    style={{ left: `${item.x}%`, top: `${item.y}%` }}
                    title={`Catch floating ${item.name}`}
                  >
                    {item.icon}
                  </button>
                ))}

                <div className="absolute bottom-3 left-4 text-[10px] font-mono text-[#9fb1a6]">
                  ORBITAL FREE-FALL STATUS: <span className="text-[#d9f36a]">100% WEIGHTLESS</span>
                </div>
              </div>
            </div>
          )}

          {/* 5. SPACEWALK & EVA */}
          {mission.interactiveType === 'eva' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-[#1b3834] space-y-4 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="text-[#d9f36a] font-bold">EMU SPACESUIT LIFE SUPPORT CONSOLE</span>
                <span>CHAMBER PRESSURE: 4.3 PSI</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-[#040e12] border border-white/5 space-y-2">
                  <div className="text-[#9fb1a6]">PRIMARY TETHER ANCHOR</div>
                  <div className={`text-base font-bold ${tetherLocked ? 'text-[#d9f36a]' : 'text-red-400'}`}>
                    {tetherLocked ? 'TETHER SECURELY LOCKED ✓' : 'DANGER: UNTETHERED IN SPACE'}
                  </div>
                  <button
                    onClick={() => {
                      playTone(400, 0.1);
                      setTetherLocked(!tetherLocked);
                    }}
                    className="px-3 py-1.5 rounded bg-[#102f2d] hover:bg-[#1a4744] text-[#d9f36a] text-xs font-bold cursor-pointer"
                  >
                    {tetherLocked ? 'Release Tether Carabiner' : 'Lock Steel Carabiner'}
                  </button>
                </div>

                <div className="p-4 rounded-lg bg-[#040e12] border border-white/5 space-y-2">
                  <div className="text-[#9fb1a6]">GOLD UV VISOR SHIELD</div>
                  <div className="text-base font-bold text-[#ffc93c]">
                    {visorGoldDown ? 'GOLD REFLECTIVE VISOR DOWN ✓' : 'UV VISOR RAISED'}
                  </div>
                  <button
                    onClick={() => {
                      playTone(300, 0.1);
                      setVisorGoldDown(!visorGoldDown);
                    }}
                    className="px-3 py-1.5 rounded bg-[#102f2d] hover:bg-[#1a4744] text-[#ffc93c] text-xs font-bold cursor-pointer"
                  >
                    {visorGoldDown ? 'Raise Visor' : 'Lower Gold Visor'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 6. ISS DOCKING SIMULATOR */}
          {mission.interactiveType === 'docking' && (
            <DockingSimulator
              onSuccess={score => {
                setMissionFinished(true);
                playSuccessChime();
                fireMissionConfetti();
                onComplete(mission.id, mission.points + Math.round(score / 10));
              }}
            />
          )}

          {/* 7. ARTEMIS MOON LANDER */}
          {mission.interactiveType === 'lunar' && (
            <LunarLander
              onSuccess={score => {
                setMissionFinished(true);
                playSuccessChime();
                fireMissionConfetti();
                onComplete(mission.id, mission.points + score);
              }}
            />
          )}

          {/* 19. OUTPOST COMMANDER */}
          {mission.interactiveType === 'outpost' && (
            <OutpostCommander
              onSuccess={score => {
                setMissionFinished(true);
                playSuccessChime();
                fireMissionConfetti();
                onComplete(mission.id, mission.points + score);
              }}
            />
          )}

          {/* 8. MARS PERSEVERANCE & INGENUITY */}
          {mission.interactiveType === 'perseverance' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-[#ef7144]/40 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#ef7144] font-bold">INGENUITY MARS HELICOPTER FLIGHT COMPUTER</span>
                <span className="text-[#d9f36a] font-bold">ATMOSPHERIC DENSITY: 0.020 KG/M³ (1% EARTH)</span>
              </div>

              <div className="relative h-44 rounded-xl bg-gradient-to-b from-[#4a1c12] to-[#240c08] border border-[#1b3834] overflow-hidden flex items-center justify-center">
                <div
                  className="text-5xl transition-transform duration-500"
                  style={{
                    transform: `translateY(-${heloAltitude * 4}px) rotate(${rotorRpm > 0 ? (rotorRpm % 360) : 0}deg)`,
                  }}
                >
                  🚁
                </div>
                <div className="absolute bottom-2 left-3 text-[10px] font-mono text-[#9fb1a6]">
                  ROTOR RPM: <strong className={rotorRpm >= 2400 ? 'text-[#d9f36a]' : 'text-orange-400'}>{rotorRpm} RPM</strong> · ALTITUDE: {heloAltitude}M
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                <div>
                  <div className="flex justify-between text-xs font-mono mb-1">
                    <span>Spin Carbon Rotors (Need 2,400+ RPM for lift):</span>
                    <strong className="text-[#ef7144]">{rotorRpm} RPM</strong>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="2700"
                    step="100"
                    value={rotorRpm}
                    onChange={e => {
                      const val = parseInt(e.target.value);
                      setRotorRpm(val);
                      if (val >= 2400) {
                        setHeloAltitude(12);
                      } else {
                        setHeloAltitude(0);
                      }
                    }}
                    className="w-full accent-[#ef7144] cursor-pointer"
                  />
                </div>

                <button
                  onClick={() => {
                    playTone(600, 0.15, 'sawtooth');
                    setLaserZapped(true);
                    playSuccessChime();
                    setMascotMessage('SuperCam laser ablation complete! Carbonate and clay signatures logged at Jezero delta.');
                  }}
                  className="px-4 py-2.5 rounded-lg bg-[#ef7144] hover:bg-[#ff7e54] text-white font-display font-bold text-xs uppercase cursor-pointer"
                >
                  {laserZapped ? 'SuperCam Laser Sampled ✓' : 'Fire SuperCam Laser at Delta Rock'}
                </button>
              </div>
            </div>
          )}

          {/* 9. PARKER SOLAR PROBE */}
          {mission.interactiveType === 'parker' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-amber-500/40 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-amber-400 font-bold">PARKER SOLAR PROBE CORONAL TELEMETRY</span>
                <span className="text-white">SPEED: 690,000 KM/H</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
                  <div className="text-[10px] text-[#9fb1a6]">HEAT SHIELD FACE TEMP</div>
                  <div className="text-xl font-bold text-red-500 mt-1">{shieldTemp}°C</div>
                </div>
                <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
                  <div className="text-[10px] text-[#9fb1a6]">INSTRUMENT BUS TEMP</div>
                  <div className="text-xl font-bold text-[#d9f36a] mt-1">28°C (NOMINAL)</div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                <span className="text-xs font-mono text-[#9fb1a6]">
                  TPS ALIGNMENT: {shieldAngle === 0 ? 'PERFECT DIRECT SOLAR SHIELDING ✓' : 'ALIGN HEAT SHIELD'}
                </span>
                <button
                  onClick={() => {
                    playSuccessChime();
                    setShieldAngle(0);
                    setMascotMessage('Shield aligned! WISPR telescope recording solar wind magnetic switchbacks.');
                  }}
                  className="px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-[#061211] font-display font-bold text-xs uppercase cursor-pointer"
                >
                  Align Carbon-Composite Heat Shield
                </button>
              </div>
            </div>
          )}

          {/* 10. DART KINETIC IMPACTOR */}
          {mission.interactiveType === 'dart' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-[#ef7144]/40 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#ef7144] font-bold">SMART NAV AUTONOMOUS TERMINAL GUIDANCE</span>
                <span className="text-[#d9f36a] font-bold">
                  {dartImpacted ? 'IMPACT CONFIRMED · DEFLECTION: -33 MIN' : 'VELOCITY: 22,500 KM/H'}
                </span>
              </div>

              <div className="relative h-44 rounded-xl bg-black border border-[#1b3834] overflow-hidden flex items-center justify-center select-none">
                <div className={`relative z-10 transition-transform duration-500 rounded-full flex items-center justify-center shadow-2xl ${
                  dartImpacted ? 'w-32 h-32 bg-orange-600/40 border-2 border-orange-400 animate-ping' : 'w-24 h-24 bg-gradient-to-tr from-gray-600 to-gray-400 border-2 border-[#ef7144]'
                }`}>
                  {!dartImpacted ? (
                    <span className="text-[9px] font-mono text-white font-bold">DIMORPHOS</span>
                  ) : (
                    <span className="text-sm font-bold text-yellow-300">BOOM! 💥</span>
                  )}
                </div>
              </div>

              <button
                onClick={() => {
                  playRocketLaunchSound();
                  setDartImpacted(true);
                  playSuccessChime();
                  setMascotMessage('Direct kinetic impact! 1,000 tons of ejecta plume shifted Dimorphos orbit by 33 minutes.');
                }}
                className="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-[#ef7144] hover:bg-[#ff7e54] text-white font-display font-bold text-xs uppercase tracking-wider transition-all cursor-pointer"
              >
                {dartImpacted ? 'Impact Recorded · Mission Success ✓' : 'Engage Terminal Kinetic Intercept'}
              </button>
            </div>
          )}

          {/* 11. PLANETARY GRAVITY LAB */}
          {mission.interactiveType === 'planets' && (
            <div className="space-y-4">
              <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
                {PLANETS.map((planet, idx) => (
                  <button
                    key={planet.name}
                    onClick={() => {
                      playUiClick();
                      setSelectedPlanetIndex(idx);
                    }}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-bold whitespace-nowrap transition-all cursor-pointer ${
                      selectedPlanetIndex === idx
                        ? 'border-[#d9f36a] bg-[#163d39] text-[#d9f36a]'
                        : 'border-[#1b3834] bg-[#091f22] text-[#9fb1a6] hover:border-white/20'
                    }`}
                  >
                    {planet.name}
                  </button>
                ))}
              </div>

              {PLANETS[selectedPlanetIndex] && (
                <div className="p-4 rounded-xl bg-[#07191e] border border-[#1b3834] grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
                  <div className="sm:col-span-4 flex flex-col items-center justify-center p-2">
                    <PlanetCanvas name={PLANETS[selectedPlanetIndex].name} stars={false} className="w-36 h-36" />
                    <span className="font-display font-bold text-base text-[#eef4e6] mt-2">
                      {PLANETS[selectedPlanetIndex].name}
                    </span>
                  </div>

                  <div className="sm:col-span-8 space-y-2 text-xs font-mono">
                    <div className="grid grid-cols-2 gap-2 text-[#bdc9c0]">
                      <div>Surface Gravity: <strong className="text-[#d9f36a]">{PLANETS[selectedPlanetIndex].gravityVsEarth}x Earth</strong></div>
                      <div>Cadet Weight ({userWeight} kg): <strong className="text-[#72d1d6]">{(userWeight * PLANETS[selectedPlanetIndex].gravityVsEarth).toFixed(1)} kg</strong></div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 12. EUROPA CLIPPER ICE RADAR */}
          {mission.interactiveType === 'clipper' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-[#72d1d6]/40 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#72d1d6] font-bold">REASON ICE-PENETRATING RADAR SOUNDER</span>
                <span className="text-[#d9f36a] font-bold">FREQUENCY: 9 & 60 MHZ</span>
              </div>

              <div className="h-32 rounded-xl bg-gradient-to-b from-cyan-900 to-blue-950 border border-white/10 p-3 flex flex-col justify-between text-xs font-mono">
                <div>SURFACE ICE SHELL (0 - 15 KM)</div>
                <div className="text-cyan-300 font-bold">
                  {oceanSounded ? 'LIQUID SALTWATER OCEAN REFLECTION CONFIRMED AT 19.4 KM ✓' : 'TRANSMITTING RADAR SOUNDING PULSES...'}
                </div>
              </div>

              <button
                onClick={() => {
                  setClipperPinging(true);
                  playTone(320, 0.25, 'triangle');
                  setTimeout(() => {
                    setClipperPinging(false);
                    setOceanSounded(true);
                    playSuccessChime();
                    setMascotMessage('Radar echo verified! Deep reflection at 19.4 km confirms liquid water interface beneath the ice shell.');
                  }, 1000);
                }}
                className="px-5 py-2.5 rounded-lg bg-[#72d1d6] text-[#061211] font-display font-bold text-xs uppercase cursor-pointer"
              >
                Transmit REASON Radar Sounding Pulse (9 & 60 MHz)
              </button>
            </div>
          )}

          {/* 13. TITAN DRAGONFLY AEROBOT */}
          {mission.interactiveType === 'dragonfly' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-amber-600/40 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-amber-400 font-bold">TITAN DRAGONFLY ROTORCRAFT ASTRONAV</span>
                <span className="text-white">SURFACE GRAVITY: 0.14G · AIR: 1.5 ATM</span>
              </div>

              <div className="h-36 rounded-xl bg-gradient-to-b from-[#78350f] to-[#451a03] border border-white/10 p-4 flex items-center justify-between text-xs font-mono">
                <div className="text-3xl animate-bounce">🐉</div>
                <div className="text-right text-amber-200">
                  <div>LANDING SITE: SHANGRI-LA DUNES</div>
                  <div className="text-[#d9f36a] font-bold mt-1">
                    {tholinSampled ? 'THOLIN ORGANIC MACROMOLECULES DETECTED ✓' : 'AWAITING ROTOR FLIGHT'}
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  setDragonflyFlight(true);
                  setTholinSampled(true);
                  playSuccessChime();
                  setMascotMessage('Flight successful! Nuclear-powered rotors traversed 12 km and drilled prebiotic tholin sands.');
                }}
                className="px-5 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-[#061211] font-display font-bold text-xs uppercase cursor-pointer"
              >
                Engage Octocopter Flight & Drill Tholin Sands
              </button>
            </div>
          )}

          {/* 14. JWST MIRROR ALIGNMENT */}
          {mission.interactiveType === 'jwst' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-[#ffc93c]/40 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#ffc93c] font-bold">PRIMARY MIRROR WAVEFRONT PHASING</span>
                <span className="text-[#d9f36a] font-bold">ALIGNED: {jwstAligned}/18 SEGMENTS</span>
              </div>

              <div className="grid grid-cols-6 gap-2 p-3 bg-black/40 rounded-xl">
                {Array.from({ length: 18 }).map((_, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      playTone(400 + i * 25, 0.1);
                      setJwstAligned(a => Math.min(18, a + 1));
                    }}
                    className={`h-10 rounded border font-mono text-xs font-bold transition-all cursor-pointer ${
                      i < jwstAligned ? 'bg-[#ffc93c] border-amber-300 text-slate-900 shadow-md' : 'bg-slate-800 border-slate-600 text-slate-400'
                    }`}
                  >
                    M{i + 1}
                  </button>
                ))}
              </div>

              <div className="flex justify-between items-center text-xs font-mono">
                <span>Wavefront Error: {jwstAligned === 18 ? '14 nm (DIFFRACTION-LIMITED) ✓' : `${(18 - jwstAligned) * 45} nm`}</span>
                <button
                  onClick={() => setJwstAligned(18)}
                  className="px-3 py-1 rounded bg-[#ffc93c] text-slate-900 font-bold cursor-pointer"
                >
                  Auto-Phase All Mirrors
                </button>
              </div>
            </div>
          )}

          {/* 15. EXOPLANET TRANSIT */}
          {mission.interactiveType === 'exoplanet' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-emerald-500/40 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-emerald-400 font-bold">PHOTOMETRIC TRANSIT SPECTROMETRY</span>
                <span className="text-[#d9f36a] font-bold">TARGET: TRAPPIST-1e</span>
              </div>

              <div className="h-32 rounded-xl bg-black border border-white/10 p-3 flex flex-col justify-between text-xs font-mono">
                <div>STAR BRIGHTNESS FLUX: 99.992% (TRANSIT DIP: -0.008%)</div>
                <div className="text-emerald-300 font-bold">
                  {bioDetected ? 'ATMOSPHERIC BIOSIGNATURE DETECTED: METHANE (CH4) + WATER (H2O) ✓' : 'AWAITING SPECTRAL SCAN...'}
                </div>
              </div>

              <button
                onClick={() => {
                  setTransitScanned(true);
                  setBioDetected(true);
                  playSuccessChime();
                  setMascotMessage('Atmospheric transmission spectrum verified! Habitable zone exoplanet with water and methane detected.');
                }}
                className="px-5 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-900 font-display font-bold text-xs uppercase cursor-pointer"
              >
                Scan Transmission Spectrum for Biosignatures
              </button>
            </div>
          )}

          {/* 16. GRAVITATIONAL WAVES */}
          {mission.interactiveType === 'gravwaves' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-cyan-500/40 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-cyan-400 font-bold">LIGO 4-KM LASER INTERFEROMETER</span>
                <span className="text-[#d9f36a] font-bold">STRAIN SENSITIVITY: 10⁻²¹</span>
              </div>

              <div className="h-32 rounded-xl bg-[#02050a] border border-white/10 p-4 flex items-center justify-between text-xs font-mono">
                <div className="text-cyan-300 font-bold">GW170817 NEUTRON STAR COLLISION</div>
                <div className="text-[#ffc93c] font-bold">
                  {interferometerLocked ? 'KILONOVA CHIRP DETECTED: 100 TONS GOLD SYNTHESIS ✓' : 'TUNING LASER CAVITIES...'}
                </div>
              </div>

              <button
                onClick={() => {
                  setInterferometerLocked(true);
                  setChirpPlaying(true);
                  playTone(150, 0.1, 'sine');
                  setTimeout(() => playTone(300, 0.1, 'sine'), 100);
                  setTimeout(() => playTone(600, 0.15, 'sine'), 200);
                  playSuccessChime();
                  setMascotMessage('Spacetime ripple confirmed! Audible chirp at 250 Hz detected simultaneously with gamma-ray burst.');
                }}
                className="px-5 py-2.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-900 font-display font-bold text-xs uppercase cursor-pointer"
              >
                Listen to Spacetime Chirp Audio
              </button>
            </div>
          )}

          {/* 17. BLACK HOLE GENERAL RELATIVITY */}
          {mission.interactiveType === 'blackhole' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-purple-500/40 space-y-4 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="text-purple-400 font-bold">GENERAL RELATIVISTIC TIME DILATION</span>
                <span className="text-[#d9f36a] font-bold">ISCO: 1.5 SCHWARZSCHILD RADII</span>
              </div>

              <div className="p-4 rounded-xl bg-black border border-white/10 space-y-2">
                <div>TIME DILATION FACTOR: 1 HOUR ON PLANET = {dilationRatio} EARTH YEARS</div>
                <input
                  type="range"
                  min="1"
                  max="15"
                  value={dilationRatio}
                  onChange={e => setDilationRatio(parseFloat(e.target.value))}
                  className="w-full accent-purple-400 cursor-pointer"
                />
              </div>

              <div className="text-[#d9f36a]">
                Kerr frame dragging active: Space-time rotating with event horizon singularity.
              </div>
            </div>
          )}

          {/* 18. VOYAGER INTERSTELLAR CROSSING */}
          {mission.interactiveType === 'voyager' && (
            <div className="p-4 sm:p-6 rounded-xl bg-[#07191e] border border-[#d9f36a]/40 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#d9f36a] font-bold">NASA DEEP SPACE NETWORK (DSN 70-METER DISH)</span>
                <span className="text-white">RANGE: 24.3 BILLION KM (163 AU)</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
                <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
                  <div className="text-[10px] text-[#9fb1a6]">ONE-WAY LIGHT TIME</div>
                  <div className="text-base font-bold text-[#d9f36a] mt-1">22h 32m 40s</div>
                </div>
                <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
                  <div className="text-[10px] text-[#9fb1a6]">SIGNAL POWER RECEIVED</div>
                  <div className="text-base font-bold text-[#72d1d6] mt-1">-160 dBm (Atto-Watts)</div>
                </div>
                <div className="p-3 rounded-lg bg-[#040e12] border border-white/5">
                  <div className="text-[10px] text-[#9fb1a6]">POWER SOURCE (RTG)</div>
                  <div className="text-base font-bold text-white mt-1">Plutonium-238 Decay</div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                <select
                  value={dsnDish}
                  onChange={e => setDsnDish(e.target.value)}
                  className="px-3 py-1.5 rounded bg-[#091f22] border border-[#719077] text-xs font-mono text-white outline-none cursor-pointer"
                >
                  <option>Goldstone DSS-14 (70m · California)</option>
                  <option>Madrid DSS-63 (70m · Spain)</option>
                  <option>Canberra DSS-43 (70m · Australia)</option>
                </select>

                <button
                  onClick={() => {
                    playTone(840, 0.3, 'sine');
                    setVoyagerCarrierLocked(true);
                    playSuccessChime();
                    setMascotMessage('DSN carrier lock acquired! Golden Record audio telemetry streaming across interstellar space.');
                  }}
                  className="px-4 py-2.5 rounded-lg bg-[#d9f36a] text-[#061211] font-display font-bold text-xs uppercase cursor-pointer"
                >
                  {voyagerCarrierLocked ? 'DSN Carrier Locked ✓' : 'Lock DSN 70m Dish on Voyager 1'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* ========================================================================= */}
        {/* QUIZ SECTION                                                              */}
        {/* ========================================================================= */}
        {currentQuestion && (
          <div className="border-t border-white/10 pt-6 space-y-4">
            <div className="flex items-center justify-between text-xs font-mono text-[#9fb1a6]">
              <span>QUESTION {questionIndex + 1} OF {mission.questions.length}</span>
              <span className="text-[#d9f36a]">{correctCount} CORRECT</span>
            </div>

            <h3 className="font-display font-bold text-lg text-[#eef4e6]">
              {currentQuestion.prompt}
            </h3>

            <div className="space-y-2">
              {optionOrder.map((originalIndex, idx) => {
                const option = currentQuestion.options[originalIndex];
                const isSelected = selectedAnswer === idx;
                const isCorrect = idx === displayedCorrectIndex;

                let btnStyle = 'border-[#1b3834] bg-[#07191e] text-[#bdc9c0] hover:border-white/20';
                if (answered) {
                  if (isCorrect) {
                    btnStyle = 'border-emerald-500 bg-emerald-950/60 text-emerald-200 font-bold';
                  } else if (isSelected) {
                    btnStyle = 'border-red-500 bg-red-950/60 text-red-200';
                  } else {
                    btnStyle = 'border-[#1b3834] bg-[#07191e] text-[#6b7280] opacity-50';
                  }
                }

                return (
                  <div
                    key={`${questionIndex}:${originalIndex}`}
                    className={answered && isSelected ? isCorrect ? 'answer-feedback-correct' : 'answer-feedback-wrong' : ''}
                  >
                    <button
                      disabled={answered}
                      onClick={() => handleSelectAnswer(idx)}
                      className={`relative z-[1] w-full p-3.5 rounded-xl border text-xs sm:text-sm text-left transition-all flex items-center justify-between cursor-pointer ${btnStyle}`}
                    >
                      <span>{option}</span>
                      {answered && isCorrect && <CheckCircle2 size={18} className="text-emerald-400 shrink-0" />}
                      {answered && isSelected && !isCorrect && <AlertTriangle size={18} className="text-red-400 shrink-0" />}
                    </button>
                    {answered && isSelected && (
                      <span className={`answer-particle-burst ${isCorrect ? 'is-correct' : 'is-wrong'}`} aria-hidden="true">
                        {(isCorrect ? CORRECT_ANSWER_PARTICLES : INCORRECT_ANSWER_PARTICLES).map(([x, y], particleIndex) => (
                          <i
                            key={particleIndex}
                            style={{
                              '--particle-x': `${x}px`,
                              '--particle-y': `${y}px`,
                              '--particle-delay': `${(particleIndex % 4) * 18}ms`,
                            } as React.CSSProperties}
                          />
                        ))}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>

            {answered && (
              <div className="p-4 rounded-xl bg-[#07191e] border border-white/10 space-y-2 text-xs font-mono">
                <div className="text-[#d9f36a] font-bold">FLIGHT EXPLANATION:</div>
                <p className="text-[#bdc9c0] leading-relaxed">{currentQuestion.explanation}</p>
                {currentQuestion.funFact && (
                  <div className="text-[#72d1d6] italic pt-1 border-t border-white/5">
                    💡 NASA Fact: {currentQuestion.funFact}
                  </div>
                )}
                <NtrsSources
                  key={`${mission.id}:${questionIndex}`}
                  missionId={mission.id}
                  questionIndex={questionIndex}
                  prompt={currentQuestion.prompt}
                  ntrsQuery={currentQuestion.ntrsQuery}
                />
                <div className="pt-2 flex justify-end">
                  <button
                    onClick={handleNextQuestion}
                    className="px-5 py-2 rounded-lg bg-[#d9f36a] hover:bg-[#cbe655] text-[#061211] font-display font-bold text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md"
                  >
                    {questionIndex + 1 < mission.questions.length ? 'Next Question →' : 'Complete Flight Certification ✓'}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Mascot telemetry prompt */}
        <div className="p-3.5 rounded-xl bg-[#07191e] border border-[#1b3834] flex items-center gap-3 text-xs font-mono text-[#9fb1a6]">
          <span className="text-xl">👩‍🚀</span>
          <span className="text-[#eef4e6]">{mascotMessage}</span>
        </div>

        {/* Mission Complete Overlay */}
        {missionFinished && (
          <div className="p-6 rounded-xl bg-gradient-to-r from-emerald-950/80 to-teal-950/80 border border-emerald-500/50 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
            <div>
              <div className="text-emerald-400 font-display font-bold text-lg">
                MISSION {mission.id} CERTIFIED COMPLETED! 🎖️
              </div>
              <p className="text-xs font-mono text-emerald-200 mt-0.5">
                Earned {mission.points} Academy Credits. Telemetry archived in Cadet Dossier.
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  playUiClick();
                  onBackToDeck();
                }}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-display font-bold text-xs uppercase cursor-pointer"
              >
                Return to Flight Deck
              </button>
              {onNextMission && mission.id < 19 && (
                <button
                  onClick={() => {
                    playUiClick();
                    onNextMission(mission.id + 1);
                  }}
                  className="px-4 py-2 rounded-lg bg-[#d9f36a] hover:bg-[#cbe655] text-[#061211] font-display font-bold text-xs uppercase cursor-pointer"
                >
                  Next Mission →
                </button>
              )}
            </div>
          </div>
        )}

        {/* Daily image reward from NASA APOD */}
        {missionFinished && <ApodReward missionLabel={`MISSION ${mission.id}`} />}
      </div>
    </div>
  );
};
