import React, { useEffect, useState } from 'react';
import {
  Award,
  Sparkles,
  ArrowRight,
  Lock,
  CheckCircle,
  ExternalLink,
  Satellite,
  Maximize2,
  RotateCcw,
  Rocket,
  Database,
  Sun,
  Moon,
  Activity,
  Compass,
  Radio,
  Orbit,
  Star,
  ShieldCheck,
  Clock,
  Zap,
  Layers,
  AlertTriangle,
  Play,
  TrendingUp,
} from 'lucide-react';
import { AstronautProfile, Mission, NasaApodData } from '../types';
import { apodImageSrc, fetchApod } from '../utils/nasaApi';
import { MISSIONS } from '../data/missionsData';
import { playUiClick, playTone, playSuccessChime } from '../utils/audio';
import { getAstronautRank } from '../utils/ranks';

interface FlightDeckProps {
  profile: AstronautProfile;
  onSelectMission: (mission: Mission) => void;
  onOpenCertificate: () => void;
  onChangeAstronaut: () => void;
  onOpenTrainer?: () => void;
  onOpenSpaceData?: () => void;
  onOpenObservatory?: () => void;
  onOpenStarMap?: () => void;
  onOpenTelemetry?: () => void;
  onOpenRadar?: () => void;
  onOpenDossier?: () => void;
  onOpenMissionControl?: () => void;
  onResetProfile?: () => void;
}

export const FlightDeck: React.FC<FlightDeckProps> = ({
  profile,
  onSelectMission,
  onOpenCertificate,
  onChangeAstronaut,
  onOpenTrainer,
  onOpenSpaceData,
  onOpenObservatory,
  onOpenStarMap,
  onOpenTelemetry,
  onOpenRadar,
  onOpenDossier,
  onOpenMissionControl,
  onResetProfile,
}) => {
  const [apodData, setApodData] = useState<NasaApodData>({
    title: 'Skylab over Earth',
    explanation:
      'NASA astronauts photographed the Skylab space station above a cloud-covered Earth during the 1974 Skylab expedition.',
    url: '/skylab-archive.jpg',
    hdurl: 'https://images-assets.nasa.gov/image/sl4-143-4707/sl4-143-4707~orig.jpg',
    date: 'NASA / JSC ARCHIVE · 1974',
  });
  const [apodLoading, setApodLoading] = useState(true);
  const [apodUnavailable, setApodUnavailable] = useState(false);
  const [apodModalOpen, setApodModalOpen] = useState(false);
  const [resetModalOpen, setResetModalOpen] = useState(false);
  const [selectedPhase, setSelectedPhase] = useState<'ALL' | 'PHASE_1' | 'PHASE_2' | 'PHASE_3' | 'PHASE_4' | 'PHASE_5'>('ALL');

  // Fetch real NASA APOD with graceful fallback
  useEffect(() => {
    let isMounted = true;

    // Shared, cached APOD fetch (same call the mission-end reward uses), so the page never
    // spends the small DEMO_KEY quota twice.
    fetchApod()
      .then(data => {
        if (!isMounted) return;
        setApodUnavailable(false);
        setApodData({
          title: data.title || 'NASA Daily Space Transmission',
          explanation: data.explanation || 'Latest deep space observation telemetry.',
          url: apodImageSrc(data) || data.url,
          hdurl: data.hdurl || apodImageSrc(data) || data.url,
          date: data.date ? `NASA / APOD · ${data.date}` : 'TODAY',
          copyright: data.copyright,
        });
      })
      .catch(() => {
        if (isMounted) setApodUnavailable(true);
      })
      .finally(() => {
        if (isMounted) setApodLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const completedCount = profile.completed.length;
  const totalMissions = MISSIONS.length;
  const progressPercent = Math.round((completedCount / totalMissions) * 100);
  const allCompleted = completedCount >= totalMissions;

  const rank = getAstronautRank(profile.points);

  // Compute next rank milestone
  const nextRankMilestone = (() => {
    if (profile.points < 25) return { nextTitle: 'ORBIT CADET', targetXp: 25, diff: 25 - profile.points, pct: (profile.points / 25) * 100 };
    if (profile.points < 70) return { nextTitle: 'FLIGHT SPECIALIST', targetXp: 70, diff: 70 - profile.points, pct: ((profile.points - 25) / (70 - 25)) * 100 };
    if (profile.points < 140) return { nextTitle: 'MISSION LEAD', targetXp: 140, diff: 140 - profile.points, pct: ((profile.points - 70) / (140 - 70)) * 100 };
    if (profile.points < 220) return { nextTitle: 'FLIGHT DIRECTOR', targetXp: 220, diff: 220 - profile.points, pct: ((profile.points - 140) / (220 - 140)) * 100 };
    if (profile.points < 320) return { nextTitle: 'CHIEF SPACE COMMANDER', targetXp: 320, diff: 320 - profile.points, pct: ((profile.points - 220) / (320 - 220)) * 100 };
    return { nextTitle: 'MAX ACADEMY RANK', targetXp: 320, diff: 0, pct: 100 };
  })();

  // Identify the prominent "Continue Mission"
  const nextMission = MISSIONS.find(m => !profile.completed.includes(m.id)) || MISSIONS[0];

  // Helper metadata: difficulty & estimated duration
  const getMissionMeta = (id: number): { difficulty: 'Beginner' | 'Intermediate' | 'Advanced'; duration: string; principle: string } => {
    if (id <= 3) return { difficulty: 'Beginner', duration: '3–5 min', principle: 'Acceleration & High-G Aerodynamics' };
    if (id <= 6) return { difficulty: 'Intermediate', duration: '5–8 min', principle: 'Microgravity Free-Fall & Orbital Rendezvous' };
    if (id === 7 || id === 8) return { difficulty: 'Intermediate', duration: '6–10 min', principle: 'Planetary Gravity & Atmospheric Lift' };
    if (id === 19) return { difficulty: 'Advanced', duration: '12–15 min', principle: 'Closed-Loop ECLSS & Planetary Life Support' };
    if (id <= 13) return { difficulty: 'Intermediate', duration: '6–9 min', principle: 'Heliophysics, Radar Sounding & Planetary Defense' };
    return { difficulty: 'Advanced', duration: '8–12 min', principle: 'Relativistic Physics, Redshift & Deep Cosmology' };
  };

  const spaceBriefings = [
    'A day on Venus is longer than its year! Space is filled with paradoxical cosmic clocks.',
    'The International Space Station completes an orbit of Earth every 92 minutes at 27,600 km/h.',
    'Mars hosts Olympus Mons, a volcano three times taller than Mount Everest with a caldera 80 km wide.',
    'A spacesuit functions as a miniature personal spacecraft with independent oxygen and thermal insulation.',
    'The James Webb Space Telescope uses gold-coated hexagonal beryllium mirrors to see the very first stars.',
  ];
  const dailyFact = spaceBriefings[new Date().getDate() % spaceBriefings.length];

  return (
    <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 space-y-10">
      {/* Space Data Atlas Live Telemetry Ribbon */}
      <section className="rounded-xl border border-[#72d1d6]/30 bg-gradient-to-r from-[#04161a] via-[#09252c] to-[#04161a] p-3 sm:p-4 backdrop-blur-md shadow-xl flex flex-col md:flex-row items-center justify-between gap-3 text-xs font-mono hud-glass">
        <div className="flex items-center gap-3 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
          <div className="flex items-center gap-2 px-2.5 py-1 rounded bg-[#72d1d6]/10 border border-[#72d1d6]/30 text-[#72d1d6] font-bold shrink-0">
            <Database size={13} className="text-[#72d1d6]" />
            <span>SPACE DATA ATLAS</span>
          </div>
          <div className="flex items-center gap-2 text-[#bdc9c0] shrink-0">
            <Sun size={12} className="text-[#ff9838]" />
            <span>DONKI Solar Flux:</span>
            <span className="text-[#d9f36a] font-bold">M-Class Active</span>
          </div>
          <span className="text-white/20 hidden sm:inline">|</span>
          <div className="flex items-center gap-2 text-[#bdc9c0] shrink-0">
            <Moon size={12} className="text-[#a5b4fc]" />
            <span>Lunar Illum (SP):</span>
            <span className="text-[#72d1d6] font-bold">72.4%</span>
          </div>
          <span className="text-white/20 hidden sm:inline">|</span>
          <div className="flex items-center gap-2 text-[#bdc9c0] shrink-0">
            <Activity size={12} className="text-[#66d17a]" />
            <span>ISS Speed:</span>
            <span className="text-[#eef4e6] font-bold">27,600 km/h</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-end gap-2 self-end md:self-auto">
          {onOpenMissionControl && (
            <button
              onClick={() => {
                playUiClick();
                onOpenMissionControl();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#ffb454]/15 hover:bg-[#ffb454]/25 border border-[#ffb454]/45 text-[#ffcf8a] hover:text-white font-bold transition-all shrink-0 cursor-pointer text-[11px]"
            >
              <Orbit size={13} />
              <span>MISSION CONTROL 3D</span>
              <ArrowRight size={13} />
            </button>
          )}
          <button
            onClick={() => {
              playUiClick();
              if (onOpenTelemetry) onOpenTelemetry();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#72d1d6]/20 hover:bg-[#72d1d6]/30 border border-[#72d1d6]/50 text-[#72d1d6] hover:text-white font-bold transition-all shrink-0 cursor-pointer text-[11px]"
          >
            <span>OPEN SPACE DATA ATLAS</span>
            <ArrowRight size={13} />
          </button>
        </div>
      </section>

      {/* Flight Deck Header */}
      <section className="space-y-4">
        <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-widest text-[#9fb1a6]">
          <span className="text-[#ef7144]">FLIGHT DECK</span>
          <span>/</span>
          <span>MISSION CONTROL</span>
          <span className="w-2 h-2 rounded-full bg-[#66a75e] animate-ping" />
        </div>

        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h1 className="font-display font-bold text-4xl sm:text-5xl lg:text-6xl text-[#eef4e6] leading-tight">
              Command your <br />
              <em className="text-[#d9f36a] not-italic">space expedition.</em>
            </h1>
            <p className="text-base text-[#bdc9c0] mt-2 max-w-lg">
              One mission at a time. The cosmos awaits your guidance, Commander{' '}
              <span className="text-[#d9f36a] font-semibold">{profile.name}</span>.
            </p>
          </div>

          {/* Progress Stamp */}
          <div className="flex items-center gap-4 bg-[#091f22] border border-[#1b3834] rounded-xl p-4 px-6 self-start md:self-auto shadow-xl hud-glass">
            <div className="text-3xl sm:text-4xl font-mono font-bold text-[#d9f36a]">
              {String(completedCount).padStart(2, '0')}{' '}
              <span className="text-white/30 text-xl font-normal">/</span>{' '}
              {String(totalMissions).padStart(2, '0')}
            </div>
            <div className="text-[10px] font-mono tracking-widest text-[#9fb1a6] leading-tight">
              MISSIONS
              <br />
              COMPLETE
            </div>
          </div>
        </div>
      </section>

      {/* =================================================================== */}
      {/* PROMINENT "CONTINUE MISSION" CALLOUT HERO BANNER */}
      {/* =================================================================== */}
      <section className="rounded-2xl border border-[#d9f36a]/40 bg-gradient-to-r from-[#0d2724]/90 via-[#092b2f]/90 to-[#07191e]/90 p-6 sm:p-7 shadow-[0_20px_50px_rgba(0,0,0,0.6)] relative overflow-hidden group hud-bracket hud-glass backdrop-blur-xl">
        {/* Subtle Cockpit Radar Grid Lines Overlay */}
        <div className="absolute inset-0 bg-[radial-gradient(#72d1d615_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none opacity-40" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#d9f36a]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-[#d9f36a] text-[#061211] font-mono font-bold text-[10px] uppercase tracking-wider flex items-center gap-1">
                <Play size={10} fill="currentColor" />
                {allCompleted ? 'RECOMMENDED RE-FLIGHT' : 'NEXT EXPEDITION OBJECTIVE'}
              </span>
              <span className="text-xs font-mono text-[#72d1d6]">
                FLIGHT #{String(nextMission.id).padStart(2, '0')} · {nextMission.category}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-3xl p-2.5 rounded-xl bg-black/40 border border-white/10 shrink-0">
                {nextMission.icon}
              </span>
              <div>
                <h2 className="font-display font-bold text-2xl sm:text-3xl text-white group-hover:text-[#d9f36a] transition-colors">
                  {nextMission.title}
                </h2>
                <div className="text-xs text-[#bdc9c0] mt-0.5 font-mono">{nextMission.subtitle}</div>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#9fb1a6] leading-relaxed line-clamp-2">
              {nextMission.desc}
            </p>

            {/* Badges: Difficulty, Duration, XP */}
            <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] font-mono">
              <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-white flex items-center gap-1">
                <Layers size={12} className="text-[#72d1d6]" />
                Difficulty: <strong className="text-[#d9f36a]">{getMissionMeta(nextMission.id).difficulty}</strong>
              </span>
              <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-white flex items-center gap-1">
                <Clock size={12} className="text-[#ff9838]" />
                Est. Duration: <strong className="text-white">{getMissionMeta(nextMission.id).duration}</strong>
              </span>
              <span className="px-2 py-0.5 rounded bg-[#d9f36a]/10 border border-[#d9f36a]/30 text-[#d9f36a] font-bold">
                +{nextMission.points} XP REWARD
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              playUiClick();
              onSelectMission(nextMission);
            }}
            className="w-full lg:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-[#d9f36a] to-[#c7e94e] hover:from-[#e4fc75] hover:to-[#d2f458] text-[#061211] font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2.5 shadow-[0_0_25px_rgba(217,243,106,0.35)] transition-all hover:scale-[1.03] active:scale-[0.98] shrink-0 cursor-pointer tactile-press hud-pulse-aura"
          >
            <Rocket size={18} />
            <span>{allCompleted ? 'Re-Fly Mission' : 'Continue Mission'}</span>
            <ArrowRight size={16} />
          </button>
        </div>
      </section>

      {/* =================================================================== */}
      {/* QUICK OPERATIONS HUB MATRIX */}
      {/* =================================================================== */}
      <section className="space-y-3">
        <div className="flex items-center justify-between text-xs font-mono text-[#9fb1a6] font-bold">
          <span>COSMORA OPERATIONS MATRIX</span>
          <span className="text-[#d9f36a]">INTERACTIVE SPACE SIMULATORS</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {/* Tile 1: Outpost Commander */}
          <div
            onClick={() => {
              playUiClick();
              const outpostMission = MISSIONS.find(m => m.interactiveType === 'outpost') || MISSIONS[MISSIONS.length - 1];
              onSelectMission(outpostMission);
            }}
            className="p-5 rounded-2xl border border-[#d9f36a]/30 bg-gradient-to-b from-[#0a2322] to-[#061414] hover:border-[#d9f36a] transition-all cursor-pointer group shadow-lg flex flex-col justify-between hud-glass tactile-press hud-card-interactive"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="w-10 h-10 rounded-xl bg-[#d9f36a]/20 border border-[#d9f36a]/30 grid place-items-center text-xl">
                  🏗️
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#d9f36a]/20 text-[#d9f36a] font-bold">
                  SIMULATOR
                </span>
              </div>
              <h3 className="font-display font-bold text-base text-white mt-3 group-hover:text-[#d9f36a] transition-colors">
                Outpost Commander
              </h3>
              <p className="text-xs text-[#9fb1a6] mt-1 leading-relaxed line-clamp-2">
                30-Sol Lunar &amp; Mars ECLSS base management with life-support and dust storms.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-[#d9f36a]">
              <span>LAUNCH SIM</span>
              <ArrowRight size={13} className="group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Tile 2: Astronaut Flight Trainer */}
          <div
            onClick={() => {
              playUiClick();
              if (onOpenTrainer) onOpenTrainer();
            }}
            className="p-5 rounded-2xl border border-[#ff9838]/30 bg-gradient-to-b from-[#1b1e16] to-[#0f140e] hover:border-[#ff9838] transition-all cursor-pointer group shadow-lg flex flex-col justify-between hud-glass tactile-press hud-card-interactive"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="w-10 h-10 rounded-xl bg-[#ff9838]/20 border border-[#ff9838]/30 grid place-items-center text-xl">
                  🚀
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#ff9838]/20 text-[#ff9838] font-bold">
                  TRAINER
                </span>
              </div>
              <h3 className="font-display font-bold text-base text-white mt-3 group-hover:text-[#ff9838] transition-colors">
                Astronaut Flight Trainer
              </h3>
              <p className="text-xs text-[#9fb1a6] mt-1 leading-relaxed line-clamp-2">
                60s countdown checklist, manual 6-DOF docking, and Cupola Earth imagery scan.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-[#ff9838]">
              <span>TRAIN CREW</span>
              <ArrowRight size={13} className="group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Tile 3: Solar Orrery & Starmap */}
          <div
            onClick={() => {
              playUiClick();
              if (onOpenObservatory) onOpenObservatory();
            }}
            className="p-5 rounded-2xl border border-[#72d1d6]/30 bg-gradient-to-b from-[#082025] to-[#041215] hover:border-[#72d1d6] transition-all cursor-pointer group shadow-lg flex flex-col justify-between hud-glass tactile-press hud-card-interactive"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="w-10 h-10 rounded-xl bg-[#72d1d6]/20 border border-[#72d1d6]/30 grid place-items-center text-xl">
                  🪐
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#72d1d6]/20 text-[#72d1d6] font-bold">
                  3D ORRERY
                </span>
              </div>
              <h3 className="font-display font-bold text-base text-white mt-3 group-hover:text-[#72d1d6] transition-colors">
                Solar Orrery &amp; Star Map
              </h3>
              <p className="text-xs text-[#9fb1a6] mt-1 leading-relaxed line-clamp-2">
                Interactive Keplerian 3D planetary orbits and celestial constellations.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-[#72d1d6]">
              <span>EXPLORE 3D</span>
              <ArrowRight size={13} className="group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Tile 4: NASA Live + Space Data Atlas */}
          <div
            onClick={() => {
              playUiClick();
              if (onOpenSpaceData) onOpenSpaceData();
            }}
            className="p-5 rounded-2xl border border-[#66d17a]/30 bg-gradient-to-b from-[#0a2318] to-[#05140d] hover:border-[#66d17a] transition-all cursor-pointer group shadow-lg flex flex-col justify-between hud-glass tactile-press hud-card-interactive"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="w-10 h-10 rounded-xl bg-[#66d17a]/20 border border-[#66d17a]/30 grid place-items-center text-xl">
                  📡
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#66d17a]/20 text-[#66d17a] font-bold">
                  LIVE DATA
                </span>
              </div>
              <h3 className="font-display font-bold text-base text-white mt-3 group-hover:text-[#66d17a] transition-colors">
                NASA Live + Orbital Radar
              </h3>
              <p className="text-xs text-[#9fb1a6] mt-1 leading-relaxed line-clamp-2">
                ISS telemetry, a 3D orbital radar, NASA space-weather feeds and the Space Data Atlas in one mission hub.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-[#66d17a]">
              <span>OPEN LIVE TRACKING</span>
              <ArrowRight size={13} className="group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

        </div>
      </section>

      {/* Telemetry Cards Grid */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Rank & Milestone */}
        <article className="rounded-xl border border-[#1b3834] bg-gradient-to-b from-[#0b2025] to-[#07171a] p-4 flex flex-col justify-between shadow-lg hud-card-interactive">
          <div>
            <div className="text-[10px] font-mono tracking-widest text-[#9fb1a6] uppercase">
              CURRENT RANK
            </div>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-xl text-[#d9f36a] font-bold">{rank.icon}</span>
              <strong className="text-base font-display font-bold text-[#eef4e6] tracking-wide">
                {rank.title}
              </strong>
            </div>
            <p className="text-xs text-[#9fb1a6] mt-2 leading-relaxed">{rank.detail}</p>
          </div>

          <div className="mt-4 pt-3 border-t border-white/5 space-y-2">
            <div className="flex items-center justify-between text-[11px] font-mono text-[#d9f36a]">
              <span>XP: {profile.points}</span>
              <span className="text-[#9fb1a6]">NEXT: {nextRankMilestone.nextTitle}</span>
            </div>
            <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#72d1d6] to-[#d9f36a] rounded-full progress-shimmer"
                style={{ width: `${nextRankMilestone.pct}%` }}
              />
            </div>
          </div>
        </article>

        {/* Card 2: Training Readiness */}
        <article className="rounded-xl border border-[#1b3834] bg-gradient-to-b from-[#0b2025] to-[#07171a] p-4 flex flex-col justify-between shadow-lg hud-card-interactive">
          <div>
            <div className="text-[10px] font-mono tracking-widest text-[#9fb1a6] uppercase">
              TRAINING READINESS
            </div>
            <div className="flex items-baseline justify-between mt-2">
              <strong className="text-3xl font-mono font-bold text-[#72d1d6]">
                {progressPercent}%
              </strong>
              <span className="text-xs font-mono text-[#9fb1a6]">
                {completedCount} / {totalMissions}
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-[#07191e] overflow-hidden mt-3 border border-white/5">
              <div
                className="h-full bg-gradient-to-r from-[#72d1d6] to-[#d9f36a] transition-all duration-500 rounded-full progress-shimmer"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-white/5 text-[11px] font-mono text-[#9fb1a6] flex items-center justify-between">
            <span>CERTIFICATE STATUS:</span>
            <span className={allCompleted ? 'text-[#d9f36a] font-bold' : 'text-[#ef7144]'}>
              {allCompleted ? 'EARNED ✓' : `${totalMissions - completedCount} REMAINING`}
            </span>
          </div>
        </article>

        {/* Card 3: Space Station Telemetry */}
        <article className="rounded-xl border border-[#1b3834] bg-gradient-to-b from-[#0b2025] to-[#07171a] p-4 flex flex-col justify-between shadow-lg hud-card-interactive">
          <div>
            <div className="flex items-center justify-between text-[10px] font-mono tracking-widest text-[#9fb1a6] uppercase">
              <span className="flex items-center gap-1.5">
                <Satellite size={12} className="text-[#d9f36a]" />
                ORBITAL TELEMETRY
              </span>
              <span className="text-[#66a75e] font-bold">LIVE</span>
            </div>
            <div className="space-y-1 mt-2 text-xs font-mono">
              <div className="flex justify-between text-[#bdc9c0]">
                <span>ISS Altitude:</span>
                <span className="text-[#eef4e6]">418 km</span>
              </div>
              <div className="flex justify-between text-[#bdc9c0]">
                <span>Orbital Speed:</span>
                <span className="text-[#d9f36a]">27,600 km/h</span>
              </div>
              <div className="flex justify-between text-[#bdc9c0]">
                <span>Earth Period:</span>
                <span className="text-[#72d1d6]">92.6 minutes</span>
              </div>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-white/5 text-[11px] font-mono text-[#9fb1a6]">
            Crew on Orbit: <span className="text-white font-bold">Expedition 72 (7 Astr.)</span>
          </div>
        </article>

        {/* Card 4: Daily Space Briefing */}
        <article className="rounded-xl border border-[#1b3834] bg-gradient-to-b from-[#0b2025] to-[#07171a] p-4 flex flex-col justify-between shadow-lg hud-card-interactive">
          <div>
            <div className="flex items-center gap-1.5 text-[10px] font-mono tracking-widest text-[#ef7144] uppercase font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-[#ef7144] animate-pulse" />
              DAILY SPACE BRIEFING
            </div>
            <p className="text-xs text-[#bdc9c0] mt-2 leading-relaxed italic line-clamp-3">
              &quot;{dailyFact}&quot;
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-white/5">
            <a
              href="https://science.nasa.gov/solar-system/"
              target="_blank"
              rel="noreferrer"
              className="text-[11px] font-mono text-[#72d1d6] hover:underline flex items-center gap-1"
            >
              <span>EXPLORE NASA SCIENCE</span>
              <ExternalLink size={10} />
            </a>
          </div>
        </article>
      </section>

      {/* NASA APOD Feature Card */}
      <section className="rounded-xl border border-[#1b3834] bg-gradient-to-r from-[#0b2025] via-[#0e272a] to-[#081b1d] p-4 sm:p-6 lg:p-8 shadow-2xl relative overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-7 space-y-3">
            <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-widest text-[#d9f36a]">
              <span className="w-2 h-2 rounded-full bg-[#d9f36a] animate-pulse" />
              <span>NASA ASTRONOMY PICTURE OF THE DAY</span>
            </div>
            <p className="text-[11px] font-mono text-[#9fb1a6]" aria-live="polite">
              {apodLoading ? 'Updating NASA feed…' : apodUnavailable ? 'NASA feed rate limit · showing verified archive' : 'NASA live feed updated'}
            </p>
            <h2 className="font-display font-bold text-2xl sm:text-3xl text-[#eef4e6]">
              {apodData.title}
            </h2>
            <p className="text-xs sm:text-sm text-[#bdc9c0] leading-relaxed line-clamp-3">
              {apodData.explanation}
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-4 text-xs font-mono">
              <button
                onClick={() => setApodModalOpen(true)}
                className="flex items-center gap-1.5 text-[#d9f36a] hover:underline cursor-pointer"
              >
                <Maximize2 size={13} />
                <span>EXPAND HIGH-RES VIEW</span>
              </button>
              <span className="text-[#9fb1a6]">{apodData.date}</span>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div
              onClick={() => setApodModalOpen(true)}
              className="relative rounded-xl overflow-hidden border border-white/10 group cursor-pointer aspect-video bg-black/60 flex items-center justify-center"
            >
              <img
                src={apodData.url}
                alt={apodData.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                onError={e => {
                  (e.target as HTMLImageElement).src = '/skylab-archive.jpg';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                <span className="text-xs font-mono text-white flex items-center gap-1.5">
                  <Maximize2 size={13} /> Click to Inspect NASA Telemetry
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =================================================================== */}
      {/* FLIGHT PLAN MISSIONS LIST */}
      {/* =================================================================== */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#1b3834] pb-3 gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold tracking-widest text-[#9fb1a6]">
              ASTRONAUT FLIGHT MISSIONS ({totalMissions} PHASES)
            </span>
          </div>
          <span className="text-xs font-mono text-[#d9f36a] font-bold">
            {completedCount} OF {totalMissions} COMPLETED ({progressPercent}%)
          </span>
        </div>

        {/* Phase Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-[11px] font-mono font-bold touch-pan-x">
          {[
            { id: 'ALL', label: `ALL MISSIONS (${totalMissions})`, short: `All (${totalMissions})` },
            { id: 'PHASE_1', label: 'PHASE 1: LAUNCH & ASCENT (1-3)', short: 'Launch' },
            { id: 'PHASE_2', label: 'PHASE 2: ORBIT & STATIONS (4-6)', short: 'Orbit' },
            { id: 'PHASE_3', label: 'PHASE 3: MOON & MARS (7-8, 19)', short: 'Moon / Mars' },
            { id: 'PHASE_4', label: 'PHASE 4: PLANETS & PROBES (9-13)', short: 'Planets' },
            { id: 'PHASE_5', label: 'PHASE 5: DEEP COSMIC ENDING (14-18)', short: 'Deep space' },
          ].map(phase => (
            <button
              key={phase.id}
              onClick={() => {
                playUiClick();
                setSelectedPhase(phase.id as any);
              }}
              className={`min-h-11 px-3 py-2 rounded-lg border whitespace-nowrap transition-all cursor-pointer touch-manipulation ${
                selectedPhase === phase.id
                  ? 'bg-[#12362f] border-[#d9f36a] text-[#d9f36a]'
                  : 'bg-[#091f22] border-[#1b3834] text-[#9fb1a6] hover:border-white/20'
              }`}
            >
              <span className="sm:hidden">{phase.short}</span>
              <span className="hidden sm:inline">{phase.label}</span>
            </button>
          ))}
        </div>

        {/* Missions Cards List */}
        <div className="space-y-3">
          {MISSIONS.filter(m => {
            if (selectedPhase === 'PHASE_1') return m.id >= 1 && m.id <= 3;
            if (selectedPhase === 'PHASE_2') return m.id >= 4 && m.id <= 6;
            if (selectedPhase === 'PHASE_3') return (m.id >= 7 && m.id <= 8) || m.id === 19;
            if (selectedPhase === 'PHASE_4') return m.id >= 9 && m.id <= 13;
            if (selectedPhase === 'PHASE_5') return m.id >= 14 && m.id <= 18;
            return true;
          }).map(mission => {
            const index = MISSIONS.findIndex(m => m.id === mission.id);
            const isCompleted = profile.completed.includes(mission.id);
            const isUnlocked =
              index === 0 || mission.interactiveType === 'outpost' || profile.completed.includes(MISSIONS[index - 1].id) || isCompleted;

            const meta = getMissionMeta(mission.id);

            return (
              <div
                key={mission.id}
                onClick={() => {
                  if (isUnlocked) {
                    playUiClick();
                    onSelectMission(mission);
                  }
                }}
                onKeyDown={event => {
                  if (isUnlocked && (event.key === 'Enter' || event.key === ' ')) {
                    event.preventDefault();
                    playUiClick();
                    onSelectMission(mission);
                  }
                }}
                role="button"
                tabIndex={isUnlocked ? 0 : -1}
                aria-label={`${mission.title}: ${isCompleted ? 'completed' : isUnlocked ? 'ready to start' : 'locked'}`}
                className={`relative rounded-xl border transition-all duration-200 overflow-hidden hud-glass tactile-press hud-card-interactive ${
                  isCompleted
                    ? 'border-[#66a75e]/40 bg-[#09221f]/50 hover:border-[#66a75e] cursor-pointer'
                    : isUnlocked
                    ? 'border-[#d9f36a]/60 bg-[#0b2025] hover:border-[#d9f36a] hover:bg-[#102b2e] cursor-pointer shadow-lg hover:shadow-[0_0_20px_rgba(217,243,106,0.15)]'
                    : 'border-[#1b3834]/40 bg-[#071517]/40 opacity-60 cursor-not-allowed'
                }`}
              >
                {/* Visual scan strip */}
                {isUnlocked && !isCompleted && (
                  <div className="absolute top-0 left-0 bottom-0 w-1.5 bg-[#d9f36a]" />
                )}
                {isCompleted && (
                  <div className="absolute top-0 left-0 bottom-0 w-1.5 bg-[#66a75e]" />
                )}

                <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    {/* Index number badge */}
                    <span className="font-mono text-sm font-bold text-[#9fb1a6] w-6">
                      {String(mission.id).padStart(2, '0')}
                    </span>

                    {/* Mission Icon */}
                    <div
                      className={`w-12 h-12 rounded-lg grid place-items-center text-2xl border shrink-0 ${
                        isCompleted
                          ? 'border-[#66a75e]/40 bg-[#12362f]'
                          : isUnlocked
                          ? 'border-[#d9f36a]/30 bg-[#153432]'
                          : 'border-white/5 bg-black/40 text-gray-600'
                      }`}
                    >
                      {isUnlocked ? mission.icon : <Lock size={18} className="text-gray-500" />}
                    </div>

                    {/* Copy */}
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[10px] font-mono font-bold tracking-widest text-[#ef7144] uppercase">
                          {mission.category}
                        </span>
                        {isCompleted && (
                          <span className="text-[10px] font-mono text-[#66a75e] flex items-center gap-1 font-bold">
                            <CheckCircle size={11} />
                            LOGGED
                          </span>
                        )}
                        <span className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-bold ${
                          meta.difficulty === 'Beginner' ? 'bg-green-900/40 text-green-300' :
                          meta.difficulty === 'Intermediate' ? 'bg-cyan-900/40 text-cyan-300' :
                          'bg-amber-900/40 text-amber-300'
                        }`}>
                          {meta.difficulty}
                        </span>
                        <span className="text-[10px] font-mono text-[#9fb1a6]">
                          ⏱ {meta.duration}
                        </span>
                      </div>
                      <h3 className="font-display font-bold text-lg sm:text-xl text-[#eef4e6]">
                        {mission.title}
                      </h3>
                      <p className="text-xs text-[#bdc9c0] mt-0.5 line-clamp-1 max-w-xl">
                        {isUnlocked ? mission.desc : 'Complete previous flight mission to unlock.'}
                      </p>
                    </div>
                  </div>

                  {/* Right Action / XP Badge */}
                  <div className="flex items-center justify-end gap-3 sm:self-center pl-10 sm:pl-0">
                    <span
                      className={`text-xs font-mono font-bold px-3 py-1.5 rounded flex items-center gap-1 shrink-0 ${
                        isCompleted
                          ? 'bg-[#12362f] text-[#66a75e] border border-[#66a75e]/30'
                          : isUnlocked
                          ? 'bg-[#d9f36a]/15 text-[#d9f36a] border border-[#d9f36a]/40'
                          : 'bg-black/30 text-gray-500 border border-white/5'
                      }`}
                    >
                      {isCompleted ? (
                        <>COMPLETE ✓</>
                      ) : isUnlocked ? (
                        <>
                          START · +{mission.points} XP <ArrowRight size={13} />
                        </>
                      ) : (
                        'LOCKED'
                      )}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Flight Plan Footer & Certificate Link */}
      <footer className="pt-6 border-t border-[#1b3834] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono">
        <span className="text-[#9fb1a6]">
          MISSION LIST · {totalMissions} MISSIONS · AUTOMATIC PERSISTENCE ACTIVE
        </span>

        <div className="flex flex-wrap items-center gap-4">
          <button
            onClick={() => {
              playUiClick();
              onOpenCertificate();
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold transition-all cursor-pointer ${
              allCompleted
                ? 'bg-[#ffc93c] hover:bg-[#ffdb65] text-[#061211] shadow-[0_0_20px_rgba(255,201,60,0.5)] animate-pulse'
                : 'border border-[#ffc93c]/40 text-[#ffc93c] hover:bg-[#ffc93c]/10'
            }`}
          >
            <Award size={15} />
            <span>{allCompleted ? '✦ CLAIM OFFICIAL CERTIFICATE' : 'PREVIEW CERTIFICATE'}</span>
          </button>

          <button
            onClick={() => {
              playUiClick();
              onChangeAstronaut();
            }}
            className="flex items-center gap-1.5 text-[#9fb1a6] hover:text-[#eef4e6] transition-colors cursor-pointer"
          >
            <RotateCcw size={13} />
            <span>CHANGE ASTRONAUT</span>
          </button>

          <button
            onClick={() => {
              playUiClick();
              setResetModalOpen(true);
            }}
            className="flex items-center gap-1 text-red-400/70 hover:text-red-400 transition-colors cursor-pointer text-[11px]"
          >
            <span>Reset Progress</span>
          </button>
        </div>
      </footer>

      {/* Safe Reset Confirmation Modal */}
      {resetModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-[#0c1618] border border-red-500/50 rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-2 text-red-400 font-mono font-bold text-sm">
              <AlertTriangle size={18} />
              <span>CONFIRM FLIGHT RECORD RESET</span>
            </div>
            <p className="text-xs text-[#bdc9c0] leading-relaxed">
              Are you sure you want to reset Commander <strong>{profile.name}</strong>&apos;s flight records? This will clear all logged missions, telemetry grades, and {profile.points} XP.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setResetModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-mono text-white transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setResetModalOpen(false);
                  if (onResetProfile) onResetProfile();
                }}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-xs font-mono font-bold text-white transition cursor-pointer shadow-lg"
              >
                Confirm Reset
              </button>
            </div>
          </div>
        </div>
      )}

      {/* NASA APOD High-Res Modal */}
      {apodModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative max-w-4xl w-full bg-[#0b2025] border border-[#d9f36a]/40 rounded-xl overflow-hidden shadow-2xl">
            <button
              onClick={() => setApodModalOpen(false)}
              className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full bg-black/60 text-white hover:text-[#d9f36a] grid place-items-center cursor-pointer border border-white/10"
            >
              ✕
            </button>
            <div className="max-h-[60vh] overflow-hidden bg-black flex items-center justify-center">
              <img
                src={apodData.hdurl || apodData.url}
                alt={apodData.title}
                className="max-h-[60vh] w-auto object-contain"
              />
            </div>
            <div className="p-6 space-y-3">
              <div className="flex items-center justify-between text-xs font-mono text-[#d9f36a]">
                <span>{apodData.date}</span>
                {apodData.copyright && <span>Credit: {apodData.copyright}</span>}
              </div>
              <h3 className="font-display font-bold text-xl sm:text-2xl text-[#eef4e6]">
                {apodData.title}
              </h3>
              <p className="text-xs sm:text-sm text-[#bdc9c0] leading-relaxed max-h-36 overflow-y-auto pr-2">
                {apodData.explanation}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
