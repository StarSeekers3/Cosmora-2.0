import React, { useEffect, useRef } from 'react';

interface SolarBackgroundProps {
  theme?: 'dark' | 'light';
  dayNightCycle?: boolean;
  reduceMotion?: boolean;
}

// NASA Planetary Fact Sheet Data (Scaled for calming visual harmony)
const NASA_PLANETS = [
  {
    name: 'Mercury',
    semiMajorAxisAU: 0.39,
    orbitRadiusFrac: 0.14,
    speedFactor: 1.0 / 0.24,
    displayRadius: 2.8,
    color: '#a0a4ab',
    shadowColor: '#3a3d42',
    glowColor: 'rgba(160, 164, 171, 0.25)',
  },
  {
    name: 'Venus',
    semiMajorAxisAU: 0.72,
    orbitRadiusFrac: 0.22,
    speedFactor: 1.0 / 0.62,
    displayRadius: 4.4,
    color: '#e4c485',
    shadowColor: '#6e542b',
    glowColor: 'rgba(228, 196, 133, 0.3)',
  },
  {
    name: 'Earth',
    semiMajorAxisAU: 1.0,
    orbitRadiusFrac: 0.33,
    speedFactor: 1.0 / 1.0,
    displayRadius: 4.8,
    color: '#4388e6',
    shadowColor: '#102d59',
    glowColor: 'rgba(67, 136, 230, 0.45)',
    hasMoon: true,
    moonDist: 9.5,
    moonPeriod: 0.22,
  },
  {
    name: 'Mars',
    semiMajorAxisAU: 1.52,
    orbitRadiusFrac: 0.45,
    speedFactor: 1.0 / 1.88,
    displayRadius: 3.6,
    color: '#d46544',
    shadowColor: '#5e2312',
    glowColor: 'rgba(212, 101, 68, 0.35)',
  },
  {
    name: 'Jupiter',
    semiMajorAxisAU: 5.2,
    orbitRadiusFrac: 0.64,
    speedFactor: 1.0 / 4.2,
    displayRadius: 9.5,
    color: '#e0b874',
    shadowColor: '#63491f',
    glowColor: 'rgba(224, 184, 116, 0.25)',
    hasBands: true,
  },
  {
    name: 'Saturn',
    semiMajorAxisAU: 9.58,
    orbitRadiusFrac: 0.85,
    speedFactor: 1.0 / 6.8,
    displayRadius: 8.0,
    color: '#ecc085',
    shadowColor: '#694d25',
    glowColor: 'rgba(236, 192, 133, 0.25)',
    hasRings: true,
  },
  {
    name: 'Uranus',
    semiMajorAxisAU: 19.2,
    orbitRadiusFrac: 0.95,
    speedFactor: 1.0 / 84,
    displayRadius: 5.3,
    color: '#91d9d4',
    shadowColor: '#24525c',
    glowColor: 'rgba(96, 205, 217, 0.28)',
    hasRings: true,
  },
  {
    name: 'Neptune',
    semiMajorAxisAU: 30.1,
    orbitRadiusFrac: 1.035,
    speedFactor: 1.0 / 164.8,
    displayRadius: 5.1,
    color: '#477edb',
    shadowColor: '#172859',
    glowColor: 'rgba(75, 135, 255, 0.34)',
    hasMoon: true,
    moonDist: 8.5,
    moonPeriod: 0.12,
  },
];

interface Star {
  x: number;
  y: number;
  baseX: number;
  baseY: number;
  depth: number;
  size: number;
  r: number;
  g: number;
  b: number;
  baseAlpha: number;
  twinkleSpeed: number;
  phase: number;
}

interface Meteor {
  active: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  len: number;
  alpha: number;
  nextSpawn: number;
}

export const SolarBackground: React.FC<SolarBackgroundProps> = ({
  theme = 'dark',
  dayNightCycle = true,
  reduceMotion = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isLight = theme === 'light';

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = 0;
    let height = 0;
    let centerX = 0;
    let centerY = 0;
    let dpr = 1;

    // Parallax state (smoothed via lerp)
    let targetParallaxX = 0;
    let targetParallaxY = 0;
    let currentParallaxX = 0;
    let currentParallaxY = 0;

    let stars: Star[] = [];
    const meteor: Meteor = {
      active: false,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      len: 45,
      alpha: 0,
      nextSpawn: performance.now() + 3500 + Math.random() * 4000,
    };

    function setup() {
      if (!canvas) return;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = canvas.width = window.innerWidth * dpr;
      height = canvas.height = window.innerHeight * dpr;
      centerX = width / 2;
      centerY = height / 2;

      stars = [];
      const count = window.innerWidth < 768 ? 70 : 140;

      // Real spectral classes (O/B blue-white, A pure white, G solar yellow, K orange)
      const spectralTypes = isLight
        ? [
            { r: 23, g: 60, b: 50, a: 0.25 },
            { r: 30, g: 70, b: 60, a: 0.2 },
            { r: 40, g: 80, b: 65, a: 0.18 },
          ]
        : [
            { r: 215, g: 235, b: 255, a: 0.8 }, // Class B
            { r: 255, g: 255, b: 255, a: 0.75 }, // Class A
            { r: 255, g: 245, b: 220, a: 0.65 }, // Class G
            { r: 255, g: 225, b: 190, a: 0.55 }, // Class K
          ];

      for (let i = 0; i < count; i++) {
        const type = spectralTypes[i % spectralTypes.length];
        const bx = Math.random() * width;
        const by = Math.random() * height;
        stars.push({
          x: bx,
          y: by,
          baseX: bx,
          baseY: by,
          depth: 0.2 + Math.random() * 0.8,
          size: (0.7 + Math.random() * 1.3) * dpr,
          r: type.r,
          g: type.g,
          b: type.b,
          baseAlpha: type.a,
          twinkleSpeed: 0.8 + Math.random() * 2.2,
          phase: Math.random() * Math.PI * 2,
        });
      }
    }

    const handleMouseMove = (e: MouseEvent) => {
      if (reduceMotion) return;
      const nx = (e.clientX / window.innerWidth - 0.5) * 2;
      const ny = (e.clientY / window.innerHeight - 0.5) * 2;
      targetParallaxX = nx * 18 * dpr;
      targetParallaxY = ny * 18 * dpr;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    const TIME_SCALE = 0.048;

    function render(time: number, nowMs: number) {
      if (!ctx) return;

      if (!reduceMotion) {
        currentParallaxX += (targetParallaxX - currentParallaxX) * 0.05;
        currentParallaxY += (targetParallaxY - currentParallaxY) * 0.05;
      } else {
        currentParallaxX = 0;
        currentParallaxY = 0;
      }

      const pCenterX = centerX + currentParallaxX * 0.3;
      const pCenterY = centerY + currentParallaxY * 0.3;
      const baseScale = Math.min(width, height) * 0.52;

      // 1. CLEAR FRAME & DEEP SPACE BASE
      if (isLight) {
        ctx.clearRect(0, 0, width, height);
      } else {
        ctx.fillStyle = '#050c0e';
        ctx.fillRect(0, 0, width, height);

        // 2. LAYERED DEEP-SPACE NEBULA CLOUDS (Subtle, cinematic, non-distracting)
        ctx.save();
        ctx.globalCompositeOperation = 'screen';

        // Nebula 1: Deep Cyan / Carina cloud (top-left)
        const neb1X = width * 0.25 + currentParallaxX * 0.15;
        const neb1Y = height * 0.3 + currentParallaxY * 0.15;
        const neb1R = Math.min(width, height) * 0.55;
        const neb1Grad = ctx.createRadialGradient(neb1X, neb1Y, 0, neb1X, neb1Y, neb1R);
        neb1Grad.addColorStop(0, 'rgba(4, 46, 52, 0.28)');
        neb1Grad.addColorStop(0.5, 'rgba(3, 28, 34, 0.12)');
        neb1Grad.addColorStop(1, 'rgba(2, 10, 14, 0)');
        ctx.fillStyle = neb1Grad;
        ctx.fillRect(0, 0, width, height);

        // Nebula 2: Deep Violet / Indigo stellar veil (bottom-right)
        const neb2X = width * 0.78 + currentParallaxX * 0.18;
        const neb2Y = height * 0.72 + currentParallaxY * 0.18;
        const neb2R = Math.min(width, height) * 0.6;
        const neb2Grad = ctx.createRadialGradient(neb2X, neb2Y, 0, neb2X, neb2Y, neb2R);
        neb2Grad.addColorStop(0, 'rgba(28, 14, 42, 0.22)');
        neb2Grad.addColorStop(0.55, 'rgba(14, 8, 26, 0.08)');
        neb2Grad.addColorStop(1, 'rgba(5, 12, 14, 0)');
        ctx.fillStyle = neb2Grad;
        ctx.fillRect(0, 0, width, height);

        ctx.restore();
      }

      // Day / Night rhythm (subtle ambient tint)
      const daylight = dayNightCycle ? 0.5 + Math.sin(time * 0.026) * 0.5 : 0.85;
      if (!isLight && daylight < 0.85) {
        ctx.fillStyle = `rgba(1, 8, 20, ${(0.85 - daylight) * 0.25})`;
        ctx.fillRect(0, 0, width, height);
      }

      // 3. TWINKLING STARFIELD WITH PARALLAX DEPTH
      for (let i = 0; i < stars.length; i++) {
        const st = stars[i];
        const sx = st.baseX + currentParallaxX * st.depth;
        const sy = st.baseY + currentParallaxY * st.depth;

        const twinkle = reduceMotion
          ? 1
          : 0.65 + 0.35 * Math.sin(time * st.twinkleSpeed + st.phase);
        const finalAlpha = Math.max(0.1, Math.min(1, st.baseAlpha * twinkle));

        ctx.fillStyle = `rgba(${st.r}, ${st.g}, ${st.b}, ${finalAlpha})`;
        ctx.beginPath();
        ctx.arc(sx, sy, st.size, 0, Math.PI * 2);
        ctx.fill();

        if (!isLight && st.size > 1.7 * dpr && finalAlpha > 0.6) {
          const halo = ctx.createRadialGradient(sx, sy, 0, sx, sy, st.size * 3.5);
          halo.addColorStop(0, `rgba(${st.r}, ${st.g}, ${st.b}, ${finalAlpha * 0.35})`);
          halo.addColorStop(1, 'rgba(255, 255, 255, 0)');
          ctx.fillStyle = halo;
          ctx.beginPath();
          ctx.arc(sx, sy, st.size * 3.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 4. OCCASIONAL SHOOTING STAR (METEOR STREAK)
      if (!reduceMotion && !isLight) {
        if (!meteor.active && nowMs > meteor.nextSpawn) {
          meteor.active = true;
          meteor.x = Math.random() * width * 0.8 + width * 0.1;
          meteor.y = Math.random() * height * 0.4;
          const angle = Math.PI * (0.16 + Math.random() * 0.18);
          const speed = 680 * dpr;
          meteor.vx = Math.cos(angle) * speed;
          meteor.vy = Math.sin(angle) * speed;
          meteor.len = (60 + Math.random() * 40) * dpr;
          meteor.alpha = 0.85;
        }

        if (meteor.active) {
          meteor.x += meteor.vx * (1 / 60);
          meteor.y += meteor.vy * (1 / 60);
          meteor.alpha -= 0.024;

          if (meteor.alpha <= 0 || meteor.x > width + 50 || meteor.y > height + 50) {
            meteor.active = false;
            meteor.nextSpawn = nowMs + 6000 + Math.random() * 7000;
          } else {
            const tailX = meteor.x - (meteor.vx / 680) * meteor.len;
            const tailY = meteor.y - (meteor.vy / 680) * meteor.len;

            const mGrad = ctx.createLinearGradient(tailX, tailY, meteor.x, meteor.y);
            mGrad.addColorStop(0, 'rgba(255, 255, 255, 0)');
            mGrad.addColorStop(0.7, `rgba(217, 243, 106, ${meteor.alpha * 0.6})`);
            mGrad.addColorStop(1, `rgba(255, 255, 255, ${meteor.alpha})`);

            ctx.save();
            ctx.lineWidth = 1.4 * dpr;
            ctx.strokeStyle = mGrad;
            ctx.beginPath();
            ctx.moveTo(tailX, tailY);
            ctx.lineTo(meteor.x, meteor.y);
            ctx.stroke();

            ctx.fillStyle = `rgba(255, 255, 255, ${meteor.alpha})`;
            ctx.beginPath();
            ctx.arc(meteor.x, meteor.y, 1.6 * dpr, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
          }
        }
      }

      // 5. REFINED ORBITAL PATHS
      NASA_PLANETS.forEach(p => {
        const orbitR = p.orbitRadiusFrac * baseScale;
        ctx.lineWidth = 1.0 * dpr;
        ctx.setLineDash([2 * dpr, 6 * dpr]);
        ctx.strokeStyle = isLight
          ? 'rgba(23, 60, 50, 0.22)'
          : 'rgba(255, 255, 255, 0.1)';
        ctx.beginPath();
        ctx.arc(pCenterX, pCenterY, orbitR, 0, Math.PI * 2);
        ctx.stroke();
      });
      ctx.setLineDash([]);

      // 6. THE SUN (SDO 171 Å Soft Golden Corona with Slow Radial Breathing)
      const breath = reduceMotion ? 0 : Math.sin(time * 0.5) * 0.05;
      const sunR = Math.max(22 * dpr, baseScale * 0.075);
      const sunAlpha = 0.62 + daylight * 0.38;

      const coronaGrad = ctx.createRadialGradient(
        pCenterX,
        pCenterY,
        sunR * 0.7,
        pCenterX,
        pCenterY,
        sunR * (2.4 + breath)
      );
      if (isLight) {
        coronaGrad.addColorStop(0, `rgba(255, 190, 60, ${0.45 * sunAlpha})`);
        coronaGrad.addColorStop(0.5, `rgba(255, 160, 40, ${0.15 * sunAlpha})`);
        coronaGrad.addColorStop(1, 'rgba(255, 140, 30, 0)');
      } else {
        coronaGrad.addColorStop(0, `rgba(255, 240, 190, ${0.75 * sunAlpha})`);
        coronaGrad.addColorStop(0.35, `rgba(255, 185, 50, ${0.35 * sunAlpha})`);
        coronaGrad.addColorStop(0.75, `rgba(255, 120, 20, ${0.10 * sunAlpha})`);
        coronaGrad.addColorStop(1, 'rgba(255, 90, 10, 0)');
      }

      ctx.fillStyle = coronaGrad;
      ctx.beginPath();
      ctx.arc(pCenterX, pCenterY, sunR * (2.4 + breath), 0, Math.PI * 2);
      ctx.fill();

      // Sun Photosphere Core
      const sunCoreGrad = ctx.createRadialGradient(
        pCenterX - sunR * 0.25,
        pCenterY - sunR * 0.25,
        sunR * 0.15,
        pCenterX,
        pCenterY,
        sunR
      );
      sunCoreGrad.addColorStop(0, `rgba(255,255,255,${sunAlpha})`);
      sunCoreGrad.addColorStop(0.3, '#fff285');
      sunCoreGrad.addColorStop(0.7, '#ffb703');
      sunCoreGrad.addColorStop(1, '#fb8500');

      ctx.fillStyle = sunCoreGrad;
      ctx.beginPath();
      ctx.arc(pCenterX, pCenterY, sunR, 0, Math.PI * 2);
      ctx.fill();

      // 7. CALM, SERENE PLANETARY ORBITS WITH REALISTIC 3D LIGHTING
      NASA_PLANETS.forEach(p => {
        const orbitR = p.orbitRadiusFrac * baseScale;
        const angle = time * p.speedFactor * TIME_SCALE;
        const px = pCenterX + Math.cos(angle) * orbitR;
        const py = pCenterY + Math.sin(angle) * orbitR;
        const pr = p.displayRadius * dpr;

        ctx.save();
        ctx.lineWidth = 1.6 * dpr;
        const trailLen = 0.32;
        const trailGrad = ctx.createLinearGradient(
          px - Math.cos(angle) * 12,
          py - Math.sin(angle) * 12,
          px,
          py
        );
        trailGrad.addColorStop(0, 'transparent');
        trailGrad.addColorStop(1, isLight ? 'rgba(23,60,50,0.28)' : 'rgba(255,255,255,0.24)');
        ctx.strokeStyle = trailGrad;
        ctx.beginPath();
        ctx.arc(pCenterX, pCenterY, orbitR, angle - trailLen, angle);
        ctx.stroke();
        ctx.restore();

        // Saturn's Rings
        if (p.hasRings) {
          ctx.save();
          ctx.translate(px, py);
          ctx.rotate(0.38);
          ctx.lineWidth = 2.8 * dpr;
          ctx.strokeStyle = isLight
            ? 'rgba(180, 120, 60, 0.45)'
            : 'rgba(235, 195, 140, 0.55)';
          ctx.beginPath();
          ctx.ellipse(0, 0, pr * 2.2, pr * 0.7, 0, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }

        // Planet Sphere with 3D Sun-lit Shading
        const lightAngle = Math.atan2(py - pCenterY, px - pCenterX);
        const pGrad = ctx.createRadialGradient(
          px - Math.cos(lightAngle) * pr * 0.4,
          py - Math.sin(lightAngle) * pr * 0.4,
          pr * 0.1,
          px,
          py,
          pr
        );
        pGrad.addColorStop(0, p.color);
        pGrad.addColorStop(0.7, p.color);
        pGrad.addColorStop(1, p.shadowColor || '#1c1e24');

        ctx.fillStyle = pGrad;
        ctx.beginPath();
        ctx.arc(px, py, pr, 0, Math.PI * 2);
        ctx.fill();

        // Atmospheric Limb Glow
        if (p.glowColor && !isLight) {
          ctx.strokeStyle = p.glowColor;
          ctx.lineWidth = 1 * dpr;
          ctx.beginPath();
          ctx.arc(px, py, pr + 0.6 * dpr, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Earth Details
        if (p.name === 'Earth' && p.hasMoon && p.moonDist) {
          const moonAngle = time * (p.moonPeriod || 0.22) * 4;
          const mx = px + Math.cos(moonAngle) * (p.moonDist * dpr);
          const my = py + Math.sin(moonAngle) * (p.moonDist * dpr);

          ctx.fillStyle = isLight ? '#727880' : '#e0e2e6';
          ctx.beginPath();
          ctx.arc(mx, my, 1.2 * dpr, 0, Math.PI * 2);
          ctx.fill();
        }

        // Jupiter Cloud Belts
        if (p.hasBands) {
          ctx.save();
          ctx.beginPath();
          ctx.arc(px, py, pr, 0, Math.PI * 2);
          ctx.clip();
          ctx.fillStyle = 'rgba(160, 90, 20, 0.28)';
          ctx.fillRect(px - pr, py - pr * 0.28, pr * 2, pr * 0.18);
          ctx.fillRect(px - pr, py + pr * 0.12, pr * 2, pr * 0.18);
          ctx.restore();
        }
      });
    }

    setup();
    const loop = (now: number) => {
      render(now / 1000, now);
      animId = requestAnimationFrame(loop);
    };
    animId = requestAnimationFrame(loop);

    const handleResize = () => {
      setup();
    };

    window.addEventListener('resize', handleResize);
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [isLight, dayNightCycle, reduceMotion]);

  return (
    <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
      <canvas
        ref={canvasRef}
        className="w-full h-full block"
        style={{ background: isLight ? 'transparent' : '#050c0e' }}
      />
    </div>
  );
};
