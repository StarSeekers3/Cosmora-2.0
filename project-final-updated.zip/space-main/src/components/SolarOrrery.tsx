import React, { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, Orbit, Sun, Moon, Sparkles } from 'lucide-react';
import { PLANETS } from '../data/planetsData';
import { playUiClick, playPlanetArrivalSound, playPlanetSelectSound } from '../utils/audio';
import { PlanetCanvas, PlanetThumb } from './PlanetCanvas';
import { NasaLiveTelemetry3D } from './NasaLiveTelemetry3D';

interface SolarOrreryProps {
  onBackToDeck: () => void;
  dayNightCycle: boolean;
}

const STAGES_PER_PLANET = 3;
const LAST_STEP = PLANETS.length * STAGES_PER_PLANET - 1;
const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));

export const SolarOrrery: React.FC<SolarOrreryProps> = ({ onBackToDeck, dayNightCycle }) => {
  const [step, setStep] = useState(2 * STAGES_PER_PLANET); // Open on Earth, as in the supplied template.
  const [activeTab, setActiveTab] = useState<'orrery' | 'solar-system'>('orrery');
  const lastMoveRef = useRef(0);
  const touchYRef = useRef<number | null>(null);
  const currentIndex = Math.floor(step / STAGES_PER_PLANET);
  const stage = step % STAGES_PER_PLANET;
  const planet = PLANETS[currentIndex];
  const lastIntroductionIndexRef = useRef(currentIndex);
  const selectionCueIndexRef = useRef<number | null>(null);
  const previousPlanet = PLANETS[currentIndex - 1];
  const nextPlanet = PLANETS[currentIndex + 1];

  useEffect(() => {
    if (stage !== 0) return;
    if (currentIndex !== lastIntroductionIndexRef.current) {
      if (selectionCueIndexRef.current === currentIndex) selectionCueIndexRef.current = null;
      else playPlanetArrivalSound(planet.name);
    }
    lastIntroductionIndexRef.current = currentIndex;
  }, [currentIndex, planet.name, stage]);

  const goTo = (next: number) => {
    const bounded = clamp(next, 0, LAST_STEP);
    if (bounded === step) return;
    const targetPlanetIndex = Math.floor(bounded / STAGES_PER_PLANET);
    const enteringAnotherPlanet = bounded % STAGES_PER_PLANET === 0 && targetPlanetIndex !== currentIndex;
    if (enteringAnotherPlanet) {
      selectionCueIndexRef.current = targetPlanetIndex;
      playPlanetSelectSound(PLANETS[targetPlanetIndex].name);
    } else playUiClick();
    setStep(bounded);
  };

  const move = (direction: -1 | 1) => {
    const now = performance.now();
    if (now - lastMoveRef.current < 720) return;
    lastMoveRef.current = now;
    setStep(value => clamp(value + direction, 0, LAST_STEP));
  };

  const viewTabs = (
    <div className="flex w-fit gap-1 rounded-xl border border-white/10 bg-[#040e12]/80 p-1 backdrop-blur-md" role="tablist" aria-label="Solar Orrery views">
      <button
        role="tab"
        aria-selected={activeTab === 'orrery'}
        onClick={() => { playUiClick(); setActiveTab('orrery'); }}
        className={`flex min-h-10 items-center gap-2 rounded-lg px-4 text-xs font-mono transition ${activeTab === 'orrery' ? 'bg-[#72d1d6] font-bold text-[#061211]' : 'text-[#9fb1a6] hover:bg-white/10 hover:text-white'}`}
      >
        <Orbit size={14} /> PLANET ORRERY
      </button>
      <button
        role="tab"
        aria-selected={activeTab === 'solar-system'}
        onClick={() => { playUiClick(); setActiveTab('solar-system'); }}
        className={`flex min-h-10 items-center gap-2 rounded-lg px-4 text-xs font-mono transition ${activeTab === 'solar-system' ? 'bg-[#d9f36a] font-bold text-[#061211]' : 'text-[#9fb1a6] hover:bg-white/10 hover:text-white'}`}
      >
        <Sun size={14} /> SOLAR SYSTEM
      </button>
    </div>
  );

  return (
    <div className="orrery-page relative z-10 mx-auto w-full max-w-[1600px] px-3 py-3 sm:px-5 sm:py-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
        <button
          onClick={() => { playUiClick(); onBackToDeck(); }}
          className="inline-flex min-h-10 items-center gap-1.5 text-xs font-mono text-[#9fb1a6] transition-colors hover:text-[#d9f36a]"
        >
          <ArrowLeft size={14} aria-hidden="true" /> RETURN TO FLIGHT PLAN
        </button>
        {viewTabs}
        <div className="hidden items-center gap-2 text-[10px] font-mono font-bold tracking-widest text-[#72d1d6] md:flex">
          <Orbit size={14} aria-hidden="true" /> SOLAR SYSTEM OBSERVATORY
        </div>
      </div>

      {activeTab === 'solar-system' ? (
        <NasaLiveTelemetry3D
          initialView="solar"
          solarOnly
          title="SOLAR SYSTEM · 3D ORRERY"
          className="!h-[calc(100dvh-11rem)] min-h-[360px] overflow-hidden rounded-2xl border border-white/10"
        />
      ) : (
        <section
          className={`orrery-journey orrery-stage-${stage}`}
          aria-label="Interactive planetary orrery"
          aria-live="polite"
          tabIndex={0}
          onWheel={event => {
            if (Math.abs(event.deltaY) > 12) {
              event.preventDefault();
              move(event.deltaY > 0 ? 1 : -1);
            }
          }}
          onKeyDown={event => {
            if (['ArrowDown', 'PageDown', ' '].includes(event.key)) { event.preventDefault(); move(1); }
            if (['ArrowUp', 'PageUp'].includes(event.key)) { event.preventDefault(); move(-1); }
            if (event.key === 'ArrowRight' && stage === 2) { event.preventDefault(); move(1); }
            if (event.key === 'ArrowLeft' && stage === 2) { event.preventDefault(); move(-1); }
          }}
          onTouchStart={event => { touchYRef.current = event.touches[0]?.clientY ?? null; }}
          onTouchEnd={event => {
            const start = touchYRef.current;
            const target = event.target as HTMLElement;
            touchYRef.current = null;
            if (start === null || target.closest('.planet-interactive')) return;
            const delta = start - (event.changedTouches[0]?.clientY ?? start);
            if (Math.abs(delta) > 44) move(delta > 0 ? 1 : -1);
          }}
        >
          <div className="orrery-starfield" aria-hidden="true" />
          <div className="orrery-nebula" aria-hidden="true" />

          <div className="orrery-stage-meta">
            <span><i /> COSMORA PLANETARY ATLAS</span>
            <span>{String(currentIndex + 1).padStart(2, '0')} / {String(PLANETS.length).padStart(2, '0')} WORLDS</span>
          </div>

          <div className="orrery-orbit-mark" aria-hidden="true"><span /><span /><span /></div>
          <div className="orrery-planet-view" key={planet.name}>
            <PlanetCanvas
              name={planet.name}
              interactive
              showTouchControls
              stars={false}
              dayNightCycle={dayNightCycle}
              className="h-full w-full"
            />
          </div>

          {stage === 0 && (
            <div className="orrery-copy orrery-copy-hero" key={`${planet.name}-hero`}>
              <p className="orrery-eyebrow">{planet.type} WORLD <span>·</span> {planet.tagline}</p>
              <h1 className="orrery-title">{planet.name}</h1>
              <div className="orrery-rule" />
              <p className="orrery-copy-text">{planet.overview}</p>
              <button className="orrery-cta" onClick={() => goTo(currentIndex * STAGES_PER_PLANET + 1)}>
                Explore {planet.name} <ArrowDown size={13} aria-hidden="true" />
              </button>
            </div>
          )}

          {stage === 1 && (
            <div className="orrery-copy orrery-copy-detail" key={`${planet.name}-detail`}>
              <p className="orrery-eyebrow">PLANET PROFILE <span>·</span> {planet.type.toUpperCase()}</p>
              <h2 className="orrery-title">{planet.name}</h2>
              <div className="orrery-rule" />
              <p className="orrery-copy-text">{planet.overview}</p>
              <div className="orrery-facts">
                <div><span>FROM SUN</span><b>{planet.distanceFromSun}</b></div>
                <div><span>DAY LENGTH</span><b>{planet.dayLength}</b></div>
                <div><span>ORBITAL YEAR</span><b>{planet.yearLength}</b></div>
                <div><span>DIAMETER</span><b>{planet.diameterKm}</b></div>
                <div><span>KNOWN MOONS</span><b>{planet.moons}</b></div>
                <div><span>GRAVITY</span><b>{planet.gravityVsEarth}g</b></div>
              </div>
              <button className="orrery-cta orrery-cta-secondary" onClick={() => goTo(currentIndex * STAGES_PER_PLANET + 2)}>
                Fly closer <ArrowRight size={13} aria-hidden="true" />
              </button>
            </div>
          )}

          {stage === 2 && (
            <div className="orrery-copy orrery-copy-zoom" key={`${planet.name}-zoom`}>
              <p className="orrery-eyebrow"><Sparkles size={12} aria-hidden="true" /> SURFACE SIGNAL <span>·</span> {planet.name.toUpperCase()}</p>
              <h2 className="orrery-title orrery-title-small">A closer look</h2>
              <div className="orrery-rule" />
              <p className="orrery-copy-text">{planet.funFact}</p>
              <p className="orrery-atmosphere"><span>ATMOSPHERE</span>{planet.atmosphere}</p>
              <button
                className="orrery-cta"
                disabled={!nextPlanet}
                onClick={() => nextPlanet && goTo((currentIndex + 1) * STAGES_PER_PLANET)}
              >
                {nextPlanet ? `Next world · ${nextPlanet.name}` : 'End of planetary route'}
                {nextPlanet && <ArrowRight size={13} aria-hidden="true" />}
              </button>
            </div>
          )}

          {stage === 0 && previousPlanet && (
            <button className="orrery-side-world orrery-side-left" onClick={() => goTo((currentIndex - 1) * STAGES_PER_PLANET)} aria-label={`Explore ${previousPlanet.name}`}>
              <PlanetThumb name={previousPlanet.name} size={54} />
              <span><small>PREVIOUS WORLD</small><b>{previousPlanet.name}</b></span>
              <ArrowLeft size={14} aria-hidden="true" />
            </button>
          )}
          {stage === 0 && nextPlanet && (
            <button className="orrery-side-world orrery-side-right" onClick={() => goTo((currentIndex + 1) * STAGES_PER_PLANET)} aria-label={`Explore ${nextPlanet.name}`}>
              <ArrowRight size={14} aria-hidden="true" />
              <span><small>NEXT WORLD</small><b>{nextPlanet.name}</b></span>
              <PlanetThumb name={nextPlanet.name} size={54} />
            </button>
          )}

          <div className="orrery-stage-dots" role="group" aria-label="Planet detail stage">
            {[0, 1, 2].map(index => (
              <button
                key={index}
                className={stage === index ? 'is-active' : ''}
                aria-label={['Planet introduction', 'Planet profile', 'Closer look'][index]}
                aria-pressed={stage === index}
                onClick={() => goTo(currentIndex * STAGES_PER_PLANET + index)}
              />
            ))}
          </div>

          <div className="orrery-bottom-bar">
            <div className="orrery-route-progress" aria-label={`World ${currentIndex + 1} of ${PLANETS.length}`}>
              {PLANETS.map((item, index) => (
                <button
                  key={item.name}
                  className={index === currentIndex ? 'is-active' : index < currentIndex ? 'is-passed' : ''}
                  aria-label={`Go to ${item.name}`}
                  aria-current={index === currentIndex ? 'step' : undefined}
                  onClick={() => goTo(index * STAGES_PER_PLANET)}
                />
              ))}
            </div>
            <span className="orrery-bottom-label">{planet.name.toUpperCase()} <i>·</i> {stage === 0 ? 'OVERVIEW' : stage === 1 ? 'PLANET PROFILE' : 'CLOSER LOOK'}</span>
            {stage < 2 && <button className="orrery-next-step" onClick={() => move(1)} aria-label="Next chapter"><ArrowDown size={15} /></button>}
            {stage === 2 && previousPlanet && <span className="orrery-bottom-hint">SCROLL OR USE ARROWS TO TRAVEL</span>}
          </div>

          <div className="orrery-cycle-pill">
            {dayNightCycle ? <Sun size={11} aria-hidden="true" /> : <Moon size={11} aria-hidden="true" />}
            {dayNightCycle ? 'SUNLIGHT CYCLE ACTIVE' : 'SUNLIGHT PAUSED'}
          </div>
        </section>
      )}
    </div>
  );
};
