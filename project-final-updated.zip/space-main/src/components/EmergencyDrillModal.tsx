import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  Flame,
  ShieldAlert,
  Zap,
  RotateCcw,
  CheckCircle2,
  X,
  Clock,
  Radio,
  Sliders,
  Sparkles,
} from 'lucide-react';
import {
  playUiClick,
  playErrorAlert,
  playSuccessChime,
  playMasterAlarmKlaxon,
  speakCapCom,
  playTone,
} from '../utils/audio';
import { fireMissionConfetti } from '../utils/confetti';
import { AstronautProfile } from '../types';

interface EmergencyDrillModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: AstronautProfile | null;
  onRewardXP?: (xp: number) => void;
}

interface EmergencyScenario {
  id: string;
  title: string;
  historicalEvent: string;
  briefing: string;
  initialTime: number;
  steps: {
    id: string;
    label: string;
    actionType: 'switch' | 'breaker' | 'valve' | 'slider';
    instruction: string;
    targetValue?: number;
  }[];
  nasaDocRef: string;
}

const EMERGENCY_SCENARIOS: EmergencyScenario[] = [
  {
    id: 'apollo13',
    title: 'Apollo 13 Cryogenic O2 Tank Rupture',
    historicalEvent: 'April 13, 1970 · 320,000 km from Earth',
    briefing: 'Master Alarm sounding! Oxygen Tank 2 pressure has plunged to 110 psi and Fuel Cell 3 is failing. Follow the NASA Flight Controller Quick Reaction Checklist (QRC) to isolate the cryogenic line and preserve remaining life support.',
    initialTime: 25,
    steps: [
      { id: 'step1', label: 'Close O2 Reactant Shutoff Valve B', actionType: 'valve', instruction: 'Isolate ruptured Tank 2 to prevent total O2 venting into space.' },
      { id: 'step2', label: 'Trip Fuel Cell 3 Circuit Breaker', actionType: 'breaker', instruction: 'Disconnect dead fuel cell before internal fire risk.' },
      { id: 'step3', label: 'Cross-Tie Life Support Bus to Battery A', actionType: 'switch', instruction: 'Ensure emergency survival power to cabin CO2 scrubbers.' },
    ],
    nasaDocRef: 'NASA SP-350 "Apollo 13 Incident Report"',
  },
  {
    id: 'gemini8',
    title: 'Gemini 8 Runaway RCS Thruster Spin',
    historicalEvent: 'March 16, 1966 · Neil Armstrong & David Scott',
    briefing: 'Warning: RCS Roll Thruster #8 is jammed in open firing position! Spacecraft roll rate is accelerating through 12°/sec toward pilot blackout. You have 20 seconds to cut off the thruster manifold and recover attitude control.',
    initialTime: 20,
    steps: [
      { id: 'step1', label: 'Isolate OAMS Roll Manifold Valve', actionType: 'valve', instruction: 'Cut fuel feed to the jammed thruster immediately.' },
      { id: 'step2', label: 'Arm Reentry Control System (RCS)', actionType: 'switch', instruction: 'Activate backup maneuvering thrusters.' },
      { id: 'step3', label: 'Engage Automated SAS Rate Dampener', actionType: 'switch', instruction: 'Apply counter-thrust impulses to arrest the spin.' },
    ],
    nasaDocRef: 'NASA Project Gemini Flight Evaluation Report Gemini VIII',
  },
  {
    id: 'iss_power',
    title: 'Space Station Main Bus Undervoltage',
    historicalEvent: 'ISS Expedition 42 Electrical Contingency',
    briefing: 'Main Bus 2B voltage dropped to 18.2V (nominal 28V). Sequential shunt unit failure threatens station cooling loops and communication antennas. Shed non-vital racks and cross-tie essential bus power.',
    initialTime: 22,
    steps: [
      { id: 'step1', label: 'Shed Non-Essential Science Racks', actionType: 'switch', instruction: 'Reduce load by 4.2 kW to prevent battery thermal runaway.' },
      { id: 'step2', label: 'Reset Solar Array Shunt Regulator', actionType: 'breaker', instruction: 'Clear short circuit on starboard solar wing.' },
      { id: 'step3', label: 'Tie Essential Bus A to Bus B', actionType: 'switch', instruction: 'Restore continuous power to primary flight computers.' },
    ],
    nasaDocRef: 'NASA ISS Flight Controller Operations Handbook FCOH-ELEC',
  },
];

export const EmergencyDrillModal: React.FC<EmergencyDrillModalProps> = ({
  isOpen,
  onClose,
  profile,
  onRewardXP,
}) => {
  const [selectedScenarioIdx, setSelectedScenarioIdx] = useState(0);
  const scenario = EMERGENCY_SCENARIOS[selectedScenarioIdx];

  const [timer, setTimer] = useState(scenario.initialTime);
  const [drillRunning, setDrillRunning] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  const [drillStatus, setDrillStatus] = useState<'standby' | 'active' | 'success' | 'failed'>('standby');
  const [klaxonActive, setKlaxonActive] = useState(false);

  // Start scenario
  const startDrill = () => {
    playUiClick();
    setTimer(scenario.initialTime);
    setCompletedSteps([]);
    setDrillStatus('active');
    setDrillRunning(true);
    setKlaxonActive(true);
    playMasterAlarmKlaxon(2);

    speakCapCom(`Houston CapCom: Master Warning alarm on the flight deck. Execute emergency procedure immediately.`);
  };

  // Timer loop
  useEffect(() => {
    if (!drillRunning || drillStatus !== 'active') return;

    const interval = setInterval(() => {
      setTimer(t => {
        if (t <= 1) {
          clearInterval(interval);
          setDrillRunning(false);
          setDrillStatus('failed');
          setKlaxonActive(false);
          playErrorAlert();
          speakCapCom('CapCom: Time expired. Critical flight parameters exceeded.');
          return 0;
        }
        if (t <= 6) {
          playTone(920, 0.08, 'sawtooth');
        }
        return t - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [drillRunning, drillStatus]);

  // Handle step completion
  const handleToggleStep = (stepId: string) => {
    if (!drillRunning || drillStatus !== 'active') return;
    if (completedSteps.includes(stepId)) return;

    playUiClick();
    playTone(700, 0.08, 'sine');
    const next = [...completedSteps, stepId];
    setCompletedSteps(next);

    // If all steps resolved
    if (next.length >= scenario.steps.length) {
      setDrillRunning(false);
      setDrillStatus('success');
      setKlaxonActive(false);
      playSuccessChime();
      fireMissionConfetti();
      speakCapCom('Houston CapCom: All telemetry nominal. Master warning cleared. Excellent work, Commander.');

      if (onRewardXP) {
        onRewardXP(50);
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className={`bg-[#061113] border-2 rounded-3xl w-full max-w-3xl overflow-hidden shadow-2xl relative flex flex-col transition-all ${
        klaxonActive ? 'border-[#ef7144] shadow-[0_0_50px_rgba(239,113,68,0.4)]' : 'border-[#1b3834]'
      }`}>
        {/* Flashing Master Alarm Warning Bar */}
        <div className={`p-4 border-b flex items-center justify-between transition-colors ${
          klaxonActive ? 'bg-[#ef7144] text-[#061211] animate-pulse' : 'bg-[#0a2327] text-[#eef4e6] border-white/10'
        }`}>
          <div className="flex items-center gap-3">
            <span className="p-2 rounded-xl bg-black/30 font-black text-xl">
              <AlertTriangle size={24} />
            </span>
            <div>
              <div className="text-[10px] font-mono tracking-widest font-black uppercase">
                NASA FLIGHT OPERATIONS · CONTINGENCY DRILL
              </div>
              <h2 className="text-xl font-display font-extrabold uppercase tracking-tight">
                Master Alarm Emergency Drill
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              playUiClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-black/20 hover:bg-black/40 transition cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Scenario Selector Tabs */}
        <div className="p-4 bg-[#040d0f] border-b border-white/5 flex flex-wrap gap-2">
          {EMERGENCY_SCENARIOS.map((s, idx) => (
            <button
              key={s.id}
              onClick={() => {
                playUiClick();
                setSelectedScenarioIdx(idx);
                setDrillStatus('standby');
                setDrillRunning(false);
                setCompletedSteps([]);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
                selectedScenarioIdx === idx
                  ? 'bg-[#ef7144] text-white shadow-md'
                  : 'bg-white/5 text-[#9fb1a6] hover:bg-white/10'
              }`}
            >
              {idx + 1}. {s.title.split(' ')[0]} {s.title.split(' ')[1]}
            </button>
          ))}
        </div>

        {/* Main Drill Body */}
        <div className="p-6 space-y-6 flex-1 overflow-y-auto">
          {/* Situation Briefing */}
          <div className="p-4 rounded-2xl bg-[#0a1f24] border border-[#ef7144]/30 space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-[#ff9838] font-bold">{scenario.historicalEvent}</span>
              <span className="text-[#9fb1a6]">{scenario.nasaDocRef}</span>
            </div>
            <h3 className="font-display font-bold text-lg text-white">
              {scenario.title}
            </h3>
            <p className="text-xs text-[#bdc9c0] leading-relaxed">
              {scenario.briefing}
            </p>
          </div>

          {/* Countdown Clock & Status Annunciator */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-[#020708] border border-white/10">
            <div>
              <span className="text-[10px] font-mono tracking-wider text-[#9fb1a6] block uppercase">
                EMERGENCY TIME REMAINING
              </span>
              <span className={`text-4xl font-mono font-black tracking-wider ${
                timer <= 6 ? 'text-[#ef7144] animate-ping' : 'text-[#d9f36a]'
              }`}>
                00:{String(timer).padStart(2, '0')} SEC
              </span>
            </div>

            {drillStatus === 'standby' && (
              <button
                onClick={startDrill}
                className="px-6 py-3 rounded-xl bg-[#ef7144] hover:bg-[#ff865c] text-white font-mono font-bold text-xs uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(239,113,68,0.4)] cursor-pointer"
              >
                Trigger Alarm &amp; Begin Drill
              </button>
            )}

            {drillStatus === 'active' && (
              <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#ef7144]/20 border border-[#ef7144] text-[#ef7144] font-mono text-xs font-bold animate-pulse">
                <AlertTriangle size={15} />
                <span>MASTER WARNING ACTIVE</span>
              </div>
            )}

            {drillStatus === 'success' && (
              <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#d9f36a]/20 border border-[#d9f36a] text-[#d9f36a] font-mono text-xs font-bold">
                <CheckCircle2 size={16} />
                <span>CONTINGENCY RESOLVED (+50 XP)</span>
              </div>
            )}

            {drillStatus === 'failed' && (
              <button
                onClick={startDrill}
                className="px-5 py-2.5 rounded-xl bg-[#ef7144] text-white font-mono font-bold text-xs uppercase flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw size={14} /> Retry Emergency
              </button>
            )}
          </div>

          {/* NASA Quick Reaction Checklist (QRC) Steps */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-mono font-bold text-[#72d1d6]">
              <span>NASA QUICK REACTION CHECKLIST (QRC)</span>
              <span>{completedSteps.length} / {scenario.steps.length} RESOLVED</span>
            </div>

            <div className="space-y-2.5">
              {scenario.steps.map((st, i) => {
                const done = completedSteps.includes(st.id);
                return (
                  <div
                    key={st.id}
                    className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      done
                        ? 'bg-[#07241e] border-[#d9f36a] text-[#d9f36a]'
                        : drillStatus === 'active'
                        ? 'bg-[#0c1f24] border-white/15 text-white hover:border-[#ff9838]'
                        : 'bg-white/5 border-transparent text-[#9fb1a6] opacity-60'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2 text-xs font-mono font-bold">
                        <span className="w-5 h-5 rounded-full bg-black/40 flex items-center justify-center text-[10px]">
                          {i + 1}
                        </span>
                        <strong className="text-sm font-display">{st.label}</strong>
                      </div>
                      <p className="text-xs text-[#9fb1a6] mt-1 pl-7">
                        {st.instruction}
                      </p>
                    </div>

                    <button
                      disabled={!drillRunning || done}
                      onClick={() => handleToggleStep(st.id)}
                      className={`px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all shrink-0 cursor-pointer ${
                        done
                          ? 'bg-[#d9f36a] text-[#061211] font-black'
                          : drillStatus === 'active'
                          ? 'bg-[#ef7144] hover:bg-[#ff865c] text-white shadow-md'
                          : 'bg-white/10 text-[#9fb1a6] cursor-not-allowed'
                      }`}
                    >
                      {done ? 'RESOLVED ✓' : 'EXECUTE PROCEDURE'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="p-4 border-t border-white/10 bg-[#040d0f] flex items-center justify-between text-[11px] font-mono text-[#9fb1a6]">
          <span>NASA EMERGENCY FLIGHT SIMULATOR · TRAIN UNDER PRESSURE</span>
          <span className="text-[#d9f36a]">APOLLO / SHUTTLE QRH PROTOCOLS</span>
        </div>
      </div>
    </div>
  );
};
