import React, { useState } from 'react';
import { AlertCircle, ArrowRight, ArrowUpRight, CheckCircle2, ShieldCheck } from 'lucide-react';
import { AstronautProfile } from '../types';
import { AVATAR_OPTIONS } from '../data/missionsData';
import { playSuccessChime, playUiClick, playErrorAlert } from '../utils/audio';
import { AvatarVisual } from './AvatarVisual';

interface CrewIntakeProps {
  currentProfile: AstronautProfile | null;
  onSaveProfile: (profile: AstronautProfile) => void;
  onStartTraining: () => void;
}

export const CrewIntake: React.FC<CrewIntakeProps> = ({
  currentProfile,
  onSaveProfile,
  onStartTraining,
}) => {
  const [name, setName] = useState(currentProfile?.name || '');
  const [selectedAvatar, setSelectedAvatar] = useState(
    currentProfile?.avatar || AVATAR_OPTIONS[0].icon
  );
  const [error, setError] = useState('');

  const currentSuit =
    AVATAR_OPTIONS.find(a => a.icon === selectedAvatar) || AVATAR_OPTIONS[0];

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanName = name.trim();
    if (!cleanName) {
      playErrorAlert();
      setError('Please enter a call sign to continue.');
      return;
    }

    playSuccessChime();
    const profile: AstronautProfile = {
      name: cleanName,
      avatar: selectedAvatar,
      points: currentProfile?.points ?? 0,
      completed: currentProfile?.completed ?? [],
      achievements: currentProfile?.achievements ?? ['RECRUIT_ENLISTED'],
      registeredAt: currentProfile?.registeredAt || new Date().toISOString(),
      soundEnabled: true,
    };

    onSaveProfile(profile);
    onStartTraining();
  };

  return (
    <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-16">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
        {/* Left Hero Copy */}
        <section className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-[#9fb1a6]">
            <span className="text-[#ef7144] font-mono">01</span>
            <span>YOUR UNIVERSE IS WAITING</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#66a75e] animate-pulse" />
          </div>

          <h1 className="font-display font-bold text-5xl sm:text-6xl lg:text-7xl leading-[0.98] text-[#eef4e6]">
            Small steps.<br />
            <em className="text-[#ef7144] not-italic">Giant</em> missions.
          </h1>

          <p className="text-base sm:text-lg text-[#bdc9c0] max-w-xl leading-relaxed">
            Suit up, solve real space challenges, test rocket propulsion, explore planetary worlds,
            and earn your official flight certificate among the stars.
          </p>

          {/* Quick Metrics */}
          <div className="flex items-center gap-6 pt-2 text-xs font-bold tracking-wider text-[#9fb1a6] border-y border-[#1b3834]/60 py-4">
            <div>
                <span className="text-xl sm:text-2xl font-mono text-[#d9f36a] mr-2">19</span>
              <span>FLIGHT MISSIONS</span>
            </div>
            <div className="w-px h-6 bg-[#1b3834]" />
            <div>
              <span className="text-xl sm:text-2xl font-mono text-[#72d1d6] mr-2">01</span>
              <span>CREW. YOU.</span>
            </div>
            <div className="w-px h-6 bg-[#1b3834]" />
            <div>
              <span className="text-xl sm:text-2xl font-mono text-[#ffc93c] mr-2">100%</span>
              <span>NASA SCIENCE</span>
            </div>
          </div>

          {/* Earth / Space Station Historic Archive Photograph */}
          <figure className="relative group hidden sm:block overflow-hidden rounded-lg border border-[#1b3834] bg-[#0b2025]/50 p-2 shadow-2xl">
            <div className="overflow-hidden rounded">
              <img
                src="/skylab-archive.jpg"
                alt="The Skylab space station above a cloud-covered Earth, photographed by NASA astronauts"
                loading="lazy"
                decoding="async"
                className="w-full h-48 sm:h-60 object-cover object-center filter saturate-85 group-hover:saturate-105 group-hover:scale-[1.02] transition-all duration-700"
              />
            </div>
            <figcaption className="flex items-center justify-between pt-2.5 px-1 text-[10px] font-mono tracking-wider text-[#9fb1a6]">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#d9f36a]" />
                EARTH ORBIT · SKYLAB EXPEDITION · 1974
              </span>
              <a
                href="https://images.nasa.gov/details/sl4-143-4707"
                target="_blank"
                rel="noreferrer"
                className="text-[#72d1d6] hover:underline flex items-center gap-0.5"
              >
                <span>NASA / JSC ARCHIVE</span>
                <ArrowUpRight size={10} />
              </a>
            </figcaption>
          </figure>
        </section>

        {/* Right Sign-in Panel */}
        <section className="lg:col-span-5 relative">
          <div className="login-card">
            <div className="login-box">
              <form onSubmit={handleSubmit} noValidate className="login-form">
                <img
                  src="/cosmora-logo.png"
                  alt="Cosmora"
                  width={128}
                  height={128}
                  className="login-logo"
                />
                <h2 className="login-header">Join the crew</h2>
                <p className="login-sub">Create your crew profile to start training.</p>

                <div className="login-field">
                  <label htmlFor="astronaut-name" className="login-label">
                    Call sign
                  </label>
                  <input
                    id="astronaut-name"
                    type="text"
                    maxLength={20}
                    autoComplete="nickname"
                    value={name}
                    aria-invalid={!!error}
                    aria-describedby={error ? 'astronaut-name-error' : undefined}
                    onChange={e => {
                      setName(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder="e.g. Commander Sarah"
                    className="login-input"
                  />
                  {error && (
                    <p id="astronaut-name-error" role="alert" className="login-error">
                      <AlertCircle size={13} aria-hidden="true" /> {error}
                    </p>
                  )}
                </div>

                <fieldset className="login-field">
                  <div className="login-label-row">
                    <legend className="login-label">Avatar</legend>
                    <span className="login-role">{currentSuit.role}</span>
                  </div>

                  <div className="login-avatars" role="radiogroup" aria-label="Choose avatar">
                    {AVATAR_OPTIONS.map(avatar => {
                      const isSelected = selectedAvatar === avatar.icon;
                      return (
                        <button
                          key={avatar.name}
                          type="button"
                          role="radio"
                          aria-checked={isSelected}
                          onClick={() => {
                            playUiClick();
                            setSelectedAvatar(avatar.icon);
                          }}
                          style={{ ['--accent' as string]: avatar.color }}
                          className={`login-avatar${isSelected ? ' is-selected' : ''}`}
                        >
                          <AvatarVisual
                            avatar={avatar.icon}
                            alt={`${avatar.name} astronaut portrait`}
                            className="w-10 h-10 rounded-full"
                          />
                          <span className="login-avatar__name">{avatar.name}</span>
                          {isSelected && (
                            <CheckCircle2 size={14} className="login-avatar__check" aria-hidden="true" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <p className="login-hint">
                    <span className="login-hint__dot" style={{ backgroundColor: currentSuit.color }} />
                    {currentSuit.suitDescription}
                  </p>
                </fieldset>

                <button type="submit" className="login-submit">
                  <span>Start training</span>
                  <ArrowRight size={18} strokeWidth={2.25} />
                </button>

                <p className="login-foot">
                  <ShieldCheck size={13} aria-hidden="true" />
                  Your progress is saved automatically on this device.
                </p>
              </form>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
