import React, { useEffect } from 'react';
import { Award, ArrowLeft, Printer, Sparkles, Lock, Orbit, ShieldCheck, BadgeCheck, Fingerprint, ChevronRight } from 'lucide-react';
import { AstronautProfile } from '../types';
import { MISSIONS } from '../data/missionsData';
import { playGrandFanfare, playUiClick } from '../utils/audio';
import { fireCertificateGrandConfetti } from '../utils/confetti';
import { getAstronautRank } from '../utils/ranks';

interface CertificateProps {
  profile: AstronautProfile;
  onBackToDeck: () => void;
}

export const Certificate: React.FC<CertificateProps> = ({ profile, onBackToDeck }) => {
  const isEligible = profile.completed.length >= 4;
  useEffect(() => {
    if (isEligible) { playGrandFanfare(); fireCertificateGrandConfetti(); }
  }, [isEligible]);

  const rank = getAstronautRank(profile.points);
  const handlePrint = () => { playUiClick(); window.print(); };
  const formattedDate = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  const serial = `COS-${String(profile.name).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 7) || 'CADET'}-${new Date().getFullYear()}`;

  return (
    <main className="relative z-10 mx-auto max-w-6xl space-y-7 px-4 py-7 sm:px-6 md:py-10">
      <div className="flex items-center justify-between gap-3 no-print">
        <button onClick={() => { playUiClick(); onBackToDeck(); }} className="group inline-flex items-center gap-2 text-xs font-mono tracking-wider text-[#9fb1a6] hover:text-[#d9f36a] transition-colors cursor-pointer"><ArrowLeft size={15} className="transition-transform group-hover:-translate-x-1" /> FLIGHT RECORD</button>
        {isEligible && <button onClick={handlePrint} className="inline-flex items-center gap-2 rounded-xl border border-[#d9f36a]/30 bg-[#d9f36a] px-4 py-2.5 text-xs font-mono font-bold tracking-wide text-[#101710] hover:bg-[#e6fc85] transition cursor-pointer"><Printer size={15} /> PRINT OFFICIAL CERTIFICATE</button>}
      </div>

      {!isEligible ? (
        <section className="relative isolate overflow-hidden rounded-[30px] border border-[#ffc93c]/25 bg-[radial-gradient(ellipse_at_50%_0%,rgba(255,201,60,.12),transparent_42%),linear-gradient(150deg,#10262b,#071518_68%,#111e1d)] px-6 py-12 text-center shadow-[0_30px_90px_rgba(0,0,0,.3)] sm:px-12 sm:py-16">
          <div className="pointer-events-none absolute -right-16 -top-24 h-80 w-80 rounded-full border border-[#ffc93c]/10 after:absolute after:inset-8 after:rounded-full after:border after:border-dashed after:border-[#72d1d6]/15 before:absolute before:inset-16 before:rounded-full before:border before:border-[#ffc93c]/10" />
          <div className="relative mx-auto grid h-20 w-20 place-items-center rounded-[24px] border border-[#ffc93c]/30 bg-[#ffc93c]/10 text-[#ffc93c] shadow-[0_0_50px_rgba(255,201,60,.12)]"><Lock size={30} /></div>
          <div className="relative mt-7 text-[10px] font-mono font-bold tracking-[.23em] text-[#ffc93c]">ACADEMY CREDENTIAL · CLEARANCE PENDING</div>
          <h1 className="relative mt-3 font-display text-3xl font-bold tracking-tight text-[#eef4e6] sm:text-5xl">Your next milestone <span className="text-[#ffc93c]">awaits.</span></h1>
          <p className="relative mx-auto mt-4 max-w-xl text-sm leading-relaxed text-[#a5b8ae]">Complete at least four flight missions to certify your space readiness and unlock the Cosmora Academy graduation record.</p>
          <div className="relative mx-auto mt-8 max-w-md rounded-2xl border border-white/10 bg-black/20 p-4 text-left">
            <div className="flex items-center justify-between text-[9px] font-mono tracking-[.15em] text-[#92a69c]"><span>MISSION CLEARANCE</span><span className="text-[#ffc93c]">{profile.completed.length} / 4 REQUIRED</span></div>
            <div className="mt-3 flex gap-1.5">{Array.from({ length: 4 }, (_, index) => <div key={index} className={`h-2 flex-1 rounded-full ${index < profile.completed.length ? 'bg-gradient-to-r from-[#72d1d6] to-[#d9f36a] shadow-[0_0_10px_rgba(217,243,106,.3)]' : 'bg-white/10'}`} />)}</div>
            <div className="mt-3 text-xs text-[#a5b8ae]">{Math.max(0, 4 - profile.completed.length)} more mission{Math.max(0, 4 - profile.completed.length) === 1 ? '' : 's'} to graduate</div>
          </div>
          <button onClick={() => { playUiClick(); onBackToDeck(); }} className="relative mt-7 inline-flex items-center gap-2 rounded-xl bg-[#d9f36a] px-6 py-3 text-sm font-bold text-[#0b1713] shadow-[0_0_24px_rgba(217,243,106,.17)] transition hover:bg-[#e6fc85] cursor-pointer">RETURN TO FLIGHT MISSIONS <ChevronRight size={16} /></button>
          <div className="relative mt-7 flex items-center justify-center gap-2 text-[9px] font-mono tracking-widest text-white/35"><Orbit size={13} /> COSMORA ACADEMY · FLIGHT TRAINING DIVISION</div>
        </section>
      ) : (
        <section className="space-y-5">
          <article className="certificate-print relative isolate overflow-hidden rounded-[30px] border border-[#ffc93c]/65 bg-[radial-gradient(ellipse_at_50%_0%,rgba(255,201,60,.13),transparent_40%),radial-gradient(ellipse_at_0%_100%,rgba(114,209,214,.10),transparent_36%),linear-gradient(145deg,#10252a,#071518_60%,#0c1e22)] p-2.5 shadow-[0_28px_90px_rgba(0,0,0,.32),0_0_55px_rgba(255,201,60,.08)] sm:p-4">
            <div className="pointer-events-none absolute inset-3 rounded-[23px] border border-[#ffc93c]/20 sm:inset-4" />
            <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-[.12]"><div className="absolute -right-24 -top-32 h-[460px] w-[460px] rounded-full border border-[#72d1d6]/45 after:absolute after:inset-12 after:rounded-full after:border after:border-dashed after:border-[#ffc93c]/50 before:absolute before:inset-24 before:rounded-full before:border before:border-[#72d1d6]/50" /><div className="absolute -bottom-48 -left-32 h-[430px] w-[430px] rounded-full border border-[#ffc93c]/35" /></div>
            <div className="relative px-5 py-8 text-center sm:px-12 sm:py-12 md:px-16 md:py-14">
              <div className="flex items-center justify-center gap-2 text-[10px] font-mono font-bold tracking-[.27em] text-[#a9c3bd]"><Orbit size={15} className="text-[#72d1d6]" /> COSMORA ACADEMY <span className="text-white/25">/</span> FLIGHT TRAINING DIVISION</div>
              <div className="mx-auto mt-8 grid h-[76px] w-[76px] place-items-center rounded-full border border-[#ffc93c]/55 bg-[radial-gradient(circle_at_35%_30%,#ffe9a3,#c88e1d_55%,#714c0e)] text-[#241b07] shadow-[0_0_36px_rgba(255,201,60,.24)]"><div className="grid h-[60px] w-[60px] place-items-center rounded-full border border-[#4f3b13]/45"><ShieldCheck size={31} strokeWidth={1.4} /></div></div>
              <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-[#66d17a]/20 bg-[#66d17a]/[.07] px-3 py-1 text-[9px] font-mono font-bold tracking-[.15em] text-[#8de59d]"><BadgeCheck size={13} /> VERIFIED FLIGHT RECORD</div>
              <h1 className="mt-5 font-display text-3xl font-bold leading-tight tracking-tight text-[#f2f3e9] sm:text-5xl md:text-6xl">Certificate of<br /><span className="bg-gradient-to-r from-[#ffe39a] via-[#ffc93c] to-[#e8a827] bg-clip-text text-transparent">Space Readiness</span></h1>
              <div className="mx-auto mt-7 h-px max-w-xl bg-gradient-to-r from-transparent via-[#ffc93c]/60 to-transparent" />
              <p className="mt-6 text-[10px] font-mono tracking-[.28em] text-[#9fb1a6]">THIS ACADEMY RECOGNIZES</p>
              <div className="mt-2 break-words font-display text-3xl font-bold tracking-wide text-[#d9f36a] sm:text-5xl">{profile.name}</div>
              <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-[#c2d0c8] sm:text-base">For successfully completing the Cosmora Junior Astronaut Mission Program, demonstrating readiness across launch operations, orbital science, and deep-space exploration.</p>

              <div className="mx-auto mt-8 grid max-w-2xl grid-cols-3 overflow-hidden rounded-2xl border border-white/10 bg-black/15">
                <div className="px-2 py-4 sm:px-5"><div className="text-2xl font-bold text-[#ffc93c] sm:text-3xl">{profile.completed.length}</div><div className="mt-1 text-[8px] font-mono tracking-[.15em] text-[#98aca2] sm:text-[9px]">MISSIONS SEALED</div></div>
                <div className="border-x border-white/10 px-2 py-4 sm:px-5"><div className="text-2xl font-bold text-[#d9f36a] sm:text-3xl">{profile.points.toLocaleString()} <span className="text-sm">XP</span></div><div className="mt-1 text-[8px] font-mono tracking-[.15em] text-[#98aca2] sm:text-[9px]">FLIGHT EXPERIENCE</div></div>
                <div className="px-2 py-4 sm:px-5"><div className="truncate text-lg font-bold text-[#72d1d6] sm:text-2xl">{rank.title}</div><div className="mt-1 text-[8px] font-mono tracking-[.15em] text-[#98aca2] sm:text-[9px]">ACADEMY RANK · {rank.grade}</div></div>
              </div>

              <div className="mx-auto mt-8 grid max-w-2xl grid-cols-2 gap-5 text-left sm:gap-10">
                <div className="border-t border-white/20 pt-3"><div className="font-display text-sm font-semibold text-[#eef4e6]">Commander Nova</div><div className="mt-0.5 text-[10px] text-[#94a89e]">Director, Mission Control</div><div className="mt-2 flex items-center gap-1.5 text-[8px] font-mono tracking-wider text-[#66d17a]"><Fingerprint size={11} /> ACADEMY AUTHORIZED</div></div>
                <div className="border-t border-white/20 pt-3 text-right"><div className="font-display text-sm font-semibold text-[#eef4e6]">Cosmora Academy</div><div className="mt-0.5 text-[10px] text-[#94a89e]">Flight Training Division</div><div className="mt-2 text-[9px] font-mono tracking-wider text-[#ffc93c]">{formattedDate}</div></div>
              </div>
              <div className="mx-auto mt-8 flex max-w-2xl flex-col justify-between gap-2 border-t border-white/8 pt-3 text-[8px] font-mono tracking-[.13em] text-white/35 sm:flex-row"><span>RECORD SERIAL · {serial}</span><span>ISSUED BY COSMORA ACADEMY · EARTH ORBIT</span></div>
            </div>
          </article>
          <div className="flex flex-col items-center justify-between gap-3 rounded-2xl border border-white/8 bg-[#0a1b1f]/80 p-4 sm:flex-row no-print"><div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl border border-[#ffc93c]/25 bg-[#ffc93c]/10 text-[#ffc93c]"><Award size={19} /></div><div><div className="text-xs font-bold text-white">Graduation record verified</div><div className="mt-0.5 text-[10px] text-[#93a79d]">Your academy credential is ready to print or save as PDF.</div></div></div><button onClick={handlePrint} className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#d9f36a] px-5 py-3 text-xs font-bold tracking-wide text-[#101710] shadow-[0_0_20px_rgba(217,243,106,.14)] transition hover:bg-[#e6fc85] cursor-pointer sm:w-auto"><Printer size={15} /> PRINT / SAVE AS PDF</button></div>
          <div className="text-center text-[9px] font-mono tracking-[.16em] text-white/30 no-print"><Sparkles size={12} className="mr-1 inline text-[#ffc93c]" /> KEEP LOOKING UP · THE UNIVERSE IS WAITING</div>
        </section>
      )}
    </main>
  );
};
