import React, { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

/* -------------------------------------------------------------------------- */
/*  Procedural, GPU-rendered planets (no textures, no network, no dependencies) */
/* -------------------------------------------------------------------------- */

interface PlanetConfig {
  type: number; // shader branch
  tilt: number; // axial tilt (deg)
  pitch: number; // view pitch (deg) – lets us see the north pole
  yaw: number; // extra yaw (deg)
  radius: number; // planet radius in normalised canvas units
  ring: number; // 0 none, 1 Saturn, 2 Uranus
  spin: number; // rad / s (negative = retrograde)
  atmo: [number, number, number];
  atmoI: number; // atmosphere intensity
  haloK: number; // halo falloff
}

export const PLANET_CONFIG: Record<string, PlanetConfig> = {
  Mercury: { type: 0, tilt: 0, pitch: 8, yaw: 0, radius: 0.8, ring: 0, spin: 0.05, atmo: [0.6, 0.6, 0.6], atmoI: 0, haloK: 20 },
  Venus: { type: 1, tilt: 177, pitch: -10, yaw: 0, radius: 0.8, ring: 0, spin: -0.03, atmo: [1.0, 0.82, 0.45], atmoI: 0.85, haloK: 11 },
  Earth: { type: 2, tilt: 23.4, pitch: 14, yaw: 0, radius: 0.8, ring: 0, spin: 0.11, atmo: [0.25, 0.55, 1.0], atmoI: 1.1, haloK: 13 },
  Mars: { type: 3, tilt: 25.2, pitch: 12, yaw: 0, radius: 0.8, ring: 0, spin: 0.1, atmo: [0.95, 0.6, 0.38], atmoI: 0.4, haloK: 18 },
  Jupiter: { type: 4, tilt: 3.1, pitch: 6, yaw: 0, radius: 0.8, ring: 0, spin: 0.22, atmo: [0.9, 0.78, 0.6], atmoI: 0.3, haloK: 16 },
  Saturn: { type: 5, tilt: 27, pitch: 17, yaw: 0, radius: 0.42, ring: 1, spin: 0.2, atmo: [0.95, 0.85, 0.6], atmoI: 0.3, haloK: 16 },
  Uranus: { type: 6, tilt: 98, pitch: 10, yaw: 38, radius: 0.42, ring: 2, spin: -0.12, atmo: [0.55, 0.9, 0.95], atmoI: 0.75, haloK: 12 },
  Neptune: { type: 7, tilt: 28, pitch: 10, yaw: 0, radius: 0.8, ring: 0, spin: 0.13, atmo: [0.25, 0.45, 1.0], atmoI: 0.85, haloK: 12 },
  Moon: { type: 8, tilt: 6.7, pitch: 8, yaw: 0, radius: 0.8, ring: 0, spin: 0.04, atmo: [0.6, 0.6, 0.6], atmoI: 0, haloK: 20 },
  Sun: { type: 9, tilt: 7.25, pitch: 6, yaw: 0, radius: 0.62, ring: 0, spin: 0.03, atmo: [1.0, 0.55, 0.16], atmoI: 1.7, haloK: 7 },
};

/* ------------------------------ GLSL shaders ------------------------------ */

const VERT = `
attribute vec2 aPos;
void main(){ gl_Position = vec4(aPos, 0.0, 1.0); }
`;

/* eslint-disable */
const FRAG = `
precision highp float;

uniform vec2  uRes;
uniform float uTime;
uniform int   uType;
uniform mat3  uM;        // planet frame -> screen frame
uniform vec3  uL;        // sun direction (screen frame)
uniform vec3  uRingN;    // ring plane normal (screen frame)
uniform float uRadius;
uniform float uRing;
uniform float uStars;
uniform vec3  uAtmo;
uniform float uAtmoI;
uniform float uHaloK;
uniform float uQuality;

vec3 gL;
float gShadow;   // ring shadow cast on planet

float sst(float a, float b, float x){ float t = clamp((x-a)/(b-a), 0.0, 1.0); return t*t*(3.0-2.0*t); }

float hash(vec3 p){
  p = fract(p*0.3183099 + vec3(0.1,0.2,0.3));
  p *= 17.0;
  return fract(p.x*p.y*p.z*(p.x+p.y+p.z));
}
vec3 hash3(vec3 p){
  return vec3(hash(p), hash(p+vec3(17.1,3.7,9.2)), hash(p+vec3(5.3,21.7,11.9)));
}
float noise(vec3 x){
  vec3 i = floor(x); vec3 f = fract(x);
  f = f*f*f*(f*(f*6.0-15.0)+10.0);
  return mix(mix(mix(hash(i+vec3(0,0,0)), hash(i+vec3(1,0,0)), f.x),
                 mix(hash(i+vec3(0,1,0)), hash(i+vec3(1,1,0)), f.x), f.y),
             mix(mix(hash(i+vec3(0,0,1)), hash(i+vec3(1,0,1)), f.x),
                 mix(hash(i+vec3(0,1,1)), hash(i+vec3(1,1,1)), f.x), f.y), f.z);
}
float fbm(vec3 p, int oct){
  float a = 0.5; float s = 0.0; float norm = 0.0;
  int octaveCount = oct;
  if(uQuality < 0.99){
    octaveCount = int(floor(float(oct) * uQuality + 0.5));
    if(octaveCount < 2) octaveCount = 2;
  }
  for(int i=0;i<7;i++){
    if(i>=octaveCount) break;
    s += a*noise(p); norm += a;
    p = p*2.03 + vec3(1.7,9.2,3.1);
    a *= 0.5;
  }
  return s/norm;
}
float h1(float x){ return fract(sin(x*12.9898)*43758.5453); }
float n1(float x){ float i=floor(x); float f=fract(x); f=f*f*(3.0-2.0*f); return mix(h1(i), h1(i+1.0), f); }

vec3 rotY(vec3 v, float a){ float c=cos(a); float s=sin(a); return vec3(c*v.x + s*v.z, v.y, -s*v.x + c*v.z); }
vec3 toLin(vec3 c){ return pow(c, vec3(2.2)); }

/* ---------------------------- crater generator ---------------------------- */
float craterLayer(vec3 p, float scale, float depth, float density){
  p *= scale;
  vec3 i = floor(p); vec3 f = fract(p);
  float h = 0.0;
  for(int x=-1;x<=1;x++){
    for(int y=-1;y<=1;y++){
      for(int z=-1;z<=1;z++){
        if(uQuality < 0.75 && x*x+y*y+z*z > 1) continue;
        vec3 g = vec3(float(x),float(y),float(z));
        vec3 id = i+g;
        if(hash(id+vec3(3.3,1.1,7.7)) > density) continue;
        vec3 o = hash3(id);
        vec3 c = g + 0.18 + 0.64*o;
        float rad = 0.16 + 0.26*hash(id+vec3(7.7,2.2,5.1));
        float t = length(f-c)/rad;
        if(t < 1.0){
          float bowl = -(1.0 - t*t);
          float floorFlat = sst(0.0,0.55,t);
          h += depth*rad*(bowl*(0.55+0.45*floorFlat));
        }
        h += depth*rad*0.55*exp(-pow((t-1.05)*4.5, 2.0));
      }
    }
  }
  return h;
}

/* --------------------------- height / elevation --------------------------- */
float earthElevO(vec3 q, int oct){
  vec3 w = vec3(fbm(q*1.5+vec3(3.0,1.0,7.0),3), fbm(q*1.5+vec3(8.0,4.0,2.0),3), fbm(q*1.5+vec3(1.0,9.0,5.0),3));
  return fbm(q*1.6 + 1.0*(w-0.5)*2.0, oct);
}
float earthElev(vec3 q){ return earthElevO(q,6); }

float heightFn(vec3 q){
  if(uType==0){
    return 0.10*fbm(q*5.0,4) + 0.020*fbm(q*40.0,3)
         + 0.55*craterLayer(q,3.6,1.0,0.55)
         + 0.65*craterLayer(q,9.0,0.8,0.5);
  } else if(uType==3){
    float lon = atan(q.z,q.x);
    float valley = sst(0.05,0.0,abs(q.y+0.09+0.02*sin(lon*7.0)+0.01*sin(lon*23.0))) * sst(1.0,0.2,abs(lon-0.9));
    return 0.12*fbm(q*4.0,5) + 0.012*fbm(q*30.0,3)
         + 0.30*craterLayer(q,5.5,0.45,0.38) + 0.18*craterLayer(q,13.0,0.35,0.4) - 0.12*valley;
  } else if(uType==8){
    float mare = sst(0.52,0.60,fbm(q*1.7+vec3(4.0,1.0,2.0),4));
    return (0.08*fbm(q*5.0,4) + 0.015*fbm(q*40.0,3)
         + 0.50*craterLayer(q,3.2,1.0,0.5)
         + 0.55*craterLayer(q,8.0,0.8,0.5))*(1.0-0.75*mare);
  } else if(uType==2){
    float e = earthElevO(q,4);
    return max(e-0.54,0.0)*0.5;
  }
  return 0.0;
}

vec3 bumpN(vec3 q, vec3 n, float strength, out float h0){
  float e = 0.010;
  h0 = heightFn(q);
  if(uQuality < 0.75) return n;
  vec3 g = vec3(heightFn(q+vec3(e,0.0,0.0))-h0, heightFn(q+vec3(0.0,e,0.0))-h0, heightFn(q+vec3(0.0,0.0,e))-h0)/e;
  g -= dot(g,q)*q;
  vec3 gs = uM*g;
  return normalize(n - strength*gs);
}

/* --------------------------------- rings ---------------------------------- */
vec4 ringSample(float r){
  if(uRing < 1.5){
    if(r<1.2 || r>2.3) return vec4(0.0);
    float rr = n1(r*70.0)*0.5 + n1(r*190.0)*0.3 + n1(r*520.0)*0.2;
    float a = 0.0;
    a += sst(1.22,1.27,r)*sst(1.55,1.50,r)*0.22;
    a += sst(1.50,1.56,r)*sst(1.97,1.93,r)*(0.80+0.30*rr);
    a += sst(2.02,2.05,r)*sst(2.27,2.24,r)*(0.52+0.35*rr);
    a -= sst(0.012,0.0,abs(r-2.215))*0.55;
    a = clamp(a,0.0,1.0);
    vec3 c = mix(vec3(0.50,0.44,0.38), vec3(0.93,0.83,0.67), sst(1.2,1.65,r));
    c = mix(c, vec3(0.82,0.72,0.58), sst(1.95,2.1,r)*0.6);
    c *= 0.72 + 0.55*rr;
    return vec4(toLin(c), a);
  } else {
    float a = 0.0;
    a += sst(0.02,0.0,abs(r-1.62))*0.10;
    a += sst(0.02,0.0,abs(r-1.70))*0.10;
    a += sst(0.02,0.0,abs(r-1.78))*0.12;
    a += sst(0.02,0.0,abs(r-1.90))*0.14;
    a += sst(0.02,0.0,abs(r-2.00))*0.16;
    a += sst(0.03,0.0,abs(r-2.30))*0.26;
    return vec4(toLin(vec3(0.6,0.65,0.68)), clamp(a,0.0,1.0));
  }
}

/* ------------------------------ planet shaders ----------------------------- */
vec3 mercuryCol(vec3 q, vec3 n){
  float h;
  vec3 nb = bumpN(q,n,2.4,h);
  float v = fbm(q*6.0+vec3(2.0),4);
  vec3 a = mix(vec3(0.27,0.255,0.245), vec3(0.50,0.47,0.44), v);
  a *= mix(vec3(1.0), vec3(1.08,1.0,0.92), fbm(q*2.0+5.0,3));
  a *= 0.82 + 0.9*clamp(h*1.4+0.1,-0.15,0.3);
  a *= 0.85 + 0.3*fbm(q*55.0,2);
  a = toLin(a);
  float d = max(dot(nb,gL),0.0);
  float d0 = max(dot(n,gL),0.0);
  return a*(d*0.75 + 0.25*d0)*1.25 + a*0.004;
}

vec3 venusCol(vec3 q, vec3 n){
  vec3 qa = rotY(q, uTime*0.008);
  float w = fbm(qa*vec3(1.5,2.6,1.5)+3.0,4);
  float s = fbm(qa*vec3(2.0,5.0,2.0) + 2.4*w, 6);
  float chev = 0.5 + 0.5*sin(q.y*8.0 + s*6.0 + w*2.5);
  vec3 a = mix(vec3(0.88,0.70,0.40), vec3(0.99,0.92,0.72), s);
  a = mix(a, vec3(0.68,0.47,0.22), (1.0-chev)*0.38*sst(0.3,0.75,w));
  a = mix(a, vec3(0.96,0.93,0.82), sst(0.6,0.95,abs(q.y))*0.4);
  a = toLin(a);
  float dn = dot(n,gL);
  float d = sst(-0.32, 0.85, dn);
  return a*d*1.25;
}

float cloudAt(vec3 q){
  vec3 qc = rotY(q, uTime*0.012);
  float w = fbm(qc*1.3+5.0,3);
  float c = fbm(qc*vec3(2.8,3.4,2.8) + 1.0*vec3(w,w*0.7,w), 6);
  float zone = 0.5 + 0.5*cos(q.y*9.0);   // cloudier belts
  c += (zone-0.5)*0.12;
  return sst(0.58,0.78,c);
}

vec3 earthCol(vec3 q, vec3 n){
  float sea = 0.54;
  float e = earthElev(q);
  float land = sst(sea-0.004,sea+0.004,e);
  float lat = abs(q.y);
  float mo = fbm(q*3.5+vec3(9.0,2.0,4.0),5);

  vec3 ocean = mix(vec3(0.006,0.05,0.16), vec3(0.03,0.26,0.40), sst(sea-0.16,sea,e));

  vec3 lowland = mix(vec3(0.34,0.30,0.14), vec3(0.09,0.26,0.07), sst(0.32,0.62,mo));
  float arid = sst(0.58,0.36,mo)*sst(0.08,0.22,lat)*sst(0.5,0.28,lat);
  lowland = mix(lowland, vec3(0.70,0.55,0.33), arid);
  lowland = mix(lowland, vec3(0.30,0.35,0.22), sst(0.45,0.7,lat)*0.5);
  float hi = sst(sea+0.05,sea+0.22,e);
  vec3 landc = mix(lowland, vec3(0.42,0.36,0.30), hi);
  float snow = sst(0.78,0.86,lat + (e-sea)*0.5 + 0.06*noise(q*8.0)) + sst(sea+0.20,sea+0.30,e)*sst(0.25,0.6,lat);
  landc = mix(landc, vec3(0.93,0.95,0.97), clamp(snow,0.0,1.0));
  landc *= 0.9 + 0.2*fbm(q*30.0,3);

  vec3 alb = mix(ocean, landc, land);
  float ice = sst(0.86,0.92,lat + 0.05*(fbm(q*7.0,3)-0.5));
  alb = mix(alb, vec3(0.92,0.95,0.98), ice);
  alb = toLin(alb);

  float h;
  vec3 nb = bumpN(q,n,0.55,h);
  nb = normalize(mix(n, nb, land));

  float cl = cloudAt(q);
  // cloud shadow: sample cloud field displaced away from the sun (in planet frame)
  vec3 lp = gL*uM;
  float cshadow = cloudAt(normalize(q - lp*0.035));

  float d = max(dot(nb,gL),0.0);
  vec3 surf = alb*d*(1.0 - 0.55*cshadow*(1.0-ice*0.0));

  vec3 V = vec3(0.0,0.0,1.0);
  vec3 Rv = reflect(-gL, n);
  float sp = pow(max(dot(Rv,V),0.0), 110.0)*1.3 + pow(max(dot(Rv,V),0.0), 14.0)*0.10;
  surf += vec3(1.0,0.93,0.82)*sp*(1.0-land)*(1.0-ice)*(1.0-cl)*step(0.0,d);

  float dc = clamp((dot(n,gL)+0.04)/1.04, 0.0, 1.0);
  vec3 cloudCol = vec3(0.93,0.95,0.98)*(dc*1.05 + 0.004);
  vec3 col = mix(surf, cloudCol, cl*0.93);

  // Ease city lights in across a wider twilight band instead of a sharp terminator.
  float night = 1.0 - sst(-0.30, 0.08, dot(n,gL));
  float city = sst(0.64,0.82, fbm(q*34.0,3)) * sst(0.50,0.70,fbm(q*5.0+2.0,3));
  city *= land*(1.0-ice)*sst(0.7,0.4,lat)*sst(sea+0.15,sea+0.02,e+0.02);
  col += vec3(1.0,0.70,0.32)*city*night*(1.0-cl*0.85)*0.58;
  return col;
}

vec3 marsCol(vec3 q, vec3 n){
  float h;
  vec3 nb = bumpN(q,n,1.7,h);
  float big = fbm(q*2.1+4.0,5);
  float dark = sst(0.50,0.64,big)*sst(0.75,0.25,abs(q.y));
  vec3 dust = mix(vec3(0.60,0.29,0.14), vec3(0.85,0.56,0.33), fbm(q*5.0+1.0,5));
  vec3 a = mix(dust, vec3(0.22,0.13,0.10), dark*0.78);
  a *= 0.85 + 0.3*fbm(q*24.0,3);
  a *= 0.88 + 0.7*clamp(h*1.2+0.05,-0.2,0.25);
  float cap = sst(0.88,0.935,abs(q.y) + 0.05*fbm(q*9.0,3));
  a = mix(a, vec3(0.93,0.91,0.89), cap);
  a = toLin(a);
  float d = max(dot(nb,gL),0.0);
  float d0 = max(dot(n,gL),0.0);
  return a*(d*0.8+0.2*d0)*1.2 + a*0.004;
}

vec3 jupiterCol(vec3 q, vec3 n){
  float lat = q.y;
  float shear = uTime*0.018*(sin(lat*14.0) + 0.5*sin(lat*31.0));
  vec3 qs = rotY(q, shear);

  float lon = atan(q.z,q.x);
  float dl = atan(sin(lon-2.2), cos(lon-2.2));
  vec2 sp = vec2(dl/0.40, (lat+0.30)/0.125);
  float e = dot(sp,sp);
  float spot = 1.0 - sst(0.55,1.0,e);
  float ring = sst(0.9,1.1,e)*sst(2.4,1.2,e);
  float swirl = sst(3.0,0.7,e);

  vec3 sc = qs*vec3(3.6,12.0,3.6);
  vec3 warp = vec3(fbm(sc+1.3,5), fbm(sc+7.7,5), fbm(sc+4.4,5)) - 0.5;
  float ang = atan(sp.y, sp.x) + (1.0-sst(0.0,3.0,e))*4.0 + uTime*0.15*spot;
  float t = fbm(qs*vec3(2.8,18.0,2.8) + warp*vec3(3.2,0.9,3.2), 7);
  t = mix(t, fbm(vec3(cos(ang)*e*0.7, sin(ang)*e*0.7, 1.0)*1.5 + 3.0, 4), swirl*0.45);

  float band = 0.5 + 0.5*sin(lat*19.0 + 0.7*sin(lat*5.3) + (t-0.5)*5.0 + (warp.x)*1.6);
  vec3 zone = vec3(0.91,0.85,0.71);
  vec3 belt = vec3(0.64,0.39,0.25);
  vec3 a = mix(zone, belt, sst(0.35,0.78,1.0-band));
  float nb1 = exp(-pow((abs(lat)-0.34)/0.065,2.0));
  float eq  = exp(-pow((lat-0.10)/0.07,2.0));
  a = mix(a, vec3(0.42,0.26,0.18), clamp(nb1*0.7+eq*0.4,0.0,1.0)*0.85);
  a *= 0.74 + 0.6*t;
  a *= 0.92 + 0.16*fbm(qs*vec3(14.0,60.0,14.0),3);
  a = mix(a, vec3(0.50,0.46,0.44), sst(0.78,0.96,abs(lat))*0.7);

  vec3 grs = mix(vec3(0.72,0.28,0.17), vec3(0.86,0.45,0.28), t);
  a = mix(a, vec3(0.93,0.88,0.78), ring*0.55);
  a = mix(a, grs, spot*0.96);
  a = toLin(a);

  float dn = dot(n,gL);
  float d = sst(-0.28, 0.80, dn);
  float limb = 0.55 + 0.45*pow(n.z,0.45);
  return a*d*limb*1.25 + a*0.003;
}

vec3 saturnCol(vec3 q, vec3 n){
  float lat = q.y;
  float shear = uTime*0.015*(sin(lat*11.0)+0.6*sin(lat*27.0));
  vec3 qs = rotY(q, shear);
  vec3 sc = qs*vec3(2.5,14.0,2.5);
  float t = fbm(sc + 1.2*vec3(fbm(sc*0.5+4.0,3)) ,5);
  float band = 0.5 + 0.5*sin(lat*24.0 + 0.9*sin(lat*6.0) + (t-0.5)*2.2);
  vec3 c1 = vec3(0.94,0.85,0.62);
  vec3 c2 = vec3(0.80,0.66,0.43);
  vec3 c3 = vec3(0.69,0.56,0.36);
  vec3 a = mix(c1, c2, sst(0.2,0.8,band));
  a = mix(a, c3, sst(0.65,1.0,1.0-band)*0.35);
  a *= 0.9 + 0.2*t;
  float pole = sst(0.72,0.95,abs(lat));
  a = mix(a, vec3(0.55,0.56,0.55), pole*0.55);
  float hex = sst(0.02,0.0,abs(abs(lat)-0.93))*0.0;
  a = toLin(a);
  float dn = dot(n,gL);
  float d = sst(-0.28, 0.80, dn);
  float limb = 0.6 + 0.4*pow(n.z,0.4);
  return a*d*limb*1.25 + a*0.003;
}

vec3 uranusCol(vec3 q, vec3 n){
  float lat = q.y;
  float t = fbm(q*vec3(2.0,9.0,2.0),4);
  vec3 base = vec3(0.60,0.84,0.88);
  vec3 a = mix(base, vec3(0.74,0.93,0.94), sst(0.15,0.95,lat));
  a = mix(a, vec3(0.50,0.76,0.82), sst(-0.1,-0.9,lat)*0.5);
  a *= 0.96 + 0.05*sin(lat*26.0 + t*3.0) + 0.04*t;
  float streak = sst(0.72,0.8, fbm(q*vec3(3.0,22.0,3.0)+9.0,4))*sst(0.1,0.5,lat);
  a = mix(a, vec3(0.9,0.98,0.98), streak*0.4);
  a = toLin(a);
  float dn = dot(n,gL);
  float d = sst(-0.30, 0.82, dn);
  float limb = 0.7 + 0.3*pow(n.z,0.4);
  return a*d*limb*1.2 + a*0.003;
}

vec3 neptuneCol(vec3 q, vec3 n){
  float lat = q.y;
  float shear = uTime*0.02*(sin(lat*9.0)+0.5*sin(lat*21.0));
  vec3 qs = rotY(q, shear);
  vec3 sc = qs*vec3(2.5,12.0,2.5);
  float t = fbm(sc + 1.0*vec3(fbm(sc*0.6+3.0,3)), 5);
  float band = 0.5 + 0.5*sin(lat*15.0 + (t-0.5)*3.0);
  vec3 a = mix(vec3(0.09,0.19,0.58), vec3(0.17,0.36,0.80), band);
  a *= 0.9 + 0.2*t;
  a = mix(a, vec3(0.28,0.55,0.95), sst(0.8,1.0,lat)*0.4);

  float lon = atan(q.z,q.x);
  float dl = atan(sin(lon-0.5), cos(lon-0.5));
  vec2 sp = vec2(dl/0.5, (lat+0.36)/0.14);
  float e = dot(sp,sp);
  float spot = 1.0 - sst(0.5,1.0,e);
  a = mix(a, vec3(0.04,0.08,0.34), spot*0.9);

  float cirrus = sst(0.66,0.78, fbm(qs*vec3(2.5,48.0,2.5)+5.0,5));
  cirrus *= sst(0.7,0.2,abs(lat+0.3)) ;
  cirrus += sst(1.6,0.9,e)*sst(0.9,1.1,e)*0.9*sst(0.45,0.7,fbm(qs*vec3(5.0,30.0,5.0),3));
  a = mix(a, vec3(0.85,0.92,1.0), clamp(cirrus,0.0,1.0)*0.55);
  a = toLin(a);
  float dn = dot(n,gL);
  float d = sst(-0.30, 0.82, dn);
  float limb = 0.6 + 0.4*pow(n.z,0.4);
  return a*d*limb*1.2 + a*0.003;
}


vec3 moonCol(vec3 q, vec3 n){
  float h;
  vec3 nb = bumpN(q,n,2.1,h);
  float mare = sst(0.54,0.64,fbm(q*2.8+vec3(4.0,1.0,2.0),5));
  float fine = fbm(q*14.0+3.0,4);
  vec3 high = mix(vec3(0.50,0.49,0.47), vec3(0.74,0.73,0.70), fine);
  vec3 dark = mix(vec3(0.26,0.26,0.28), vec3(0.38,0.38,0.40), fine);
  vec3 a = mix(high, dark, mare*0.85);
  // bright ejecta rays around a Tycho-like crater near the south pole
  vec3 tc = normalize(vec3(-0.25,-0.72,0.64));
  float ray = pow(max(dot(q,tc),0.0), 60.0);
  float rays = pow(max(dot(q,tc),0.0), 6.0) * sst(0.55,0.8,fbm(q*vec3(9.0,9.0,9.0)+tc*30.0,3));
  a += vec3(0.30)*clamp(ray*1.5 + rays*0.25, 0.0, 0.5);
  a *= 0.80 + 0.9*clamp(h*1.3+0.1,-0.15,0.3);
  a *= 0.9 + 0.2*fbm(q*60.0,2);
  a = toLin(a);
  float d = max(dot(nb,gL),0.0);
  float d0 = max(dot(n,gL),0.0);
  return a*(d*0.78 + 0.22*d0)*1.4 + a*0.003;
}

vec3 sunCol(vec3 q, vec3 n){
  vec3 qa = rotY(q, uTime*0.02);
  float mu = clamp(n.z, 0.0, 1.0);
  float gran = fbm(qa*26.0 + vec3(0.0, uTime*0.10, 0.0), 4);
  float cells = fbm(qa*9.0 + 2.0*gran + vec3(uTime*0.03), 5);
  float plage = fbm(qa*3.0 + vec3(uTime*0.012, 5.0, 1.0), 4);
  vec3 hot  = vec3(1.00,0.93,0.58);
  vec3 mid  = vec3(1.00,0.64,0.18);
  vec3 cool = vec3(0.86,0.30,0.05);
  vec3 a = mix(mid, hot, sst(0.35,0.75,cells));
  a = mix(a, cool, sst(0.55,0.20,gran)*0.45);
  // sunspots with a darker umbra, restricted to active latitudes
  float lat = abs(q.y);
  float act = sst(0.75,0.25,lat)*sst(0.02,0.18,lat);
  float spots = sst(0.70,0.76,fbm(qa*vec3(3.4,3.4,3.4)+vec3(9.0,2.0,4.0),3))*act;
  float umbra = sst(0.78,0.86,fbm(qa*vec3(3.4,3.4,3.4)+vec3(9.0,2.0,4.0),3))*act;
  a = mix(a, vec3(0.38,0.10,0.02), spots*0.85);
  a = mix(a, vec3(0.08,0.02,0.0), umbra*0.9);
  // bright faculae toward the limb
  a += vec3(0.25,0.18,0.06)*sst(0.6,0.8,plage)*(1.0-mu)*1.5;
  // limb darkening (redder and dimmer at the edge)
  float ld = 1.0 - 0.50*(1.0-mu) - 0.08*(1.0-mu)*(1.0-mu);
  a *= ld;
  a = mix(a, a*vec3(1.0,0.72,0.45), pow(1.0-mu, 1.8)*0.5);
  a = toLin(a);
  return a*1.9;
}

vec3 starField(vec2 frag){
  vec2 c = floor(frag*0.5);
  float hh = fract(sin(dot(c, vec2(12.9898,78.233)))*43758.5453);
  float s = step(0.9965,hh)*(hh-0.9965)/0.0035;
  float tw = 0.75 + 0.25*sin(uTime*1.7 + hh*180.0);
  vec3 tint = mix(vec3(0.7,0.8,1.0), vec3(1.0,0.9,0.75), fract(hh*91.7));
  vec3 bg = mix(vec3(0.012,0.035,0.036), vec3(0.003,0.012,0.014), clamp(length(frag/uRes-0.5)*1.6,0.0,1.0));
  return bg + tint*s*s*tw*1.4;
}

void main(){
  vec2 frag = gl_FragCoord.xy;
  float m = min(uRes.x,uRes.y);
  vec2 p = (frag - 0.5*uRes)/(0.5*m);
  float R = uRadius;
  float d = length(p);
  float aa = 2.2/m;
  gL = normalize(uL);

  vec3 fg = vec3(0.0);   // linear colour (straight alpha)
  float fa = 0.0;
  // Slow, low-amplitude breathing keeps the atmospheric edge alive without flashing.
  float atmospherePulse = 1.0 + 0.08*sin(uTime*0.42);

  /* outer atmospheric halo */
  float rho = d/R;
  if(rho > 1.0 && uAtmoI > 0.0){
    vec2 dir = p/max(d,1e-4);
    float lit = clamp(dot(dir, normalize(gL.xy+1e-4))*0.55 + 0.55, 0.0, 1.0);
    if(uType==9){
      // corona: radial streamers that slowly drift, symmetric around the disc
      float ang = atan(dir.y, dir.x);
      float streamer = 0.75 + 0.5*fbm(vec3(cos(ang)*2.2, sin(ang)*2.2, uTime*0.05), 3);
      lit = 1.0;
      float core = exp(-(rho-1.0)*uHaloK*1.2)*uAtmoI*0.55*streamer*atmospherePulse;
      float wide = exp(-(rho-1.0)*uHaloK*0.28)*0.16*streamer;
      fg = toLin(uAtmo);
      fa = clamp(core + wide, 0.0, 1.0);
    } else {
    float g = exp(-(rho-1.0)*uHaloK*1.2)*uAtmoI*0.55*lit*lit*atmospherePulse;
    fg = toLin(uAtmo);
    fa = clamp(g, 0.0, 1.0);
    }
  }

  /* ring geometry (screen-space plane intersection) */
  vec4 ringC = vec4(0.0);
  float ringFront = 0.0;
  if(uRing > 0.5){
    float nz = uRingN.z;
    if(abs(nz) > 0.015){
      float zh = -(uRingN.x*p.x + uRingN.y*p.y)/nz;
      vec3 H = vec3(p, zh);
      float r = length(H)/R;
      ringC = ringSample(r);
      ringFront = (zh > 0.0 || d > R) ? 1.0 : 0.0;
      float b = dot(H,gL);
      float perp2 = dot(H,H) - b*b;
      float shadow = (b < 0.0) ? sst(R*R*1.02, R*R*0.9, perp2) : 0.0;
      float sunSide = (dot(uRingN,gL)*nz > 0.0) ? 1.0 : 0.38;
      ringC.rgb *= (1.0 - 0.93*shadow)*sunSide*1.15 + 0.01;
    }
  }

  /* planet disc */
  float cover = 1.0 - sst(R-aa, R+aa, d);
  if(d < R + aa*1.5){
    vec2 xy = p/R;
    float l2 = dot(xy,xy);
    if(l2 > 1.0) xy /= sqrt(l2);
    float z = sqrt(max(1.0-dot(xy,xy),0.0));
    vec3 n = vec3(xy, z);
    vec3 q = n*uM;

    gShadow = 0.0;
    if(uRing > 0.5){
      float dl2 = dot(uRingN,gL);
      if(abs(dl2) > 0.02){
        vec3 P = n*R;
        float tt = -dot(uRingN,P)/dl2;
        if(tt > 0.0){
          vec3 hit = P + tt*gL;
          gShadow = ringSample(length(hit)/R).a*0.85;
        }
      }
    }

    vec3 pc;
    if(uType==0)      pc = mercuryCol(q,n);
    else if(uType==1) pc = venusCol(q,n);
    else if(uType==2) pc = earthCol(q,n);
    else if(uType==3) pc = marsCol(q,n);
    else if(uType==4) pc = jupiterCol(q,n);
    else if(uType==5) pc = saturnCol(q,n);
    else if(uType==6) pc = uranusCol(q,n);
    else if(uType==8) pc = moonCol(q,n);
    else if(uType==9) pc = sunCol(q,n);
    else              pc = neptuneCol(q,n);
    pc *= (1.0 - gShadow);

    if(uAtmoI > 0.0 && uType != 9){
      float limb = 1.0 - n.z;
      float rim = pow(limb, 2.2);
      float horizon = exp(-pow((limb - 0.035) / 0.045, 2.0));
      float sunSide = sst(-0.30,0.55,dot(n,gL));
      float twil = exp(-pow(dot(n,gL)/0.16, 2.0));
      vec3 sc = toLin(uAtmo);
      pc += sc*rim*uAtmoI*(0.10 + 0.58*sunSide)*0.55*atmospherePulse;
      pc += sc*horizon*uAtmoI*(0.18 + 0.62*sunSide)*0.42*atmospherePulse;
      if(uType==1 || uType==2) pc += vec3(1.0,0.42,0.18)*twil*horizon*uAtmoI*0.18*atmospherePulse;
    }

    fg = mix(fg, pc, cover);
    fa = mix(fa, 1.0, cover);
  }

  /* ring composite */
  float vis = ringC.a * ringFront;
  if(vis > 0.001){
    fg = mix(fg, ringC.rgb, vis);
    fa = mix(fa, 1.0, vis);
  }

  vec3 outc = pow(clamp(fg,0.0,3.0), vec3(1.0/2.2));
  if(uStars > 0.5){
    vec3 bg = starField(frag);
    gl_FragColor = vec4(mix(bg, outc, fa), 1.0);
  } else {
    gl_FragColor = vec4(outc*fa, fa);
  }
}
`;

/* ------------------------------ matrix helpers ----------------------------- */
type Mat3 = number[]; // column-major
const rad = (d: number) => (d * Math.PI) / 180;
const Rx = (a: number): Mat3 => { const c = Math.cos(a), s = Math.sin(a); return [1, 0, 0, 0, c, s, 0, -s, c]; };
const Ry = (a: number): Mat3 => { const c = Math.cos(a), s = Math.sin(a); return [c, 0, -s, 0, 1, 0, s, 0, c]; };
const Rz = (a: number): Mat3 => { const c = Math.cos(a), s = Math.sin(a); return [c, s, 0, -s, c, 0, 0, 0, 1]; };
const mul = (A: Mat3, B: Mat3): Mat3 => {
  const out = new Array(9).fill(0);
  for (let col = 0; col < 3; col++)
    for (let row = 0; row < 3; row++)
      for (let k = 0; k < 3; k++) out[col * 3 + row] += A[k * 3 + row] * B[col * 3 + k];
  return out;
};

/* --------------------------------- renderer -------------------------------- */
class PlanetRenderer {
  canvas: HTMLCanvasElement;
  gl: WebGLRenderingContext;
  prog: WebGLProgram;
  u: Record<string, WebGLUniformLocation | null> = {};

  constructor(canvas: HTMLCanvasElement, preserve = false, antialias = true) {
    this.canvas = canvas;
    const gl = canvas.getContext('webgl', {
      alpha: true,
      premultipliedAlpha: true,
      antialias,
      preserveDrawingBuffer: preserve,
    }) as WebGLRenderingContext | null;
    if (!gl) throw new Error('WebGL unavailable');
    this.gl = gl;

    const compile = (type: number, src: string) => {
      const sh = gl.createShader(type)!;
      gl.shaderSource(sh, src);
      gl.compileShader(sh);
      if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
        const log = gl.getShaderInfoLog(sh);
        gl.deleteShader(sh);
        throw new Error('Shader compile error: ' + log);
      }
      return sh;
    };
    const prog = gl.createProgram()!;
    gl.attachShader(prog, compile(gl.VERTEX_SHADER, VERT));
    gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FRAG));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error('Link error: ' + gl.getProgramInfoLog(prog));
    this.prog = prog;
    gl.useProgram(prog);

    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, 'aPos');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

    ['uRes', 'uTime', 'uType', 'uM', 'uL', 'uRingN', 'uRadius', 'uRing', 'uStars', 'uAtmo', 'uAtmoI', 'uHaloK', 'uQuality'].forEach(
      n => (this.u[n] = gl.getUniformLocation(prog, n)),
    );
  }

  draw(name: string, time: number, spin: number, stars: boolean, quality = 1, dayNightCycle = false) {
    const cfg = PLANET_CONFIG[name] ?? PLANET_CONFIG.Earth;
    const gl = this.gl;
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    const axis = mul(Ry(rad(cfg.yaw)), mul(Rx(rad(cfg.pitch)), Rz(rad(cfg.tilt))));
    const M = mul(axis, Ry(spin));
    const ringN = [axis[3], axis[4], axis[5]]; // image of (0,1,0)
    const sunAngle = dayNightCycle ? time * 0.026 : 0;
    const sunCos = Math.cos(sunAngle);
    const sunSin = Math.sin(sunAngle);
    const L = [-0.78 * sunCos - 0.3 * sunSin, -0.78 * sunSin + 0.3 * sunCos, 0.55];

    gl.uniform2f(this.u.uRes, this.canvas.width, this.canvas.height);
    gl.uniform1f(this.u.uTime, time);
    gl.uniform1i(this.u.uType, cfg.type);
    gl.uniformMatrix3fv(this.u.uM, false, new Float32Array(M));
    gl.uniform3f(this.u.uL, L[0], L[1], L[2]);
    gl.uniform3f(this.u.uRingN, ringN[0], ringN[1], ringN[2]);
    gl.uniform1f(this.u.uRadius, cfg.radius);
    gl.uniform1f(this.u.uRing, cfg.ring);
    gl.uniform1f(this.u.uStars, stars ? 1 : 0);
    gl.uniform3f(this.u.uAtmo, cfg.atmo[0], cfg.atmo[1], cfg.atmo[2]);
    gl.uniform1f(this.u.uAtmoI, cfg.atmoI);
    gl.uniform1f(this.u.uHaloK, cfg.haloK);
    gl.uniform1f(this.u.uQuality, quality);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }

  dispose() {
    const ext = this.gl.getExtension('WEBGL_lose_context');
    ext?.loseContext();
  }
}

/* --------------------------------- component -------------------------------- */
const FALLBACK: Record<string, string> = {
  Mercury: 'radial-gradient(circle at 30% 30%, #c0c0c0, #858590 55%, #2a2a30)',
  Venus: 'radial-gradient(circle at 30% 30%, #ffe3a0, #e2a84a 55%, #5e330f)',
  Earth: 'radial-gradient(circle at 30% 30%, #57cc99, #38a3a5 50%, #0e1b30)',
  Mars: 'radial-gradient(circle at 30% 30%, #f0a070, #b4542b 55%, #3a1408)',
  Jupiter: 'radial-gradient(circle at 30% 30%, #f0dcc0, #b8825a 55%, #3c2214)',
  Saturn: 'radial-gradient(circle at 30% 30%, #f6e6b0, #c8a468 55%, #3e2f16)',
  Uranus: 'radial-gradient(circle at 30% 30%, #d6f6f6, #8fd2d8 55%, #1c4b52)',
  Neptune: 'radial-gradient(circle at 30% 30%, #6aa0ff, #2848c8 55%, #0a1440)',
  Moon: 'radial-gradient(circle at 30% 30%, #e4e2dc, #9a9890 55%, #26262a)',
  Sun: 'radial-gradient(circle at 50% 50%, #fff3b0, #ff9d2a 60%, #c2410c)',
};

interface PlanetCanvasProps {
  name: string;
  className?: string;
  interactive?: boolean;
  showTouchControls?: boolean;
  stars?: boolean;
  /** Rotate the sun around the planet on the shared slow day/night cycle. */
  dayNightCycle?: boolean;
  /** 0 disables auto-rotation, 1 = default speed */
  speed?: number;
}

export const PlanetCanvas: React.FC<PlanetCanvasProps> = ({ name, className = '', interactive = false, showTouchControls = false, stars = true, dayNightCycle = false, speed = 1 }) => {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const nameRef = useRef(name);
  const dayNightCycleRef = useRef(dayNightCycle);
  const redrawRef = useRef<(() => void) | null>(null);
  const rotateByRef = useRef<(direction: number) => void>(() => undefined);
  const [failed, setFailed] = useState(false);
  nameRef.current = name;
  dayNightCycleRef.current = dayNightCycle;

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;

    const isMobile = window.matchMedia?.('(max-width: 768px), (pointer: coarse)').matches ?? false;
    let renderer: PlanetRenderer;
    try {
      renderer = new PlanetRenderer(canvas, false, !isMobile);
    } catch (e) {
      console.warn('[PlanetCanvas] falling back to CSS planet:', e);
      setFailed(true);
      return;
    }

    const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const renderQuality = isMobile ? 0.65 : 1;
    const frameInterval = isMobile ? 1000 / 30 : 1000 / 60;
    let raf = 0;
    let lastRender = Number.NEGATIVE_INFINITY;
    let visible = true;
    let spin = 0.9;
    let vel = 0;
    let dragging = false;
    let lastX = 0;
    let last = performance.now();
    const t0 = last;
    rotateByRef.current = direction => {
      spin += direction * 0.55;
      vel = 0;
      renderer.draw(nameRef.current, (performance.now() - t0) / 1000, spin, stars, renderQuality, dayNightCycleRef.current);
    };

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, isMobile ? 1.25 : 2);
      const w = Math.max(32, Math.round(wrap.clientWidth * dpr));
      const h = Math.max(32, Math.round(wrap.clientHeight * dpr));
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
      }
    };

    const frame = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.1);
      last = now;
      const cfg = PLANET_CONFIG[nameRef.current] ?? PLANET_CONFIG.Earth;
      if (!dragging) {
        const auto = reduceMotion ? 0 : cfg.spin * speed;
        spin += (auto + vel) * dt;
        vel *= Math.pow(0.04, dt);
      }
      if (now - lastRender >= frameInterval) {
        resize();
        renderer.draw(nameRef.current, (now - t0) / 1000, spin, stars, renderQuality, dayNightCycleRef.current);
        lastRender = now;
      }
      if (visible && !document.hidden && !reduceMotion) raf = requestAnimationFrame(frame);
      else raf = 0;
    };
    const kick = () => {
      if (!raf) {
        last = performance.now();
        lastRender = Number.NEGATIVE_INFINITY;
        raf = requestAnimationFrame(frame);
      }
    };

    const redraw = () => {
      resize();
      renderer.draw(nameRef.current, (performance.now() - t0) / 1000, spin, stars, renderQuality, dayNightCycleRef.current);
    };
    redrawRef.current = redraw;
    const ro = new ResizeObserver(redraw);
    ro.observe(wrap);
    const io = new IntersectionObserver(entries => {
      visible = entries[0]?.isIntersecting ?? true;
      if (visible) kick();
    });
    io.observe(wrap);
    const onVis = () => !document.hidden && kick();
    document.addEventListener('visibilitychange', onVis);

    // redraw once when the planet changes while paused (reduced motion)
    kick();

    let down: ((e: PointerEvent) => void) | null = null;
    let move: ((e: PointerEvent) => void) | null = null;
    let up: ((e: PointerEvent) => void) | null = null;
    if (interactive) {
      down = e => {
        dragging = true;
        lastX = e.clientX;
        vel = 0;
        canvas.setPointerCapture(e.pointerId);
        canvas.style.cursor = 'grabbing';
      };
      move = e => {
        if (!dragging) return;
        const dx = e.clientX - lastX;
        lastX = e.clientX;
        const delta = (dx / Math.max(canvas.clientWidth, 1)) * 5.0;
        spin += delta;
        vel = delta * 40;
        if (reduceMotion) renderer.draw(nameRef.current, (performance.now() - t0) / 1000, spin, stars, renderQuality, dayNightCycleRef.current);
      };
      up = e => {
        dragging = false;
        canvas.style.cursor = 'grab';
        try { canvas.releasePointerCapture(e.pointerId); } catch { /* noop */ }
        kick();
      };
      canvas.style.cursor = 'grab';
      canvas.style.touchAction = 'pan-y';
      canvas.addEventListener('pointerdown', down);
      canvas.addEventListener('pointermove', move);
      canvas.addEventListener('pointerup', up);
      canvas.addEventListener('pointercancel', up);
    }

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      document.removeEventListener('visibilitychange', onVis);
      if (down) canvas.removeEventListener('pointerdown', down);
      if (move) canvas.removeEventListener('pointermove', move);
      if (up) {
        canvas.removeEventListener('pointerup', up);
        canvas.removeEventListener('pointercancel', up);
      }
      redrawRef.current = null;
      rotateByRef.current = () => undefined;
      renderer.dispose();
    };
  }, [interactive, stars, speed]);

  useEffect(() => {
    redrawRef.current?.();
  }, [name, dayNightCycle]);

  if (failed) {
    return (
      <div ref={wrapRef} className={`${className} flex items-center justify-center`}>
        <div className="w-3/5 aspect-square rounded-full" style={{ background: FALLBACK[name] ?? FALLBACK.Earth }} />
      </div>
    );
  }

  return (
    <div ref={wrapRef} className={`${className} ${interactive ? 'planet-interactive' : ''}`}>
      <canvas ref={canvasRef} className="block w-full h-full" aria-label={`${name} – rendered planet`} role="img" />
      {interactive && showTouchControls && (
        <div className="planet-touch-controls" role="group" aria-label={`${name} rotation controls`}>
          <button type="button" aria-label="Rotate planet left" onClick={() => rotateByRef.current(-1)}>
            <ChevronLeft size={20} aria-hidden="true" />
          </button>
          <span>SWIPE TO ROTATE</span>
          <button type="button" aria-label="Rotate planet right" onClick={() => rotateByRef.current(1)}>
            <ChevronRight size={20} aria-hidden="true" />
          </button>
        </div>
      )}
    </div>
  );
};

/* ------------------------------ static thumbnails ------------------------------ */
let thumbRenderer: PlanetRenderer | null = null;
let thumbBroken = false;
const thumbCache = new Map<string, string>();

function renderThumb(name: string, px: number): string | null {
  if (thumbBroken) return null;
  const key = name + ':' + px;
  const hit = thumbCache.get(key);
  if (hit) return hit;
  try {
    if (!thumbRenderer) {
      const c = document.createElement('canvas');
      c.width = px;
      c.height = px;
      thumbRenderer = new PlanetRenderer(c, true);
    }
    const c = thumbRenderer.canvas;
    c.width = px;
    c.height = px;
    thumbRenderer.draw(name, 0, 1.1, false);
    const url = c.toDataURL('image/png');
    thumbCache.set(key, url);
    return url;
  } catch (e) {
    thumbBroken = true;
    return null;
  }
}

export const PlanetThumb: React.FC<{ name: string; size?: number; className?: string }> = ({ name, size = 40, className = '' }) => {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    const px = Math.round(size * 3);
    const id = window.setTimeout(() => setUrl(renderThumb(name, px)), 0);
    return () => window.clearTimeout(id);
  }, [name, size]);
  return (
    <div className={`shrink-0 ${className}`} style={{ width: size, height: size }}>
      {url ? (
        <img src={url} alt={name} width={size} height={size} draggable={false} className="w-full h-full" />
      ) : (
        <div className="w-full h-full rounded-full" style={{ background: FALLBACK[name] ?? FALLBACK.Earth, transform: 'scale(0.8)' }} />
      )}
    </div>
  );
};
