import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft, Satellite as SatIcon, Plus, Minus, RotateCcw, Volume2, VolumeX, Star, Crosshair,
  Activity, Pause, MapPin, Orbit as OrbitIcon, Clock, Globe,
} from 'lucide-react';
import { geoPath, geoOrthographic, geoCircle, geoGraticule10 } from 'd3-geo';
import { feature } from 'topojson-client';
import world from 'world-atlas/countries-110m.json';
import {
  eciToEcf, eciToGeodetic, ecfToLookAngles, gstime, degreesLat, degreesLong, propagate, type OMMJsonObject,
} from 'satellite.js';
import { subsolarPoint } from '../utils/astro';
import { playUiClick } from '../utils/audio';
import { PlanetCanvas } from './PlanetCanvas';
import {
  CLASS_META, DEFAULT_CLASSES, GROUPS, ORBIT_CLASSES, makeSat, simulatedElements,
  type GroupId, type OrbitClass, type Sat,
} from './nasa/orbitalRadarData';

/* eslint-disable @typescript-eslint/no-explicit-any */
const topo: any = world;
const LAND: any = feature(topo, topo.objects.land);
const GRATICULE: any = geoGraticule10();

const D2R = Math.PI / 180;
const R2D = 180 / Math.PI;
const EARTH_R = 6371;
const KM_TO_MI = 0.621371;
const MAX_ZOOM = 5;
const MIN_ZOOM = 0.6;
const IDLE_MS = 120_000;

type Status = 'pending' | 'live' | 'sim';
type Body = 'Earth' | 'Moon' | 'Mars' | 'Sun';
type FeedPayload = { fetchedAt: string; elements: OMMJsonObject[] };
type Pass = { aos: number; los: number; maxEl: number; maxT: number; alreadyUp: boolean };

/* -------------------------------- data feed -------------------------------- */
const CACHE_TTL = 2 * 60 * 60 * 1000;
const cacheKey = (g: GroupId) => `cosmora:radar:gp:${g}:v1`;

async function loadGroup(group: GroupId): Promise<FeedPayload | null> {
  try {
    const raw = localStorage.getItem(cacheKey(group));
    if (raw) {
      const parsed = JSON.parse(raw) as { t: number; data: FeedPayload };
      if (Date.now() - parsed.t < CACHE_TTL && parsed.data.elements?.length) return parsed.data;
    }
  } catch { /* storage unavailable */ }
  const ctl = new AbortController();
  const timer = window.setTimeout(() => ctl.abort(), 12_000);
  try {
    const res = await fetch(`/api/orbits?group=${group}`, { signal: ctl.signal, headers: { Accept: 'application/json' } });
    if (!res.ok) return null;
    const json = await res.json();
    if (!Array.isArray(json?.elements) || !json.elements.length) return null;
    const data: FeedPayload = { fetchedAt: json.fetchedAt, elements: json.elements };
    try { localStorage.setItem(cacheKey(group), JSON.stringify({ t: Date.now(), data })); } catch { /* quota */ }
    return data;
  } catch {
    return null;
  } finally {
    window.clearTimeout(timer);
  }
}

/* ------------------------------ space weather ------------------------------ */
interface Weather { kp: number; at: string; level: 1 | 2 | 3 | 4 | 5; label: string; g: string }
function weatherFromKp(kp: number, at: string): Weather {
  // DEFCON-style readout derived from NOAA's planetary Kp / G-scale.
  const g = kp >= 9 ? 'G5' : kp >= 8 ? 'G4' : kp >= 7 ? 'G3' : kp >= 6 ? 'G2' : kp >= 5 ? 'G1' : 'G0';
  const level = kp >= 8 ? 1 : kp >= 7 ? 2 : kp >= 6 ? 3 : kp >= 5 ? 4 : 5;
  const label = ['', 'Extreme storm', 'Severe storm', 'Strong storm', 'Minor storm', 'All quiet'][level];
  return { kp, at, level, label, g };
}
const LEVEL_COLOR: Record<number, string> = { 1: '#ff4d4d', 2: '#ff7a3c', 3: '#ffb02e', 4: '#ffe066', 5: '#66d17a' };

/* --------------------------------- helpers --------------------------------- */
const fmtInt = (n: number) => Math.round(n).toLocaleString('en-US');
function fmtClock(ms: number, utc: boolean) {
  const d = new Date(ms);
  return utc
    ? d.toISOString().slice(11, 19)
    : d.toLocaleTimeString([], { hour12: false });
}
function propagateSat(s: Sat, ms: number) {
  const d = new Date(ms);
  const st = propagate(s.satrec, d);
  if (!st?.position || !Number.isFinite(st.position.x)) { s.ok = false; return; }
  const gm = gstime(d);
  const ecf = eciToEcf(st.position, gm);
  const gd = eciToGeodetic(st.position, gm);
  const v = st.velocity as unknown as { x: number; y: number; z: number };
  s.x = ecf.x; s.y = ecf.y; s.z = ecf.z;
  s.lat = degreesLat(gd.latitude); s.lon = degreesLong(gd.longitude); s.alt = gd.height;
  s.speed = v ? Math.hypot(v.x, v.y, v.z) : 0;
  s.ok = true;
}
function orbitRing(s: Sat, ms: number, n = 144): number[] {
  const out: number[] = [];
  const gm = gstime(new Date(ms));
  for (let i = 0; i <= n; i++) {
    const st = propagate(s.satrec, new Date(ms + (i / n) * s.periodMin * 60_000));
    if (!st?.position || !Number.isFinite(st.position.x)) continue;
    const e = eciToEcf(st.position, gm);
    out.push(e.x, e.y, e.z);
  }
  return out;
}
function nextPass(s: Sat, lat: number, lon: number, fromMs: number): Pass | null {
  const obs = { latitude: lat * D2R, longitude: lon * D2R, height: 0 };
  const step = 30_000;
  let inPass = false, aos = 0, maxEl = 0, maxT = 0, alreadyUp = false;
  for (let t = fromMs; t < fromMs + 24 * 3600_000; t += step) {
    const d = new Date(t);
    const st = propagate(s.satrec, d);
    if (!st?.position || !Number.isFinite(st.position.x)) continue;
    const el = ecfToLookAngles(obs, eciToEcf(st.position, gstime(d))).elevation * R2D;
    if (el > 10) {
      if (!inPass) { inPass = true; aos = t; maxEl = el; maxT = t; alreadyUp = t === fromMs; }
      else if (el > maxEl) { maxEl = el; maxT = t; }
    } else if (inPass) {
      return { aos, los: t, maxEl, maxT, alreadyUp };
    }
  }
  return inPass ? { aos, los: fromMs + 24 * 3600_000, maxEl, maxT, alreadyUp } : null;
}

/* --------------------------- planetary body facts --------------------------- */
const BODY_FACTS: Record<Exclude<Body, 'Earth'>, { tagline: string; rows: [string, string][]; note: string }> = {
  Moon: {
    tagline: 'Earth’s only natural satellite',
    rows: [['Diameter', '3,474 km'], ['Mean distance', '384,400 km'], ['Surface gravity', '1.62 m/s² (0.17 g)'], ['Orbital period', '27.3 days'], ['Day length (synodic)', '29.5 Earth days'], ['Surface temperature', '−173 °C to 127 °C']],
    note: 'Tidally locked: we always see the same near side. The dark patches are ancient basaltic maria; the bright rays come from young impact craters.',
  },
  Mars: {
    tagline: 'The red planet',
    rows: [['Diameter', '6,779 km'], ['Distance from Sun', '1.52 AU'], ['Surface gravity', '3.71 m/s² (0.38 g)'], ['Year', '687 Earth days'], ['Day length', '24 h 37 min'], ['Moons', 'Phobos & Deimos']],
    note: 'Thin CO₂ atmosphere, polar ice caps and the largest volcano in the Solar System, Olympus Mons.',
  },
  Sun: {
    tagline: 'Our G-type main-sequence star',
    rows: [['Diameter', '1,391,000 km'], ['Surface temperature', '≈ 5,500 °C'], ['Core temperature', '≈ 15 million °C'], ['Mass', '≈ 333,000 Earths'], ['Age', '≈ 4.6 billion years'], ['Rotation', '≈ 25 days at equator']],
    note: 'Granulation cells, dark sunspots and bright limb faculae are drawn procedurally. Space weather from the Sun drives the Kp index shown on the Earth radar.',
  },
};

/* ================================== component ================================ */
export const OrbitalRadar: React.FC<{ onBackToDeck: () => void }> = ({ onBackToDeck }) => {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [body, setBody] = useState<Body>('Earth');
  const [groupsOn, setGroupsOn] = useState<Record<GroupId, boolean>>(() => Object.fromEntries(GROUPS.map(g => [g.id, g.defaultOn])) as Record<GroupId, boolean>);
  const [classesOn, setClassesOn] = useState<Record<OrbitClass, boolean>>({ ...DEFAULT_CLASSES });
  const [status, setStatus] = useState<Record<GroupId, Status>>(() => Object.fromEntries(GROUPS.map(g => [g.id, 'pending'])) as Record<GroupId, Status>);
  const [progress, setProgress] = useState(0);
  const [version, setVersion] = useState(0);
  const [tracks, setTracks] = useState(true);
  const [follow, setFollow] = useState(true);
  const [voice, setVoice] = useState(false);
  const [miles, setMiles] = useState(false);
  const [utc, setUtc] = useState(true);
  const [warp, setWarp] = useState(1);
  const [paused, setPaused] = useState(false);
  const [selectedUid, setSelectedUid] = useState<string | null>(null);
  const [hoverName, setHoverName] = useState('');
  const [tick, setTick] = useState(0);
  const [weather, setWeather] = useState<Weather | null>(null);
  const [weatherErr, setWeatherErr] = useState(false);
  const [pass, setPass] = useState<{ state: 'idle' | 'locating' | 'calc' | 'denied' | 'none' | 'ok'; data?: Pass }>({ state: 'idle' });
  const [watch, setWatch] = useState<{ norad: number; name: string }[]>(() => {
    try { return JSON.parse(localStorage.getItem('cosmora:radar:watch:v1') || '[]'); } catch { return []; }
  });

  /* mutable render state (read by the animation loop without re-subscribing) */
  const satsRef = useRef<Map<GroupId, Sat[]>>(new Map());
  const live = useRef({ groupsOn, classesOn, tracks, follow, selectedUid, watch, paused, warp, body });
  live.current = { groupsOn, classesOn, tracks, follow, selectedUid, watch, paused, warp, body };
  const view = useRef({ lon: 15, lat: 22, zoom: 1, dragging: false, moved: 0, lx: 0, ly: 0 });
  const clock = useRef({ real0: Date.now(), sim0: Date.now() });
  const lastInteract = useRef(Date.now());
  const ringRef = useRef<{ uid: string; pts: number[]; at: number } | null>(null);
  const kickRef = useRef<() => void>(() => undefined);
  const reduceMotion = useMemo(() => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false, []);
  const stars = useMemo(() => {
    let a = 12345;
    const r = () => { a = (a * 1664525 + 1013904223) >>> 0; return a / 4294967296; };
    return Array.from({ length: 160 }, () => [r(), r(), 0.4 + r() * 1.1, 0.25 + r() * 0.6] as const);
  }, []);

  const simNow = useCallback(() => clock.current.sim0 + (Date.now() - clock.current.real0) * live.current.warp, []);
  const touch = useCallback(() => {
    lastInteract.current = Date.now();
    if (live.current.paused) { setPaused(false); }
  }, []);

  /* ---- load every constellation: live CelesTrak first, offline model as fallback ---- */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      let done = 0;
      for (const g of GROUPS) {
        const feed = await loadGroup(g.id);
        if (cancelled) return;
        const sim = !feed;
        const elements = feed ? feed.elements : simulatedElements(g.id, Date.now());
        const sats = elements.map((e, i) => makeSat(e, g.id, sim, i)).filter((s): s is Sat => !!s);
        const now = simNow();
        sats.forEach(s => propagateSat(s, now));
        satsRef.current.set(g.id, sats);
        done += 1;
        setStatus(prev => ({ ...prev, [g.id]: sim ? 'sim' : 'live' }));
        setProgress(Math.round((done / GROUPS.length) * 100));
        setVersion(v => v + 1);
        kickRef.current();
      }
    })();
    return () => { cancelled = true; };
  }, [simNow]);

  /* ---- NOAA SWPC planetary Kp ---- */
  useEffect(() => {
    let cancelled = false;
    const pull = async () => {
      try {
        const res = await fetch('https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json');
        if (!res.ok) throw new Error(String(res.status));
        const rows = (await res.json()) as string[][];
        const last = rows[rows.length - 1];
        const kp = parseFloat(last[1]);
        if (!Number.isFinite(kp)) throw new Error('bad kp');
        if (!cancelled) { setWeather(weatherFromKp(kp, last[0])); setWeatherErr(false); }
      } catch {
        if (!cancelled) setWeatherErr(true);
      }
    };
    void pull();
    const id = window.setInterval(pull, 5 * 60_000);
    return () => { cancelled = true; window.clearInterval(id); };
  }, []);

  /* ---- 1 Hz UI clock + inactivity pause ---- */
  useEffect(() => {
    const id = window.setInterval(() => {
      if (!live.current.paused) {
        setTick(t => t + 1);
        if (Date.now() - lastInteract.current > IDLE_MS) setPaused(true);
      }
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => { if (!paused) kickRef.current(); }, [paused]);

  /* ---- selection helpers ---- */
  const allSats = useCallback(() => Array.from(satsRef.current.values()).flat(), []);
  const selected = useMemo(() => (selectedUid ? allSats().find(s => s.uid === selectedUid) ?? null : null), [selectedUid, allSats, version]);
  const selectByNorad = (norad: number) => {
    const s = allSats().find(x => x.norad === norad);
    if (s) { setBody('Earth'); setSelectedUid(s.uid); setFollow(true); touch(); }
  };

  useEffect(() => {
    ringRef.current = null;
    setPass({ state: 'idle' });
    if (voice && selected && 'speechSynthesis' in window) {
      const u = new SpeechSynthesisUtterance(
        `${selected.name.replace(/\(SIM\)/, 'simulated')}. ${CLASS_META[selected.cls].label} satellite, ${fmtInt(selected.alt)} kilometers up, ` +
        `moving at ${selected.speed.toFixed(1)} kilometers per second, completing an orbit every ${fmtInt(selected.periodMin)} minutes.`,
      );
      u.rate = 1.05; u.pitch = 0.92;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedUid]);
  useEffect(() => { if (!voice && 'speechSynthesis' in window) window.speechSynthesis.cancel(); }, [voice]);
  useEffect(() => () => { if ('speechSynthesis' in window) window.speechSynthesis.cancel(); }, []);

  const toggleWatch = (s: Sat) => {
    setWatch(prev => {
      const next = prev.some(w => w.norad === s.norad) ? prev.filter(w => w.norad !== s.norad) : [...prev, { norad: s.norad, name: s.name }];
      try { localStorage.setItem('cosmora:radar:watch:v1', JSON.stringify(next)); } catch { /* ignore */ }
      return next;
    });
  };

  const predictPass = () => {
    if (!selected) return;
    if (selected.cls === 'GEO') { setPass({ state: 'none' }); return; }
    if (!navigator.geolocation) { setPass({ state: 'denied' }); return; }
    setPass({ state: 'locating' });
    navigator.geolocation.getCurrentPosition(
      pos => {
        setPass({ state: 'calc' });
        window.setTimeout(() => {
          const p = nextPass(selected, pos.coords.latitude, pos.coords.longitude, simNow());
          setPass(p ? { state: 'ok', data: p } : { state: 'none' });
        }, 30);
      },
      () => setPass({ state: 'denied' }),
      { timeout: 10_000, maximumAge: 600_000 },
    );
  };

  /* ---- render + propagation loop (Earth view only) ---- */
  useEffect(() => {
    if (body !== 'Earth') return;
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const proj = geoOrthographic().clipAngle(90).precision(0.6);
    const path = geoPath(proj, ctx as any);
    let w = 0, h = 0, dpr = 1;
    let raf = 0;
    let lastFrame = performance.now();
    let lastProp = 0;
    const hitX: number[] = [], hitY: number[] = [];
    const hitS: Sat[] = [];
    let hoverX = -1, hoverY = -1, lastHover = '';

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = wrap.clientWidth; h = wrap.clientHeight;
      canvas.width = Math.max(32, Math.round(w * dpr));
      canvas.height = Math.max(32, Math.round(h * dpr));
      canvas.style.width = `${w}px`; canvas.style.height = `${h}px`;
    };
    resize();
    const ro = new ResizeObserver(() => { resize(); kick(); });
    ro.observe(wrap);

    const visibleSats = () => {
      const L = live.current;
      const out: Sat[] = [];
      for (const [gid, list] of satsRef.current) {
        if (!L.groupsOn[gid]) continue;
        for (const s of list) if (s.ok && L.classesOn[s.cls]) out.push(s);
      }
      return out;
    };

    const frame = (now: number) => {
      raf = 0;
      const L = live.current;
      if (L.paused || document.hidden) return;
      const dt = Math.min((now - lastFrame) / 1000, 0.1);
      lastFrame = now;
      const v = view.current;
      const simMs = simNow();

      /* propagate at ~1.5 Hz real-time (faster while time-warped) */
      const propEvery = L.warp > 1 ? 250 : 1500;
      if (now - lastProp > propEvery) {
        lastProp = now;
        for (const [gid, list] of satsRef.current) if (L.groupsOn[gid]) for (const s of list) propagateSat(s, simMs);
      }
      const sel = L.selectedUid ? visibleSats().find(s => s.uid === L.selectedUid) ?? null : null;
      if (L.tracks && sel) {
        const r = ringRef.current;
        if (!r || r.uid !== sel.uid || Math.abs(simMs - r.at) > 4000 * Math.max(1, L.warp)) {
          ringRef.current = { uid: sel.uid, pts: orbitRing(sel, simMs), at: simMs };
        }
      }

      /* camera */
      if (!v.dragging) {
        if (L.follow && sel) {
          // Look at the satellite from slightly "above" its orbit plane so the track reads as an ellipse, not an edge-on line.
          let tLon = sel.lon, tLat = Math.max(-70, Math.min(70, sel.lat));
          const rg = ringRef.current;
          if (rg && rg.uid === sel.uid && rg.pts.length > 12) {
            const q = Math.floor(rg.pts.length / 12) * 3; // ≈ quarter orbit ahead
            const [ax, ay, az] = [rg.pts[0], rg.pts[1], rg.pts[2]];
            const [bx, by, bz] = [rg.pts[q], rg.pts[q + 1], rg.pts[q + 2]];
            let nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
            const nl = Math.hypot(nx, ny, nz) || 1;
            const rl = Math.hypot(ax, ay, az) || 1;
            if (nz < 0) { nx = -nx; ny = -ny; nz = -nz; }
            const cx2 = (ax / rl) * 0.78 + (nx / nl) * 0.62, cy2 = (ay / rl) * 0.78 + (ny / nl) * 0.62, cz2 = (az / rl) * 0.78 + (nz / nl) * 0.62;
            tLon = Math.atan2(cy2, cx2) * R2D;
            tLat = Math.max(-70, Math.min(70, Math.asin(cz2 / Math.hypot(cx2, cy2, cz2)) * R2D));
          }
          const dl = ((tLon - v.lon + 540) % 360) - 180;
          v.lon += dl * Math.min(1, dt * 2.2);
          v.lat += (tLat - v.lat) * Math.min(1, dt * 2.2);
        } else if (!reduceMotion && !sel) {
          v.lon += 3 * dt;
        }
      }
      v.lon = ((v.lon + 540) % 360) - 180;

      /* draw */
      const k0 = Math.min(w, h) * 0.5 * 0.76;
      const rpx = k0 * v.zoom;
      const k = rpx / EARTH_R;
      const cx = w / 2, cy = h / 2;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);

      for (const [sx, sy, sr, sa] of stars) {
        ctx.fillStyle = `rgba(200,225,255,${sa})`;
        ctx.fillRect(sx * w, sy * h, sr, sr);
      }

      // atmosphere glow
      const glow = ctx.createRadialGradient(cx, cy, rpx * 0.97, cx, cy, rpx * 1.28);
      glow.addColorStop(0, 'rgba(90,190,255,0.55)');
      glow.addColorStop(0.35, 'rgba(60,140,255,0.18)');
      glow.addColorStop(1, 'rgba(40,100,255,0)');
      ctx.fillStyle = glow;
      ctx.beginPath(); ctx.arc(cx, cy, rpx * 1.28, 0, Math.PI * 2); ctx.fill();

      proj.translate([cx, cy]).scale(rpx).rotate([-v.lon, -v.lat, 0]);
      const sun = subsolarPoint(new Date(simMs));

      // ocean
      const sunE = Math.cos(sun.lat * D2R) * Math.sin((sun.lon - v.lon) * D2R);
      const ocean = ctx.createRadialGradient(cx + sunE * rpx * 0.45, cy - Math.sin(sun.lat * D2R) * rpx * 0.3, rpx * 0.1, cx, cy, rpx);
      ocean.addColorStop(0, '#1c5d92');
      ocean.addColorStop(0.6, '#0d3558');
      ocean.addColorStop(1, '#071a31');
      ctx.fillStyle = ocean;
      ctx.beginPath(); path({ type: 'Sphere' } as any); ctx.fill();

      ctx.strokeStyle = 'rgba(114,209,214,0.10)'; ctx.lineWidth = 0.6;
      ctx.beginPath(); path(GRATICULE); ctx.stroke();
      ctx.fillStyle = '#1d5a47'; ctx.strokeStyle = 'rgba(160,240,200,0.45)'; ctx.lineWidth = 0.7;
      ctx.beginPath(); path(LAND); ctx.fill(); ctx.stroke();

      // night side with soft twilight
      const anti: [number, number] = [sun.lon + 180, -sun.lat];
      ctx.fillStyle = 'rgba(2,6,20,0.17)';
      for (const r of [90, 93.5, 97, 100.5, 104]) {
        ctx.beginPath(); path(geoCircle().center(anti).radius(r)()); ctx.fill();
      }
      // limb
      const limb = ctx.createRadialGradient(cx, cy, rpx * 0.86, cx, cy, rpx);
      limb.addColorStop(0, 'rgba(90,190,255,0)');
      limb.addColorStop(1, 'rgba(110,200,255,0.38)');
      ctx.fillStyle = limb;
      ctx.beginPath(); ctx.arc(cx, cy, rpx, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(140,220,255,0.55)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(cx, cy, rpx, 0, Math.PI * 2); ctx.stroke();

      /* view transform for km-space points */
      const cl = Math.cos(v.lon * D2R), sl = Math.sin(v.lon * D2R);
      const cp = Math.cos(v.lat * D2R), sp = Math.sin(v.lat * D2R);
      const R2 = EARTH_R * EARTH_R;
      const project = (x: number, y: number, z: number) => {
        const x1 = x * cl + y * sl, y1 = -x * sl + y * cl;
        const D = x1 * cp + z * sp, Z = -x1 * sp + z * cp;
        return { px: cx + y1 * k, py: cy - Z * k, front: D >= 0 || y1 * y1 + Z * Z > R2 ? (D >= 0 ? 1 : 0.35) : 0 };
      };

      // orbit track of the selected satellite
      const ring = ringRef.current;
      if (L.tracks && sel && ring && ring.uid === sel.uid && ring.pts.length > 6) {
        const col = CLASS_META[sel.cls].color;
        ctx.lineWidth = 1.4;
        let prev = project(ring.pts[0], ring.pts[1], ring.pts[2]);
        for (let i = 3; i < ring.pts.length; i += 3) {
          const cur = project(ring.pts[i], ring.pts[i + 1], ring.pts[i + 2]);
          const a = Math.min(prev.front, cur.front);
          if (a > 0) {
            ctx.globalAlpha = a === 1 ? 0.95 : 0.35;
            ctx.strokeStyle = col;
            ctx.beginPath(); ctx.moveTo(prev.px, prev.py); ctx.lineTo(cur.px, cur.py); ctx.stroke();
          }
          prev = cur;
        }
        ctx.globalAlpha = 1;
      }

      // satellites, bucketed by class for cheap fillStyle changes
      hitS.length = 0; hitX.length = 0; hitY.length = 0;
      const size = Math.max(1.8, 1.4 + v.zoom * 0.7);
      const watched = new Set(L.watch.map(x => x.norad));
      for (const cls of ORBIT_CLASSES) {
        if (!L.classesOn[cls]) continue;
        const col = CLASS_META[cls].color;
        for (const [gid, list] of satsRef.current) {
          if (!L.groupsOn[gid]) continue;
          const debris = gid === 'DEBRIS';
          ctx.fillStyle = debris ? '#ff8a5c' : col;
          const sz = debris ? size * 0.7 : gid === 'STATIONS' ? size * 2.2 : size;
          for (const s of list) {
            if (!s.ok || s.cls !== cls) continue;
            const p = project(s.x, s.y, s.z);
            if (p.front === 0) continue;
            ctx.globalAlpha = p.front === 1 ? (debris ? 0.75 : 1) : 0.4;
            ctx.fillRect(p.px - sz / 2, p.py - sz / 2, sz, sz);
            hitS.push(s); hitX.push(p.px); hitY.push(p.py);
          }
        }
      }
      ctx.globalAlpha = 1;

      // watchlist halos + selection reticle
      for (let i = 0; i < hitS.length; i++) {
        const s = hitS[i];
        if (watched.has(s.norad) && s.uid !== L.selectedUid) {
          ctx.strokeStyle = '#ffd34d'; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.arc(hitX[i], hitY[i], 5, 0, Math.PI * 2); ctx.stroke();
        }
      }
      if (sel) {
        const p = project(sel.x, sel.y, sel.z);
        if (p.front > 0) {
          const pulse = 8 + 3 * Math.sin(now / 260);
          ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.6;
          ctx.beginPath(); ctx.arc(p.px, p.py, pulse, 0, Math.PI * 2); ctx.stroke();
          ctx.font = '600 11px ui-monospace, SFMono-Regular, Menlo, monospace';
          const label = sel.name.replace(' (SIM)', '');
          const tw = ctx.measureText(label).width;
          const lx = Math.min(p.px + 14, w - tw - 8);
          ctx.fillStyle = 'rgba(4,16,18,0.8)'; ctx.fillRect(lx - 4, p.py - 22, tw + 8, 16);
          ctx.fillStyle = '#fff'; ctx.fillText(label, lx, p.py - 10);
        }
      }

      // hover test
      if (hoverX >= 0 && !v.dragging) {
        let best = -1, bd = 100;
        for (let i = 0; i < hitS.length; i++) {
          const d = (hitX[i] - hoverX) ** 2 + (hitY[i] - hoverY) ** 2;
          if (d < bd) { bd = d; best = i; }
        }
        const name = best >= 0 ? hitS[best].name.replace(' (SIM)', '') : '';
        if (name !== lastHover) { lastHover = name; setHoverName(name); canvas.style.cursor = name ? 'pointer' : 'grab'; }
      }

      raf = requestAnimationFrame(frame);
    };
    function kick() { if (!raf && !live.current.paused) { lastFrame = performance.now(); raf = requestAnimationFrame(frame); } }
    kickRef.current = kick;
    kick();

    /* pointer interaction */
    const pick = (x: number, y: number) => {
      let best = -1, bd = 14 * 14;
      for (let i = 0; i < hitS.length; i++) {
        const d = (hitX[i] - x) ** 2 + (hitY[i] - y) ** 2;
        if (d < bd) { bd = d; best = i; }
      }
      return best >= 0 ? hitS[best] : null;
    };
    const rect = () => canvas.getBoundingClientRect();
    const down = (e: PointerEvent) => {
      const v = view.current;
      v.dragging = true; v.moved = 0; v.lx = e.clientX; v.ly = e.clientY;
      canvas.setPointerCapture(e.pointerId); canvas.style.cursor = 'grabbing';
      touch();
    };
    const move = (e: PointerEvent) => {
      const v = view.current;
      const r = rect();
      hoverX = e.clientX - r.left; hoverY = e.clientY - r.top;
      if (!v.dragging) return;
      const dx = e.clientX - v.lx, dy = e.clientY - v.ly;
      v.lx = e.clientX; v.ly = e.clientY; v.moved += Math.abs(dx) + Math.abs(dy);
      const sens = 0.32 / v.zoom;
      v.lon -= dx * sens;
      v.lat = Math.max(-85, Math.min(85, v.lat + dy * sens));
      if (v.moved > 4 && live.current.follow) setFollow(false);
      touch();
    };
    const up = (e: PointerEvent) => {
      const v = view.current;
      const wasClick = v.dragging && v.moved < 5;
      v.dragging = false; canvas.style.cursor = 'grab';
      try { canvas.releasePointerCapture(e.pointerId); } catch { /* noop */ }
      if (wasClick) {
        const r = rect();
        const s = pick(e.clientX - r.left, e.clientY - r.top);
        if (s) { playUiClick(); setSelectedUid(s.uid); setFollow(true); } else setSelectedUid(null);
      }
    };
    const leave = () => { hoverX = -1; hoverY = -1; lastHover = ''; setHoverName(''); };
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      const v = view.current;
      v.zoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, v.zoom * (e.deltaY < 0 ? 1.12 : 1 / 1.12)));
      touch();
    };
    canvas.style.cursor = 'grab'; canvas.style.touchAction = 'none';
    canvas.addEventListener('pointerdown', down);
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerup', up);
    canvas.addEventListener('pointercancel', up);
    canvas.addEventListener('pointerleave', leave);
    canvas.addEventListener('wheel', wheel, { passive: false });
    const onVis = () => { if (!document.hidden) kick(); };
    document.addEventListener('visibilitychange', onVis);

    return () => {
      cancelAnimationFrame(raf); raf = 0;
      ro.disconnect();
      canvas.removeEventListener('pointerdown', down);
      canvas.removeEventListener('pointermove', move);
      canvas.removeEventListener('pointerup', up);
      canvas.removeEventListener('pointercancel', up);
      canvas.removeEventListener('pointerleave', leave);
      canvas.removeEventListener('wheel', wheel);
      document.removeEventListener('visibilitychange', onVis);
      kickRef.current = () => undefined;
    };
  }, [body, simNow, stars, reduceMotion, touch]);

  /* ---- derived UI data ---- */
  const counts = useMemo(() => {
    const byClass: Record<OrbitClass, number> = { LEO: 0, MEO: 0, GEO: 0, HEO: 0 };
    const byGroup: Partial<Record<GroupId, number>> = {};
    for (const [gid, list] of satsRef.current) {
      byGroup[gid] = list.length;
      if (groupsOn[gid]) for (const s of list) byClass[s.cls] += 1;
    }
    return { byClass, byGroup, total: ORBIT_CLASSES.reduce((a, c) => a + byClass[c], 0) };
  }, [version, groupsOn]);

  const loading = progress < 100;
  const simMs = simNow();
  const liveCount = GROUPS.filter(g => status[g.id] === 'live').length;
  const simCount = GROUPS.filter(g => status[g.id] === 'sim').length;
  const dist = (km: number) => (miles ? `${fmtInt(km * KM_TO_MI)} mi` : `${fmtInt(km)} km`);
  const speedStr = (kms: number) => (miles ? `${fmtInt(kms * KM_TO_MI * 3600)} mph` : `${kms.toFixed(2)} km/s`);
  void tick;

  const zoomBy = (f: number) => { view.current.zoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, view.current.zoom * f)); touch(); };
  const resetView = () => { view.current.zoom = 1; view.current.lat = 22; setSelectedUid(null); touch(); };
  const setWarpTo = (next: number) => {
    const now = Date.now();
    clock.current = { sim0: simNow(), real0: now };
    setWarp(next); live.current.warp = next; touch();
  };
  const resetTime = () => { clock.current = { sim0: Date.now(), real0: Date.now() }; setWarp(1); live.current.warp = 1; touch(); };

  const chip = 'min-h-9 px-3 rounded-lg border text-[11px] font-mono font-bold tracking-wide transition-colors cursor-pointer inline-flex items-center gap-1.5';
  const on = 'border-[#72d1d6] bg-[#72d1d6]/15 text-[#72d1d6]';
  const off = 'border-white/10 bg-white/[0.03] text-[#9fb1a6] hover:border-white/30';

  return (
    <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-6 md:py-8 space-y-4" onPointerDown={touch} onKeyDown={touch}>
      {/* title bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <button onClick={() => { playUiClick(); onBackToDeck(); }} className="min-h-11 inline-flex items-center gap-1.5 text-xs font-mono text-[#9fb1a6] hover:text-[#d9f36a] transition-colors cursor-pointer">
          <ArrowLeft size={14} /><span>RETURN TO FLIGHT PLAN</span>
        </button>
        <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono">
          <span className="inline-flex items-center gap-1.5 text-[#72d1d6] font-bold"><SatIcon size={14} />ORBITAL RADAR</span>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-white/10 bg-black/30 text-[#eef4e6]" title="Mission clock">
            <Clock size={12} className="text-[#d9f36a]" />
            <button onClick={() => setUtc(u => !u)} className="cursor-pointer tabular-nums" aria-label="Toggle UTC or local time">
              {fmtClock(simMs, utc)} {utc ? 'UTC' : 'LOCAL'}
            </button>
            {warp !== 1 && <span className="text-[#ffc93c]">· {warp}×</span>}
          </span>
        </div>
      </div>

      {/* body switcher */}
      <div className="flex flex-wrap gap-2" role="tablist" aria-label="Celestial body">
        {(['Earth', 'Moon', 'Mars', 'Sun'] as Body[]).map(b => (
          <button key={b} role="tab" aria-selected={body === b} onClick={() => { playUiClick(); setBody(b); }} className={`${chip} ${body === b ? on : off}`}>
            <Globe size={13} />{b === 'Earth' ? 'EARTH · LIVE RADAR' : b.toUpperCase()}
          </button>
        ))}
      </div>

      {body !== 'Earth' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
          <div className="lg:col-span-8 rounded-2xl border border-white/10 bg-[#020a0c] overflow-hidden">
            <PlanetCanvas key={body} name={body} interactive showTouchControls className="w-full h-[min(68vh,640px)] min-h-[360px]" dayNightCycle={body !== 'Sun'} />
          </div>
          <div className="lg:col-span-4 rounded-2xl border border-white/10 bg-[#0a1a1c]/90 p-5 space-y-4">
            <div>
              <span className="text-[10px] font-mono tracking-widest text-[#ef7144] font-bold">{body === 'Moon' ? 'NATURAL SATELLITE' : body === 'Sun' ? 'STAR' : 'PLANET'}</span>
              <h2 className="font-display font-bold text-3xl text-[#eef4e6]">{body}</h2>
              <p className="text-sm text-[#72d1d6] italic">{BODY_FACTS[body].tagline}</p>
            </div>
            <dl className="divide-y divide-white/5 text-sm">
              {BODY_FACTS[body].rows.map(([k, v]) => (
                <div key={k} className="flex justify-between gap-3 py-2"><dt className="text-[#9fb1a6]">{k}</dt><dd className="font-mono text-[#eef4e6] text-right">{v}</dd></div>
              ))}
            </dl>
            <p className="text-xs leading-relaxed text-[#bdc9c0]">{BODY_FACTS[body].note}</p>
            {body === 'Sun' && weather && (
              <div className="rounded-lg border border-white/10 p-3 text-xs font-mono" style={{ borderColor: LEVEL_COLOR[weather.level] + '66' }}>
                <span className="text-[#9fb1a6]">NOAA Kp now </span><b style={{ color: LEVEL_COLOR[weather.level] }}>{weather.kp.toFixed(1)} · {weather.g} · {weather.label}</b>
              </div>
            )}
          </div>
        </div>
      ) : (
        <>
          {/* toggles */}
          <div className="flex flex-wrap gap-2">
            <button className={`${chip} ${tracks ? on : off}`} onClick={() => setTracks(t => !t)} aria-pressed={tracks}><OrbitIcon size={13} />TRACKS</button>
            <button className={`${chip} ${follow ? on : off}`} onClick={() => setFollow(f => !f)} aria-pressed={follow}><Crosshair size={13} />FOLLOW</button>
            <button className={`${chip} ${voice ? on : off}`} onClick={() => setVoice(v => !v)} aria-pressed={voice}>{voice ? <Volume2 size={13} /> : <VolumeX size={13} />}VOICE</button>
            <button className={`${chip} ${off}`} onClick={() => setMiles(m => !m)}>UNITS · {miles ? 'MI' : 'KM'}</button>
            <div className="inline-flex rounded-lg border border-white/10 overflow-hidden" role="group" aria-label="Time warp">
              {[1, 60, 600, 3600].map(x => (
                <button key={x} onClick={() => setWarpTo(x)} className={`min-h-9 px-3 text-[11px] font-mono font-bold cursor-pointer ${warp === x ? 'bg-[#ffc93c]/20 text-[#ffc93c]' : 'text-[#9fb1a6] hover:bg-white/5'}`}>{x === 1 ? 'LIVE' : `${x}×`}</button>
              ))}
              {warp !== 1 && <button onClick={resetTime} className="min-h-9 px-3 text-[11px] font-mono font-bold text-[#d9f36a] hover:bg-white/5 cursor-pointer">NOW</button>}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
            {/* globe */}
            <div className="lg:col-span-8 relative rounded-2xl border border-[#72d1d6]/30 bg-[radial-gradient(ellipse_at_center,#07161d,#020609)] overflow-hidden shadow-2xl">
              <div ref={wrapRef} className="relative w-full h-[62vh] min-h-[420px] max-h-[720px]">
                <canvas ref={canvasRef} className="absolute inset-0" role="img" aria-label="Interactive 3D globe showing satellites around Earth" />
              </div>

              {/* altitude classes */}
              <div className="absolute top-3 left-3 flex flex-col gap-1.5 max-w-[60%]">
                <div className="flex flex-wrap gap-1.5">
                  {ORBIT_CLASSES.map(c => (
                    <button key={c} onClick={() => setClassesOn(p => ({ ...p, [c]: !p[c] }))} aria-pressed={classesOn[c]} title={`${CLASS_META[c].label} · ${CLASS_META[c].range}`}
                      className={`min-h-8 px-2.5 rounded-md border text-[10px] font-mono font-bold inline-flex items-center gap-1.5 backdrop-blur-sm cursor-pointer ${classesOn[c] ? 'border-white/30 bg-black/55 text-white' : 'border-white/10 bg-black/40 text-[#6f8178]'}`}>
                      <i className="w-2 h-2 rounded-sm" style={{ background: CLASS_META[c].color, opacity: classesOn[c] ? 1 : 0.3 }} />{c}<span className="text-[#9fb1a6]">{fmtInt(counts.byClass[c])}</span>
                    </button>
                  ))}
                </div>
                <div className="flex gap-3 text-[10px] font-mono text-[#9fb1a6]">
                  <button className="hover:text-[#d9f36a] cursor-pointer" onClick={() => setClassesOn({ LEO: true, MEO: true, GEO: true, HEO: true })}>All</button>
                  <button className="hover:text-[#d9f36a] cursor-pointer" onClick={() => setClassesOn({ LEO: false, MEO: false, GEO: false, HEO: false })}>None</button>
                  <button className="hover:text-[#d9f36a] cursor-pointer" onClick={() => setClassesOn({ ...DEFAULT_CLASSES })}>Default</button>
                </div>
              </div>

              {/* zoom */}
              <div className="absolute top-3 right-3 flex flex-col gap-1.5">
                <button aria-label="Zoom in" onClick={() => zoomBy(1.25)} className="w-9 h-9 grid place-items-center rounded-md border border-white/15 bg-black/55 text-white hover:border-[#72d1d6] cursor-pointer"><Plus size={16} /></button>
                <button aria-label="Zoom out" onClick={() => zoomBy(1 / 1.25)} className="w-9 h-9 grid place-items-center rounded-md border border-white/15 bg-black/55 text-white hover:border-[#72d1d6] cursor-pointer"><Minus size={16} /></button>
                <button aria-label="Reset view" onClick={resetView} className="w-9 h-9 grid place-items-center rounded-md border border-white/15 bg-black/55 text-white hover:border-[#72d1d6] cursor-pointer"><RotateCcw size={15} /></button>
              </div>

              {/* footer readouts */}
              <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between gap-3 pointer-events-none">
                <div className="text-[10px] font-mono leading-relaxed text-[#9fb1a6] bg-black/45 backdrop-blur-sm rounded-md px-2.5 py-1.5">
                  <div><b className="text-[#eef4e6]">{fmtInt(counts.total)}</b> OBJECTS PLOTTED · SGP4</div>
                  <div>{liveCount > 0 ? <span className="text-[#66d17a]">● LIVE {liveCount}/{GROUPS.length} FEEDS</span> : null}{simCount > 0 ? <span className="text-[#ffc93c]">{liveCount > 0 ? ' · ' : ''}◐ OFFLINE MODEL {simCount}</span> : null}</div>
                </div>
                {hoverName && <div className="text-[11px] font-mono text-white bg-black/70 rounded-md px-2.5 py-1.5">{hoverName}</div>}
              </div>

              {loading && (
                <div className="absolute inset-0 grid place-items-center bg-[#020609]/80 backdrop-blur-[2px] text-center" role="status">
                  <div>
                    <SatIcon size={34} className="mx-auto text-[#72d1d6] animate-pulse" />
                    <p className="mt-3 font-mono text-sm text-[#eef4e6]">Loading satellites… {progress}%</p>
                    <p className="font-mono text-[11px] text-[#9fb1a6]">Syncing live orbital data…</p>
                    <div className="mt-3 mx-auto h-1 w-48 rounded bg-white/10 overflow-hidden"><div className="h-full bg-[#72d1d6] transition-all" style={{ width: `${progress}%` }} /></div>
                  </div>
                </div>
              )}
              {paused && (
                <button onClick={touch} className="absolute inset-0 grid place-items-center bg-[#020609]/80 backdrop-blur-sm cursor-pointer">
                  <span className="text-center"><Pause size={30} className="mx-auto text-[#ffc93c]" /><span className="block mt-2 font-mono text-sm text-[#eef4e6]">Paused for inactivity</span><span className="block font-mono text-[11px] text-[#9fb1a6]">Tap to resume real-time updates</span></span>
                </button>
              )}
            </div>

            {/* side panels */}
            <div className="lg:col-span-4 space-y-4">
              {/* selected satellite */}
              <section className="rounded-2xl border border-white/10 bg-[#0a1a1c]/90 p-4">
                <h3 className="text-[10px] font-mono tracking-widest text-[#9fb1a6] font-bold mb-2">SELECTED OBJECT</h3>
                {selected ? (
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="font-display font-bold text-lg text-[#eef4e6] leading-tight break-words">{selected.name.replace(' (SIM)', '')}</p>
                        <p className="text-[11px] font-mono" style={{ color: CLASS_META[selected.cls].color }}>{selected.cls} · {CLASS_META[selected.cls].label}{selected.sim && <span className="text-[#ffc93c]"> · OFFLINE MODEL</span>}</p>
                      </div>
                      <button aria-label={watch.some(w => w.norad === selected.norad) ? 'Remove from watchlist' : 'Add to watchlist'} onClick={() => toggleWatch(selected)} className="w-10 h-10 shrink-0 grid place-items-center rounded-lg border border-white/10 hover:border-[#ffd34d] cursor-pointer">
                        <Star size={18} className={watch.some(w => w.norad === selected.norad) ? 'text-[#ffd34d] fill-[#ffd34d]' : 'text-[#9fb1a6]'} />
                      </button>
                    </div>
                    <dl className="grid grid-cols-2 gap-x-3 gap-y-2 text-[11px] font-mono">
                      {([
                        ['NORAD ID', selected.sim ? '—' : String(selected.norad)],
                        ['GROUP', GROUPS.find(g => g.id === selected.group)?.label ?? ''],
                        ['ALTITUDE', dist(selected.alt)],
                        ['SPEED', speedStr(selected.speed)],
                        ['INCLINATION', `${selected.incl.toFixed(1)}°`],
                        ['PERIOD', `${selected.periodMin.toFixed(selected.periodMin > 300 ? 0 : 1)} min`],
                        ['LATITUDE', `${selected.lat.toFixed(2)}°`],
                        ['LONGITUDE', `${selected.lon.toFixed(2)}°`],
                      ] as [string, string][]).map(([k, v]) => (
                        <div key={k}><dt className="text-[#6f8178]">{k}</dt><dd className="text-[#eef4e6]">{v}</dd></div>
                      ))}
                    </dl>
                    <button onClick={predictPass} className={`${chip} ${off} w-full justify-center`}><MapPin size={13} />PREDICT NEXT PASS OVER ME</button>
                    {pass.state === 'locating' && <p className="text-[11px] font-mono text-[#9fb1a6]">Requesting your location…</p>}
                    {pass.state === 'calc' && <p className="text-[11px] font-mono text-[#9fb1a6]">Calculating 24 h of passes…</p>}
                    {pass.state === 'denied' && <p className="text-[11px] font-mono text-[#ffb02e]">Location unavailable — allow location access to predict passes.</p>}
                    {pass.state === 'none' && <p className="text-[11px] font-mono text-[#9fb1a6]">{selected.cls === 'GEO' ? 'Geostationary objects hold a fixed spot in the sky — no passes.' : 'No pass above 10° elevation in the next 24 h.'}</p>}
                    {pass.state === 'ok' && pass.data && (
                      <div className="rounded-lg border border-[#d9f36a]/30 bg-[#d9f36a]/5 p-2.5 text-[11px] font-mono leading-relaxed text-[#eef4e6]">
                        <div>{pass.data.alreadyUp ? 'OVERHEAD NOW · ' : 'RISES '}<b>{fmtClock(pass.data.aos, utc)}</b> {utc ? 'UTC' : ''}</div>
                        <div>MAX ELEVATION <b>{pass.data.maxEl.toFixed(0)}°</b> at {fmtClock(pass.data.maxT, utc)}</div>
                        <div>SETS <b>{fmtClock(pass.data.los, utc)}</b> · {Math.max(1, Math.round((pass.data.los - pass.data.aos) / 60000))} min</div>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-[#9fb1a6] leading-relaxed">Click any satellite on the globe to see its live altitude, speed and orbit track. Drag to rotate, scroll to zoom.</p>
                )}
              </section>

              {/* space weather */}
              <section className="rounded-2xl border bg-[#0a1a1c]/90 p-4" style={{ borderColor: weather ? LEVEL_COLOR[weather.level] + '55' : 'rgba(255,255,255,0.1)' }}>
                <h3 className="text-[10px] font-mono tracking-widest text-[#9fb1a6] font-bold mb-2 flex items-center gap-1.5"><Activity size={12} />SPACE WEATHER · NOAA SWPC</h3>
                {weather ? (
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-xl grid place-items-center font-display font-bold text-2xl" style={{ background: LEVEL_COLOR[weather.level] + '22', color: LEVEL_COLOR[weather.level], border: `1px solid ${LEVEL_COLOR[weather.level]}66` }} title="Threat level (5 = quiet, 1 = extreme)">{weather.level}</div>
                    <div className="text-[11px] font-mono leading-relaxed">
                      <div className="text-[#eef4e6] font-bold">{weather.label}</div>
                      <div className="text-[#9fb1a6]">Kp {weather.kp.toFixed(1)} · {weather.g}</div>
                      <div className="text-[#6f8178]">Geomagnetic storms raise drag on LEO satellites.</div>
                    </div>
                  </div>
                ) : (
                  <p className="text-[11px] font-mono text-[#9fb1a6]">{weatherErr ? 'Space-weather feed unavailable right now.' : 'Fetching Kp index…'}</p>
                )}
              </section>

              {/* constellations */}
              <section className="rounded-2xl border border-white/10 bg-[#0a1a1c]/90 p-4">
                <h3 className="text-[10px] font-mono tracking-widest text-[#9fb1a6] font-bold mb-2">CONSTELLATIONS</h3>
                <div className="grid grid-cols-1 gap-1.5 max-h-72 overflow-y-auto pr-1">
                  {GROUPS.map(g => (
                    <button key={g.id} onClick={() => setGroupsOn(p => ({ ...p, [g.id]: !p[g.id] }))} aria-pressed={groupsOn[g.id]} title={g.blurb}
                      className={`min-h-10 px-3 rounded-lg border text-left flex items-center justify-between gap-2 cursor-pointer ${groupsOn[g.id] ? 'border-[#72d1d6]/60 bg-[#72d1d6]/10' : 'border-white/10 bg-white/[0.02] opacity-70'}`}>
                      <span className="text-xs text-[#eef4e6]">{g.label}</span>
                      <span className="text-[10px] font-mono text-[#9fb1a6]">
                        {status[g.id] === 'pending' ? '…' : fmtInt(counts.byGroup[g.id] ?? 0)}
                        <span className={status[g.id] === 'live' ? 'text-[#66d17a]' : status[g.id] === 'sim' ? 'text-[#ffc93c]' : ''}> {status[g.id] === 'live' ? 'LIVE' : status[g.id] === 'sim' ? 'SIM' : ''}</span>
                      </span>
                    </button>
                  ))}
                </div>
              </section>

              {/* watchlist */}
              <section className="rounded-2xl border border-white/10 bg-[#0a1a1c]/90 p-4">
                <h3 className="text-[10px] font-mono tracking-widest text-[#9fb1a6] font-bold mb-2 flex items-center gap-1.5"><Star size={12} className="text-[#ffd34d]" />WATCHLIST</h3>
                {watch.length === 0 ? (
                  <p className="text-xs text-[#9fb1a6]">Star a satellite to keep it here. Saved in this browser only.</p>
                ) : (
                  <ul className="space-y-1.5">
                    {watch.map(w => {
                      const s = allSats().find(x => x.norad === w.norad);
                      return (
                        <li key={w.norad}>
                          <button onClick={() => selectByNorad(w.norad)} className="w-full min-h-10 px-3 rounded-lg border border-white/10 hover:border-[#ffd34d]/60 text-left flex items-center justify-between gap-2 cursor-pointer">
                            <span className="text-xs text-[#eef4e6] truncate">{w.name.replace(' (SIM)', '')}</span>
                            <span className="text-[10px] font-mono text-[#9fb1a6] shrink-0">{s?.ok ? dist(s.alt) : '—'}</span>
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </section>
            </div>
          </div>

          <p className="text-[10px] font-mono text-[#6f8178] leading-relaxed">
            Orbital elements: CelesTrak GP data (sampled per constellation) propagated in-browser with SGP4. Groups that can’t be reached fall back to a clearly marked offline model.
            Kp index: NOAA Space Weather Prediction Center. Threat level is a simple readout derived from Kp, not an official alert.
          </p>
        </>
      )}
    </div>
  );
};
