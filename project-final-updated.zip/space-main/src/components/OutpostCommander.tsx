import React, { useState } from 'react';
import {
  Zap,
  Wind,
  Sprout,
  Shield,
  Radiation,
  RotateCcw,
  Rocket,
  Plus,
  Minus,
  AlertTriangle,
  Droplets,
  Heart,
  Sun,
  Moon,
  Battery,
  Layers,
  Thermometer,
  Activity,
  Award,
  Sparkles,
  Info,
  CheckCircle2,
  SlidersHorizontal,
} from 'lucide-react';
import {
  playUiClick,
  playErrorAlert,
  playSuccessChime,
  playTone,
} from '../utils/audio';
import { OutpostScene } from './OutpostScene';

type PlanetId = 'moon' | 'mars';
type HabId = 'inflatable' | 'regolith' | 'lavatube';
type PowerId = 'solar' | 'fission' | 'hybrid';
type DifficultyId = 'cadet' | 'nominal' | 'hardcore';

interface CrewAllocation {
  power: number;       // Solar/reactor upkeep & cleaning
  lifeSupport: number; // ECLSS O2, CO2 scrubbers, atmospheric pressure
  water: number;       // Greywater recycler + ice extraction
  farm: number;        // Hydroponic crop trays & lighting
  shield: number;      // Regolith piling / 3D sintering
  rest: number;        // Sleep, medical, morale recovery
}

interface OutpostState {
  sol: number;
  battery: number;     // 0 - 100%
  oxygen: number;      // 0 - 100%
  water: number;       // 0 - 100%
  food: number;        // 0 - 100%
  shielding: number;   // 0 - 100%
  radiationDose: number; // mSv cumulative
  crewMorale: number;  // 0 - 100%
  habitatIntegrity: number; // 0 - 100%
}

interface OutpostModifiers {
  lostHours: number;
  sunlightMult: number;
  o2Leak: number;
  waterLeak: number;
  flareDose: number;
  farmYieldMult: number;
  powerDrainMult: number;
}

interface EventChoice {
  label: string;
  scientificContext: string;
  consequenceText: string;
  modifiers: Partial<OutpostModifiers>;
  moraleDelta?: number;
  healthDelta?: number;
}

interface OutpostEvent {
  id: string;
  title: string;
  description: string;
  scientificPrinciple: string;
  choiceA: EventChoice;
  choiceB: EventChoice;
  planetFilter?: PlanetId;
}

const TOTAL_SOLS = 30;
const NOMINAL_DAILY_HOURS = 8;
const clamp = (val: number, min = 0, max = 100) => Math.max(min, Math.min(max, val));

const PLANET_SPECS: Record<
  PlanetId,
  {
    name: string;
    environmentTag: string;
    description: string;
    radDoseRate: number;      // mSv per sol
    radLimit: number;         // Max safe career limit (mSv)
    gravity: string;
    atmosphericPressure: string;
    iceAvailability: number;  // Water multiplier
    getSunlight: (sol: number) => number;
    scienceNote: string;
  }
> = {
  moon: {
    name: 'Lunar South Pole (Shackleton Crater Rim)',
    environmentTag: 'Airless Vacuum · 1/6th Earth Gravity (1.62 m/s²)',
    description:
      'Permanently shadowed polar craters harbor billions of tons of water ice. However, an orbital eclipse/lunar night (sols 11–17) drops surface sunlight to just 15%.',
    radDoseRate: 1.4,
    radLimit: 45,
    gravity: '0.166 g',
    atmosphericPressure: '0.00 kPa (Hard Vacuum)',
    iceAvailability: 1.3,
    getSunlight: (sol: number) => (sol >= 11 && sol <= 17 ? 0.15 : 1.0),
    scienceNote:
      'Without an atmosphere or magnetic dipole, Galactic Cosmic Rays (GCR) hit the lunar regolith unimpeded. Peak sunlight peaks at the rims (Peaks of Eternal Light).',
  },
  mars: {
    name: 'Mars (Jezero Crater Delta)',
    environmentTag: 'Thin CO₂ Atmosphere (0.6 kPa) · 38% Earth Gravity (3.72 m/s²)',
    description:
      'Atmosphere allows MOXIE CO₂-to-O₂ extraction. Sunlight is only 52% of Earth orbit, and regional atmospheric dust storms can blot out the Sun for multiple sols.',
    radDoseRate: 0.85,
    radLimit: 38,
    gravity: '0.38 g',
    atmosphericPressure: '0.61 kPa (95% CO₂)',
    iceAvailability: 0.9,
    getSunlight: (sol: number) => (sol >= 14 && sol <= 18 ? 0.35 : 0.65),
    scienceNote:
      'Mars atmosphere shields roughly 40% of deep-space cosmic rays compared to the Moon, but dust storms drastically drop photovoltaic power generation.',
  },
};

const HABITAT_SPECS: Record<
  HabId,
  {
    name: string;
    tagline: string;
    baseShielding: number;
    farmMultiplier: number;
    description: string;
    scienceTradeoff: string;
  }
> = {
  inflatable: {
    name: 'Inflatable TransHab / Kevlar Module',
    tagline: 'Lightweight Launch Mass · Generous Greenhouse Volume',
    baseShielding: 15,
    farmMultiplier: 1.35,
    description: 'Multi-layer expandable shell with expansive crop trays (+35% farm yield), but minimal initial radiation shielding.',
    scienceTradeoff: 'Requires early crew time dedicated to piling protective regolith berms over the outer fabric.',
  },
  regolith: {
    name: '3D-Printed Sintered Regolith Dome',
    tagline: 'In-Situ Local Materials · High Structural Mass',
    baseShielding: 45,
    farmMultiplier: 1.0,
    description: 'Robotic microwave sintering creates a thick basalt stone carapace (45% starting shielding and high micrometeorite resistance).',
    scienceTradeoff: 'Balanced baseline; provides dependable protection from Sol 1.',
  },
  lavatube: {
    name: 'Subsurface Basalt Lava Tube Shelter',
    tagline: 'Natural Rock Overburden · Thermal Stability',
    baseShielding: 75,
    farmMultiplier: 0.85,
    description: 'Underground volcanic cavern blocks 75% of radiation and eliminates temperature extremes, but reduces greenhouse space (-15%).',
    scienceTradeoff: 'Virtually immune to solar flares, but demands more electric power for artificial plant growth LEDs.',
  },
};

const POWER_SPECS: Record<
  PowerId,
  {
    name: string;
    tagline: string;
    dayCapacity: number;
    nightCapacity: number;
    description: string;
  }
> = {
  solar: {
    name: 'Vertical Solar Array Towers (VSAT) + Regenerative Fuel Cells',
    tagline: '140 kW Peak Solar · High Day Efficiency',
    dayCapacity: 140,
    nightCapacity: 25,
    description: 'Lightweight launch mass. Generates abundant power in full sunlight, but requires strict battery conservation during lunar night or dust storms.',
  },
  fission: {
    name: 'Surface Fission Power (NASA Kilopower 40 kWe)',
    tagline: '85 kW Continuous · Unaffected by Dust or Night',
    dayCapacity: 85,
    nightCapacity: 85,
    description: 'Stirling engine fission reactor produces steady power 24/7 through dust storms and lunar eclipses, with zero dependence on solar flux.',
  },
  hybrid: {
    name: 'Hybrid Photovoltaic + Stirling Radioisotope (RTG)',
    tagline: '110 kW Day / 50 kW Night Baseline',
    dayCapacity: 110,
    nightCapacity: 50,
    description: 'Combines solar tracking panels with plutonium-238 decay heat generation for a balanced, redundant power architecture.',
  },
};

const OUTPOST_EVENTS: OutpostEvent[] = [
  {
    id: 'solar_flare',
    title: 'Coronal Mass Ejection: Solar Proton Event (SPE)',
    description: 'Orbital radiation sensors detect an X-class solar flare. A high-energy proton shockwave will impact the habitat within 4 hours.',
    scientificPrinciple: 'Solar Proton Events deliver dangerous acute ionizing radiation doses. Mass shielding (water or sintered regolith) absorbs proton kinetic energy.',
    choiceA: {
      label: 'Shelter in Water-Shielded Storm Cellar',
      scientificContext: 'Crews pack into the central module surrounded by greywater storage tanks.',
      consequenceText: 'Diverted 2 crew-hours. Minimal radiation exposure absorbed.',
      modifiers: { lostHours: 2, flareDose: 1.5 },
      moraleDelta: -3,
    },
    choiceB: {
      label: 'Maintain Critical Surface Work Outside',
      scientificContext: 'Astronauts remain in EVA suits to complete external maintenance.',
      consequenceText: 'Zero hours lost, but crew absorbs a significant acute radiation spike (+9.0 mSv).',
      modifiers: { lostHours: 0, flareDose: 9.0 },
      moraleDelta: -8,
    },
  },
  {
    id: 'micrometeorite_leak',
    title: 'Hypervelocity Micrometeorite Puncture',
    description: 'A 2 mm space rock shard traveling at 22 km/s breached the secondary airlock seal. Acoustic sensors detect air venting to space.',
    scientificPrinciple: 'In vacuum, a 2 mm puncture vents ~400 liters of breathable cabin air per hour until equalized or patched.',
    choiceA: {
      label: 'Immediate Emergency EVA Seal & Patch',
      scientificContext: 'Two astronauts suit up to apply epoxy sealant tape and an aluminum patch over the hull puncture.',
      consequenceText: 'Expended 3 crew-hours. Atmosphere sealed with negligible air loss.',
      modifiers: { lostHours: 3, o2Leak: 2 },
      moraleDelta: +2,
    },
    choiceB: {
      label: 'Isolate Outer Module & Vent to Vacuum',
      scientificContext: 'Seal internal hatch doors and sacrifice the outer storage bay air.',
      consequenceText: 'Saved crew hours, but vented 12% of total oxygen reserves.',
      modifiers: { lostHours: 0, o2Leak: 12 },
      moraleDelta: -6,
    },
  },
  {
    id: 'crop_blight',
    title: 'Hydroponic Root Fungus Infection',
    description: 'Humidity in the plant growth chamber caused fungal mold to spread across the rapid-cycling dwarf wheat crop trays.',
    scientificPrinciple: 'Closed-loop greenhouses require sterile balance. Mold consumes oxygen and rots harvestable biomass.',
    choiceA: {
      label: 'Sanitize Nutrient Solution & Prune Crops',
      scientificContext: 'Flush water circulation loop with UV sterilization and replace fouled trays.',
      consequenceText: 'Cost 2 crew-hours and cut today’s yield by 40%, but saved the master seed stock.',
      modifiers: { lostHours: 2, farmYieldMult: 0.6 },
      moraleDelta: +1,
    },
    choiceB: {
      label: 'Harvest Early & Rely on Stored Rations',
      scientificContext: 'Salvage what biomass remains without deep sanitization.',
      consequenceText: 'Saved crew time, but lost 25% of ongoing agricultural food generation.',
      modifiers: { lostHours: 0, farmYieldMult: 0.35 },
      moraleDelta: -5,
    },
  },
  {
    id: 'dust_storm_mars',
    title: 'Regional Atmospheric Dust Storm (Tau = 2.4)',
    description: 'Ferric oxide dust clouds envelope the crater, reducing solar insolation and depositing static cling dust on photovoltaic glass.',
    scientificPrinciple: 'Martian dust particles are electrostatically charged. Suspended dust particles scatter sunlight via Mie scattering.',
    planetFilter: 'mars',
    choiceA: {
      label: 'Curtail Non-Essential Systems & Conserve Power',
      scientificContext: 'Shut down non-critical scientific instruments and dim greenhouse LED lighting.',
      consequenceText: 'Power demand decreased by 30%; greenhouse output temporarily halved.',
      modifiers: { powerDrainMult: 0.7, farmYieldMult: 0.5 },
      moraleDelta: -2,
    },
    choiceB: {
      label: 'Deploy Electrostatic Dust Shakers at Full Power',
      scientificContext: 'Vibrate panels using high-voltage AC electric fields to shake off dust grains.',
      consequenceText: 'Maintained 80% solar generation, but consumed 15% extra battery reserves.',
      modifiers: { sunlightMult: 0.8, powerDrainMult: 1.2 },
      moraleDelta: 0,
    },
  },
  {
    id: 'lunar_cold_trap',
    title: 'Water Ice Volatile Discovery in Shadowed Trench',
    description: 'Autonomous rover telemetry detects an exceptionally pure slab of water ice in a permanently shadowed crevasse near the habitat.',
    scientificPrinciple: 'Cold traps preserve cometary water ice for billions of years at -240°C. Extracting ice provides water and fuel feedstock.',
    planetFilter: 'moon',
    choiceA: {
      label: 'Dispatch EVA Team with Thermal Melt Probe',
      scientificContext: 'Astronauts lower a thermal sublimation coil into the crater to extract water vapor.',
      consequenceText: 'Invested 2 crew-hours. Harvested +15% fresh water and replenished ECLSS loops!',
      modifiers: { lostHours: 2, waterLeak: -15 },
      moraleDelta: +6,
    },
    choiceB: {
      label: 'Prioritize Scheduled Habitat Maintenance',
      scientificContext: 'Remain focused on nominal base maintenance and log coordinates for future mission.',
      consequenceText: 'Maintained strict work schedule; ice remains stored in situ.',
      modifiers: {},
      moraleDelta: 0,
    },
  },
];

const DEFAULT_MODS: OutpostModifiers = {
  lostHours: 0,
  sunlightMult: 1,
  o2Leak: 0,
  waterLeak: 0,
  flareDose: 0,
  farmYieldMult: 1,
  powerDrainMult: 1,
};

export const OutpostCommander: React.FC<{ onSuccess: (score: number) => void }> = ({ onSuccess }) => {
  const [phase, setPhase] = useState<'setup' | 'briefing' | 'simulation' | 'event' | 'debrief'>('setup');
  const [planet, setPlanet] = useState<PlanetId>('moon');
  const [hab, setHab] = useState<HabId>('regolith');
  const [power, setPower] = useState<PowerId>('solar');
  const [difficulty, setDifficulty] = useState<DifficultyId>('nominal');

  // Simulation State
  const [state, setState] = useState<OutpostState>({
    sol: 1,
    battery: 100,
    oxygen: 85,
    water: 90,
    food: 85,
    shielding: 45,
    radiationDose: 0,
    crewMorale: 90,
    habitatIntegrity: 100,
  });

  const [alloc, setAlloc] = useState<CrewAllocation>({
    power: 1,
    lifeSupport: 2,
    water: 2,
    farm: 2,
    shield: 1,
    rest: 0,
  });

  const [currentEvent, setCurrentEvent] = useState<OutpostEvent | null>(null);
  const [modifiers, setModifiers] = useState<OutpostModifiers>(DEFAULT_MODS);
  const [solLog, setSolLog] = useState<string[]>([]);
  const [history, setHistory] = useState<{ sol: number; o2: number; water: number; food: number; bat: number; dose: number }[]>([]);
  const [missionResult, setMissionResult] = useState<{ success: boolean; failureReason?: string; score: number } | null>(null);
  const [rewardClaimed, setRewardClaimed] = useState(false);

  const P = PLANET_SPECS[planet];
  const H = HABITAT_SPECS[hab];
  const POW = POWER_SPECS[power];

  // Difficulty adjustment coefficients
  const diffMult = difficulty === 'cadet' ? 0.8 : difficulty === 'hardcore' ? 1.25 : 1.0;

  // Real-time calculation of daily simulation step
  const computeForecast = (st: OutpostState, a: CrewAllocation, m: OutpostModifiers) => {
    const rawSun = P.getSunlight(st.sol) * m.sunlightMult;
    const basePowerGen = rawSun > 0.4 ? POW.dayCapacity * rawSun : POW.nightCapacity;
    const powerGen = basePowerGen * (1 + a.power * 0.08); // +8% per crew hour on power upkeep
    const powerDemand = (55 + a.lifeSupport * 4 + a.water * 3 + a.farm * 5 + a.shield * 2) * m.powerDrainMult * diffMult;
    const netPower = (powerGen - powerDemand) * 0.45;
    const nextBattery = clamp(st.battery + netPower);
    const isBrownout = nextBattery <= 5;
    const efficiency = isBrownout ? 0.35 : 1.0;

    // Oxygen dynamics: 4 astronauts consume ~3.4 kg/sol. Produced by Sabatier/electrolysis + farm
    const o2Produced = (a.lifeSupport * 4.2 * efficiency + a.farm * 0.8 * efficiency) * (planet === 'mars' ? 1.15 : 1.0); // MOXIE boost on Mars
    const o2Consumed = 8.5 * diffMult + m.o2Leak;
    const nextO2 = clamp(st.oxygen + o2Produced - o2Consumed);

    // Water dynamics: greywater recovery (95%) + ice mining - drinking/hygiene/farming
    const waterRecycled = (a.water * 4.5 * P.iceAvailability * efficiency);
    const waterConsumed = 7.5 * diffMult + a.farm * 1.5 + m.waterLeak;
    const nextWater = clamp(st.water + waterRecycled - waterConsumed);

    // Food production: greenhouse harvest vs 4 crew consumption
    const foodGrown = a.farm * 3.8 * H.farmMultiplier * m.farmYieldMult * efficiency;
    const foodEaten = 8.0 * diffMult;
    const nextFood = clamp(st.food + foodGrown - foodEaten);

    // Shielding buildup: regolith piling
    const nextShielding = Math.min(100, st.shielding + a.shield * 3.5);

    // Radiation dose: GCR baseline attenuated by shielding + solar flare event
    const effectiveShieldFraction = nextShielding / 100;
    const dailyRad = (P.radDoseRate + m.flareDose) * (1 - effectiveShieldFraction * 0.82) * diffMult;
    const nextDose = st.radiationDose + dailyRad;

    // Crew morale: influenced by rest, food shortages, brownouts
    const moraleDelta = (a.rest * 2.5) - (isBrownout ? 8 : 0) - (nextO2 < 30 ? 10 : 0) - (nextFood < 30 ? 8 : 0);
    const nextMorale = clamp(st.crewMorale + moraleDelta);

    return {
      powerGen,
      powerDemand,
      netPower,
      isBrownout,
      battery: nextBattery,
      oxygen: nextO2,
      water: nextWater,
      food: nextFood,
      shielding: nextShielding,
      radiationDose: nextDose,
      crewMorale: nextMorale,
      dailyRad,
    };
  };

  const startOutpostMission = () => {
    playUiClick();
    const initialShield = H.baseShielding;
    const initialReserve = difficulty === 'cadet' ? 95 : difficulty === 'hardcore' ? 70 : 80;

    setState({
      sol: 1,
      battery: 100,
      oxygen: initialReserve,
      water: initialReserve,
      food: initialReserve,
      shielding: initialShield,
      radiationDose: 0,
      crewMorale: 95,
      habitatIntegrity: 100,
    });
    setAlloc({ power: 1, lifeSupport: 2, water: 2, farm: 2, shield: 1, rest: 0 });
    setModifiers(DEFAULT_MODS);
    setHistory([]);
    setSolLog([
      `SOL 01: ${P.name.toUpperCase()} expedition inaugurated. Habitat: ${H.name}. Power: ${POW.name}. Systems nominal.`,
    ]);
    setRewardClaimed(false);
    setMissionResult(null);

    // Check for Sol 1 event or proceed to planning
    triggerSolStart(1);
  };

  const triggerSolStart = (solNum: number) => {
    const applicableEvents = OUTPOST_EVENTS.filter(
      e => !e.planetFilter || e.planetFilter === planet
    );

    // 40% chance of scientifically plausible contingency event on any given sol
    const triggerEvent = Math.random() < 0.42 && solNum > 1;

    if (triggerEvent) {
      const selected = applicableEvents[Math.floor(Math.random() * applicableEvents.length)];
      setCurrentEvent(selected);
      setPhase('event');
      playTone(280, 0.25, 'triangle');
    } else {
      setCurrentEvent(null);
      setModifiers(DEFAULT_MODS);
      setPhase('simulation');
    }
  };

  const handleResolveEvent = (choice: EventChoice) => {
    playUiClick();
    const newMods: OutpostModifiers = {
      ...DEFAULT_MODS,
      ...choice.modifiers,
    };
    setModifiers(newMods);
    setSolLog(prev => [
      `SOL ${String(state.sol).padStart(2, '0')}: Contingency "${currentEvent?.title}" → Choice: "${choice.label}". ${choice.consequenceText}`,
      ...prev,
    ].slice(0, 15));

    setCurrentEvent(null);
    setPhase('simulation');
  };

  const allocatedHours = alloc.power + alloc.lifeSupport + alloc.water + alloc.farm + alloc.shield + alloc.rest;
  const availableHours = Math.max(2, NOMINAL_DAILY_HOURS - modifiers.lostHours);

  const handleAdjustHours = (category: keyof CrewAllocation, delta: number) => {
    const currentVal = alloc[category];
    const nextVal = currentVal + delta;
    if (nextVal < 0) {
      playTone(180, 0.08, 'sawtooth');
      return;
    }
    if (delta > 0 && allocatedHours >= availableHours) {
      playTone(220, 0.12, 'sawtooth');
      return;
    }

    playTone(delta > 0 ? 380 + nextVal * 45 : 320, 0.08, 'sine');
    setAlloc({
      ...alloc,
      [category]: nextVal,
    });
  };

  const forecast = computeForecast(state, alloc, modifiers);

  const advanceSol = () => {
    playUiClick();
    const f = forecast;

    const nextState: OutpostState = {
      sol: state.sol,
      battery: f.battery,
      oxygen: f.oxygen,
      water: f.water,
      food: f.food,
      shielding: f.shielding,
      radiationDose: f.radiationDose,
      crewMorale: f.crewMorale,
      habitatIntegrity: state.habitatIntegrity,
    };

    setHistory(prev => [
      ...prev,
      {
        sol: state.sol,
        o2: f.oxygen,
        water: f.water,
        food: f.food,
        bat: f.battery,
        dose: f.radiationDose,
      },
    ]);

    // Check critical life support failure conditions
    let failureReason: string | null = null;
    if (f.oxygen <= 0) failureReason = 'ECLSS Oxygen Depletion: Atmospheric partial pressure dropped below breathable hypoxia threshold.';
    else if (f.water <= 0) failureReason = 'Water Recycling Loop Exhaustion: Dehydration crisis rendered crew incapacitated.';
    else if (f.food <= 0) failureReason = 'Agricultural Starvation: Food reserves depleted before next greenhouse harvest.';
    else if (f.radiationDose >= P.radLimit) failureReason = `Cumulative Radiation Exposure Exceeded Safe NASA Career Limit (${P.radLimit} mSv).`;
    else if (f.crewMorale <= 5) failureReason = 'Crew Psychological Breakdown: Severe mission burnout and critical equipment neglect.';

    if (failureReason) {
      playErrorAlert();
      const scoreEarned = Math.round((state.sol / TOTAL_SOLS) * 60);
      setMissionResult({
        success: false,
        failureReason,
        score: scoreEarned,
      });
      setPhase('debrief');
      return;
    }

    // Success condition: reached Sol 30!
    if (state.sol >= TOTAL_SOLS) {
      playSuccessChime();
      const survivalBonus = 100;
      const resourceScore = Math.round((f.oxygen + f.water + f.food + f.battery) / 4);
      const radPenalty = Math.round(f.radiationDose * 0.8);
      const finalScore = Math.max(50, survivalBonus + resourceScore - radPenalty);

      setMissionResult({
        success: true,
        score: finalScore,
      });
      setPhase('debrief');
      return;
    }

    // Advance to next sol
    const nextSolNum = state.sol + 1;
    setState({ ...nextState, sol: nextSolNum });
    setSolLog(prev => [
      `SOL ${String(state.sol).padStart(2, '0')}: O₂ ${f.oxygen.toFixed(0)}% · H₂O ${f.water.toFixed(0)}% · Food ${f.food.toFixed(0)}% · Battery ${f.battery.toFixed(0)}% · Dose +${f.dailyRad.toFixed(2)} mSv${f.isBrownout ? ' · CRITICAL BROWNOUT' : ''}`,
      ...prev,
    ].slice(0, 15));

    triggerSolStart(nextSolNum);
  };

  // =========================================================================
  // VIEW: SETUP PHASE
  // =========================================================================
  if (phase === 'setup') {
    return (
      <div className="space-y-6 max-w-4xl mx-auto p-4 sm:p-6 bg-[#040f12]/90 border border-[#1b3834] rounded-2xl shadow-2xl hud-glass">
        <div className="border-b border-white/10 pb-4">
          <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-widest text-[#d9f36a]">
            <Rocket size={15} />
            <span>NASA ARTEMIS &amp; MARS ARCHITECTURE DESIGN LAB</span>
          </div>
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-[#eef4e6] mt-1">
            Outpost Commander: 30-Sol Planetary Survival Sim
          </h2>
          <p className="text-xs sm:text-sm text-[#9fb1a6] mt-1.5 leading-relaxed">
            Establish and manage humanity&apos;s first permanent extraterrestrial base. Balance interconnected electrical power, ECLSS life-support recycling, hydroponic crops, water ice extraction, and radiation shielding against authentic solar storms and harsh planetary diurnal cycles.
          </p>
        </div>

        <OutpostScene
          planet={planet}
          habitat={hab}
          sol={state.sol}
          sunlight={Math.round(PLANET_SPECS[planet].getSunlight(state.sol) * 100)}
        />

        {/* 1. Destination Selection */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-mono text-[#d9f36a] font-bold">
            <span>1 · SELECT PLANETARY ENVIRONMENT</span>
            <span className="text-[#9fb1a6] text-[10px]">GRAVITY &amp; ATMOSPHERIC REGIME</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {(Object.keys(PLANET_SPECS) as PlanetId[]).map(key => {
              const spec = PLANET_SPECS[key];
              const isSelected = planet === key;
              return (
                <button
                  key={key}
                  onClick={() => { playUiClick(); setPlanet(key); }}
                  className={`p-4 rounded-xl text-left border transition-all cursor-pointer ${
                    isSelected
                      ? 'border-[#d9f36a] bg-[#0d282b] shadow-[0_0_15px_rgba(217,243,106,0.15)]'
                      : 'border-white/10 bg-black/40 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-display font-bold text-base text-white">{spec.name}</span>
                    {key === 'moon' ? <Moon size={16} className="text-[#72d1d6]" /> : <Sun size={16} className="text-[#ef7144]" />}
                  </div>
                  <div className="text-[10px] font-mono text-[#d9f36a] mt-1">{spec.environmentTag}</div>
                  <p className="text-xs text-[#bdc9c0] mt-2 leading-relaxed">{spec.description}</p>
                  <div className="mt-3 pt-2 border-t border-white/5 text-[10px] font-mono text-[#9fb1a6]">
                    Max Dose Limit: <strong className="text-white">{spec.radLimit} mSv</strong> · Ice: <strong className="text-white">{spec.iceAvailability * 100}%</strong>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. Habitat Structure Selection */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-mono text-[#72d1d6] font-bold">
            <span>2 · SELECT HABITAT ARCHITECTURE</span>
            <span className="text-[#9fb1a6] text-[10px]">IN-SITU REGOLITH VS. EXPANDABLE SHELL</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {(Object.keys(HABITAT_SPECS) as HabId[]).map(key => {
              const spec = HABITAT_SPECS[key];
              const isSelected = hab === key;
              return (
                <button
                  key={key}
                  onClick={() => { playUiClick(); setHab(key); }}
                  className={`p-3.5 rounded-xl text-left border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'border-[#72d1d6] bg-[#0a272c]'
                      : 'border-white/10 bg-black/40 hover:border-white/20'
                  }`}
                >
                  <div>
                    <span className="font-display font-bold text-sm text-white">{spec.name}</span>
                    <div className="text-[10px] font-mono text-[#72d1d6] mt-0.5">{spec.tagline}</div>
                    <p className="text-xs text-[#9fb1a6] mt-2 leading-relaxed">{spec.description}</p>
                  </div>
                  <div className="mt-3 pt-2 border-t border-white/5 text-[10px] font-mono text-[#bdc9c0]">
                    Shielding: <strong className="text-[#d9f36a]">{spec.baseShielding}%</strong> · Farm: <strong className="text-white">{spec.farmMultiplier * 100}%</strong>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 3. Primary Power System Selection */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-mono text-[#ff9838] font-bold">
            <span>3 · SELECT PRIMARY ELECTRICAL POWER SOURCE</span>
            <span className="text-[#9fb1a6] text-[10px]">SOLAR VS. SURFACE FISSION REACTOR</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {(Object.keys(POWER_SPECS) as PowerId[]).map(key => {
              const spec = POWER_SPECS[key];
              const isSelected = power === key;
              return (
                <button
                  key={key}
                  onClick={() => { playUiClick(); setPower(key); }}
                  className={`p-3.5 rounded-xl text-left border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'border-[#ff9838] bg-[#211b0e]'
                      : 'border-white/10 bg-black/40 hover:border-white/20'
                  }`}
                >
                  <div>
                    <span className="font-display font-bold text-sm text-white">{spec.name}</span>
                    <div className="text-[10px] font-mono text-[#ff9838] mt-0.5">{spec.tagline}</div>
                    <p className="text-xs text-[#9fb1a6] mt-2 leading-relaxed">{spec.description}</p>
                  </div>
                  <div className="mt-3 pt-2 border-t border-white/5 text-[10px] font-mono text-[#bdc9c0]">
                    Day: <strong className="text-white">{spec.dayCapacity} kW</strong> · Night: <strong className="text-[#d9f36a]">{spec.nightCapacity} kW</strong>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. Difficulty Tier */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/10">
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-[#9fb1a6]">DIFFICULTY:</span>
            {(['cadet', 'nominal', 'hardcore'] as DifficultyId[]).map(d => (
              <button
                key={d}
                onClick={() => { playUiClick(); setDifficulty(d); }}
                className={`px-3 py-1 rounded-lg text-xs font-mono font-bold uppercase transition cursor-pointer ${
                  difficulty === d
                    ? 'bg-[#d9f36a] text-[#061211]'
                    : 'bg-white/5 text-[#9fb1a6] border border-white/10 hover:border-white/30'
                }`}
              >
                {d}
              </button>
            ))}
          </div>

          <button
            onClick={startOutpostMission}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#d9f36a] to-[#bde246] hover:from-[#e4fc75] hover:to-[#cbf050] text-[#061211] font-mono font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg transition cursor-pointer"
          >
            <Rocket size={16} />
            <span>COMMENCE MISSION SOL 1</span>
          </button>
        </div>
      </div>
    );
  }

  // =========================================================================
  // VIEW: CONTINGENCY EVENT OVERLAY
  // =========================================================================
  if (phase === 'event' && currentEvent) {
    return (
      <div className="space-y-6 max-w-3xl mx-auto p-5 sm:p-7 bg-[#0b1b1f] border border-[#ef7144] rounded-2xl shadow-2xl animate-in fade-in duration-200">
        <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-widest text-[#ef7144]">
          <AlertTriangle size={18} className="animate-pulse" />
          <span>CRITICAL CONTINGENCY ALERT · SOL {String(state.sol).padStart(2, '0')}</span>
        </div>

        <div>
          <h3 className="font-display font-bold text-xl sm:text-2xl text-white">
            {currentEvent.title}
          </h3>
          <p className="text-sm text-[#eef4e6] mt-2 leading-relaxed">
            {currentEvent.description}
          </p>
        </div>

        <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 text-xs font-mono text-[#bdc9c0] space-y-1">
          <div className="text-[10px] text-[#72d1d6] font-bold uppercase">NASA SCIENTIFIC PRINCIPLE:</div>
          <p className="leading-relaxed">{currentEvent.scientificPrinciple}</p>
        </div>

        {/* Choice Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <button
            onClick={() => handleResolveEvent(currentEvent.choiceA)}
            className="p-4 rounded-xl text-left border border-white/15 bg-[#06171a] hover:border-[#d9f36a] hover:bg-[#0c262a] transition-all cursor-pointer space-y-2 group"
          >
            <div className="font-display font-bold text-sm text-[#eef4e6] group-hover:text-[#d9f36a]">
              [OPTION A] {currentEvent.choiceA.label}
            </div>
            <p className="text-xs text-[#9fb1a6] leading-relaxed">
              {currentEvent.choiceA.scientificContext}
            </p>
            <div className="text-[10px] font-mono text-[#d9f36a] pt-1">
              Consequence: {currentEvent.choiceA.consequenceText}
            </div>
          </button>

          <button
            onClick={() => handleResolveEvent(currentEvent.choiceB)}
            className="p-4 rounded-xl text-left border border-white/15 bg-[#06171a] hover:border-[#ef7144] hover:bg-[#1a1410] transition-all cursor-pointer space-y-2 group"
          >
            <div className="font-display font-bold text-sm text-[#eef4e6] group-hover:text-[#ef7144]">
              [OPTION B] {currentEvent.choiceB.label}
            </div>
            <p className="text-xs text-[#9fb1a6] leading-relaxed">
              {currentEvent.choiceB.scientificContext}
            </p>
            <div className="text-[10px] font-mono text-[#ef7144] pt-1">
              Consequence: {currentEvent.choiceB.consequenceText}
            </div>
          </button>
        </div>
      </div>
    );
  }

  // =========================================================================
  // VIEW: MISSION DEBRIEF REPORT (SUCCESS OR FAILURE)
  // =========================================================================
  if (phase === 'debrief' && missionResult) {
    const isSuccess = missionResult.success;
    return (
      <div className="space-y-6 max-w-3xl mx-auto p-6 sm:p-8 bg-[#040f12] border border-white/10 rounded-2xl shadow-2xl">
        <div className={`p-5 rounded-xl border ${isSuccess ? 'border-[#d9f36a] bg-[#0c2620]' : 'border-[#ef7144] bg-[#220d0a]'}`}>
          <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-widest text-[#d9f36a]">
            {isSuccess ? <Award size={18} /> : <AlertTriangle size={18} className="text-[#ef7144]" />}
            <span>NASA OUTPOST COMMANDER FLIGHT DEBRIEF</span>
          </div>
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-white mt-1">
            {isSuccess ? `Mission Accomplished: 30 Sols Survived!` : `Mission Terminated on Sol ${state.sol}`}
          </h2>
          <p className="text-xs sm:text-sm text-[#bdc9c0] mt-2 leading-relaxed">
            {isSuccess
              ? `Your command of the ${P.name} outpost maintained critical life support, electrical balance, and kept cumulative radiation exposure within safety limits.`
              : missionResult.failureReason}
          </p>
        </div>

        {/* Telemetry Summary */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
          <div className="p-3 rounded-xl bg-white/5 border border-white/5">
            <span className="text-[10px] text-[#9fb1a6] block">FINAL OXYGEN</span>
            <span className="text-base font-bold text-[#72d1d6]">{state.oxygen.toFixed(0)}%</span>
          </div>
          <div className="p-3 rounded-xl bg-white/5 border border-white/5">
            <span className="text-[10px] text-[#9fb1a6] block">WATER STORED</span>
            <span className="text-base font-bold text-[#66d17a]">{state.water.toFixed(0)}%</span>
          </div>
          <div className="p-3 rounded-xl bg-white/5 border border-white/5">
            <span className="text-[10px] text-[#9fb1a6] block">TOTAL DOSE</span>
            <span className={`text-base font-bold ${state.radiationDose > P.radLimit ? 'text-red-400' : 'text-[#ffc93c]'}`}>
              {state.radiationDose.toFixed(1)} / {P.radLimit} mSv
            </span>
          </div>
          <div className="p-3 rounded-xl bg-white/5 border border-white/5">
            <span className="text-[10px] text-[#9fb1a6] block">CREW MORALE</span>
            <span className="text-base font-bold text-[#d9f36a]">{state.crewMorale.toFixed(0)}%</span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-white/10">
          <button
            onClick={() => { playUiClick(); setPhase('setup'); }}
            className="px-4 py-2.5 rounded-xl border border-white/15 bg-white/5 hover:bg-white/10 text-xs font-mono font-bold text-white transition flex items-center gap-2 cursor-pointer"
          >
            <RotateCcw size={14} />
            <span>Re-Configure Outpost</span>
          </button>

          {isSuccess && !rewardClaimed && (
            <button
              onClick={() => {
                setRewardClaimed(true);
                playSuccessChime();
                onSuccess(missionResult.score);
              }}
              className="px-6 py-2.5 rounded-xl bg-[#d9f36a] hover:bg-[#e4fc75] text-[#061211] font-mono font-bold text-xs uppercase flex items-center gap-2 shadow-lg transition cursor-pointer"
            >
              <Sparkles size={15} />
              <span>Claim +{missionResult.score} Mission XP</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  // =========================================================================
  // VIEW: MAIN INTERCONNECTED SIMULATION DASHBOARD
  // =========================================================================
  const sunPct = Math.round(P.getSunlight(state.sol) * modifiers.sunlightMult * 100);

  return (
    <div className="space-y-6 max-w-5xl mx-auto p-4 sm:p-6 bg-[#040f12]/95 border border-[#1b3834] rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.6)] hud-bracket hud-glass backdrop-blur-xl">
      {/* Top Cockpit Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#9fb1a6]">
            <span className="text-[#d9f36a] font-bold">{P.name.toUpperCase()}</span>
            <span>·</span>
            <span>{H.name.toUpperCase()}</span>
            <span>·</span>
            <span className="text-[#ff9838]">{POW.name.toUpperCase()}</span>
          </div>
          <h2 className="font-display font-bold text-xl sm:text-2xl text-white mt-1">
            Outpost Operations Deck
          </h2>
        </div>

        <div className="flex items-center gap-4 self-end sm:self-center">
          <div className="text-right font-mono">
            <span className="text-[10px] text-[#9fb1a6] block uppercase tracking-wider">EXPEDITION CLOCK</span>
            <span className="text-xl sm:text-2xl font-bold text-[#d9f36a]">
              SOL {String(state.sol).padStart(2, '0')}{' '}
              <span className="text-white/30 text-sm font-normal">/ {TOTAL_SOLS}</span>
            </span>
          </div>
        </div>
      </div>

      {/* Environmental Radar Banner */}
      <div className="p-3 rounded-xl bg-gradient-to-r from-[#06151a] via-[#092228] to-[#06151a] border border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <div className="flex items-center gap-2 text-[#9fb1a6]">
          <Sun size={14} className="text-[#ffc93c]" />
          <span>Surface Sunlight:</span>
          <strong className={sunPct < 40 ? 'text-[#ef7144]' : 'text-white'}>{sunPct}%</strong>
          {sunPct < 40 && <span className="text-[10px] text-[#ef7144]">(Lunar Night / Dust Storm Active)</span>}
        </div>
        <div className="flex items-center gap-2 text-[#9fb1a6]">
          <Radiation size={14} className="text-[#ef7144]" />
          <span>Solar Flux:</span>
          <strong className="text-white">{modifiers.flareDose > 0 ? 'HIGH FLARE EVENT' : 'Nominal GCR'}</strong>
        </div>
        <div className="flex items-center gap-2 text-[#9fb1a6]">
          <Activity size={14} className="text-[#72d1d6]" />
          <span>Power Generation:</span>
          <strong className="text-[#d9f36a]">{forecast.powerGen.toFixed(0)} kW</strong>
        </div>
      </div>

      <OutpostScene
        planet={planet}
        habitat={hab}
        sol={state.sol}
        sunlight={sunPct}
        compact
      />

      {/* Primary Life Support Gauges Cluster */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3">
        {/* Battery */}
        <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#9fb1a6]">
            <span className="flex items-center gap-1"><Battery size={13} className="text-[#ffc93c]" />BATTERY</span>
            <span className="text-white font-bold">{state.battery.toFixed(0)}%</span>
          </div>
          <div className="h-2 rounded-full bg-white/10 overflow-hidden">
            <div
              className={`h-full transition-all duration-300 rounded-full progress-shimmer ${state.battery < 20 ? 'bg-red-500 animate-pulse' : 'bg-[#ffc93c]'}`}
              style={{ width: `${state.battery}%` }}
            />
          </div>
          <span className={`text-[10px] font-mono block ${forecast.netPower < 0 ? 'text-[#ef7144]' : 'text-[#66d17a]'}`}>
            {forecast.netPower > 0 ? '+' : ''}{forecast.netPower.toFixed(1)} kW net
          </span>
        </div>

        {/* Oxygen */}
        <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#9fb1a6]">
            <span className="flex items-center gap-1"><Wind size={13} className="text-[#72d1d6]" />OXYGEN</span>
            <span className="text-white font-bold">{state.oxygen.toFixed(0)}%</span>
          </div>
          <div className="h-2 rounded-full bg-white/10 overflow-hidden">
            <div
              className={`h-full transition-all duration-300 rounded-full progress-shimmer ${state.oxygen < 25 ? 'bg-red-500 animate-pulse' : 'bg-[#72d1d6]'}`}
              style={{ width: `${state.oxygen}%` }}
            />
          </div>
          <span className={`text-[10px] font-mono block ${forecast.oxygen - state.oxygen < 0 ? 'text-[#ef7144]' : 'text-[#66d17a]'}`}>
            {(forecast.oxygen - state.oxygen) > 0 ? '+' : ''}{(forecast.oxygen - state.oxygen).toFixed(1)}% / sol
          </span>
        </div>

        {/* Water */}
        <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#9fb1a6]">
            <span className="flex items-center gap-1"><Droplets size={13} className="text-[#66d17a]" />WATER</span>
            <span className="text-white font-bold">{state.water.toFixed(0)}%</span>
          </div>
          <div className="h-2 rounded-full bg-white/10 overflow-hidden">
            <div
              className={`h-full transition-all duration-300 rounded-full progress-shimmer ${state.water < 25 ? 'bg-red-500 animate-pulse' : 'bg-[#66d17a]'}`}
              style={{ width: `${state.water}%` }}
            />
          </div>
          <span className={`text-[10px] font-mono block ${forecast.water - state.water < 0 ? 'text-[#ef7144]' : 'text-[#66d17a]'}`}>
            {(forecast.water - state.water) > 0 ? '+' : ''}{(forecast.water - state.water).toFixed(1)}% / sol
          </span>
        </div>

        {/* Food */}
        <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#9fb1a6]">
            <span className="flex items-center gap-1"><Sprout size={13} className="text-[#d9f36a]" />CROPS</span>
            <span className="text-white font-bold">{state.food.toFixed(0)}%</span>
          </div>
          <div className="h-2 rounded-full bg-white/10 overflow-hidden">
            <div
              className={`h-full transition-all duration-300 rounded-full progress-shimmer ${state.food < 25 ? 'bg-red-500 animate-pulse' : 'bg-[#d9f36a]'}`}
              style={{ width: `${state.food}%` }}
            />
          </div>
          <span className={`text-[10px] font-mono block ${forecast.food - state.food < 0 ? 'text-[#ef7144]' : 'text-[#66d17a]'}`}>
            {(forecast.food - state.food) > 0 ? '+' : ''}{(forecast.food - state.food).toFixed(1)}% / sol
          </span>
        </div>

        {/* Radiation */}
        <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#9fb1a6]">
            <span className="flex items-center gap-1"><Radiation size={13} className="text-[#ef7144]" />DOSE</span>
            <span className="text-white font-bold">{state.radiationDose.toFixed(1)} mSv</span>
          </div>
          <div className="h-2 rounded-full bg-white/10 overflow-hidden">
            <div
              className={`h-full transition-all duration-300 rounded-full progress-shimmer ${state.radiationDose > P.radLimit * 0.75 ? 'bg-red-500' : 'bg-[#ef7144]'}`}
              style={{ width: `${Math.min(100, (state.radiationDose / P.radLimit) * 100)}%` }}
            />
          </div>
          <span className="text-[10px] font-mono text-[#9fb1a6] block">
            Limit: {P.radLimit} mSv max
          </span>
        </div>

        {/* Crew Morale */}
        <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#9fb1a6]">
            <span className="flex items-center gap-1"><Heart size={13} className="text-pink-400" />MORALE</span>
            <span className="text-white font-bold">{state.crewMorale.toFixed(0)}%</span>
          </div>
          <div className="h-2 rounded-full bg-white/10 overflow-hidden">
            <div
              className="h-full transition-all duration-300 rounded-full bg-pink-400 progress-shimmer"
              style={{ width: `${state.crewMorale}%` }}
            />
          </div>
          <span className="text-[10px] font-mono text-[#9fb1a6] block">
            4 Expeditioners
          </span>
        </div>
      </div>

      {/* Brownout Alert Banner */}
      {forecast.isBrownout && (
        <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/50 flex items-center gap-2.5 text-xs font-mono text-red-200">
          <AlertTriangle size={16} className="text-red-400 shrink-0 animate-bounce" />
          <span>CRITICAL BROWNOUT PREDICTED: Battery depleting. Life support systems and hydroponics will drop to 35% efficiency. Assign crew to Power or reduce loads immediately!</span>
        </div>
      )}

      {/* Crew Allocation Control Deck */}
      <div className="p-4 sm:p-5 rounded-xl bg-black/40 border border-white/10 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
          <div>
            <div className="text-[10px] font-mono text-[#d9f36a] uppercase font-bold tracking-wider">
              DAILY CREW-HOUR ASSIGNMENT
            </div>
            <div className="text-xs text-[#9fb1a6] mt-0.5">
              4-Astronaut Expedition (8 productive hours nominal baseline). Allocate time across vital life-support subsystems.
            </div>
          </div>
          <div className="text-xs font-mono font-bold text-white bg-white/10 px-3 py-1.5 rounded-lg border border-white/10 self-start sm:self-auto">
            AVAILABLE: <span className={availableHours - allocatedHours === 0 ? 'text-[#66d17a]' : 'text-[#d9f36a]'}>{availableHours - allocatedHours}</span> OF {availableHours} HOURS
          </div>
        </div>

        {/* Sliders Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
          {/* Power Upkeep */}
          <div className="p-3 rounded-lg bg-white/5 border border-white/5 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 text-white font-bold">
                <Zap size={14} className="text-[#ffc93c]" />
                <span>Power Systems Upkeep</span>
              </div>
              <div className="text-[10px] text-[#9fb1a6] mt-0.5">+8% generation efficiency per hour</div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => handleAdjustHours('power', -1)} className="w-7 h-7 rounded border border-white/20 grid place-items-center hover:bg-white/10 cursor-pointer">
                <Minus size={13} />
              </button>
              <span className="w-5 text-center font-bold text-[#d9f36a]">{alloc.power}h</span>
              <button onClick={() => handleAdjustHours('power', 1)} className="w-7 h-7 rounded border border-white/20 grid place-items-center hover:bg-white/10 cursor-pointer">
                <Plus size={13} />
              </button>
            </div>
          </div>

          {/* Life Support */}
          <div className="p-3 rounded-lg bg-white/5 border border-white/5 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 text-white font-bold">
                <Wind size={14} className="text-[#72d1d6]" />
                <span>ECLSS Oxygen Generation</span>
              </div>
              <div className="text-[10px] text-[#9fb1a6] mt-0.5">+4.2% oxygen production per hour</div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => handleAdjustHours('lifeSupport', -1)} className="w-7 h-7 rounded border border-white/20 grid place-items-center hover:bg-white/10 cursor-pointer">
                <Minus size={13} />
              </button>
              <span className="w-5 text-center font-bold text-[#d9f36a]">{alloc.lifeSupport}h</span>
              <button onClick={() => handleAdjustHours('lifeSupport', 1)} className="w-7 h-7 rounded border border-white/20 grid place-items-center hover:bg-white/10 cursor-pointer">
                <Plus size={13} />
              </button>
            </div>
          </div>

          {/* Water & Ice ISRU */}
          <div className="p-3 rounded-lg bg-white/5 border border-white/5 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 text-white font-bold">
                <Droplets size={14} className="text-[#66d17a]" />
                <span>Water Recycling &amp; Ice ISRU</span>
              </div>
              <div className="text-[10px] text-[#9fb1a6] mt-0.5">+4.5% water recycling &amp; melt per hour</div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => handleAdjustHours('water', -1)} className="w-7 h-7 rounded border border-white/20 grid place-items-center hover:bg-white/10 cursor-pointer">
                <Minus size={13} />
              </button>
              <span className="w-5 text-center font-bold text-[#d9f36a]">{alloc.water}h</span>
              <button onClick={() => handleAdjustHours('water', 1)} className="w-7 h-7 rounded border border-white/20 grid place-items-center hover:bg-white/10 cursor-pointer">
                <Plus size={13} />
              </button>
            </div>
          </div>

          {/* Hydroponic Farming */}
          <div className="p-3 rounded-lg bg-white/5 border border-white/5 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 text-white font-bold">
                <Sprout size={14} className="text-[#d9f36a]" />
                <span>Hydroponic Greenhouse</span>
              </div>
              <div className="text-[10px] text-[#9fb1a6] mt-0.5">+3.8% fresh crop biomass per hour</div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => handleAdjustHours('farm', -1)} className="w-7 h-7 rounded border border-white/20 grid place-items-center hover:bg-white/10 cursor-pointer">
                <Minus size={13} />
              </button>
              <span className="w-5 text-center font-bold text-[#d9f36a]">{alloc.farm}h</span>
              <button onClick={() => handleAdjustHours('farm', 1)} className="w-7 h-7 rounded border border-white/20 grid place-items-center hover:bg-white/10 cursor-pointer">
                <Plus size={13} />
              </button>
            </div>
          </div>

          {/* Radiation Shielding */}
          <div className="p-3 rounded-lg bg-white/5 border border-white/5 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 text-white font-bold">
                <Shield size={14} className="text-[#9fb1a6]" />
                <span>Regolith Berm Sintering</span>
              </div>
              <div className="text-[10px] text-[#9fb1a6] mt-0.5">+3.5% radiation shielding per hour</div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => handleAdjustHours('shield', -1)} className="w-7 h-7 rounded border border-white/20 grid place-items-center hover:bg-white/10 cursor-pointer">
                <Minus size={13} />
              </button>
              <span className="w-5 text-center font-bold text-[#d9f36a]">{alloc.shield}h</span>
              <button onClick={() => handleAdjustHours('shield', 1)} className="w-7 h-7 rounded border border-white/20 grid place-items-center hover:bg-white/10 cursor-pointer">
                <Plus size={13} />
              </button>
            </div>
          </div>

          {/* Rest & Morale */}
          <div className="p-3 rounded-lg bg-white/5 border border-white/5 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 text-white font-bold">
                <Heart size={14} className="text-pink-400" />
                <span>Crew Rest &amp; Medical Check</span>
              </div>
              <div className="text-[10px] text-[#9fb1a6] mt-0.5">+2.5% psychological morale recovery</div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => handleAdjustHours('rest', -1)} className="w-7 h-7 rounded border border-white/20 grid place-items-center hover:bg-white/10 cursor-pointer">
                <Minus size={13} />
              </button>
              <span className="w-5 text-center font-bold text-[#d9f36a]">{alloc.rest}h</span>
              <button onClick={() => handleAdjustHours('rest', 1)} className="w-7 h-7 rounded border border-white/20 grid place-items-center hover:bg-white/10 cursor-pointer">
                <Plus size={13} />
              </button>
            </div>
          </div>
        </div>

        {/* Advance Sol Button */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs font-mono text-[#9fb1a6]">
            Every choice alters tomorrow&apos;s survival probability. Review telemetry forecast before committing.
          </div>
          <button
            onClick={advanceSol}
            className="w-full sm:w-auto px-8 py-3 rounded-xl bg-[#d9f36a] hover:bg-[#cbf050] text-[#061211] font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition cursor-pointer"
          >
            <span>Simulate Sol {state.sol} &rarr; Sol {state.sol + 1}</span>
          </button>
        </div>
      </div>

      {/* Decision Log and Mission Chronology */}
      {solLog.length > 0 && (
        <div className="p-4 rounded-xl bg-black/30 border border-white/5 space-y-2">
          <div className="text-[10px] font-mono text-[#9fb1a6] uppercase font-bold tracking-wider">
            OUTPOST FLIGHT LOG (RECENT SOLS)
          </div>
          <div className="space-y-1 max-h-32 overflow-y-auto pr-1">
            {solLog.map((logLine, idx) => (
              <div key={idx} className="text-[11px] font-mono text-[#bdc9c0] leading-snug">
                {logLine}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
