import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Rocket,
  Compass,
  Eye,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Zap,
  Award,
  Layers,
  ArrowRight,
  ShieldCheck,
  Volume2,
  VolumeX,
  Gauge,
  Flame,
  Radio,
  Clock,
  ChevronRight,
  ExternalLink,
  BookOpen,
  Sliders,
  RefreshCw,
  Search,
  Crosshair,
  Lock,
  Unlock,
  Check,
  Maximize2
} from 'lucide-react';
import { AstronautProfile } from '../types';
import {
  playUiClick,
  playRcsThrusterSound,
  playDockingLatchSound,
  playErrorAlert,
  playSuccessChime,
  playRocketLaunchSound,
  playQuindarTone,
  playGrandFanfare,
  playTone,
} from '../utils/audio';
import { fireMissionConfetti } from '../utils/confetti';
import { ApodReward } from './nasa/ApodReward';
import { ChecklistPhotoLog } from './nasa/ChecklistPhotoLog';
import { EpicObservation } from './nasa/EpicObservation';
import { NtrsSources } from './nasa/NtrsSources';

interface AstronautTrainerProps {
  profile: AstronautProfile | null;
  onUpdateProfile?: (updated: AstronautProfile) => void;
  onBackToDeck: () => void;
}

// ---------------------------------------------------------------------------
// NASA CITATION ARCHIVE: Every fact is traceable to official NASA sources
// ---------------------------------------------------------------------------
interface NasaCitation {
  id: string;
  missionNumber: 1 | 2 | 3;
  topic: string;
  sourceDoc: string;
  nasaRefCode: string;
  fact: string;
  url?: string;
}

const NASA_CITATIONS: NasaCitation[] = [
  {
    id: 'cabin-press',
    missionNumber: 1,
    topic: 'Cabin Atmospheric Pressure (14.7 psi)',
    sourceDoc: 'NASA-STD-3001, Vol. 2: Space Flight Human-System Standard',
    nasaRefCode: 'NASA-STD-3001 §6.2.1 Atmosphere Specification',
    fact: 'NASA crew vehicles (Apollo command module pre-launch, Space Shuttle, Orion, Crew Dragon) establish a sea-level equivalent 14.7 psi (101.3 kPa) mixed atmosphere (21% O2, 79% N2) to avoid pure-oxygen fire hazards and decompression sickness.',
  },
  {
    id: 'cryo-valves',
    missionNumber: 1,
    topic: 'Cryogenic Propellant Isolation & Purge',
    sourceDoc: 'NASA SP-4029: Space Shuttle Launch Countdown Operations',
    nasaRefCode: 'NASA Terminal Countdown Demonstration Test (TCDT) Step 4.2',
    fact: 'Liquid Hydrogen (-253°C) and Liquid Oxygen (-183°C) fill and drain umbilical lines must be purged with high-pressure gaseous helium and isolated with mechanical safety locks before ignition to prevent explosive boil-off backpressure.',
  },
  {
    id: 'gimbal-hydraulics',
    missionNumber: 1,
    topic: 'Thrust Vector Control (TVC) Actuator Sweep (3,000 psi)',
    sourceDoc: 'NASA SLS Flight Systems Operations Manual, Rev B, §5.3',
    nasaRefCode: 'NASA TM-2020-220491: TVC Hydraulic Power Unit Qualification',
    fact: 'Rocket engines steer by physically gimbaling (tilting) their nozzles up to ±5° using hydraulic or electromechanical actuators operating at 3,000 psi. At T-45 seconds, flight computers cycle all nozzles through full range of motion.',
  },
  {
    id: 'abort-pyros',
    missionNumber: 1,
    topic: 'Launch Abort System (LAS) Pyrotechnic Arming',
    sourceDoc: 'NASA Orion Crew Exploration Vehicle Flight Test (Orion PA-1)',
    nasaRefCode: 'NASA/TM-2010-216447: Launch Abort System Flight Test Results',
    fact: 'The Launch Abort System solid motor tower can pull the astronaut capsule away from a failing booster at 15g acceleration in under 2 seconds. The pyrotechnic igniters are armed from Safe to Armed at T-90s via dual-inhibit switches.',
  },
  {
    id: 'imu-align',
    missionNumber: 1,
    topic: 'Inertial Measurement Unit (IMU) Gyro Drift Calibration',
    sourceDoc: 'Apollo 11 Flight Plan, Section 3-2 "Terminal Pre-Launch Alignment"',
    nasaRefCode: 'NASA SP-2008-568: GN&C Flight Operations Handbook',
    fact: 'Before launch, three orthogonal ring-laser gyros and accelerometers align with Earth rotation. Drift rate must measure less than 0.015° per hour to ensure the orbital insertion burn hits the planned pericenter within 0.1%.',
  },
  {
    id: 's-band-comm',
    missionNumber: 1,
    topic: 'Spacecraft S-Band Radio Link (2287.5 MHz)',
    sourceDoc: 'NASA Space Communications and Navigation (SCaN) Architecture',
    nasaRefCode: 'NASA-SP-2014-5001 SCaN Reference Manual §3.1',
    fact: 'NASA space-to-ground voice, telemetry, and abort commands use S-Band radio frequencies (2200–2290 MHz uplink/downlink). The flight transponder locks to Launch Control Center Kennedy at 2287.5 MHz with bi-phase phase-shift keying.',
  },
  {
    id: 'idss-standard',
    missionNumber: 2,
    topic: 'International Docking System Standard (IDSS)',
    sourceDoc: 'NASA International Docking System Standard Interface Definition (Rev E)',
    nasaRefCode: 'IDSS IDD Rev E, Section 3.2.1 Capture Tolerances',
    fact: 'IDSS governs modern docking for the ISS, Crew Dragon, Starliner, and Artemis Gateway. Capture criteria mandate lateral misalignment < 0.20 m, angular error < 2.5°, and contact velocity between 0.03 m/s and 0.12 m/s.',
  },
  {
    id: 'rcs-physics',
    missionNumber: 2,
    topic: 'Reaction Control System (RCS) Zero-Gravity Inertia',
    sourceDoc: 'NASA/TP-2014-218556: ISS Automated and Manual Rendezvous & Proximity Operations',
    nasaRefCode: 'NASA JSC Flight Operations Directorate (FOD-ISS-341)',
    fact: 'In orbital microgravity, Newton’s 1st Law governs all movement: an RCS thruster impulse introduces a velocity vector that never decays until counter-thrust is fired. Astronauts must never hold thrusters continuously, but fire pulsed burns.',
  },
  {
    id: 'cupola-ceo',
    missionNumber: 3,
    topic: 'Crew Earth Observations (CEO) from the ISS Cupola',
    sourceDoc: 'NASA Johnson Space Center Earth Science & Remote Sensing Unit',
    nasaRefCode: 'NASA RP-1280: Astronaut Earth Observation Field Manual',
    fact: 'The ISS Cupola provides a 360° panoramic view of Earth. Astronauts use Nikon digital SLRs with 800mm lenses to document dynamic geological formations, tropical cyclone storm tracks, auroras, and human development.',
  },
  {
    id: 'richat-structure',
    missionNumber: 3,
    topic: 'Richat Structure "Eye of the Sahara" (Mauritania)',
    sourceDoc: 'NASA Earth Observatory Record EO-10255',
    nasaRefCode: 'NASA ISS Crew Photography Catalog ISS064-E-29177',
    fact: 'The 40 km wide circular dome in the Sahara was initially thought to be a meteorite crater, but NASA field studies proved it is a deeply eroded alkaline igneous and sedimentary uplift dome, serving as a primary astronaut visual benchmark.',
  },
  {
    id: 'grand-canyon',
    missionNumber: 3,
    topic: 'Grand Canyon Geological Incision (Arizona, USA)',
    sourceDoc: 'NASA Earth Observatory / USGS Joint Remote Sensing Report',
    nasaRefCode: 'NASA ISS062-E-104921 Earth Observation Log',
    fact: 'From 420 km altitude, the distinct stratigraphy of the Colorado Plateau reveals nearly 2 billion years of Earth’s geological record. The Colorado River carved the 1.6 km deep chasm primarily during the last 5 to 6 million years.',
  },
  {
    id: 'super-typhoon',
    missionNumber: 3,
    topic: 'Tropical Cyclone Eyewall & Coriolis Vortex',
    sourceDoc: 'NASA Earth Applied Sciences & NASA Disasters Program',
    nasaRefCode: 'NASA ISS065-E-182390 Crew Weather Monitoring',
    fact: 'Astronauts gauge storm strength by photographing the circular stadium effect in the eyewall. Cloud towers rise over 18 km into the stratosphere, and the eye remains calm while outer spiraling bands drive 250+ km/h sustained winds.',
  },
  {
    id: 'nile-at-night',
    missionNumber: 3,
    topic: 'Nile River Delta & Suez Canal Luminous Footprint',
    sourceDoc: 'NASA Gateway to Astronaut Photography of Earth (eol.jsc.nasa.gov)',
    nasaRefCode: 'NASA ISS063-E-80412 Night Earth Imagery Catalog',
    fact: 'At night, 95% of Egypt’s population is illuminated along the narrow, ribbon-like floodplain of the Nile River and Delta, creating a vivid contrast with the unpopulated desert. The Suez Canal shows up as a bright transit line linking seas.',
  },
  {
    id: 'great-barrier-reef',
    missionNumber: 3,
    topic: 'Great Barrier Reef Coral Morphology (Australia)',
    sourceDoc: 'NASA Earth Observatory EO-89211 & Coral Reef Bleaching Study',
    nasaRefCode: 'NASA ISS053-E-314051 Marine Remote Sensing',
    fact: 'Spanning over 2,300 km, the Great Barrier Reef is the largest structure composed of living organisms on Earth. Astronaut photography documents shallow turquoise lagoon bleaching and sediment runoff into deep blue Coral Sea depths.',
  },
];

// ---------------------------------------------------------------------------
// BADGES DEFINITIONS
// ---------------------------------------------------------------------------
interface Badge {
  id: string;
  title: string;
  mission: string;
  icon: string;
  color: string;
  criteria: string;
  nasaRef: string;
}

const TRAINER_BADGES: Badge[] = [
  {
    id: 'badge-launch',
    title: 'Launch Systems Specialist',
    mission: 'Mission 1: T-Minus Checklist',
    icon: '⚡',
    color: '#ff9838',
    criteria: 'Configured all 6 critical launch subsystems within the 60-second window without aborting.',
    nasaRef: 'NASA SP-2008-568 Flight Crew Operations Checklist Certification',
  },
  {
    id: 'badge-docking',
    title: 'Orbital Docking Master',
    mission: 'Mission 2: ISS Rendezvous',
    icon: '🚀',
    color: '#72d1d6',
    criteria: 'Docked spacecraft to ISS Harmony Port within IDSS tolerances (|X,Y| < 0.2m, angle < 2.5°, speed < 0.12 m/s).',
    nasaRef: 'NASA International Docking System Standard (IDSS) Rev E',
  },
  {
    id: 'badge-observer',
    title: 'Lead Earth Observer',
    mission: 'Mission 3: Earth Observation',
    icon: '🌍',
    color: '#66d17a',
    criteria: 'Successfully surveyed and identified 4 NASA planetary and geological sites from the Cupola.',
    nasaRef: 'NASA Johnson Space Center Crew Earth Observations (CEO) Protocol',
  },
  {
    id: 'badge-wings',
    title: 'Junior Astronaut Wings',
    mission: 'Full Academy Qualification',
    icon: '⭐',
    color: '#d9f36a',
    criteria: 'Completed all 3 core training simulations. Certified for orbital spaceflight.',
    nasaRef: 'NASA Astronaut Candidate (ASCAN) Class Flight Qualification',
  },
];

export const AstronautTrainer: React.FC<AstronautTrainerProps> = ({
  profile,
  onUpdateProfile,
  onBackToDeck,
}) => {
  // Navigation within the trainer
  const [activeTab, setActiveTab] = useState<'hub' | 'm1' | 'm2' | 'm3' | 'badges' | 'citations'>('hub');
  
  // Stored state for badge completions
  const [unlockedBadges, setUnlockedBadges] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('cosmora_trainer_badges');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [activeCitation, setActiveCitation] = useState<NasaCitation | null>(null);

  // Helper to unlock badges
  const unlockBadge = useCallback((badgeId: string) => {
    setUnlockedBadges(prev => {
      if (prev.includes(badgeId)) return prev;
      const updated = [...prev, badgeId];
      try {
        localStorage.setItem('cosmora_trainer_badges', JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }
      playGrandFanfare();
      fireMissionConfetti();

      // Check if all 3 missions done -> unlock wings
      if (
        updated.includes('badge-launch') &&
        updated.includes('badge-docking') &&
        updated.includes('badge-observer') &&
        !updated.includes('badge-wings')
      ) {
        setTimeout(() => {
          setUnlockedBadges(all => {
            const withWings = [...all, 'badge-wings'];
            localStorage.setItem('cosmora_trainer_badges', JSON.stringify(withWings));
            playSuccessChime();
            return withWings;
          });
        }, 1500);
      }

      // Add points to profile
      if (profile && onUpdateProfile) {
        const bonusXP = 40;
        const newProfile = {
          ...profile,
          points: profile.points + bonusXP,
          achievements: [...(profile.achievements || []), badgeId],
        };
        onUpdateProfile(newProfile);
      }

      return updated;
    });
  }, [profile, onUpdateProfile]);

  // =========================================================================
  // MISSION 1: PRE-LAUNCH CHECKLIST UNDER TIME PRESSURE
  // =========================================================================
  const [m1Timer, setM1Timer] = useState(60);
  const [m1Running, setM1Running] = useState(false);
  const [m1Completed, setM1Completed] = useState(false);
  const [m1Failed, setM1Failed] = useState(false);
  const [m1FailReason, setM1FailReason] = useState('');

  // 6 checklist states
  const [m1CabinPress, setM1CabinPress] = useState(10.2); // Target: 14.7 psi
  const [m1CabinBleedOpen, setM1CabinBleedOpen] = useState(false);
  const [m1CryoLocked, setM1CryoLocked] = useState(false);
  const [m1GimbalPressure, setM1GimbalPressure] = useState(600); // Target: 3000 psi
  const [m1GimbalHolding, setM1GimbalHolding] = useState(false);
  const [m1LasArmed, setM1LasArmed] = useState(false);
  const [m1LasCoverOpen, setM1LasCoverOpen] = useState(false);
  const [m1ImuAligned, setM1ImuAligned] = useState(false);
  const [m1CommFrequency, setM1CommFrequency] = useState(2210.0); // Target: 2287.5 MHz
  const [m1CommLocked, setM1CommLocked] = useState(false);

  // Check overall launch checklist state
  const isCabinGo = m1CabinPress >= 14.4 && m1CabinPress <= 15.0;
  const isCryoGo = m1CryoLocked;
  const isGimbalGo = m1GimbalPressure >= 2950;
  const isLasGo = m1LasArmed;
  const isImuGo = m1ImuAligned;
  const isCommGo = m1CommLocked;
  const allSystemsGo = isCabinGo && isCryoGo && isGimbalGo && isLasGo && isImuGo && isCommGo;

  // Launch countdown loop
  useEffect(() => {
    if (!m1Running || m1Completed || m1Failed) return;

    const interval = setInterval(() => {
      setM1Timer(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setM1Running(false);
          setM1Failed(true);
          setM1FailReason('COUNTDOWN EXPIRED AT T-00:00 · Subsystems not in GO status in time.');
          playErrorAlert();
          return 0;
        }
        // Audible ticks in last 10 seconds
        if (prev <= 10) {
          playTone(880, 0.05, 'square');
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [m1Running, m1Completed, m1Failed]);

  // Cabin pressurization physics when bleed is open
  useEffect(() => {
    if (!m1Running || m1Completed) return;
    if (m1CabinBleedOpen && m1CabinPress < 14.7) {
      const interval = setInterval(() => {
        setM1CabinPress(p => {
          const next = Math.min(14.7, Number((p + 0.3).toFixed(1)));
          if (next >= 14.7) {
            playQuindarTone('intro');
          }
          return next;
        });
      }, 100);
      return () => clearInterval(interval);
    }
  }, [m1Running, m1CabinBleedOpen, m1CabinPress, m1Completed]);

  // Gimbal hydraulic sweep test button hold
  useEffect(() => {
    if (!m1Running || m1Completed) return;
    if (m1GimbalHolding && m1GimbalPressure < 3000) {
      const interval = setInterval(() => {
        setM1GimbalPressure(p => {
          const next = Math.min(3000, p + 160);
          if (next >= 3000) {
            playSuccessChime();
          }
          return next;
        });
      }, 80);
      return () => clearInterval(interval);
    }
  }, [m1Running, m1GimbalHolding, m1GimbalPressure, m1Completed]);

  // Check completion
  useEffect(() => {
    if (allSystemsGo && m1Running && !m1Completed) {
      setM1Completed(true);
      setM1Running(false);
      playRocketLaunchSound();
      playSuccessChime();
      unlockBadge('badge-launch');
    }
  }, [allSystemsGo, m1Running, m1Completed, unlockBadge]);

  const startMission1 = () => {
    playUiClick();
    playQuindarTone('intro');
    setM1Timer(60);
    setM1Running(true);
    setM1Completed(false);
    setM1Failed(false);
    setM1FailReason('');
    setM1CabinPress(10.2);
    setM1CabinBleedOpen(false);
    setM1CryoLocked(false);
    setM1GimbalPressure(600);
    setM1GimbalHolding(false);
    setM1LasArmed(false);
    setM1LasCoverOpen(false);
    setM1ImuAligned(false);
    setM1CommFrequency(2210.0);
    setM1CommLocked(false);
  };

  // =========================================================================
  // MISSION 2: DOCKING ALIGNMENT GAME (6-DOF IDSS STANDARD)
  // =========================================================================
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [m2Active, setM2Active] = useState(false);
  const [m2Completed, setM2Completed] = useState(false);
  const [m2Aborted, setM2Aborted] = useState(false);
  const [m2AbortReason, setM2AbortReason] = useState('');

  // Dynamics
  const [rangeZ, setRangeZ] = useState(30.0); // meters from port
  const [velZ, setVelZ] = useState(0.24); // closure speed (m/s)
  const [devX, setDevX] = useState(4.2); // lateral X offset (m)
  const [devY, setDevY] = useState(-3.5); // vertical Y offset (m)
  const [rateX, setRateX] = useState(-0.06); // m/s drift X
  const [rateY, setRateY] = useState(0.04); // m/s drift Y
  const [pitchAngle, setPitchAngle] = useState(5.8); // deg
  const [yawAngle, setYawAngle] = useState(-4.2); // deg
  const [rollAngle, setRollAngle] = useState(8.5); // deg
  const [pitchRate, setPitchRate] = useState(-0.08); // deg/s
  const [yawRate, setYawRate] = useState(0.06); // deg/s
  const [rollRate, setRollRate] = useState(-0.05); // deg/s
  const [rcsFuel, setRcsFuel] = useState(100); // %
  const [floodlightOn, setFloodlightOn] = useState(true);
  const [sasHold, setSasHold] = useState(false);

  // Thruster fire animations
  const [lastThrust, setLastThrust] = useState<string | null>(null);

  const resetMission2 = () => {
    playUiClick();
    setM2Active(true);
    setM2Completed(false);
    setM2Aborted(false);
    setM2AbortReason('');
    setRangeZ(30.0);
    setVelZ(0.22);
    setDevX(4.5);
    setDevY(-3.8);
    setRateX(-0.07);
    setRateY(0.05);
    setPitchAngle(6.2);
    setYawAngle(-4.5);
    setRollAngle(8.0);
    setPitchRate(-0.06);
    setYawRate(0.05);
    setRollRate(-0.04);
    setRcsFuel(100);
    setSasHold(false);
  };

  // RCS Input handlers
  const fireRcs = (axis: 'tx+' | 'tx-' | 'ty+' | 'ty-' | 'tz+' | 'tz-' | 'pitch+' | 'pitch-' | 'yaw+' | 'yaw-' | 'roll+' | 'roll-') => {
    if (!m2Active || m2Completed || m2Aborted) return;
    if (rcsFuel <= 0) return;

    playRcsThrusterSound();
    setRcsFuel(f => Math.max(0, f - 0.7));
    setLastThrust(axis);
    setTimeout(() => setLastThrust(null), 180);

    const deltaV = 0.04;
    const deltaDeg = 0.45;

    switch (axis) {
      case 'tx+': setRateX(r => r + deltaV); break;
      case 'tx-': setRateX(r => r - deltaV); break;
      case 'ty+': setRateY(r => r + deltaV); break;
      case 'ty-': setRateY(r => r - deltaV); break;
      case 'tz+': setVelZ(v => Math.min(0.40, v + 0.03)); break;
      case 'tz-': setVelZ(v => Math.max(-0.10, v - 0.03)); break;
      case 'pitch+': setPitchRate(r => r + deltaDeg); break;
      case 'pitch-': setPitchRate(r => r - deltaDeg); break;
      case 'yaw+': setYawRate(r => r + deltaDeg); break;
      case 'yaw-': setYawRate(r => r - deltaDeg); break;
      case 'roll+': setRollRate(r => r + deltaDeg); break;
      case 'roll-': setRollRate(r => r - deltaDeg); break;
    }
  };

  // Keyboard controls for docking
  useEffect(() => {
    if (!m2Active || m2Completed || m2Aborted) return;

    const onKeyDown = (e: KeyboardEvent) => {
      // Avoid scrolling
      if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyQ', 'KeyE', 'KeyR', 'KeyF', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        e.preventDefault();
      }
      switch (e.code) {
        case 'KeyW': fireRcs('ty+'); break;
        case 'KeyS': fireRcs('ty-'); break;
        case 'KeyA': fireRcs('tx-'); break;
        case 'KeyD': fireRcs('tx+'); break;
        case 'KeyR': fireRcs('tz+'); break; // forward closure
        case 'KeyF': fireRcs('tz-'); break; // retard brake
        case 'ArrowUp': fireRcs('pitch+'); break;
        case 'ArrowDown': fireRcs('pitch-'); break;
        case 'ArrowLeft': fireRcs('yaw-'); break;
        case 'ArrowRight': fireRcs('yaw+'); break;
        case 'KeyQ': fireRcs('roll-'); break;
        case 'KeyE': fireRcs('roll+'); break;
        case 'Space':
          playUiClick();
          setSasHold(s => !s);
          break;
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [m2Active, m2Completed, m2Aborted, rcsFuel]);

  // Docking Physics integration loop
  useEffect(() => {
    if (!m2Active || m2Completed || m2Aborted) return;

    const dt = 0.05; // 50ms tick
    const interval = setInterval(() => {
      // Update Range
      setRangeZ(rz => {
        const nextRange = rz - velZ * dt;

        // Check for contact at 0.15m
        if (nextRange <= 0.20) {
          // IDSS tolerances:
          // Centerline error < 0.25m
          // Pitch / Yaw < 3.0 deg
          // Roll < 4.5 deg
          // Velocity between 0.02 and 0.14 m/s
          const inLateral = Math.abs(devX) <= 0.25 && Math.abs(devY) <= 0.25;
          const inAngle = Math.abs(pitchAngle) <= 3.0 && Math.abs(yawAngle) <= 3.0 && Math.abs(rollAngle) <= 4.5;
          const inSpeed = velZ >= 0.02 && velZ <= 0.15;

          if (inLateral && inAngle && inSpeed) {
            setM2Completed(true);
            setM2Active(false);
            playDockingLatchSound();
            playSuccessChime();
            fireMissionConfetti();
            unlockBadge('badge-docking');
            return 0.0;
          } else {
            setM2Aborted(true);
            setM2Active(false);
            playErrorAlert();
            if (!inLateral) {
              setM2AbortReason(`LATERAL OFFSET FAULT (|X|=${Math.abs(devX).toFixed(2)}m, |Y|=${Math.abs(devY).toFixed(2)}m > 0.25m IDSS max).`);
            } else if (!inAngle) {
              setM2AbortReason(`ANGULAR MISALIGNMENT FAULT (Pitch/Yaw=${Math.max(Math.abs(pitchAngle), Math.abs(yawAngle)).toFixed(1)}° > 3.0° max).`);
            } else {
              setM2AbortReason(`IMPACT VELOCITY EXCEEDED (${velZ.toFixed(2)} m/s > 0.15 m/s threshold). Soft latch rebound.`);
            }
            return 0.2;
          }
        }
        return nextRange;
      });

      // Update offsets
      setDevX(x => x + rateX * dt);
      setDevY(y => y + rateY * dt);
      setPitchAngle(p => p + pitchRate * dt);
      setYawAngle(y => y + yawRate * dt);
      setRollAngle(r => r + rollRate * dt);

      // Automated SAS dampening if active
      if (sasHold) {
        setRateX(rx => rx * 0.96);
        setRateY(ry => ry * 0.96);
        setPitchRate(pr => pr * 0.95);
        setYawRate(yr => yr * 0.95);
        setRollRate(rr => rr * 0.95);
      }
    }, 50);

    return () => clearInterval(interval);
  }, [m2Active, m2Completed, m2Aborted, velZ, devX, devY, rateX, rateY, pitchAngle, yawAngle, rollAngle, pitchRate, yawRate, rollRate, sasHold, unlockBadge]);

  // Canvas drawing for Mission 2 Docking Viewport
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width = canvas.clientWidth * window.devicePixelRatio;
    const h = canvas.height = canvas.clientHeight * window.devicePixelRatio;

    ctx.save();
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    const cw = canvas.clientWidth;
    const ch = canvas.clientHeight;

    // Deep space background with starfield
    ctx.fillStyle = '#030809';
    ctx.fillRect(0, 0, cw, ch);

    // Earth limb curve in the background
    const earthY = ch * 0.88 + pitchAngle * 3;
    const earthGrad = ctx.createLinearGradient(0, earthY - 40, 0, ch);
    earthGrad.addColorStop(0, 'rgba(56, 189, 248, 0.25)'); // atmospheric glow
    earthGrad.addColorStop(0.15, 'rgba(14, 116, 144, 0.4)');
    earthGrad.addColorStop(0.6, '#082f49');
    earthGrad.addColorStop(1, '#02182b');
    ctx.fillStyle = earthGrad;
    ctx.beginPath();
    ctx.ellipse(cw / 2 - yawAngle * 4, earthY + 120, cw * 0.9, 160, (rollAngle * Math.PI) / 180, 0, Math.PI * 2);
    ctx.fill();

    // Orbital clouds on earth
    ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.beginPath();
    ctx.ellipse(cw * 0.45 - yawAngle * 3, earthY + 70, cw * 0.35, 30, (rollAngle * Math.PI) / 180, 0, Math.PI * 2);
    ctx.fill();

    // 3D Perspective of ISS Docking Target
    // As distance shrinks from 30m -> 0m, the docking target grows
    const targetScale = Math.min(4.5, Math.max(0.6, (32 - rangeZ) / 7));
    const centerX = cw / 2 + (devX * 24) * (targetScale * 0.5) + (yawAngle * 2.5);
    const centerY = ch / 2 - (devY * 24) * (targetScale * 0.5) + (pitchAngle * 2.5);

    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.rotate((-rollAngle * Math.PI) / 180);

    // ISS Module Hull in background (Cylindrical Harmony module)
    const hullR = 75 * targetScale;
    ctx.fillStyle = '#1e293b';
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 2 * targetScale;
    ctx.beginPath();
    ctx.arc(0, 0, hullR * 1.35, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Solar panels arms in background
    ctx.fillStyle = '#0f172a';
    ctx.strokeStyle = '#0284c7';
    ctx.lineWidth = 1.5;
    ctx.fillRect(-hullR * 2.4, -hullR * 0.3, hullR * 1.1, hullR * 0.6);
    ctx.strokeRect(-hullR * 2.4, -hullR * 0.3, hullR * 1.1, hullR * 0.6);
    ctx.fillRect(hullR * 1.3, -hullR * 0.3, hullR * 1.1, hullR * 0.6);
    ctx.strokeRect(hullR * 1.3, -hullR * 0.3, hullR * 1.1, hullR * 0.6);

    // Outer Docking Ring (PMA-2 / IDA ring)
    const ringGrad = ctx.createRadialGradient(0, 0, hullR * 0.5, 0, 0, hullR);
    ringGrad.addColorStop(0, '#334155');
    ringGrad.addColorStop(0.7, '#64748b');
    ringGrad.addColorStop(1, '#94a3b8');
    ctx.fillStyle = ringGrad;
    ctx.beginPath();
    ctx.arc(0, 0, hullR, 0, Math.PI * 2);
    ctx.fill();

    // Docking Tunnel Entry (Dark hollow)
    ctx.fillStyle = '#020617';
    ctx.beginPath();
    ctx.arc(0, 0, hullR * 0.65, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // 3 Guide Petals (IDSS Standard tri-petal design)
    for (let i = 0; i < 3; i++) {
      const angle = (i * 120 * Math.PI) / 180;
      ctx.save();
      ctx.rotate(angle);
      ctx.fillStyle = '#e2e8f0';
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(-10 * targetScale, -hullR);
      ctx.lineTo(0, -hullR - 18 * targetScale);
      ctx.lineTo(10 * targetScale, -hullR);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    // Optical Center Target (The Crosshair and stand-off cross)
    ctx.strokeStyle = '#d9f36a';
    ctx.lineWidth = 2;
    // Central cross
    const crossSize = 22 * targetScale;
    ctx.beginPath();
    ctx.moveTo(-crossSize, 0); ctx.lineTo(crossSize, 0);
    ctx.moveTo(0, -crossSize); ctx.lineTo(0, crossSize);
    ctx.stroke();

    // Inner target circle
    ctx.beginPath();
    ctx.arc(0, 0, 9 * targetScale, 0, Math.PI * 2);
    ctx.stroke();

    // Stand-off post (creates 3D parallex offset indicating pitch & yaw)
    const postX = (yawAngle * 1.8) * targetScale;
    const postY = (-pitchAngle * 1.8) * targetScale;
    ctx.strokeStyle = '#ef7144';
    ctx.fillStyle = '#ef7144';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(postX, postY, 4 * targetScale, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.restore(); // Restore target transform

    // HUD OVERLAY (Fixed to cockpit camera boresight)
    ctx.strokeStyle = 'rgba(217, 243, 106, 0.45)';
    ctx.lineWidth = 1;

    // Central Boresight Crosshair
    const cx = cw / 2;
    const cy = ch / 2;
    ctx.beginPath();
    ctx.moveTo(cx - 30, cy); ctx.lineTo(cx - 10, cy);
    ctx.moveTo(cx + 10, cy); ctx.lineTo(cx + 30, cy);
    ctx.moveTo(cx, cy - 30); ctx.lineTo(cx, cy - 10);
    ctx.moveTo(cx, cy + 10); ctx.lineTo(cx, cy + 30);
    ctx.stroke();

    // Center reticle ring
    ctx.beginPath();
    ctx.arc(cx, cy, 50, 0, Math.PI * 2);
    ctx.stroke();

    // Velocity Vector Indicator (Where the ship is physically drifting)
    const velMarkerX = cx - (rateX * 220);
    const velMarkerY = cy + (rateY * 220);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.arc(velMarkerX, velMarkerY, 8, 0, Math.PI * 2);
    ctx.moveTo(velMarkerX - 12, velMarkerY); ctx.lineTo(velMarkerX + 12, velMarkerY);
    ctx.moveTo(velMarkerX, velMarkerY - 12); ctx.lineTo(velMarkerX, velMarkerY + 12);
    ctx.stroke();

    // HUD Corners
    const bracketSize = 24;
    ctx.strokeStyle = 'rgba(217, 243, 106, 0.7)';
    ctx.lineWidth = 2;
    // Top Left
    ctx.beginPath(); ctx.moveTo(20, 20 + bracketSize); ctx.lineTo(20, 20); ctx.lineTo(20 + bracketSize, 20); ctx.stroke();
    // Top Right
    ctx.beginPath(); ctx.moveTo(cw - 20 - bracketSize, 20); ctx.lineTo(cw - 20, 20); ctx.lineTo(cw - 20, 20 + bracketSize); ctx.stroke();
    // Bottom Left
    ctx.beginPath(); ctx.moveTo(20, ch - 20 - bracketSize); ctx.lineTo(20, ch - 20); ctx.lineTo(20 + bracketSize, ch - 20); ctx.stroke();
    // Bottom Right
    ctx.beginPath(); ctx.moveTo(cw - 20 - bracketSize, ch - 20); ctx.lineTo(cw - 20, ch - 20); ctx.lineTo(cw - 20, ch - 20 - bracketSize); ctx.stroke();

    // Night Floodlight Effect
    if (floodlightOn) {
      const spot = ctx.createRadialGradient(cx, cy, 60, cx, cy, cw * 0.6);
      spot.addColorStop(0, 'rgba(255, 255, 255, 0.08)');
      spot.addColorStop(0.7, 'rgba(255, 255, 255, 0.02)');
      spot.addColorStop(1, 'rgba(0, 0, 0, 0.3)');
      ctx.fillStyle = spot;
      ctx.fillRect(0, 0, cw, ch);
    }

    ctx.restore();
  }, [rangeZ, velZ, devX, devY, pitchAngle, yawAngle, rollAngle, rateX, rateY, floodlightOn]);

  // =========================================================================
  // MISSION 3: CREW EARTH OBSERVATION (CEO) SCIENTIFIC SCOUTING
  // =========================================================================
  interface EarthSite {
    id: string;
    title: string;
    location: string;
    description: string;
    objective: string;
    fact: string;
    astronautQuote: string;
    citation: string;
    targetCoords: { xPct: number; yPct: number; radiusPct: number };
    nasaAssetUrl: string;
    spectralInfo: {
      rgb: string;
      infrared: string;
      coastal: string;
      night: string;
    };
  }

  const EARTH_SITES: EarthSite[] = [
    {
      id: 'richat',
      title: 'Eye of the Sahara (Richat Structure)',
      location: 'Adrar Plateau, Mauritania (21.12° N, 11.40° W)',
      description: 'A striking 40-kilometer (25 mi) circular geological dome rising from the Sahara sands. Used as an orientation landmark by Gemini, Shuttle, and ISS astronauts.',
      objective: 'Locate and tag the central core uplift ring of the Richat Structure.',
      fact: 'Initially believed to be an impact crater, NASA radar and petrographic sampling showed it is an alkaline volcanic and sedimentary dome that eroded over 100 million years.',
      astronautQuote: '“Over North Africa, the Sahara looks endless until suddenly the Bull’s Eye appears. It is one of the most reliable visual milestones we have from orbit.” — ISS Expedition 35',
      citation: 'NASA Earth Observatory EO-10255 & ISS064-E-29177',
      targetCoords: { xPct: 52, yPct: 48, radiusPct: 14 },
      nasaAssetUrl: 'https://images-assets.nasa.gov/image/iss064e029177/iss064e029177~medium.jpg',
      spectralInfo: {
        rgb: 'Natural sand and quartzite limestone contrasts',
        infrared: 'Highlights sparse acacia vegetation in peripheral wadis',
        coastal: 'Accentuates windblown quartz dust plumes',
        night: 'Total darkness in the desert interior',
      },
    },
    {
      id: 'grandcanyon',
      title: 'Grand Canyon & Colorado Plateau',
      location: 'Arizona, United States (36.05° N, 112.14° W)',
      description: 'A 446 km long, 1.6 km deep chasm carved by the Colorado River through nearly 2 billion years of Earth’s crustal history.',
      objective: 'Locate the main incised river bend canyon between the North and South Rims.',
      fact: 'From the Cupola, astronauts can clearly observe the horizontal Kaibab Limestone, Coconino Sandstone, and Precambrian basement rocks stratified by color and elevation.',
      astronautQuote: '“You see the deep red fracture carved across the desert plateau. You can trace every single bend of the river with your naked eye.” — Chris Hadfield',
      citation: 'NASA Earth Observatory / ISS062-E-104921',
      targetCoords: { xPct: 47, yPct: 50, radiusPct: 15 },
      nasaAssetUrl: 'https://images-assets.nasa.gov/image/iss062e104921/iss062e104921~medium.jpg',
      spectralInfo: {
        rgb: 'Red oxidized sedimentary rock and pine forests',
        infrared: 'High NIR reflectance along riparian river vegetation',
        coastal: 'Silt runoff detection in Lake Mead basin',
        night: 'Las Vegas and Phoenix glow on the canyon horizon',
      },
    },
    {
      id: 'typhoon',
      title: 'Super Typhoon Eyewall Dynamics',
      location: 'Western Pacific Ocean',
      description: 'A Category 5 tropical cyclone displaying an almost perfectly circular eyewall with deep tropospheric convective cloud towers.',
      objective: 'Pinpoint the central calm eye and measure the cloud eyewall radius.',
      fact: 'Astronauts help meteorologists determine storm intensity by measuring cloud-top shadows cast inside the eye to calculate the eyewall slope (stadium effect).',
      astronautQuote: '“Staring down into the eye of a hurricane from 250 miles above is humbling. You see both supreme mathematical symmetry and raw kinetic force.” — Karen Nyberg',
      citation: 'NASA ISS Crew Earth Observations ISS065-E-182390',
      targetCoords: { xPct: 50, yPct: 50, radiusPct: 16 },
      nasaAssetUrl: 'https://images-assets.nasa.gov/image/iss065e182390/iss065e182390~medium.jpg',
      spectralInfo: {
        rgb: 'High albedo cloud tops with dark ocean eye center',
        infrared: 'Cold convective cloud tops (-75°C) highlighted in purple/red',
        coastal: 'Atmospheric moisture vapor gradient',
        night: 'Intense lightning flashes inside the eyewall',
      },
    },
    {
      id: 'nile_night',
      title: 'Nile River & Suez Canal at Night',
      location: 'Egypt & Red Sea (30.04° N, 31.23° W)',
      description: 'The golden ribbon of civilization: 95% of Egypt’s population lives along the banks of the Nile, creating a sharp luminous boundary with the arid desert.',
      objective: 'Locate the brilliant junction of the Nile Delta apex and the Suez Canal maritime shipping route.',
      fact: 'Night photography from the ISS proves that human habitability is intimately tethered to water availability. The Suez Canal shows up as an unbroken line of illuminated ships and port facilities.',
      astronautQuote: '“At night, the Nile looks like a brilliant glowing lotus flower blooming into the dark Mediterranean.” — Scott Kelly',
      citation: 'NASA Gateway to Astronaut Photography of Earth ISS063-E-80412',
      targetCoords: { xPct: 54, yPct: 44, radiusPct: 15 },
      nasaAssetUrl: 'https://images-assets.nasa.gov/image/iss063e080412/iss063e080412~medium.jpg',
      spectralInfo: {
        rgb: 'Golden sodium and white LED city lighting',
        infrared: 'Distinguishes urban concrete heat islands from cold desert sands',
        coastal: 'Mediterranean coastline and Suez Gulf navigation lights',
        night: 'Maximum illumination contrast (peak CEO night target)',
      },
    },
  ];

  const [currentSiteIdx, setCurrentSiteIdx] = useState(0);
  const [spectralMode, setSpectralMode] = useState<'rgb' | 'infrared' | 'coastal' | 'night'>('rgb');
  const [magnification, setMagnification] = useState<number>(1);
  const [identifiedSites, setIdentifiedSites] = useState<string[]>([]);
  const [scanFeedback, setScanFeedback] = useState<string | null>(null);
  const [reticlePos, setReticlePos] = useState({ x: 50, y: 50 });

  const currentSite = EARTH_SITES[currentSiteIdx];

  // Part B of the observation mission: live DSCOVR/EPIC full-disc survey.
  const [m3Part, setM3Part] = useState<'cupola' | 'epic'>('cupola');
  const [m3EpicDone, setM3EpicDone] = useState(false);
  const handleEpicComplete = useCallback(() => {
    setM3EpicDone(true);
    let firstTime = true;
    try {
      if (localStorage.getItem('cosmora_trainer_epic_bonus')) firstTime = false;
      else localStorage.setItem('cosmora_trainer_epic_bonus', '1');
    } catch {
      /* storage unavailable: still award once per session via state */
    }
    if (firstTime && profile && onUpdateProfile) {
      playGrandFanfare();
      onUpdateProfile({ ...profile, points: profile.points + 20 });
    }
  }, [profile, onUpdateProfile]);

  const handleScanTarget = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const xPct = ((e.clientX - rect.left) / rect.width) * 100;
    const yPct = ((e.clientY - rect.top) / rect.height) * 100;
    setReticlePos({ x: xPct, y: yPct });

    // Calculate distance to target center
    const dx = xPct - currentSite.targetCoords.xPct;
    const dy = yPct - currentSite.targetCoords.yPct;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist <= currentSite.targetCoords.radiusPct) {
      playSuccessChime();
      setScanFeedback(`✓ TARGET VERIFIED: ${currentSite.title.toUpperCase()}! Coordinates logged to NASA Earth Observation Registry.`);
      if (!identifiedSites.includes(currentSite.id)) {
        const next = [...identifiedSites, currentSite.id];
        setIdentifiedSites(next);
        if (next.length >= 4) {
          unlockBadge('badge-observer');
          fireMissionConfetti();
        }
      }
    } else {
      playTone(320, 0.15, 'sawtooth');
      setScanFeedback(`✗ TARGET OFF-AXIS: Scan closer to the central geological/atmospheric anomaly (${Math.round(dist)}% delta).`);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      {/* ------------------------------------------------------------------- */}
      {/* Top Header & Syllabus Overview */}
      {/* ------------------------------------------------------------------- */}
      <section className="bg-gradient-to-r from-[#0a2327] via-[#0b1c20] to-[#07171a] border border-[#1b3834] rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#d9f36a]/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono font-bold tracking-widest text-[#d9f36a] uppercase">
              <span className="w-2 h-2 rounded-full bg-[#d9f36a] animate-ping" />
              <span>NASA Astronaut Candidate (ASCAN) Flight Syllabus</span>
            </div>
            <h1 className="font-display font-extrabold text-3xl sm:text-4xl text-[#eef4e6] mt-2 tracking-tight">
              Astronaut Flight Trainer
            </h1>
            <p className="text-sm text-[#bdc9c0] mt-2 max-w-2xl leading-relaxed">
              Experience the core skills of real spaceflight through 3 hands-on simulators. Complete the terminal countdown under time pressure, execute manual 6-DOF ISS docking, and survey Earth from the Cupola. Every procedure, rule, and gauge is traceable to certified NASA flight documentation.
            </p>
          </div>

          {/* Quick stats and qualification badge count */}
          <div className="flex items-center gap-4 bg-[#061211]/80 backdrop-blur-md border border-[#1b3834] p-4 rounded-xl self-start lg:self-auto">
            <div className="text-center px-2">
              <span className="block text-2xl font-mono font-bold text-[#d9f36a]">
                {unlockedBadges.length} / 4
              </span>
              <span className="text-[10px] font-mono tracking-wider text-[#9fb1a6] uppercase">
                Badges Earned
              </span>
            </div>
            <div className="w-px h-10 bg-white/10" />
            <button
              onClick={() => setActiveTab('badges')}
              className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#d9f36a]/10 hover:bg-[#d9f36a]/20 border border-[#d9f36a]/30 text-xs font-mono text-[#d9f36a] transition-all"
            >
              <Award size={15} />
              <span>View Badges</span>
            </button>
          </div>
        </div>

        {/* Training Modules Navigation Bar */}
        <div className="mt-8 pt-6 border-t border-white/10 flex flex-wrap items-center gap-2 sm:gap-3">
          <button
            onClick={() => { playUiClick(); setActiveTab('hub'); }}
            className={`px-4 py-2.5 rounded-lg text-xs font-mono font-bold tracking-wider transition-all flex items-center gap-2 ${
              activeTab === 'hub'
                ? 'bg-[#d9f36a] text-[#061211] shadow-[0_0_15px_rgba(217,243,106,0.3)]'
                : 'bg-[#07191e] hover:bg-[#0a2327] text-[#9fb1a6] border border-[#1b3834]'
            }`}
          >
            <Compass size={14} />
            <span>TRAINER HUB</span>
          </button>

          <button
            onClick={() => { playUiClick(); setActiveTab('m1'); }}
            className={`px-4 py-2.5 rounded-lg text-xs font-mono font-bold tracking-wider transition-all flex items-center gap-2 ${
              activeTab === 'm1'
                ? 'bg-[#ff9838] text-[#061211] shadow-[0_0_15px_rgba(255,152,56,0.3)]'
                : 'bg-[#07191e] hover:bg-[#0a2327] text-[#9fb1a6] border border-[#1b3834]'
            }`}
          >
            <Clock size={14} />
            <span>M1: PRE-LAUNCH COUNTDOWN</span>
            {unlockedBadges.includes('badge-launch') && <span className="text-[10px]">✓</span>}
          </button>

          <button
            onClick={() => { playUiClick(); setActiveTab('m2'); }}
            className={`px-4 py-2.5 rounded-lg text-xs font-mono font-bold tracking-wider transition-all flex items-center gap-2 ${
              activeTab === 'm2'
                ? 'bg-[#72d1d6] text-[#061211] shadow-[0_0_15px_rgba(114,209,214,0.3)]'
                : 'bg-[#07191e] hover:bg-[#0a2327] text-[#9fb1a6] border border-[#1b3834]'
            }`}
          >
            <Crosshair size={14} />
            <span>M2: ISS DOCKING ALIGNMENT</span>
            {unlockedBadges.includes('badge-docking') && <span className="text-[10px]">✓</span>}
          </button>

          <button
            onClick={() => { playUiClick(); setActiveTab('m3'); }}
            className={`px-4 py-2.5 rounded-lg text-xs font-mono font-bold tracking-wider transition-all flex items-center gap-2 ${
              activeTab === 'm3'
                ? 'bg-[#66d17a] text-[#061211] shadow-[0_0_15px_rgba(102,209,122,0.3)]'
                : 'bg-[#07191e] hover:bg-[#0a2327] text-[#9fb1a6] border border-[#1b3834]'
            }`}
          >
            <Eye size={14} />
            <span>M3: EARTH CUPOLA SCANNER</span>
            {unlockedBadges.includes('badge-observer') && <span className="text-[10px]">✓</span>}
          </button>

          <button
            onClick={() => { playUiClick(); setActiveTab('badges'); }}
            className={`px-4 py-2.5 rounded-lg text-xs font-mono font-bold tracking-wider transition-all flex items-center gap-2 ${
              activeTab === 'badges'
                ? 'bg-[#d9f36a] text-[#061211]'
                : 'bg-[#07191e] hover:bg-[#0a2327] text-[#9fb1a6] border border-[#1b3834]'
            }`}
          >
            <Award size={14} />
            <span>QUALIFICATION BADGES</span>
          </button>

          <button
            onClick={() => { playUiClick(); setActiveTab('citations'); }}
            className={`px-4 py-2.5 rounded-lg text-xs font-mono font-bold tracking-wider transition-all flex items-center gap-2 ${
              activeTab === 'citations'
                ? 'bg-[#eef4e6] text-[#061211]'
                : 'bg-[#07191e] hover:bg-[#0a2327] text-[#9fb1a6] border border-[#1b3834]'
            }`}
          >
            <BookOpen size={14} />
            <span>NASA SOURCES &amp; ARCHIVE ({NASA_CITATIONS.length})</span>
          </button>
        </div>
      </section>

      {/* ------------------------------------------------------------------- */}
      {/* TAB 0: TRAINER HUB OVERVIEW */}
      {/* ------------------------------------------------------------------- */}
      {activeTab === 'hub' && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Card 1 */}
            <div className="bg-[#0b2025] border border-[#1b3834] rounded-xl p-6 flex flex-col justify-between hover:border-[#ff9838]/50 transition-all shadow-xl group">
              <div>
                <div className="flex items-center justify-between">
                  <span className="p-2.5 rounded-lg bg-[#ff9838]/10 text-[#ff9838] border border-[#ff9838]/20">
                    <Clock size={20} />
                  </span>
                  <span className="text-[10px] font-mono tracking-widest text-[#9fb1a6] uppercase">
                    STAGE 01 · 60 SECONDS
                  </span>
                </div>
                <h3 className="font-display font-bold text-xl text-[#eef4e6] mt-4 group-hover:text-[#ff9838] transition-colors">
                  Pre-Launch Checklist Under Time Pressure
                </h3>
                <p className="text-xs text-[#9fb1a6] mt-2 leading-relaxed">
                  Operate 6 authentic cockpit switches and valves (cabin pressure, cryogenic valves, TVC steering hydraulics, pyrotechnic abort, and telemetry) before T-00:00.
                </p>
                <div className="mt-4 pt-3 border-t border-white/5 space-y-1 text-[11px] font-mono text-[#bdc9c0]">
                  <div className="flex justify-between"><span>Skill:</span><span className="text-[#eef4e6]">High-pressure rapid diagnostics</span></div>
                  <div className="flex justify-between"><span>NASA Doc:</span><span className="text-[#ff9838]">NASA-STD-3001 &amp; SP-4029</span></div>
                  <div className="flex justify-between"><span>Status:</span><span className={unlockedBadges.includes('badge-launch') ? 'text-[#d9f36a] font-bold' : 'text-[#9fb1a6]'}>{unlockedBadges.includes('badge-launch') ? 'QUALIFIED ✓' : 'PENDING EVALUATION'}</span></div>
                </div>
              </div>
              <button
                onClick={() => { playUiClick(); setActiveTab('m1'); }}
                className="mt-6 w-full py-2.5 px-4 rounded-lg bg-[#ff9838] hover:bg-[#ffa954] text-[#061211] font-mono font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2"
              >
                <span>Launch Mission 1</span>
                <ArrowRight size={14} />
              </button>
            </div>

            {/* Card 2 */}
            <div className="bg-[#0b2025] border border-[#1b3834] rounded-xl p-6 flex flex-col justify-between hover:border-[#72d1d6]/50 transition-all shadow-xl group">
              <div>
                <div className="flex items-center justify-between">
                  <span className="p-2.5 rounded-lg bg-[#72d1d6]/10 text-[#72d1d6] border border-[#72d1d6]/20">
                    <Crosshair size={20} />
                  </span>
                  <span className="text-[10px] font-mono tracking-widest text-[#9fb1a6] uppercase">
                    STAGE 02 · 6-DOF PHYSICS
                  </span>
                </div>
                <h3 className="font-display font-bold text-xl text-[#eef4e6] mt-4 group-hover:text-[#72d1d6] transition-colors">
                  ISS Docking Alignment Simulator
                </h3>
                <p className="text-xs text-[#9fb1a6] mt-2 leading-relaxed">
                  Fly manual 6-DOF RCS translation and attitude rotation toward the International Space Station Harmony Forward Port within official NASA IDSS tolerances.
                </p>
                <div className="mt-4 pt-3 border-t border-white/5 space-y-1 text-[11px] font-mono text-[#bdc9c0]">
                  <div className="flex justify-between"><span>Skill:</span><span className="text-[#eef4e6]">Newtonian orbital momentum</span></div>
                  <div className="flex justify-between"><span>NASA Doc:</span><span className="text-[#72d1d6]">IDSS Interface Def Rev E</span></div>
                  <div className="flex justify-between"><span>Status:</span><span className={unlockedBadges.includes('badge-docking') ? 'text-[#d9f36a] font-bold' : 'text-[#9fb1a6]'}>{unlockedBadges.includes('badge-docking') ? 'QUALIFIED ✓' : 'PENDING EVALUATION'}</span></div>
                </div>
              </div>
              <button
                onClick={() => { playUiClick(); setActiveTab('m2'); }}
                className="mt-6 w-full py-2.5 px-4 rounded-lg bg-[#72d1d6] hover:bg-[#8ae0e5] text-[#061211] font-mono font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2"
              >
                <span>Launch Mission 2</span>
                <ArrowRight size={14} />
              </button>
            </div>

            {/* Card 3 */}
            <div className="bg-[#0b2025] border border-[#1b3834] rounded-xl p-6 flex flex-col justify-between hover:border-[#66d17a]/50 transition-all shadow-xl group">
              <div>
                <div className="flex items-center justify-between">
                  <span className="p-2.5 rounded-lg bg-[#66d17a]/10 text-[#66d17a] border border-[#66d17a]/20">
                    <Eye size={20} />
                  </span>
                  <span className="text-[10px] font-mono tracking-widest text-[#9fb1a6] uppercase">
                    STAGE 03 · NASA OBSERVATORY
                  </span>
                </div>
                <h3 className="font-display font-bold text-xl text-[#eef4e6] mt-4 group-hover:text-[#66d17a] transition-colors">
                  Earth Observation Cupola Task
                </h3>
                <p className="text-xs text-[#9fb1a6] mt-2 leading-relaxed">
                  Scan high-resolution NASA astronaut photography of the Sahara, Grand Canyon, Super Typhoons, and the Nile. Apply multi-spectral filters to identify real geological features.
                </p>
                <div className="mt-4 pt-3 border-t border-white/5 space-y-1 text-[11px] font-mono text-[#bdc9c0]">
                  <div className="flex justify-between"><span>Skill:</span><span className="text-[#eef4e6]">Remote sensing &amp; geology</span></div>
                  <div className="flex justify-between"><span>NASA Doc:</span><span className="text-[#66d17a]">NASA CEO Protocol RP-1280</span></div>
                  <div className="flex justify-between"><span>Status:</span><span className={unlockedBadges.includes('badge-observer') ? 'text-[#d9f36a] font-bold' : 'text-[#9fb1a6]'}>{unlockedBadges.includes('badge-observer') ? 'QUALIFIED ✓' : 'PENDING EVALUATION'}</span></div>
                </div>
              </div>
              <button
                onClick={() => { playUiClick(); setActiveTab('m3'); }}
                className="mt-6 w-full py-2.5 px-4 rounded-lg bg-[#66d17a] hover:bg-[#7fe392] text-[#061211] font-mono font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2"
              >
                <span>Launch Mission 3</span>
                <ArrowRight size={14} />
              </button>
            </div>
          </div>

          {/* NASA Verification Banner */}
          <div className="p-5 rounded-xl bg-[#061211] border border-[#1b3834] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="p-2 rounded-lg bg-[#d9f36a]/10 text-[#d9f36a]">
                <ShieldCheck size={20} />
              </span>
              <div>
                <h4 className="text-xs font-mono font-bold uppercase text-[#eef4e6]">
                  100% Traceable to NASA Flight Documentation
                </h4>
                <p className="text-[11px] text-[#9fb1a6] mt-0.5">
                  No fictional approximations. All 14 subsystem standards, docking thresholds, and orbital imagery are indexed in the NASA Research Archive.
                </p>
              </div>
            </div>
            <button
              onClick={() => { playUiClick(); setActiveTab('citations'); }}
              className="text-xs font-mono text-[#d9f36a] hover:underline flex items-center gap-1 shrink-0"
            >
              <span>Explore NASA Sources</span>
              <ExternalLink size={13} />
            </button>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* MISSION 1: PRE-LAUNCH CHECKLIST UNDER TIME PRESSURE */}
      {/* ------------------------------------------------------------------- */}
      {activeTab === 'm1' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          {/* Mission Top Header */}
          <div className="bg-[#0b2025] border border-[#1b3834] rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-[11px] font-mono font-bold text-[#ff9838]">
                <span>MISSION 01</span>
                <span>/</span>
                <span>PAD 39B TERMINAL COUNTDOWN</span>
              </div>
              <h2 className="text-2xl font-display font-bold text-[#eef4e6] mt-1">
                Pre-Launch Subsystem Checklist
              </h2>
              <p className="text-xs text-[#9fb1a6] mt-1 max-w-xl">
                Configure all 6 life-support, propulsion, and avionics systems before T-00:00. Watch your pressure dials and follow real flight rules.
              </p>
            </div>

            {/* Countdown Clock */}
            <div className="flex items-center gap-4">
              <div className="bg-[#051113] border-2 border-[#1b3834] px-6 py-2.5 rounded-xl text-center shadow-inner">
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#9fb1a6] block">
                  TERMINAL COUNT
                </span>
                <span className={`text-3xl font-mono font-black tracking-wider ${
                  m1Timer <= 10 ? 'text-[#ef7144] animate-pulse' : 'text-[#d9f36a]'
                }`}>
                  T-{String(Math.floor(m1Timer / 60)).padStart(2, '0')}:{String(m1Timer % 60).padStart(2, '0')}
                </span>
              </div>

              {!m1Running ? (
                <button
                  onClick={startMission1}
                  className="px-5 py-3 rounded-xl bg-[#ff9838] hover:bg-[#ffa954] text-[#061211] font-mono font-bold text-xs uppercase tracking-wider shadow-lg transition-all flex items-center gap-2"
                >
                  <Rocket size={16} />
                  <span>{m1Completed || m1Failed ? 'Restart Countdown' : 'Begin Countdown'}</span>
                </button>
              ) : (
                <button
                  onClick={() => { playErrorAlert(); setM1Running(false); setM1Failed(true); setM1FailReason('ABORT CALLED BY CREW COMMANDER.'); }}
                  className="px-4 py-3 rounded-xl bg-[#ef7144]/20 hover:bg-[#ef7144]/30 border border-[#ef7144]/40 text-[#ef7144] font-mono font-bold text-xs uppercase tracking-wider transition-all"
                >
                  Hold / Abort
                </button>
              )}
            </div>
          </div>

          {/* Status Alert Banners */}
          {m1Completed && (
            <div className="p-4 rounded-xl bg-[#d9f36a]/15 border-2 border-[#d9f36a] text-[#d9f36a] flex items-center justify-between gap-4 animate-in slide-in-from-top-2">
              <div className="flex items-center gap-3">
                <CheckCircle2 size={24} className="shrink-0" />
                <div>
                  <h4 className="font-bold text-sm">ALL SYSTEMS GO FOR LAUNCH! COUNTDOWN COMPLETE!</h4>
                  <p className="text-xs text-[#bdc9c0] mt-0.5">
                    Main engine ignition confirmed. All 6 subsystems nominal per NASA-STD-3001. Badge unlocked: <strong>Launch Systems Specialist</strong> (+40 XP).
                  </p>
                </div>
              </div>
              <button
                onClick={() => { playUiClick(); setActiveTab('m2'); }}
                className="px-4 py-2 rounded-lg bg-[#d9f36a] text-[#061211] font-mono font-bold text-xs uppercase flex items-center gap-1.5 shrink-0"
              >
                <span>Proceed to Mission 2</span>
                <ChevronRight size={14} />
              </button>
            </div>
          )}

          {m1Completed && <ApodReward missionLabel="MISSION 1" />}

          {m1Failed && (
            <div className="p-4 rounded-xl bg-[#ef7144]/15 border-2 border-[#ef7144] text-[#ef7144] flex items-center justify-between gap-4 animate-in slide-in-from-top-2">
              <div className="flex items-center gap-3">
                <AlertTriangle size={24} className="shrink-0" />
                <div>
                  <h4 className="font-bold text-sm">LAUNCH SCRUBBED · COUNTDOWN HALTED</h4>
                  <p className="text-xs text-[#bdc9c0] mt-0.5">{m1FailReason}</p>
                </div>
              </div>
              <button
                onClick={startMission1}
                className="px-4 py-2 rounded-lg bg-[#ef7144] text-white font-mono font-bold text-xs uppercase flex items-center gap-1.5 shrink-0"
              >
                <RotateCcw size={14} />
                <span>Retry Count</span>
              </button>
            </div>
          )}

          {/* The 6 Cockpit Instruments Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {/* 1. Cabin Atmosphere */}
            <div className={`p-5 rounded-xl border transition-all ${
              isCabinGo ? 'bg-[#09221d] border-[#d9f36a]' : 'bg-[#0b2025] border-[#1b3834]'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono tracking-wider text-[#9fb1a6]">SYS 01 · ECLSS ATMOSPHERE</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  isCabinGo ? 'bg-[#d9f36a] text-[#061211]' : 'bg-[#ef7144]/20 text-[#ef7144]'
                }`}>
                  {isCabinGo ? 'GO (14.7 psi)' : 'PRESSURE LOW'}
                </span>
              </div>
              <h4 className="font-display font-bold text-lg text-[#eef4e6] mt-2">
                Cabin Pressurization
              </h4>
              <p className="text-xs text-[#9fb1a6] mt-1">
                Target: 14.7 psi (Apollo/Artemis baseline). Open O2 bleed valve until pressure locks.
              </p>

              {/* Gauge Display */}
              <div className="mt-4 bg-[#051113] p-3 rounded-lg border border-white/5 flex items-center justify-between">
                <div className="text-2xl font-mono font-bold text-[#eef4e6]">
                  {m1CabinPress.toFixed(1)} <span className="text-xs text-[#9fb1a6]">psi</span>
                </div>
                <div className="w-24 h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#d9f36a] transition-all duration-150"
                    style={{ width: `${Math.min(100, (m1CabinPress / 15) * 100)}%` }}
                  />
                </div>
              </div>

              <div className="mt-4">
                <button
                  disabled={!m1Running || isCabinGo}
                  onClick={() => { playUiClick(); setM1CabinBleedOpen(true); }}
                  className={`w-full py-2.5 rounded-lg text-xs font-mono font-bold transition-all ${
                    isCabinGo
                      ? 'bg-[#d9f36a]/20 text-[#d9f36a] cursor-default'
                      : m1CabinBleedOpen
                      ? 'bg-[#d9f36a] text-[#061211] animate-pulse'
                      : 'bg-white/10 hover:bg-white/20 text-[#eef4e6]'
                  }`}
                >
                  {isCabinGo ? 'PRESSURE NOMINAL (14.7 psi) ✓' : m1CabinBleedOpen ? 'PRESSURIZING…' : 'OPEN O2 BLEED VALVE'}
                </button>
              </div>
              <div className="mt-2 text-[10px] font-mono text-[#9fb1a6]">
                Ref: NASA-STD-3001 §6.2 Atmosphere
              </div>
            </div>

            {/* 2. Cryogenic Propellant Valves */}
            <div className={`p-5 rounded-xl border transition-all ${
              isCryoGo ? 'bg-[#09221d] border-[#d9f36a]' : 'bg-[#0b2025] border-[#1b3834]'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono tracking-wider text-[#9fb1a6]">SYS 02 · PROPULSION CRYO</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  isCryoGo ? 'bg-[#d9f36a] text-[#061211]' : 'bg-[#ef7144]/20 text-[#ef7144]'
                }`}>
                  {isCryoGo ? 'ISOLATED' : 'LINES OPEN'}
                </span>
              </div>
              <h4 className="font-display font-bold text-lg text-[#eef4e6] mt-2">
                Cryo Fill &amp; Drain Lock
              </h4>
              <p className="text-xs text-[#9fb1a6] mt-1">
                Isolate LH2 (-253°C) and LOX fill umbilicals to prevent pressure venting at ignition.
              </p>

              <div className="mt-4 bg-[#051113] p-3 rounded-lg border border-white/5 space-y-1 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-[#9fb1a6]">LOX Feed Line:</span>
                  <span className={isCryoGo ? 'text-[#d9f36a]' : 'text-[#ff9838]'}>{isCryoGo ? 'SECURE' : 'FLOWING'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9fb1a6]">LH2 Umbilical:</span>
                  <span className={isCryoGo ? 'text-[#d9f36a]' : 'text-[#ff9838]'}>{isCryoGo ? 'LOCKED' : 'OPEN'}</span>
                </div>
              </div>

              <div className="mt-4">
                <button
                  disabled={!m1Running || isCryoGo}
                  onClick={() => { playUiClick(); playTone(440, 0.08); setM1CryoLocked(true); }}
                  className={`w-full py-2.5 rounded-lg text-xs font-mono font-bold transition-all ${
                    isCryoGo
                      ? 'bg-[#d9f36a]/20 text-[#d9f36a] cursor-default'
                      : 'bg-white/10 hover:bg-white/20 text-[#eef4e6]'
                  }`}
                >
                  {isCryoGo ? 'CRYO VALVES LOCKED ✓' : 'ENGAGE DUAL ISOLATION LOCK'}
                </button>
              </div>
              <div className="mt-2 text-[10px] font-mono text-[#9fb1a6]">
                Ref: NASA SP-4029 Terminal Countdown Step 4.2
              </div>
            </div>

            {/* 3. Gimbal Hydraulics Sweep */}
            <div className={`p-5 rounded-xl border transition-all ${
              isGimbalGo ? 'bg-[#09221d] border-[#d9f36a]' : 'bg-[#0b2025] border-[#1b3834]'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono tracking-wider text-[#9fb1a6]">SYS 03 · TVC ACTUATORS</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  isGimbalGo ? 'bg-[#d9f36a] text-[#061211]' : 'bg-[#ef7144]/20 text-[#ef7144]'
                }`}>
                  {isGimbalGo ? '3,000 PSI GO' : 'PRESSURE LOW'}
                </span>
              </div>
              <h4 className="font-display font-bold text-lg text-[#eef4e6] mt-2">
                Hydraulic Gimbal Sweep
              </h4>
              <p className="text-xs text-[#9fb1a6] mt-1">
                Hold the Sweep Test button to cycle engine steering nozzles and hit 3,000 psi.
              </p>

              <div className="mt-4 bg-[#051113] p-3 rounded-lg border border-white/5 flex items-center justify-between">
                <div className="text-2xl font-mono font-bold text-[#eef4e6]">
                  {m1GimbalPressure} <span className="text-xs text-[#9fb1a6]">psi</span>
                </div>
                <div className="w-24 h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#d9f36a] transition-all duration-100"
                    style={{ width: `${Math.min(100, (m1GimbalPressure / 3000) * 100)}%` }}
                  />
                </div>
              </div>

              <div className="mt-4">
                <button
                  disabled={!m1Running || isGimbalGo}
                  onMouseDown={() => { playUiClick(); setM1GimbalHolding(true); }}
                  onMouseUp={() => setM1GimbalHolding(false)}
                  onTouchStart={() => { playUiClick(); setM1GimbalHolding(true); }}
                  onTouchEnd={() => setM1GimbalHolding(false)}
                  className={`w-full py-2.5 rounded-lg text-xs font-mono font-bold transition-all select-none ${
                    isGimbalGo
                      ? 'bg-[#d9f36a]/20 text-[#d9f36a] cursor-default'
                      : m1GimbalHolding
                      ? 'bg-[#72d1d6] text-[#061211]'
                      : 'bg-white/10 hover:bg-white/20 text-[#eef4e6]'
                  }`}
                >
                  {isGimbalGo ? 'HYDRAULICS NOMINAL (3,000 psi) ✓' : m1GimbalHolding ? 'HOLDING: PRESSURIZING…' : 'PRESS & HOLD: GIMBAL TEST'}
                </button>
              </div>
              <div className="mt-2 text-[10px] font-mono text-[#9fb1a6]">
                Ref: NASA SLS Operations Manual §5.3 TVC
              </div>
            </div>

            {/* 4. Launch Abort System (LAS) */}
            <div className={`p-5 rounded-xl border transition-all ${
              isLasGo ? 'bg-[#09221d] border-[#d9f36a]' : 'bg-[#0b2025] border-[#1b3834]'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono tracking-wider text-[#9fb1a6]">SYS 04 · SAFETY ABORT</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  isLasGo ? 'bg-[#d9f36a] text-[#061211]' : 'bg-[#ef7144]/20 text-[#ef7144]'
                }`}>
                  {isLasGo ? 'ARMED' : 'SAFE / DISARMED'}
                </span>
              </div>
              <h4 className="font-display font-bold text-lg text-[#eef4e6] mt-2">
                Launch Abort Pyros
              </h4>
              <p className="text-xs text-[#9fb1a6] mt-1">
                Flip the physical safety guard cover open, then switch the pyrotechnic bus to ARMED.
              </p>

              <div className="mt-4 bg-[#051113] p-3 rounded-lg border border-white/5 space-y-1 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-[#9fb1a6]">Safety Guard:</span>
                  <span className={m1LasCoverOpen ? 'text-[#d9f36a]' : 'text-[#ef7144]'}>{m1LasCoverOpen ? 'OPEN' : 'CLOSED'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9fb1a6]">Jettison Bus:</span>
                  <span className={isLasGo ? 'text-[#d9f36a]' : 'text-[#9fb1a6]'}>{isLasGo ? 'ACTIVE 28V' : 'ISOLATED'}</span>
                </div>
              </div>

              <div className="mt-4 flex gap-2">
                <button
                  disabled={!m1Running || isLasGo}
                  onClick={() => { playUiClick(); setM1LasCoverOpen(true); }}
                  className={`flex-1 py-2.5 rounded-lg text-xs font-mono font-bold transition-all ${
                    m1LasCoverOpen ? 'bg-white/5 text-[#9fb1a6] cursor-default' : 'bg-white/10 hover:bg-white/20 text-[#eef4e6]'
                  }`}
                >
                  {m1LasCoverOpen ? 'COVER OPEN' : 'FLIP COVER'}
                </button>
                <button
                  disabled={!m1Running || !m1LasCoverOpen || isLasGo}
                  onClick={() => { playUiClick(); playQuindarTone('outro'); setM1LasArmed(true); }}
                  className={`flex-1 py-2.5 rounded-lg text-xs font-mono font-bold transition-all ${
                    isLasGo
                      ? 'bg-[#d9f36a]/20 text-[#d9f36a] cursor-default'
                      : m1LasCoverOpen
                      ? 'bg-[#ef7144] hover:bg-[#ff865c] text-white'
                      : 'bg-white/5 text-white/30 cursor-not-allowed'
                  }`}
                >
                  {isLasGo ? 'ARMED ✓' : 'ARM ABORT'}
                </button>
              </div>
              <div className="mt-2 text-[10px] font-mono text-[#9fb1a6]">
                Ref: NASA Orion Launch Abort TM-2010-216447
              </div>
            </div>

            {/* 5. Flight Computer IMU Alignment */}
            <div className={`p-5 rounded-xl border transition-all ${
              isImuGo ? 'bg-[#09221d] border-[#d9f36a]' : 'bg-[#0b2025] border-[#1b3834]'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono tracking-wider text-[#9fb1a6]">SYS 05 · GN&amp;C AVIONICS</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  isImuGo ? 'bg-[#d9f36a] text-[#061211]' : 'bg-[#ef7144]/20 text-[#ef7144]'
                }`}>
                  {isImuGo ? 'ALIGNED (<0.01°/hr)' : 'DRIFT UNCERTIFIED'}
                </span>
              </div>
              <h4 className="font-display font-bold text-lg text-[#eef4e6] mt-2">
                Inertial Gyro Alignment
              </h4>
              <p className="text-xs text-[#9fb1a6] mt-1">
                Calibrate the ring-laser gyros to Earth rotation coordinates before booster separation.
              </p>

              <div className="mt-4 bg-[#051113] p-3 rounded-lg border border-white/5 space-y-1 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-[#9fb1a6]">Star Tracker:</span>
                  <span className={isImuGo ? 'text-[#d9f36a]' : 'text-[#ff9838]'}>{isImuGo ? 'OPTICAL LOCK' : 'ACQUIRING'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9fb1a6]">Platform Drift:</span>
                  <span className={isImuGo ? 'text-[#d9f36a]' : 'text-[#ef7144]'}>{isImuGo ? '0.008° / hr' : '0.142° / hr'}</span>
                </div>
              </div>

              <div className="mt-4">
                <button
                  disabled={!m1Running || isImuGo}
                  onClick={() => { playUiClick(); playTone(780, 0.1); setM1ImuAligned(true); }}
                  className={`w-full py-2.5 rounded-lg text-xs font-mono font-bold transition-all ${
                    isImuGo
                      ? 'bg-[#d9f36a]/20 text-[#d9f36a] cursor-default'
                      : 'bg-white/10 hover:bg-white/20 text-[#eef4e6]'
                  }`}
                >
                  {isImuGo ? 'IMU CALIBRATED & LOCKED ✓' : 'CALIBRATE GYRO PLATFORM'}
                </button>
              </div>
              <div className="mt-2 text-[10px] font-mono text-[#9fb1a6]">
                Ref: Apollo 11 Flight Plan §3-2 IMU Fine Align
              </div>
            </div>

            {/* 6. Spacecraft S-Band Radio Lock */}
            <div className={`p-5 rounded-xl border transition-all ${
              isCommGo ? 'bg-[#09221d] border-[#d9f36a]' : 'bg-[#0b2025] border-[#1b3834]'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono tracking-wider text-[#9fb1a6]">SYS 06 · S-BAND TELEMETRY</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  isCommGo ? 'bg-[#d9f36a] text-[#061211]' : 'bg-[#ef7144]/20 text-[#ef7144]'
                }`}>
                  {isCommGo ? 'CARRIER LOCK' : 'SEARCHING'}
                </span>
              </div>
              <h4 className="font-display font-bold text-lg text-[#eef4e6] mt-2">
                S-Band Transponder Lock
              </h4>
              <p className="text-xs text-[#9fb1a6] mt-1">
                Tune telemetry downlink to NASA Kennedy Launch Control (target: 2287.5 MHz).
              </p>

              <div className="mt-4 bg-[#051113] p-3 rounded-lg border border-white/5 space-y-1 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-[#9fb1a6]">Current Frequency:</span>
                  <span className="text-[#eef4e6] font-bold">{m1CommFrequency.toFixed(1)} MHz</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9fb1a6]">Bitrate Downlink:</span>
                  <span className={isCommGo ? 'text-[#d9f36a]' : 'text-[#9fb1a6]'}>{isCommGo ? '1.024 Mbps' : '0.0 kbps'}</span>
                </div>
              </div>

              <div className="mt-4 flex gap-2">
                <button
                  disabled={!m1Running || isCommGo}
                  onClick={() => {
                    playUiClick();
                    setM1CommFrequency(2287.5);
                    setM1CommLocked(true);
                    playQuindarTone('intro');
                  }}
                  className={`w-full py-2.5 rounded-lg text-xs font-mono font-bold transition-all ${
                    isCommGo
                      ? 'bg-[#d9f36a]/20 text-[#d9f36a] cursor-default'
                      : 'bg-white/10 hover:bg-white/20 text-[#eef4e6]'
                  }`}
                >
                  {isCommGo ? 'LOCKED AT 2287.5 MHz ✓' : 'TUNE 2287.5 MHz & LOCK'}
                </button>
              </div>
              <div className="mt-2 text-[10px] font-mono text-[#9fb1a6]">
                Ref: NASA SCaN Architecture SP-2014-5001
              </div>
            </div>
          </div>

          <ChecklistPhotoLog
            systems={[
              { label: 'CABIN PRESSURE', go: isCabinGo },
              { label: 'CRYO VALVES', go: isCryoGo },
              { label: 'GIMBAL', go: isGimbalGo },
              { label: 'ABORT SYSTEM', go: isLasGo },
              { label: 'IMU', go: isImuGo },
              { label: 'S-BAND COMMS', go: isCommGo },
            ]}
          />
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* MISSION 2: ORBITAL RENDEZVOUS & DOCKING ALIGNMENT GAME */}
      {/* ------------------------------------------------------------------- */}
      {activeTab === 'm2' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          <div className="bg-[#0b2025] border border-[#1b3834] rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-[11px] font-mono font-bold text-[#72d1d6]">
                <span>MISSION 02</span>
                <span>/</span>
                <span>ISS HARMONY FORWARD PORT PMA-2</span>
              </div>
              <h2 className="text-2xl font-display font-bold text-[#eef4e6] mt-1">
                Precision Orbital Docking Simulator
              </h2>
              <p className="text-xs text-[#9fb1a6] mt-1 max-w-xl">
                Pilot the incoming vehicle to manual contact with the space station. Remember Newton’s first law: in zero gravity, every thruster pulse keeps drifting until counter-thrust is applied.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setFloodlightOn(f => !f)}
                className={`px-3 py-2 rounded-lg text-xs font-mono border transition-all ${
                  floodlightOn ? 'bg-[#72d1d6]/20 border-[#72d1d6] text-[#72d1d6]' : 'bg-white/5 border-white/10 text-[#9fb1a6]'
                }`}
              >
                Floodlight {floodlightOn ? 'ON' : 'OFF'}
              </button>
              <button
                onClick={resetMission2}
                className="px-4 py-2.5 rounded-lg bg-[#72d1d6] hover:bg-[#8ae0e5] text-[#061211] font-mono font-bold text-xs uppercase flex items-center gap-1.5 shadow-lg"
              >
                <RotateCcw size={14} />
                <span>Reset Approach</span>
              </button>
            </div>
          </div>

          {/* Success / Failure Banners */}
          {m2Completed && (
            <div className="p-4 rounded-xl bg-[#d9f36a]/15 border-2 border-[#d9f36a] text-[#d9f36a] flex items-center justify-between gap-4 animate-in slide-in-from-top-2">
              <div className="flex items-center gap-3">
                <CheckCircle2 size={24} className="shrink-0" />
                <div>
                  <h4 className="font-bold text-sm">CONTACT AND HARD CAPTURE CONFIRMED!</h4>
                  <p className="text-xs text-[#bdc9c0] mt-0.5">
                    IDSS capture latches locked. Structural pressure seal verified with ISS Harmony Module. Badge unlocked: <strong>Orbital Docking Master</strong> (+40 XP).
                  </p>
                </div>
              </div>
              <button
                onClick={() => { playUiClick(); setActiveTab('m3'); }}
                className="px-4 py-2 rounded-lg bg-[#d9f36a] text-[#061211] font-mono font-bold text-xs uppercase flex items-center gap-1.5 shrink-0"
              >
                <span>Proceed to Mission 3</span>
                <ChevronRight size={14} />
              </button>
            </div>
          )}

          {m2Completed && <ApodReward missionLabel="MISSION 2" />}

          {m2Aborted && (
            <div className="p-4 rounded-xl bg-[#ef7144]/15 border-2 border-[#ef7144] text-[#ef7144] flex items-center justify-between gap-4 animate-in slide-in-from-top-2">
              <div className="flex items-center gap-3">
                <AlertTriangle size={24} className="shrink-0" />
                <div>
                  <h4 className="font-bold text-sm">DOCKING ABORT · RETREAT TO STAND-OFF 30M</h4>
                  <p className="text-xs text-[#bdc9c0] mt-0.5">{m2AbortReason}</p>
                </div>
              </div>
              <button
                onClick={resetMission2}
                className="px-4 py-2 rounded-lg bg-[#ef7144] text-white font-mono font-bold text-xs uppercase flex items-center gap-1.5 shrink-0"
              >
                <RotateCcw size={14} />
                <span>Retry Approach</span>
              </button>
            </div>
          )}

          {/* Main Simulation Viewport and Flight Instrument Cluster */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Viewport Canvas (3 cols) */}
            <div className="lg:col-span-3 bg-black rounded-2xl border-2 border-[#1b3834] relative overflow-hidden shadow-2xl flex flex-col min-h-[460px]">
              <canvas ref={canvasRef} className="w-full h-full flex-1 block" />

              {/* HUD Telemetry Top Strip */}
              <div className="absolute top-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
                <div className="bg-[#061211]/85 backdrop-blur-md px-3.5 py-1.5 rounded-lg border border-white/10 text-xs font-mono flex items-center gap-3">
                  <span className="text-[#9fb1a6]">RANGE:</span>
                  <span className="text-lg font-bold text-[#d9f36a]">{rangeZ.toFixed(2)}m</span>
                  <span className="text-white/20">|</span>
                  <span className="text-[#9fb1a6]">CLOSURE:</span>
                  <span className={`font-bold ${velZ > 0.15 ? 'text-[#ef7144]' : 'text-[#72d1d6]'}`}>
                    {velZ.toFixed(2)} m/s
                  </span>
                </div>

                <div className="bg-[#061211]/85 backdrop-blur-md px-3.5 py-1.5 rounded-lg border border-white/10 text-xs font-mono flex items-center gap-3">
                  <span className="text-[#9fb1a6]">RCS FUEL:</span>
                  <span className={`font-bold ${rcsFuel < 20 ? 'text-[#ef7144]' : 'text-[#d9f36a]'}`}>
                    {rcsFuel.toFixed(0)}%
                  </span>
                  <div className="w-14 h-2 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-[#d9f36a]" style={{ width: `${rcsFuel}%` }} />
                  </div>
                </div>
              </div>

              {/* Bottom Tolerance Readout */}
              <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2 pointer-events-none text-[11px] font-mono">
                <div className="bg-[#061211]/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 flex gap-3">
                  <span className={Math.abs(devX) <= 0.25 ? 'text-[#d9f36a]' : 'text-[#ef7144]'}>
                    ΔX: {devX > 0 ? `+${devX.toFixed(2)}` : devX.toFixed(2)}m
                  </span>
                  <span className={Math.abs(devY) <= 0.25 ? 'text-[#d9f36a]' : 'text-[#ef7144]'}>
                    ΔY: {devY > 0 ? `+${devY.toFixed(2)}` : devY.toFixed(2)}m
                  </span>
                </div>

                <div className="bg-[#061211]/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 flex gap-3">
                  <span className={Math.abs(pitchAngle) <= 3.0 ? 'text-[#d9f36a]' : 'text-[#ef7144]'}>
                    P: {pitchAngle.toFixed(1)}°
                  </span>
                  <span className={Math.abs(yawAngle) <= 3.0 ? 'text-[#d9f36a]' : 'text-[#ef7144]'}>
                    Y: {yawAngle.toFixed(1)}°
                  </span>
                  <span className={Math.abs(rollAngle) <= 4.5 ? 'text-[#d9f36a]' : 'text-[#ef7144]'}>
                    R: {rollAngle.toFixed(1)}°
                  </span>
                </div>
              </div>
            </div>

            {/* Flight Controls Panel (1 col) */}
            <div className="bg-[#0b2025] border border-[#1b3834] rounded-2xl p-5 flex flex-col justify-between space-y-6 shadow-xl">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#9fb1a6]">6-DOF RCS CONTROLLER</span>
                  <button
                    onClick={() => { playUiClick(); setSasHold(s => !s); }}
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border transition-all ${
                      sasHold ? 'bg-[#d9f36a] text-[#061211] border-[#d9f36a]' : 'bg-white/5 border-white/10 text-[#9fb1a6]'
                    }`}
                  >
                    SAS AUTO-DAMP {sasHold ? 'ON' : 'OFF'}
                  </button>
                </div>

                {/* Translation Controls */}
                <div className="mt-4">
                  <span className="text-xs font-mono font-bold text-[#eef4e6] block mb-2">Translation (X / Y / Z)</span>
                  <div className="grid grid-cols-3 gap-1.5 text-center">
                    <div />
                    <button onClick={() => fireRcs('ty+')} className="p-2.5 rounded bg-white/10 hover:bg-white/20 active:bg-[#72d1d6] active:text-[#061211] font-mono text-xs font-bold text-[#eef4e6] border border-white/10">▲ UP (W)</button>
                    <div />
                    <button onClick={() => fireRcs('tx-')} className="p-2.5 rounded bg-white/10 hover:bg-white/20 active:bg-[#72d1d6] active:text-[#061211] font-mono text-xs font-bold text-[#eef4e6] border border-white/10">◀ L (A)</button>
                    <div className="p-2.5 text-[10px] font-mono text-[#9fb1a6] flex items-center justify-center">TRANS</div>
                    <button onClick={() => fireRcs('tx+')} className="p-2.5 rounded bg-white/10 hover:bg-white/20 active:bg-[#72d1d6] active:text-[#061211] font-mono text-xs font-bold text-[#eef4e6] border border-white/10">R (D) ▶</button>
                    <div />
                    <button onClick={() => fireRcs('ty-')} className="p-2.5 rounded bg-white/10 hover:bg-white/20 active:bg-[#72d1d6] active:text-[#061211] font-mono text-xs font-bold text-[#eef4e6] border border-white/10">▼ DN (S)</button>
                    <div />
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <button onClick={() => fireRcs('tz+')} className="py-2 px-3 rounded bg-white/10 hover:bg-white/20 active:bg-[#d9f36a] active:text-[#061211] font-mono text-xs font-bold text-[#eef4e6] border border-white/10">FWD + (R)</button>
                    <button onClick={() => fireRcs('tz-')} className="py-2 px-3 rounded bg-white/10 hover:bg-white/20 active:bg-[#ef7144] active:text-[#061211] font-mono text-xs font-bold text-[#eef4e6] border border-white/10">BRAKE - (F)</button>
                  </div>
                </div>

                {/* Attitude Rotation Controls */}
                <div className="mt-5 pt-4 border-t border-white/10">
                  <span className="text-xs font-mono font-bold text-[#eef4e6] block mb-2">Attitude (Pitch / Yaw / Roll)</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button onClick={() => fireRcs('pitch+')} className="py-2 px-2.5 rounded bg-white/10 hover:bg-white/20 font-mono text-xs text-[#eef4e6] border border-white/10">PITCH UP (↑)</button>
                    <button onClick={() => fireRcs('pitch-')} className="py-2 px-2.5 rounded bg-white/10 hover:bg-white/20 font-mono text-xs text-[#eef4e6] border border-white/10">PITCH DN (↓)</button>
                    <button onClick={() => fireRcs('yaw-')} className="py-2 px-2.5 rounded bg-white/10 hover:bg-white/20 font-mono text-xs text-[#eef4e6] border border-white/10">YAW L (←)</button>
                    <button onClick={() => fireRcs('yaw+')} className="py-2 px-2.5 rounded bg-white/10 hover:bg-white/20 font-mono text-xs text-[#eef4e6] border border-white/10">YAW R (→)</button>
                    <button onClick={() => fireRcs('roll-')} className="py-2 px-2.5 rounded bg-white/10 hover:bg-white/20 font-mono text-xs text-[#eef4e6] border border-white/10">ROLL CCW (Q)</button>
                    <button onClick={() => fireRcs('roll+')} className="py-2 px-2.5 rounded bg-white/10 hover:bg-white/20 font-mono text-xs text-[#eef4e6] border border-white/10">ROLL CW (E)</button>
                  </div>
                </div>
              </div>

              {/* IDSS Tolerance Criteria helper */}
              <div className="p-3 bg-[#051113] rounded-lg border border-white/5 text-[11px] font-mono text-[#9fb1a6] space-y-1">
                <span className="text-[#d9f36a] font-bold block">NASA IDSS Tolerance Gate:</span>
                <div>• Lateral |X|, |Y| &lt; 0.25 m</div>
                <div>• Alignment Pitch/Yaw &lt; 3.0°</div>
                <div>• Touchdown speed: 0.03 – 0.15 m/s</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* MISSION 3: CREW EARTH OBSERVATION (CEO) SCIENTIFIC SCOUTING */}
      {/* ------------------------------------------------------------------- */}
      {activeTab === 'm3' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          <div className="bg-[#0b2025] border border-[#1b3834] rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-[11px] font-mono font-bold text-[#66d17a]">
                <span>MISSION 03</span>
                <span>/</span>
                <span>ISS CUPOLA OBSERVATION BAY</span>
              </div>
              <h2 className="text-2xl font-display font-bold text-[#eef4e6] mt-1">
                Crew Earth Observation Task
              </h2>
              <p className="text-xs text-[#9fb1a6] mt-1 max-w-xl">
                Identify real geological formations, storm dynamics, and human settlements from genuine NASA astronaut orbital photography. Click on the image to scan and register target features.
              </p>
            </div>

            {/* Sites Progress Badge */}
            <div className="bg-[#051113] border border-[#1b3834] px-4 py-2.5 rounded-xl text-xs font-mono flex items-center gap-3">
              <span className="text-[#9fb1a6]">TARGETS IDENTIFIED:</span>
              <span className="text-base font-bold text-[#66d17a]">{identifiedSites.length} / 4</span>
            </div>
          </div>

          {/* Part switcher: ISS Cupola targets vs live EPIC Earth disc */}
          <div className="flex flex-wrap gap-2" role="tablist" aria-label="Observation mission parts">
            {([['cupola', 'PART A · ISS CUPOLA TARGETS'], ['epic', 'PART B · LIVE EARTH DISC (EPIC)']] as const).map(([id, label]) => (
              <button
                key={id}
                role="tab"
                aria-selected={m3Part === id}
                onClick={() => { playUiClick(); setM3Part(id); }}
                className={`px-4 py-2 rounded-lg text-xs font-mono font-bold tracking-wider transition-all flex items-center gap-2 cursor-pointer ${
                  m3Part === id
                    ? 'bg-[#66d17a] text-[#061211] shadow-md'
                    : 'bg-[#07191e] hover:bg-[#0a2327] text-[#9fb1a6] border border-[#1b3834]'
                }`}
              >
                <span>{label}</span>
                {id === 'cupola' && identifiedSites.length >= 4 && <Check size={12} />}
                {id === 'epic' && m3EpicDone && <Check size={12} />}
              </button>
            ))}
          </div>

          {m3Part === 'cupola' && (<>
          {/* Site Selector Tabs */}
          <div className="flex flex-wrap gap-2">
            {EARTH_SITES.map((site, index) => {
              const isDone = identifiedSites.includes(site.id);
              const isCurrent = currentSiteIdx === index;
              return (
                <button
                  key={site.id}
                  onClick={() => { playUiClick(); setCurrentSiteIdx(index); setScanFeedback(null); }}
                  className={`px-3.5 py-2 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-2 ${
                    isCurrent
                      ? 'bg-[#66d17a] text-[#061211] shadow-md'
                      : 'bg-[#07191e] hover:bg-[#0a2327] text-[#9fb1a6] border border-[#1b3834]'
                  }`}
                >
                  <span>{index + 1}. {site.title.split('(')[0]}</span>
                  {isDone && <Check size={12} className={isCurrent ? 'text-[#061211]' : 'text-[#66d17a]'} />}
                </button>
              );
            })}
          </div>

          {/* Interactive Observation Viewfinder */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Viewfinder Canvas / Image (2 cols) */}
            <div className="lg:col-span-2 space-y-3">
              <div
                onClick={handleScanTarget}
                className="relative bg-black rounded-2xl border-2 border-[#1b3834] overflow-hidden aspect-video cursor-crosshair group shadow-2xl select-none"
              >
                {/* NASA Astronaut Image with dynamic CSS spectral filters */}
                <img
                  src={currentSite.nasaAssetUrl}
                  alt={currentSite.title}
                  className="w-full h-full object-cover transition-all duration-300 pointer-events-none"
                  style={{
                    transform: `scale(${magnification})`,
                    filter:
                      spectralMode === 'infrared'
                        ? 'contrast(160%) saturate(220%) hue-rotate(90deg)'
                        : spectralMode === 'coastal'
                        ? 'contrast(140%) saturate(180%) hue-rotate(180deg)'
                        : spectralMode === 'night'
                        ? 'contrast(200%) brightness(140%) invert(10%)'
                        : 'none',
                  }}
                  onError={(e) => {
                    // Fallback to local skylab archive or high quality NASA backup if network drops
                    (e.target as HTMLImageElement).src = '/skylab-archive.jpg';
                  }}
                />

                {/* Cupola Window Frame Border Overlay */}
                <div className="absolute inset-0 border-[12px] border-[#07171a]/70 rounded-2xl pointer-events-none" />

                {/* Reticle Scanner Overlay */}
                <div
                  className="absolute w-12 h-12 -ml-6 -mt-6 border-2 border-[#d9f36a] rounded-full pointer-events-none transition-transform duration-75 flex items-center justify-center"
                  style={{ left: `${reticlePos.x}%`, top: `${reticlePos.y}%` }}
                >
                  <div className="w-2 h-2 bg-[#d9f36a] rounded-full" />
                  <div className="absolute w-20 h-px bg-[#d9f36a]/50" />
                  <div className="absolute h-20 w-px bg-[#d9f36a]/50" />
                </div>

                {/* Compass & Telemetry HUD Overlay */}
                <div className="absolute top-4 left-4 bg-[#061211]/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 text-[11px] font-mono text-[#eef4e6] pointer-events-none">
                  <div>LAT/LON: {currentSite.location}</div>
                  <div className="text-[10px] text-[#d9f36a]">SPECTRAL FILTER: {spectralMode.toUpperCase()}</div>
                </div>

                <div className="absolute bottom-4 right-4 bg-[#061211]/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 text-[10px] font-mono text-[#9fb1a6] pointer-events-none">
                  CLICK TO SCAN &amp; VERIFY FEATURE
                </div>
              </div>

              {/* Spectral Filter Selector & Zoom Tools */}
              <div className="p-3 bg-[#0b2025] rounded-xl border border-[#1b3834] flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
                <div className="flex items-center gap-1.5">
                  <span className="text-[#9fb1a6] mr-1">FILTER:</span>
                  <button
                    onClick={() => { playUiClick(); setSpectralMode('rgb'); }}
                    className={`px-2.5 py-1 rounded border transition-all ${
                      spectralMode === 'rgb' ? 'bg-[#d9f36a] text-[#061211] font-bold border-[#d9f36a]' : 'bg-white/5 border-white/10 text-[#bdc9c0]'
                    }`}
                  >
                    RGB Natural
                  </button>
                  <button
                    onClick={() => { playUiClick(); setSpectralMode('infrared'); }}
                    className={`px-2.5 py-1 rounded border transition-all ${
                      spectralMode === 'infrared' ? 'bg-[#ff9838] text-[#061211] font-bold border-[#ff9838]' : 'bg-white/5 border-white/10 text-[#bdc9c0]'
                    }`}
                  >
                    Thermal / Infrared
                  </button>
                  <button
                    onClick={() => { playUiClick(); setSpectralMode('coastal'); }}
                    className={`px-2.5 py-1 rounded border transition-all ${
                      spectralMode === 'coastal' ? 'bg-[#72d1d6] text-[#061211] font-bold border-[#72d1d6]' : 'bg-white/5 border-white/10 text-[#bdc9c0]'
                    }`}
                  >
                    Hydrology
                  </button>
                  <button
                    onClick={() => { playUiClick(); setSpectralMode('night'); }}
                    className={`px-2.5 py-1 rounded border transition-all ${
                      spectralMode === 'night' ? 'bg-[#eef4e6] text-[#061211] font-bold border-[#eef4e6]' : 'bg-white/5 border-white/10 text-[#bdc9c0]'
                    }`}
                  >
                    Luminosity
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[#9fb1a6]">MAG:</span>
                  <button
                    onClick={() => setMagnification(1)}
                    className={`px-2 py-1 rounded border ${magnification === 1 ? 'bg-white/20 text-white' : 'bg-white/5 text-[#9fb1a6]'}`}
                  >
                    1.0x
                  </button>
                  <button
                    onClick={() => setMagnification(1.4)}
                    className={`px-2 py-1 rounded border ${magnification === 1.4 ? 'bg-white/20 text-white' : 'bg-white/5 text-[#9fb1a6]'}`}
                  >
                    1.4x
                  </button>
                  <button
                    onClick={() => setMagnification(1.8)}
                    className={`px-2 py-1 rounded border ${magnification === 1.8 ? 'bg-white/20 text-white' : 'bg-white/5 text-[#9fb1a6]'}`}
                  >
                    1.8x
                  </button>
                </div>
              </div>

              {/* Feedback Alert */}
              {scanFeedback && (
                <div className={`p-3.5 rounded-xl border text-xs font-mono animate-in fade-in ${
                  scanFeedback.startsWith('✓')
                    ? 'bg-[#d9f36a]/15 border-[#d9f36a] text-[#d9f36a]'
                    : 'bg-[#ff9838]/15 border-[#ff9838] text-[#ff9838]'
                }`}>
                  {scanFeedback}
                </div>
              )}
            </div>

            {/* Scientific Briefing Card (1 col) */}
            <div className="bg-[#0b2025] border border-[#1b3834] rounded-2xl p-6 space-y-4 flex flex-col justify-between shadow-xl">
              <div className="space-y-4">
                <div>
                  <span className="text-[10px] font-mono tracking-wider text-[#66d17a] uppercase block">
                    TARGET 0{currentSiteIdx + 1} OF 04 · SCIENTIFIC TARGET
                  </span>
                  <h3 className="font-display font-bold text-xl text-[#eef4e6] mt-1">
                    {currentSite.title}
                  </h3>
                  <div className="text-xs text-[#9fb1a6] mt-0.5">{currentSite.location}</div>
                </div>

                <div className="p-3 bg-[#051113] rounded-xl border border-white/5">
                  <span className="text-[10px] font-mono uppercase text-[#d9f36a] block font-bold mb-1">
                    NASA Mission Objective:
                  </span>
                  <p className="text-xs text-[#bdc9c0] leading-relaxed">
                    {currentSite.objective}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] font-mono uppercase text-[#9fb1a6] block font-bold mb-1">
                    Geological &amp; Physical Analysis:
                  </span>
                  <p className="text-xs text-[#9fb1a6] leading-relaxed">
                    {currentSite.fact}
                  </p>
                </div>

                <div className="p-3 bg-white/5 rounded-xl border border-white/5 italic text-xs text-[#bdc9c0] leading-relaxed">
                  {currentSite.astronautQuote}
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 space-y-3">
                <div className="text-[10px] font-mono text-[#9fb1a6]">
                  Traceable NASA Archive: <span className="text-[#66d17a] font-bold">{currentSite.citation}</span>
                </div>
                {currentSiteIdx < EARTH_SITES.length - 1 ? (
                  <button
                    onClick={() => { playUiClick(); setCurrentSiteIdx(i => i + 1); setScanFeedback(null); }}
                    className="w-full py-2.5 rounded-lg bg-[#66d17a] hover:bg-[#7fe392] text-[#061211] font-mono font-bold text-xs uppercase flex items-center justify-center gap-1.5"
                  >
                    <span>Next Earth Target</span>
                    <ChevronRight size={14} />
                  </button>
                ) : (
                  <button
                    onClick={() => { playUiClick(); setActiveTab('badges'); }}
                    className="w-full py-2.5 rounded-lg bg-[#d9f36a] hover:bg-[#e4f788] text-[#061211] font-mono font-bold text-xs uppercase flex items-center justify-center gap-1.5 shadow-lg"
                  >
                    <Award size={14} />
                    <span>Complete Qualification &amp; Badges</span>
                  </button>
                )}
              </div>
            </div>
          </div>
          </>)}

          {m3Part === 'epic' && <EpicObservation onSurveyComplete={handleEpicComplete} />}

          {(identifiedSites.length >= 4 || m3EpicDone) && <ApodReward missionLabel="MISSION 3" />}
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* TAB 4: QUALIFICATION BADGES SHOWCASE */}
      {/* ------------------------------------------------------------------- */}
      {activeTab === 'badges' && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <span className="text-xs font-mono font-bold uppercase text-[#d9f36a] tracking-widest">
              OFFICIAL CERTIFICATION RECORDS
            </span>
            <h2 className="text-3xl font-display font-bold text-[#eef4e6]">
              Astronaut Candidate Badges
            </h2>
            <p className="text-xs text-[#9fb1a6]">
              Earn official qualification badges by completing all 3 interactive flight trainer missions. Badges verify your operational readiness across countdown checklists, orbital docking, and Earth science.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {TRAINER_BADGES.map(badge => {
              const unlocked = unlockedBadges.includes(badge.id);
              return (
                <div
                  key={badge.id}
                  className={`p-6 rounded-2xl border transition-all flex flex-col justify-between relative overflow-hidden ${
                    unlocked
                      ? 'bg-gradient-to-b from-[#0e292d] to-[#07171a] border-[#d9f36a] shadow-[0_0_20px_rgba(217,243,106,0.15)]'
                      : 'bg-[#08191c] border-white/5 opacity-60'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-4xl p-3 rounded-2xl bg-black/40 border border-white/10 shadow-inner">
                        {badge.icon}
                      </span>
                      <span className={`text-[10px] font-mono px-2 py-1 rounded font-bold uppercase ${
                        unlocked ? 'bg-[#d9f36a] text-[#061211]' : 'bg-white/10 text-[#9fb1a6]'
                      }`}>
                        {unlocked ? 'AWARDED ✓' : 'LOCKED'}
                      </span>
                    </div>

                    <h3 className="font-display font-bold text-lg text-[#eef4e6] mt-4">
                      {badge.title}
                    </h3>
                    <div className="text-[11px] font-mono text-[#d9f36a] mt-0.5">
                      {badge.mission}
                    </div>
                    <p className="text-xs text-[#9fb1a6] mt-3 leading-relaxed">
                      {badge.criteria}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-white/10 text-[10px] font-mono text-[#bdc9c0] space-y-1">
                    <span className="text-[#9fb1a6] block">NASA STANDARD:</span>
                    <span className="text-[#eef4e6]">{badge.nasaRef}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Graduation Certificate Action */}
          {unlockedBadges.includes('badge-wings') && (
            <div className="p-6 rounded-2xl bg-gradient-to-r from-[#d9f36a]/15 via-[#72d1d6]/15 to-[#ff9838]/15 border-2 border-[#d9f36a] text-center space-y-4">
              <span className="text-3xl">🌟</span>
              <h3 className="text-2xl font-display font-bold text-[#d9f36a]">
                Congratulations, Cadet {profile?.name || 'Astronaut'}!
              </h3>
              <p className="text-xs text-[#eef4e6] max-w-lg mx-auto">
                You have passed all three qualification phases of the Astronaut Flight Trainer: T-Minus Launch Countdown, Precision Orbital Rendezvous, and Cupola Earth Science.
              </p>
              <div className="flex justify-center gap-4 pt-2">
                <button
                  onClick={() => { playUiClick(); onBackToDeck(); }}
                  className="px-6 py-2.5 rounded-xl bg-[#d9f36a] text-[#061211] font-mono font-bold text-xs uppercase shadow-lg hover:scale-105 transition-all"
                >
                  Return to Flight Deck
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* TAB 5: NASA SOURCES & VERIFICATION ARCHIVE */}
      {/* ------------------------------------------------------------------- */}
      {activeTab === 'citations' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          <div className="bg-[#0b2025] border border-[#1b3834] rounded-xl p-6">
            <span className="text-xs font-mono font-bold uppercase text-[#d9f36a] tracking-widest block mb-1">
              EDUCATIONAL RIGOR &amp; TRANSPARENCY
            </span>
            <h2 className="text-2xl font-display font-bold text-[#eef4e6]">
              NASA Flight Manual Citation Directory
            </h2>
            <p className="text-xs text-[#9fb1a6] mt-2 max-w-2xl leading-relaxed">
              Every numerical tolerance, atmospheric pressure, valve interlock, docking velocity, and orbital photograph in the Cosmora Flight Trainer is traceable directly to real NASA missions, technical publications, and astronaut handbooks.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {NASA_CITATIONS.map(citation => (
              <div
                key={citation.id}
                className="p-5 rounded-xl bg-[#091f22] border border-[#1b3834] hover:border-[#d9f36a]/40 transition-all flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] font-mono text-[#9fb1a6]">
                    <span>MISSION 0{citation.missionNumber}</span>
                    <span className="text-[#d9f36a]">{citation.nasaRefCode}</span>
                  </div>
                  <h4 className="font-display font-bold text-base text-[#eef4e6] mt-1">
                    {citation.topic}
                  </h4>
                  <div className="text-[11px] font-mono text-[#72d1d6] mt-0.5">
                    {citation.sourceDoc}
                  </div>
                  <p className="text-xs text-[#9fb1a6] mt-2 leading-relaxed">
                    {citation.fact}
                  </p>
                </div>
                <NtrsSources prompt={citation.topic} onDemand />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
