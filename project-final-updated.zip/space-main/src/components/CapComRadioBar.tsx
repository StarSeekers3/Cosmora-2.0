import React, { useState, useEffect } from 'react';
import { Radio, Volume2, VolumeX, Sparkles, X, RotateCcw } from 'lucide-react';
import { playUiClick, speakCapCom } from '../utils/audio';

export const CapComRadioBar: React.FC = () => {
  const [transmission, setTransmission] = useState<{ text: string; active: boolean } | null>(null);
  const [minimized, setMinimized] = useState(false);

  useEffect(() => {
    const handleTransmission = (e: Event) => {
      const custom = e as CustomEvent<{ text: string; active: boolean }>;
      if (custom.detail) {
        setTransmission(custom.detail);
        if (custom.detail.active) {
          setMinimized(false);
        }
      }
    };

    window.addEventListener('capcom-transmission', handleTransmission);
    return () => window.removeEventListener('capcom-transmission', handleTransmission);
  }, []);

  if (!transmission || !transmission.text) return null;

  return (
    <div className="fixed bottom-14 left-4 right-4 sm:left-auto sm:right-6 sm:w-[480px] z-50 animate-in slide-in-from-bottom-4 duration-300">
      <div className="bg-[#051417]/95 backdrop-blur-md border-2 border-[#72d1d6] rounded-2xl p-4 shadow-[0_12px_40px_rgba(0,0,0,0.6)] relative overflow-hidden">
        {/* Glow indicator line */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#d9f36a] via-[#72d1d6] to-[#ff9838] animate-pulse" />

        <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-2.5">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#72d1d6]">
            <Radio size={14} className="text-[#d9f36a] animate-pulse" />
            <span>SPACE-TO-GROUND LOOP · COMM 1 (2287.5 MHz)</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#d9f36a]/20 text-[#d9f36a] text-[10px] font-mono font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-[#d9f36a] animate-ping" />
              LIVE
            </span>
            <button
              onClick={() => setTransmission(null)}
              className="p-1 rounded text-[#9fb1a6] hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Close radio transmission"
            >
              <X size={14} />
            </button>
          </div>
        </div>

        <div className="mt-3 flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-[#0a2327] border border-[#72d1d6]/30 text-[#d9f36a] shrink-0 mt-0.5 relative">
            <Radio size={18} className="relative z-10" />
            <div className="absolute inset-0 bg-[#72d1d6]/10 rounded-xl animate-ping opacity-50" />
          </div>

          <div className="flex-1 min-w-0">
            <div className="text-[10px] font-mono text-[#9fb1a6] uppercase tracking-wider flex items-center justify-between">
              <span>NASA JSC CAPCOM / FLIGHT DIRECTOR</span>
              <div className="flex items-center gap-1">
                {/* Animated EQ Bars */}
                <div className="flex items-end gap-0.5 h-4 px-1">
                  <div className="w-1 bg-[#d9f36a] rounded-sm eq-bar-1" />
                  <div className="w-1 bg-[#72d1d6] rounded-sm eq-bar-2" />
                  <div className="w-1 bg-[#d9f36a] rounded-sm eq-bar-3" />
                  <div className="w-1 bg-[#ff9838] rounded-sm eq-bar-4" />
                </div>
                <span className="text-[9px] text-[#72d1d6]">QUINDAR 2525Hz</span>
              </div>
            </div>
            <p className="text-xs sm:text-sm font-mono text-[#eef4e6] font-medium leading-relaxed mt-1 italic drop-shadow-[0_0_8px_rgba(238,244,230,0.2)]">
              &quot;{transmission.text}&quot;
            </p>
          </div>
        </div>

        <div className="mt-3 pt-2.5 border-t border-white/5 flex items-center justify-between text-[10px] font-mono text-[#9fb1a6]">
          <span className="flex items-center gap-1.5 text-[#d9f36a]">
            <span>✦</span> Voice synthesis with Quindar beeps enabled
          </span>
          <button
            onClick={() => {
              playUiClick();
              speakCapCom(transmission.text);
            }}
            className="text-[10px] font-mono text-[#72d1d6] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw size={11} /> Replay Audio
          </button>
        </div>
      </div>
    </div>
  );
};
