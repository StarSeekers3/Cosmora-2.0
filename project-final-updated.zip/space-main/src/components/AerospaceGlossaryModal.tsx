import React, { useState, useMemo } from 'react';
import { BookOpen, Search, X, Sparkles, ExternalLink, HelpCircle, ArrowRight } from 'lucide-react';
import { AEROSPACE_GLOSSARY, GlossaryTerm } from '../data/aerospaceGlossaryData';
import { playUiClick, playTone } from '../utils/audio';

interface AerospaceGlossaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialSearch?: string;
}

export const AerospaceGlossaryModal: React.FC<AerospaceGlossaryModalProps> = ({
  isOpen,
  onClose,
  initialSearch = '',
}) => {
  const [search, setSearch] = useState(initialSearch);
  const [selectedCat, setSelectedCat] = useState<string>('ALL');
  const [selectedTerm, setSelectedTerm] = useState<GlossaryTerm | null>(AEROSPACE_GLOSSARY[0]);

  const categories = useMemo(() => {
    const cats = new Set<string>();
    AEROSPACE_GLOSSARY.forEach(t => cats.add(t.category));
    return ['ALL', ...Array.from(cats)];
  }, []);

  const filteredTerms = useMemo(() => {
    return AEROSPACE_GLOSSARY.filter(t => {
      const matchSearch =
        t.term.toLowerCase().includes(search.toLowerCase()) ||
        t.shortDefinition.toLowerCase().includes(search.toLowerCase()) ||
        t.plainEnglishExplanation.toLowerCase().includes(search.toLowerCase());
      const matchCat = selectedCat === 'ALL' || t.category === selectedCat;
      return matchSearch && matchCat;
    });
  }, [search, selectedCat]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#07181c] border-2 border-[#72d1d6]/40 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden relative">
        {/* Top Header */}
        <div className="p-5 sm:p-6 border-b border-white/10 bg-[#092227] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#72d1d6]/20 text-[#72d1d6] border border-[#72d1d6]/40">
              <BookOpen size={22} />
            </div>
            <div>
              <div className="text-[10px] font-mono tracking-widest text-[#d9f36a] uppercase font-bold">
                NASA FLIGHT DECK JARGON DECODER
              </div>
              <h2 className="text-xl sm:text-2xl font-display font-bold text-[#eef4e6]">
                Astronaut Flight Lexicon
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              playUiClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-[#9fb1a6] hover:text-white transition-colors cursor-pointer"
            aria-label="Close glossary"
          >
            <X size={20} />
          </button>
        </div>

        {/* Search & Category Filter */}
        <div className="p-4 sm:p-5 border-b border-white/5 bg-[#051316] space-y-3">
          <div className="relative">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#9fb1a6]" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search space terms, physics, flight rules (e.g. Max-Q, Delta-V, Gimbal)…"
              className="w-full bg-[#030d0f] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm font-mono text-[#eef4e6] placeholder-[#9fb1a6]/50 focus:outline-none focus:border-[#72d1d6]"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-mono">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => {
                  playUiClick();
                  setSelectedCat(cat);
                }}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all font-bold ${
                  selectedCat === cat
                    ? 'bg-[#72d1d6] text-[#061211] shadow-md'
                    : 'bg-white/5 text-[#9fb1a6] hover:bg-white/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Content: 2-Column Split (List on Left, Rich Detailed Explanation on Right) */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden min-h-[380px]">
          {/* Left Terms List */}
          <div className="md:col-span-5 border-r border-white/10 overflow-y-auto p-3 space-y-2 max-h-[460px] scrollbar-thin scrollbar-thumb-white/10">
            {filteredTerms.map(t => {
              const active = selectedTerm?.id === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => {
                    playTone(600, 0.04);
                    setSelectedTerm(t);
                  }}
                  className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                    active
                      ? 'bg-[#0e292e] border-[#72d1d6] text-white shadow-lg'
                      : 'bg-white/5 border-transparent text-[#9fb1a6] hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-display font-bold text-xs sm:text-sm text-[#eef4e6]">
                      {t.term}
                    </span>
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/40 text-[#72d1d6]">
                      {t.category.split(' ')[0]}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#bdc9c0] mt-1 line-clamp-2 leading-relaxed">
                    {t.shortDefinition}
                  </p>
                </button>
              );
            })}

            {filteredTerms.length === 0 && (
              <div className="p-8 text-center text-xs font-mono text-[#9fb1a6]">
                No terms matched &quot;{search}&quot;. Try searching for Max-Q, Delta-V, or Orbit.
              </div>
            )}
          </div>

          {/* Right Detailed Description Card */}
          <div className="md:col-span-7 p-6 overflow-y-auto space-y-5 bg-[#061417]">
            {selectedTerm ? (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div>
                  <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#72d1d6]">
                    <span>{selectedTerm.category.toUpperCase()}</span>
                    <span>/</span>
                    <span className="text-[#d9f36a]">{selectedTerm.nasaRefCode}</span>
                  </div>
                  <h3 className="font-display font-extrabold text-2xl text-[#eef4e6] mt-1">
                    {selectedTerm.term}
                  </h3>
                </div>

                {/* Plain English Breakdown for young space fans */}
                <div className="p-4 rounded-2xl bg-[#092226] border border-[#72d1d6]/30 space-y-1.5">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-[#d9f36a] font-bold block">
                    PLAIN ENGLISH EXPLANATION (FOR FUTURE ASTRONAUTS):
                  </span>
                  <p className="text-sm text-[#eef4e6] leading-relaxed">
                    {selectedTerm.plainEnglishExplanation}
                  </p>
                </div>

                {/* NASA Real Mission Example */}
                <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-1.5">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-[#ff9838] font-bold block">
                    REAL NASA FLIGHT APPLICATION:
                  </span>
                  <p className="text-xs text-[#bdc9c0] leading-relaxed">
                    {selectedTerm.nasaMissionExample}
                  </p>
                </div>

                {/* Mathematical or Aerospace metric */}
                {selectedTerm.formulaOrMetric && (
                  <div className="p-3 bg-white/5 rounded-xl border border-white/5 font-mono text-xs text-[#72d1d6] flex items-center justify-between">
                    <span className="text-[#9fb1a6] text-[10px]">FLIGHT SPEC / METRIC:</span>
                    <span className="font-bold">{selectedTerm.formulaOrMetric}</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-xs font-mono text-[#9fb1a6]">
                Select any aerospace term to inspect its NASA definition.
              </div>
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="p-4 border-t border-white/10 bg-[#051113] flex items-center justify-between text-[11px] font-mono text-[#9fb1a6]">
          <span>INDEXED FROM NASA FLIGHT CREW OPERATIONS HANDBOOK</span>
          <span className="text-[#d9f36a]">30+ AEROSPACE TERMS</span>
        </div>
      </div>
    </div>
  );
};
