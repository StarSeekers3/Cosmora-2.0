import React, { useEffect, useRef, useState } from 'react';
import {
  Volume2, VolumeX, Sun, Moon, Award, Compass, Sparkles, Orbit, Star, Radio, ShieldCheck, Check,
  Menu, X, ChevronDown, SlidersHorizontal, UserCog, Rocket, Database, Satellite, type LucideIcon,
} from 'lucide-react';
import { AstronautProfile } from '../types';
import { playUiClick } from '../utils/audio';
import { getAstronautRank } from '../utils/ranks';
import { AvatarVisual } from './AvatarVisual';

export type AppView =
  | 'intake'
  | 'flightdeck'
  | 'trainer'
  | 'spacedata'
  | 'mission'
  | 'certificate'
  | 'observatory'
  | 'starmap'
  | 'telemetry'
  | 'radar'
  | 'dossier'
  | 'missioncontrol'
  | 'blackhole';

interface HeaderProps {
  profile: AstronautProfile | null;
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  soundMuted: boolean;
  onToggleSound: () => void;
  bgMode: 'solar' | 'blackhole';
  onToggleBgMode: () => void;
  reduceMotion: boolean;
  onToggleReduceMotion: () => void;
  dayNightCycle: boolean;
  onToggleDayNightCycle: () => void;
  backgroundToggleEnabled?: boolean;
}

interface NavItem {
  id: AppView;
  label: string;
  desc: string;
  icon: LucideIcon;
  accent: string;
  live?: boolean;
}

const PRIMARY: NavItem[] = [
  { id: 'flightdeck', label: 'Missions', desc: 'Your missions and progress', icon: Compass, accent: '#d9f36a' },
  { id: 'trainer', label: 'Training', desc: 'Launch, docking and Earth scan practice', icon: Rocket, accent: '#ff9838' },
  { id: 'observatory', label: 'Solar System', desc: 'Explore every planet in 3D', icon: Orbit, accent: '#72d1d6' },
  { id: 'starmap', label: 'Star Map', desc: 'Constellations and deep-sky objects', icon: Star, accent: '#ffc93c' },
  { id: 'telemetry', label: 'Live Data', desc: 'ISS tracker, space weather and NASA data', icon: Radio, accent: '#66d17a', live: true },
];
const ACCOUNT: NavItem[] = [
  { id: 'dossier', label: 'My Profile', desc: 'Badge, rank and achievements', icon: ShieldCheck, accent: '#72d1d6' },
  { id: 'certificate', label: 'Certificate', desc: 'Your graduation certificate', icon: Award, accent: '#ffc93c' },
];

const RANK_STEPS = [0, 25, 70, 140, 220, 320];
const CERT_MISSIONS = 4;

function rankProgress(xp: number) {
  const next = RANK_STEPS.find(s => s > xp);
  if (next === undefined) return { pct: 100, next: null as number | null, prev: 320 };
  const prev = [...RANK_STEPS].reverse().find(s => s <= xp) ?? 0;
  return { pct: Math.round(((xp - prev) / (next - prev)) * 100), next, prev };
}

/** Closes a popover on outside pointer-down or Escape. */
function useDismiss(open: boolean, close: () => void, ref: React.RefObject<HTMLElement | null>) {
  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) close(); };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
    document.addEventListener('pointerdown', onDown);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('pointerdown', onDown); document.removeEventListener('keydown', onKey); };
  }, [open, close, ref]);
}

const Switch: React.FC<{ on: boolean; compact?: boolean }> = ({ on, compact = false }) => (
  <span className={`cn-switch ${compact ? 'cn-switch--compact' : ''} ${on ? 'is-on' : ''}`} aria-hidden="true">
    <i />
    <Check className="cn-switch-check" size={25} strokeWidth={2.8} />
    <X className="cn-switch-off" size={25} strokeWidth={2.8} />
  </span>
);

export const Header: React.FC<HeaderProps> = ({
  profile, currentView, onNavigate, theme, onToggleTheme, soundMuted, onToggleSound, bgMode, onToggleBgMode, reduceMotion, onToggleReduceMotion, dayNightCycle, onToggleDayNightCycle,
  backgroundToggleEnabled = true,
}) => {
  const [menu, setMenu] = useState<null | 'account' | 'display'>(null);
  const [sheet, setSheet] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const accountRef = useRef<HTMLDivElement>(null);
  const displayRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLElement>(null);

  const rank = profile ? getAstronautRank(profile.points) : null;
  const prog = profile ? rankProgress(profile.points) : null;
  const rankInk = rank ? `color-mix(in srgb, ${rank.color}, var(--nav-strong) var(--rank-mix))` : undefined;
  const done = profile ? Math.min(profile.completed.length, CERT_MISSIONS) : 0;

  const closeAccount = () => setMenu(m => (m === 'account' ? null : m));
  const closeDisplay = () => setMenu(m => (m === 'display' ? null : m));
  useDismiss(menu === 'account', closeAccount, accountRef);
  useDismiss(menu === 'display', closeDisplay, displayRef);
  useDismiss(sheet, () => setSheet(false), headerRef);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 6);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  useEffect(() => { setMenu(null); setSheet(false); }, [currentView]);

  const go = (view: AppView) => { playUiClick(); setMenu(null); setSheet(false); onNavigate(view); };
  const accentStyle = (c: string) => ({ ['--accent' as string]: c }) as React.CSSProperties;
  const isActive = (id: AppView) => (currentView === id || (id === 'telemetry' && (currentView === 'radar' || currentView === 'spacedata')) ? 'page' : undefined);
  const currentPageLabel = currentView === 'intake'
    ? 'Create profile'
    : currentView === 'missioncontrol'
      ? 'Mission Control'
      : currentView === 'radar'
        ? 'Live Data'
        : currentView === 'spacedata'
          ? 'Live Data'
        : currentView === 'blackhole'
        ? 'Black Holes'
        : [...PRIMARY, ...ACCOUNT].find(item => item.id === currentView)?.label ?? 'Mission';

  const displayRows = (
    <>
      <button className="cn-item cn-focus" role="menuitemcheckbox" aria-checked={!soundMuted} onClick={() => { playUiClick(); onToggleSound(); }}>
        <span className="cn-item-ico" style={accentStyle('#d9f36a')}>{soundMuted ? <VolumeX size={17} /> : <Volume2 size={17} />}</span>
        <span className="flex-1 min-w-0"><div className="cn-item-title">Sound effects</div><div className="cn-item-desc">{soundMuted ? 'Muted' : 'Sound on'}</div></span>
        <Switch on={!soundMuted} />
      </button>
      <button className="cn-item cn-focus" role="menuitemcheckbox" aria-checked={theme === 'light'} onClick={() => { playUiClick(); onToggleTheme(); }}>
        <span className="cn-item-ico" style={accentStyle('#ffc93c')}>{theme === 'light' ? <Sun size={17} /> : <Moon size={17} />}</span>
        <span className="flex-1 min-w-0"><div className="cn-item-title">Light mode</div><div className="cn-item-desc">{theme === 'light' ? 'Light mode is on' : 'Dark mode is on'}</div></span>
        <Switch on={theme === 'light'} />
      </button>
      <button className="cn-item cn-focus" role="menuitemcheckbox" aria-checked={reduceMotion} onClick={() => { playUiClick(); onToggleReduceMotion(); }}>
        <span className="cn-item-ico" style={accentStyle('#ef7144')}><SlidersHorizontal size={17} /></span>
        <span className="flex-1 min-w-0"><div className="cn-item-title">Reduce motion</div><div className="cn-item-desc">{reduceMotion ? 'Animations are reduced' : 'Animations are on'}</div></span>
        <Switch on={reduceMotion} />
      </button>
      <button className="cn-item cn-focus" role="menuitemcheckbox" aria-checked={dayNightCycle} onClick={() => { playUiClick(); onToggleDayNightCycle(); }}>
        <span className="cn-item-ico" style={accentStyle('#ffc93c')}><Sun size={17} /></span>
        <span className="flex-1 min-w-0"><div className="cn-item-title">Day and night</div><div className="cn-item-desc">{dayNightCycle ? 'Background changes slowly' : 'Paused'}</div></span>
        <Switch on={dayNightCycle} />
      </button>
      {backgroundToggleEnabled && (
        <button className="cn-item cn-focus" role="menuitemcheckbox" aria-checked={bgMode === 'blackhole'} onClick={() => { playUiClick(); onToggleBgMode(); }}>
          <span className="cn-item-ico" style={accentStyle('#72d1d6')}>{bgMode === 'solar' ? <Orbit size={17} /> : <Sparkles size={17} />}</span>
          <span className="flex-1 min-w-0"><div className="cn-item-title">Background</div><div className="cn-item-desc">{bgMode === 'solar' ? 'Solar system' : 'Black hole'}</div></span>
          <Switch on={bgMode === 'blackhole'} />
        </button>
      )}
    </>
  );

  return (
    <>
      <a href="#main-content" className="cn-skip">Skip to main content</a>
      <header ref={headerRef} className={`cn-header ${scrolled ? 'is-scrolled' : ''}`}>
        <div className="cn-header-inner mx-auto flex items-center gap-3 lg:gap-5">
          {/* Brand */}
          <button onClick={() => go(profile ? 'flightdeck' : 'intake')} className="cn-brand cn-focus shrink-0 group" aria-label="Cosmora home">
            <img src="/cosmora-neon-wordmark.png" alt="Cosmora" className="h-9 w-[132px] sm:h-10 sm:w-[205px] xl:h-11 xl:w-[220px] object-contain drop-shadow-[0_0_10px_rgba(61,182,255,0.18)] transition-transform duration-300 group-hover:scale-[1.02]" />
          </button>

          {/* Primary navigation (desktop) */}
          {profile && (
            <nav aria-label="Primary" className="cn-primary-nav hidden xl:flex shrink-0 items-center gap-0.5">
              {PRIMARY.map(item => {
                const Icon = item.icon;
                return (
                  <button key={item.id} className="cn-link cn-focus" style={accentStyle(item.accent)} aria-current={isActive(item.id)} onClick={() => go(item.id)}>
                    <Icon size={16} />
                    <span>{item.label}</span>
                    {item.live && <i className="cn-live-dot" aria-label="live data" />}
                  </button>
                );
              })}
            </nav>
          )}

          <div className="flex-1" />

          {/* Right cluster (desktop) */}
          <div className="cn-header-tools hidden xl:flex items-center gap-2">
            <div ref={displayRef} className="relative">
              <button className="cn-iconbtn cn-focus" aria-haspopup="menu" aria-expanded={menu === 'display'} aria-label="Settings"
                onClick={() => { playUiClick(); setMenu(m => (m === 'display' ? null : 'display')); }}>
                <SlidersHorizontal size={17} />
              </button>
              {menu === 'display' && (
                <div className="cn-panel" role="menu" aria-label="Settings" style={{ width: 300 }}>
                  <div className="cn-menu-label">Settings</div>
                  {displayRows}
                </div>
              )}
            </div>

            {profile && rank && prog && (
              <div ref={accountRef} className="relative">
                <button className="cn-account cn-focus" aria-haspopup="menu" aria-expanded={menu === 'account'} aria-label="Account menu"
                  onClick={() => { playUiClick(); setMenu(m => (m === 'account' ? null : 'account')); }}>
                  <AvatarVisual avatar={profile.avatar} alt={`${profile.name} avatar`} className="cn-avatar select-none" />
                  <span className="min-w-[104px] max-w-[140px]">
                    <span className="flex items-center justify-between gap-2">
                      <span className="text-[12.5px] font-bold leading-tight truncate" style={{ color: 'var(--nav-strong)' }}>{profile.name}</span>
                    </span>
                    <span className="block text-[10px] font-mono tracking-wide truncate" style={{ color: rankInk }}>{rank.icon} {rank.title}</span>
                  </span>
                  <span className="text-right leading-tight">
                    <span className="block text-[12px] font-mono font-bold" style={{ color: 'var(--lime)' }}>{profile.points} XP</span>
                    <span className="cn-xpbar block w-[58px] mt-1"><i style={{ width: `${prog.pct}%` }} /></span>
                  </span>
                  <ChevronDown size={15} style={{ color: 'var(--nav-muted)', transform: menu === 'account' ? 'rotate(180deg)' : undefined, transition: 'transform .18s' }} />
                </button>

                {menu === 'account' && (
                  <div className="cn-panel" role="menu" aria-label="Cadet account">
                    <div className="px-3 pt-2.5 pb-3">
                      <div className="flex items-center gap-3">
                        <AvatarVisual avatar={profile.avatar} alt={`${profile.name} avatar`} className="cn-avatar !w-11 !h-11 !text-[22px]" />
                        <div className="min-w-0">
                          <div className="text-[14px] font-bold truncate" style={{ color: 'var(--nav-strong)' }}>{profile.name}</div>
                          <div className="text-[11px] font-mono" style={{ color: rankInk }}>{rank.icon} {rank.title} · {rank.grade}</div>
                        </div>
                      </div>
                      <div className="mt-3">
                        <div className="flex justify-between text-[10px] font-mono mb-1" style={{ color: 'var(--nav-muted)' }}>
                          <span>{profile.points} XP</span>
                          <span>{prog.next ? `${prog.next - profile.points} XP to next rank` : 'Highest rank reached'}</span>
                        </div>
                        <div className="cn-xpbar !h-[5px]"><i style={{ width: `${prog.pct}%` }} /></div>
                      </div>
                    </div>
                    <div className="cn-sep" />
                    {ACCOUNT.map(item => {
                      const Icon = item.icon;
                      return (
                        <button key={item.id} role="menuitem" className="cn-item cn-focus" style={accentStyle(item.accent)} aria-current={isActive(item.id)} onClick={() => go(item.id)}>
                          <span className="cn-item-ico"><Icon size={17} /></span>
                          <span className="flex-1 min-w-0"><div className="cn-item-title">{item.label}</div><div className="cn-item-desc">{item.desc}</div></span>
                          {item.id === 'certificate' && <span className="cn-pill" style={done >= CERT_MISSIONS ? { background: 'rgba(255,201,60,.9)', color: '#061211' } : undefined}>{done}/{CERT_MISSIONS}</span>}
                        </button>
                      );
                    })}
                    <div className="cn-sep" />
                    <button role="menuitem" className="cn-item cn-focus" style={accentStyle('#9fb1a6')} onClick={() => go('intake')}>
                      <span className="cn-item-ico"><UserCog size={17} /></span>
                      <span className="flex-1 min-w-0"><div className="cn-item-title">Edit profile</div><div className="cn-item-desc">Change your name or avatar</div></span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right cluster (mobile / tablet) */}
          <div className="flex xl:hidden items-center gap-1.5 sm:gap-2">
            {profile && (
              <span className="hidden sm:flex items-center gap-1.5 h-10 px-2.5 rounded-[10px] text-[12px] font-mono font-bold" style={{ background: 'var(--nav-chip)', border: '1px solid var(--nav-border)', color: 'var(--lime)' }}>
                <Sparkles size={13} />{profile.points} XP
              </span>
            )}
            <span className="hidden min-[360px]:inline-block max-w-[76px] sm:max-w-[120px] truncate text-[9px] sm:text-[10px] font-mono font-bold tracking-wide" style={{ color: 'var(--nav-muted)' }} aria-live="polite">{currentPageLabel}</span>
            <button className="cn-iconbtn cn-focus" aria-label={sheet ? 'Close menu' : 'Open menu'} aria-expanded={sheet} aria-controls="cn-sheet" onClick={() => { playUiClick(); setSheet(s => !s); }}>
              {sheet ? <X size={19} /> : <Menu size={19} />}
            </button>
          </div>
        </div>

        {/* Mobile / tablet sheet */}
        {sheet && (
          <div id="cn-sheet" className="cn-sheet xl:hidden" role="dialog" aria-label="Main menu">
            {profile && rank && prog && (
              <div className="flex items-center gap-3 p-3 mb-2 rounded-2xl" style={{ background: 'var(--nav-chip)', border: '1px solid var(--nav-border)' }}>
                <AvatarVisual avatar={profile.avatar} alt={`${profile.name} avatar`} className="cn-avatar !w-12 !h-12 !text-[24px]" />
                <div className="flex-1 min-w-0">
                  <div className="text-[14px] font-bold truncate" style={{ color: 'var(--nav-strong)' }}>{profile.name}</div>
                  <div className="text-[11px] font-mono" style={{ color: rankInk }}>{rank.icon} {rank.title}</div>
                  <div className="cn-xpbar mt-2"><i style={{ width: `${prog.pct}%` }} /></div>
                </div>
                <div className="text-right text-[11px] font-mono" style={{ color: 'var(--nav-muted)' }}>
                  <div className="text-[14px] font-bold" style={{ color: 'var(--lime)' }}>{profile.points} XP</div>
                  {prog.next ? `${prog.next - profile.points} to next` : 'Max rank'}
                </div>
              </div>
            )}
            {profile && (
              <>
                <div className="cn-menu-label">Menu</div>
                {PRIMARY.map(item => {
                  const Icon = item.icon;
                  return (
                    <button key={item.id} className="cn-item cn-focus" style={accentStyle(item.accent)} aria-current={isActive(item.id)} onClick={() => go(item.id)}>
                      <span className="cn-item-ico"><Icon size={18} /></span>
                      <span className="flex-1 min-w-0"><div className="cn-item-title">{item.label}</div><div className="cn-item-desc">{item.desc}</div></span>
                      {item.live && <i className="cn-live-dot" />}
                    </button>
                  );
                })}
                <div className="cn-menu-label">Account</div>
                {ACCOUNT.map(item => {
                  const Icon = item.icon;
                  return (
                    <button key={item.id} className="cn-item cn-focus" style={accentStyle(item.accent)} aria-current={isActive(item.id)} onClick={() => go(item.id)}>
                      <span className="cn-item-ico"><Icon size={18} /></span>
                      <span className="flex-1 min-w-0"><div className="cn-item-title">{item.label}</div><div className="cn-item-desc">{item.desc}</div></span>
                      {item.id === 'certificate' && <span className="cn-pill">{done}/{CERT_MISSIONS}</span>}
                    </button>
                  );
                })}
                <button className="cn-item cn-focus" style={accentStyle('#9fb1a6')} onClick={() => go('intake')}>
                  <span className="cn-item-ico"><UserCog size={18} /></span>
                  <span className="flex-1 min-w-0"><div className="cn-item-title">Edit profile</div><div className="cn-item-desc">Change your name or avatar</div></span>
                </button>
                <div className="cn-sep" />
              </>
            )}
            <div className="cn-menu-label">Settings</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-1">
              <button className="cn-tile cn-focus" aria-pressed={!soundMuted} onClick={() => { playUiClick(); onToggleSound(); }}>
                <Switch compact on={!soundMuted} /><span>{soundMuted ? 'Sound off' : 'Sound on'}</span>
              </button>
              <button className="cn-tile cn-focus" aria-pressed={theme === 'light'} onClick={() => { playUiClick(); onToggleTheme(); }}>
                <Switch compact on={theme === 'light'} /><span>{theme === 'light' ? 'Light' : 'Dark'}</span>
              </button>
              <button className="cn-tile cn-focus" aria-pressed={bgMode === 'blackhole'} onClick={() => { playUiClick(); onToggleBgMode(); }}>
                <Switch compact on={bgMode === 'blackhole'} /><span>{bgMode === 'solar' ? 'Solar system' : 'Black hole'}</span>
              </button>
              <button className="cn-tile cn-focus" aria-pressed={reduceMotion} onClick={() => { playUiClick(); onToggleReduceMotion(); }}>
                <Switch compact on={reduceMotion} /><span>{reduceMotion ? 'Motion off' : 'Motion on'}</span>
              </button>
              <button className="cn-tile cn-focus" aria-pressed={dayNightCycle} onClick={() => { playUiClick(); onToggleDayNightCycle(); }}>
                <Switch compact on={dayNightCycle} /><span>{dayNightCycle ? 'Day/night on' : 'Day/night off'}</span>
              </button>
            </div>
          </div>
        )}

              </header>
    </>
  );
};
