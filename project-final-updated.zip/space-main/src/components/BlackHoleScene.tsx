import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Pause, Play, Sliders } from 'lucide-react';

interface BlackHoleSceneProps {
  interactive?: boolean;
  theme?: 'dark' | 'light';
}

export const BlackHoleScene: React.FC<BlackHoleSceneProps> = ({
  interactive = false,
  theme = 'dark',
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [speed, setSpeed] = useState(0.42);
  const [paused, setPaused] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const [webglError, setWebglError] = useState(false);
  const speedRef = useRef(speed);
  const pausedRef = useRef(paused);
  speedRef.current = speed;
  pausedRef.current = paused;
  const isLight = theme === 'light';

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: 'low-power',
      });
    } catch (error) {
      console.error('[BlackHoleScene] Unable to initialize WebGL rendering.', error);
      setWebglError(true);
      return;
    }

    setWebglError(false);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    mount.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(isLight ? 0x09090d : 0x02040a);
    const camera = new THREE.PerspectiveCamera(42, window.innerWidth / window.innerHeight, 0.1, 140);
    camera.position.set(0, 4.5, 20);
    camera.lookAt(0, -2, 0);

    scene.add(new THREE.AmbientLight(isLight ? 0x8e7892 : 0x28182a, 0.85));
    const keyLight = new THREE.PointLight(isLight ? 0xffc388 : 0xff9a52, 48, 36, 1.7);
    keyLight.position.set(-5, 5, 4);
    scene.add(keyLight);

    const starCount = window.innerWidth < 768 ? 650 : 1500;
    const starPositions = new Float32Array(starCount * 3);
    const starColors = new Float32Array(starCount * 3);
    const colorChoices = [
      new THREE.Color(isLight ? 0x694e77 : 0xd8dfff),
      new THREE.Color(isLight ? 0xb57846 : 0xffdca5),
      new THREE.Color(isLight ? 0x667f9c : 0x9cc9ff),
    ];
    for (let i = 0; i < starCount; i += 1) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const radius = 52 + Math.random() * 24;
      starPositions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      starPositions[i * 3 + 1] = radius * Math.cos(phi);
      starPositions[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
      const color = colorChoices[i % colorChoices.length];
      starColors[i * 3] = color.r;
      starColors[i * 3 + 1] = color.g;
      starColors[i * 3 + 2] = color.b;
    }
    const starsGeometry = new THREE.BufferGeometry();
    starsGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    starsGeometry.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
    const stars = new THREE.Points(
      starsGeometry,
      new THREE.PointsMaterial({
        size: 0.105,
        sizeAttenuation: true,
        transparent: true,
        opacity: isLight ? 0.38 : 0.9,
        vertexColors: true,
      })
    );
    scene.add(stars);

    const horizon = new THREE.Mesh(
      new THREE.SphereGeometry(1.34, 64, 48),
      new THREE.MeshBasicMaterial({ color: 0x010207 })
    );
    scene.add(horizon);

    const photonSphere = new THREE.Mesh(
      new THREE.TorusGeometry(1.43, 0.012, 8, 220),
      new THREE.MeshBasicMaterial({
        color: isLight ? 0xffb35d : 0xffd995,
        transparent: true,
        opacity: isLight ? 0.48 : 0.7,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    photonSphere.rotation.x = -0.33;
    scene.add(photonSphere);

    const diskMaterial = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uLightTheme: { value: isLight ? 1 : 0 },
      },
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform float uLightTheme;
        varying vec2 vUv;
        float hash(vec2 p) {
          p = fract(p * vec2(123.34, 456.21));
          p += dot(p, p + 45.32);
          return fract(p.x * p.y);
        }
        float noise(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          return mix(
            mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
            mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x),
            f.y
          );
        }
        void main() {
          vec2 centered = (vUv - 0.5) * 2.0;
          float radius = length(centered);
          float angle = atan(centered.y, centered.x);
          float innerEdge = smoothstep(0.31, 0.4, radius);
          float outerEdge = 1.0 - smoothstep(0.92, 1.0, radius);
          vec2 flow = vec2(angle * 3.2 - uTime * 0.16, radius * 18.0 - angle * 0.7);
          float turbulence = noise(flow) * 0.58 + noise(flow * 2.4 + 6.7) * 0.42;
          float filaments = 0.48 + 0.52 * smoothstep(0.15, 0.82, turbulence);
          float doppler = 0.38 + 0.62 * smoothstep(-0.55, 0.88, cos(angle));
          float heat = 1.0 - smoothstep(0.39, 0.91, radius);
          float innerGlow = exp(-pow((radius - 0.43) * 12.0, 2.0));
          float hotSpot = pow(max(0.0, cos(angle - uTime * 0.12 - 1.2)), 18.0)
                        * exp(-pow((radius - 0.53) * 9.0, 2.0));
          vec3 outer = mix(vec3(0.24, 0.035, 0.018), vec3(0.55, 0.13, 0.035), doppler);
          vec3 inner = mix(vec3(0.82, 0.25, 0.055), vec3(1.0, 0.72, 0.32), doppler);
          vec3 color = mix(outer, inner, heat) * (0.84 + turbulence * 0.4);
          color += vec3(0.28, 0.16, 0.055) * innerGlow * doppler;
          color += vec3(0.22, 0.11, 0.035) * hotSpot;
          if (uLightTheme > 0.5) {
            color = mix(vec3(0.3, 0.06, 0.02), vec3(0.88, 0.34, 0.065), heat);
          }
          float alpha = innerEdge * outerEdge * filaments * (0.32 + doppler * 0.5);
          gl_FragColor = vec4(color, alpha * (0.52 + innerGlow * 0.16 + hotSpot * 0.14));
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }
      `,
      side: THREE.DoubleSide,
      transparent: true,
      depthWrite: false,
      blending: THREE.NormalBlending,
    });

    const disk = new THREE.Mesh(new THREE.RingGeometry(1.42, 4.8, 320, 64), diskMaterial);
    disk.rotation.x = 1.1;
    scene.add(disk);

    const lensingHalo = new THREE.Group();
    lensingHalo.rotation.x = -0.33;
    scene.add(lensingHalo);
    for (let i = 0; i < 2; i += 1) {
      const halo = new THREE.Mesh(
        new THREE.TorusGeometry(1.55 + i * 0.13, 0.008 - i * 0.002, 6, 180),
        new THREE.MeshBasicMaterial({
          color: i === 0 ? 0xffe7b5 : 0xffa95e,
          transparent: true,
          opacity: (0.32 - i * 0.1) * (isLight ? 0.65 : 1),
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      );
      lensingHalo.add(halo);
    }

    const glowCanvas = document.createElement('canvas');
    glowCanvas.width = 128;
    glowCanvas.height = 128;
    const glowContext = glowCanvas.getContext('2d');
    if (glowContext) {
      const glow = glowContext.createRadialGradient(64, 64, 4, 64, 64, 64);
      glow.addColorStop(0, 'rgba(255,219,161,0.23)');
      glow.addColorStop(0.18, 'rgba(255,155,73,0.12)');
      glow.addColorStop(1, 'rgba(255,110,38,0)');
      glowContext.fillStyle = glow;
      glowContext.fillRect(0, 0, 128, 128);
    }
    const glowTexture = new THREE.CanvasTexture(glowCanvas);
    const glowSprite = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowTexture,
      color: isLight ? 0xffc47a : 0xffffff,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      opacity: isLight ? 0.12 : 0.2,
    }));
    glowSprite.scale.set(12, 1.3, 1);
    scene.add(glowSprite);

    const resizeObserver = new ResizeObserver(() => {
      if (!mount.clientWidth || !mount.clientHeight) return;
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    });
    resizeObserver.observe(mount);

    const timer = new THREE.Timer();
    timer.connect(document);
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let frameId = 0;
    const render = () => {
      frameId = window.requestAnimationFrame(render);
      timer.update();
      const delta = Math.min(timer.getDelta(), 0.05);
      const elapsed = timer.getElapsed();
      if (!pausedRef.current && !reducedMotion) {
        disk.rotation.z += delta * speedRef.current * 0.2;
        photonSphere.rotation.z += delta * speedRef.current * 0.035;
        lensingHalo.rotation.z += delta * speedRef.current * 0.11;
        stars.rotation.y += delta * 0.002;
        diskMaterial.uniforms.uTime.value = elapsed * speedRef.current;
        const orbit = elapsed * 0.035;
        camera.position.x = Math.sin(orbit) * 0.55;
        camera.position.y = 4.5 + Math.sin(orbit * 0.6) * 0.12;
        camera.lookAt(0, -2, 0);
      }
      renderer.render(scene, camera);
    };
    render();

    return () => {
      window.cancelAnimationFrame(frameId);
      timer.dispose();
      resizeObserver.disconnect();
      scene.traverse(object => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Points || object instanceof THREE.Sprite) {
          if (object instanceof THREE.Mesh || object instanceof THREE.Points) object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : object.material ? [object.material] : [];
          materials.forEach(material => {
            if (material instanceof THREE.ShaderMaterial) {
              Object.values(material.uniforms).forEach(uniform => {
                if (uniform.value instanceof THREE.Texture) uniform.value.dispose();
              });
            }
            material.dispose();
          });
        }
      });
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [isLight]);

  return (
    <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
      <div ref={mountRef} className="absolute inset-0" />
      {webglError && <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,#190f17_0%,#030509_72%)]" aria-hidden="true" />}
      {interactive && (
        <div
          className={`absolute bottom-6 right-6 z-20 pointer-events-auto rounded-xl p-3.5 text-xs shadow-2xl border ${
            isLight
              ? 'bg-white/95 border-[#173c32]/30 text-[#17251f]'
              : 'bg-[#0b2025]/88 border-[#72d1d6]/35 text-[#eef4e6]'
          } backdrop-blur-md space-y-2.5 min-w-[260px]`}
        >
          <div className="flex items-center justify-between">
            <button
              onClick={() => setShowControls(!showControls)}
              className={`flex items-center gap-2 font-display font-bold hover:underline cursor-pointer ${
                isLight ? 'text-[#1e6f3d]' : 'text-[#72d1d6]'
              }`}
            >
              <Sliders size={14} />
              <span>BLACK HOLE OBSERVATION HUD</span>
            </button>
            <span className="rounded bg-cyan-400/10 px-2 py-0.5 font-mono text-[9px] font-bold text-cyan-300">
              3D · LENSING
            </span>
          </div>
          {showControls && (
            <div className="space-y-2.5 border-t border-current/10 pt-2 font-mono text-[11px]">
              <label className="block">
                <span className="mb-1 flex justify-between">
                  <span>Accretion flow</span>
                  <strong>{paused ? 'PAUSED' : `${speed.toFixed(2)}×`}</strong>
                </span>
                <input
                  type="range"
                  min="0.1"
                  max="1.8"
                  step="0.05"
                  value={speed}
                  onChange={event => {
                    setSpeed(Number(event.target.value));
                    setPaused(false);
                  }}
                  className="w-full cursor-pointer accent-cyan-400"
                />
              </label>
              <button
                onClick={() => setPaused(value => !value)}
                className="flex items-center gap-1.5 rounded bg-cyan-400/15 px-2.5 py-1 text-[10px] font-bold text-cyan-200 transition hover:bg-cyan-400/25"
              >
                {paused ? <Play size={11} /> : <Pause size={11} />}
                {paused ? 'RESUME FLOW' : 'PAUSE ANIMATION'}
              </button>
              <p className="text-[10px] leading-snug text-gray-400">
                Three-dimensional event horizon, tilted plasma disk and gravitational lensing inspired by NASA Goddard simulations.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
