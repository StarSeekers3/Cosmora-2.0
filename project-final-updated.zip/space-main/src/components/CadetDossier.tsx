import React, { useState, useMemo } from 'react';
import {
  ArrowLeft,
  Printer,
  ShieldCheck,
  Award,
  Sparkles,
  Lock,
  QrCode,
  Orbit,
  Fingerprint,
  ChevronRight,
  BadgeCheck,
  Clock,
  CheckCircle2,
  Rocket,
  Search,
  SlidersHorizontal,
  Layers,
  Activity,
  Flame,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Zap,
  Play,
  RotateCcw,
  Star,
  Medal,
  BookOpen,
  AlertTriangle,
} from 'lucide-react';
import { AstronautProfile, MissionHistoryRecord } from '../types';
import { BADGES, MISSIONS } from '../data/missionsData';
import {
  getProfileMissionHistory,
  SAMPLE_NASA_SIMULATED_FLIGHTS,
  NASA_MISSION_TELEMETRY,
} from '../data/missionTelemetryData';
import { playUiClick, playSuccessChime, playTone, speakCapCom } from '../utils/audio';
import { getAstronautRank } from '../utils/ranks';
import { AvatarVisual } from './AvatarVisual';
import { MissionPatchGenerator } from './MissionPatchGenerator';
import { EmergencyDrillModal } from './EmergencyDrillModal';
import { AerospaceGlossaryModal } from './AerospaceGlossaryModal';

interface GradeBadgeProps {
  grade: 'S' | 'A+' | 'A' | 'B';
  compact?: boolean;
}

const GradeStarIcon: React.FC<{ grade: 'S' | 'A+' | 'A' | 'B'; size?: number }> = ({ grade, size = 12 }) => {
  switch (grade) {
    case 'S':
      return <Star size={size} className="fill-[#ffd700] text-[#ffd700] drop-shadow-[0_0_5px_rgba(255,215,0,0.9)]" />;
    case 'A+':
      return <Star size={size} className="fill-[#e2e8f0] text-[#94a3b8] drop-shadow-[0_0_4px_rgba(226,232,240,0.8)]" />;
    case 'A':
      return <Star size={size} className="fill-[#f59e0b] text-[#b45309] drop-shadow-[0_0_4px_rgba(245,158,11,0.7)]" />;
    case 'B':
    default:
      return <Star size={size} className="fill-[#38bdf8] text-[#0284c7] drop-shadow-[0_0_3px_rgba(56,189,248,0.6)]" />;
  }
};

const GradeBadge: React.FC<GradeBadgeProps> = ({ grade, compact = false }) => {
  switch (grade) {
    case 'S':
      // Gold Star Badge
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-mono font-extrabold rounded-lg border transition-all ${
            compact
              ? 'px-2 py-0.5 text-[10px] bg-gradient-to-r from-[#ffe259]/20 to-[#ffa751]/20 border-[#ffc93c] text-[#ffd700] shadow-[0_0_10px_rgba(255,201,60,0.35)]'
              : 'px-2.5 py-1 text-xs bg-gradient-to-r from-[#ffd700] via-[#ffc93c] to-[#f59e0b] text-[#061211] border-[#ffe259] shadow-[0_0_14px_rgba(255,215,0,0.5)] animate-pulse'
          }`}
          title="Gold Star Distinction: Grade S (Optimum NASA Flight Trajectory)"
        >
          <span className="flex items-center">
            <Star size={compact ? 11 : 13} className="fill-[#ffd700] text-[#ffd700] drop-shadow-[0_0_6px_rgba(255,215,0,0.9)]" />
          </span>
          <span className={compact ? 'tracking-wider' : 'tracking-widest font-black'}>
            {compact ? 'GOLD STAR · S' : 'GOLD STAR · GRADE S'}
          </span>
        </span>
      );
    case 'A+':
      // Silver Star Badge
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-mono font-extrabold rounded-lg border transition-all ${
            compact
              ? 'px-2 py-0.5 text-[10px] bg-gradient-to-r from-[#f1f5f9]/15 to-[#cbd5e1]/15 border-[#94a3b8] text-[#e2e8f0] shadow-[0_0_8px_rgba(203,213,225,0.3)]'
              : 'px-2.5 py-1 text-xs bg-gradient-to-r from-[#f8fafc] via-[#e2e8f0] to-[#cbd5e1] text-[#0f172a] border-[#e2e8f0] shadow-[0_0_12px_rgba(226,232,240,0.45)]'
          }`}
          title="Silver Star Distinction: Grade A+ (Exemplary NASA Flight Performance)"
        >
          <span className="flex items-center">
            <Star size={compact ? 11 : 13} className="fill-[#e2e8f0] text-[#94a3b8] drop-shadow-[0_0_6px_rgba(226,232,240,0.7)]" />
          </span>
          <span className={compact ? 'tracking-wider' : 'tracking-widest font-black'}>
            {compact ? 'SILVER STAR · A+' : 'SILVER STAR · GRADE A+'}
          </span>
        </span>
      );
    case 'A':
      // Bronze Star Badge
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-mono font-extrabold rounded-lg border transition-all ${
            compact
              ? 'px-2 py-0.5 text-[10px] bg-gradient-to-r from-[#d97706]/15 to-[#b45309]/15 border-[#d97706] text-[#f59e0b] shadow-[0_0_8px_rgba(217,119,6,0.25)]'
              : 'px-2.5 py-1 text-xs bg-gradient-to-r from-[#f59e0b] via-[#d97706] to-[#b45309] text-white border-[#f59e0b] shadow-[0_0_10px_rgba(245,158,11,0.35)]'
          }`}
          title="Bronze Star Distinction: Grade A (Nominal NASA Flight Standard)"
        >
          <span className="flex items-center">
            <Star size={compact ? 11 : 13} className="fill-[#f59e0b] text-[#b45309] drop-shadow-[0_0_5px_rgba(245,158,11,0.6)]" />
          </span>
          <span className={compact ? 'tracking-wider' : 'tracking-widest font-black'}>
            {compact ? 'BRONZE STAR · A' : 'BRONZE STAR · GRADE A'}
          </span>
        </span>
      );
    case 'B':
    default:
      // Cadet Blue-Steel Star
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-mono font-extrabold rounded-lg border transition-all ${
            compact
              ? 'px-2 py-0.5 text-[10px] bg-[#0284c7]/15 border-[#38bdf8]/40 text-[#38bdf8]'
              : 'px-2.5 py-1 text-xs bg-gradient-to-r from-[#0284c7] to-[#0369a1] text-white border-[#38bdf8]'
          }`}
          title="Cadet Flight Star: Grade B (Flight Parameters Certified)"
        >
          <span className="flex items-center">
            <Star size={compact ? 11 : 13} className="fill-[#38bdf8] text-[#0284c7]" />
          </span>
          <span className={compact ? 'tracking-wider' : 'tracking-widest font-black'}>
            {compact ? 'CADET STAR · B' : 'CADET STAR · GRADE B'}
          </span>
        </span>
      );
  }
};

interface CadetDossierProps {
  profile: AstronautProfile;
  onBackToDeck: () => void;
  onOpenCertificate: () => void;
  onReFlyMission?: (missionId: number) => void;
  onRewardXP?: (xp: number) => void;
}

export const CadetDossier: React.FC<CadetDossierProps> = ({
  profile,
  onBackToDeck,
  onOpenCertificate,
  onReFlyMission,
  onRewardXP,
}) => {
  const [activeTab, setActiveTab] = useState<'history' | 'badges'>('history');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [expandedMissionId, setExpandedMissionId] = useState<number | null>(null);
  const [demoLoaded, setDemoLoaded] = useState(false);

  // New Modals: Mission Patch, Emergency Drill, Aerospace Glossary
  const [isPatchModalOpen, setIsPatchModalOpen] = useState(false);
  const [isEmergencyModalOpen, setIsEmergencyModalOpen] = useState(false);
  const [isGlossaryModalOpen, setIsGlossaryModalOpen] = useState(false);

  // Mini-game simulation state inside expanded telemetry debrief
  const [simAdjustments, setSimAdjustments] = useState<Record<number, number>>({});
  const [simOptimized, setSimOptimized] = useState<Record<number, boolean>>({});

  const handlePrint = () => {
    playUiClick();
    window.print();
  };

  const rank = getAstronautRank(profile.points);

  const missionByBadge: Record<string, number> = {
    CENTRIFUGE_ACE: 1,
    FIRST_LAUNCH: 2,
    MAX_Q_SURVIVOR: 3,
    ZERO_G_ACROBAT: 4,
    EVA_WALKER: 5,
    DOCKING_MASTER: 6,
    LUNAR_PILOT: 7,
    MARS_AVIATOR: 8,
    PARKER_SUN_TOUCHER: 9,
    PLANETARY_DEFENDER: 10,
    PLANETARY_EXPLORER: 11,
    EUROPA_OCEAN_PIONEER: 12,
    TITAN_DRAGONFLY: 13,
    JWST_ALIGNER: 14,
    EXOPLANET_HUNTER: 15,
    GRAV_WAVE_ACOUSTICIAN: 16,
    DEEP_SPACE_PIONEER: 17,
    INTERSTELLAR_VOYAGER: 18,
  };

  const badges = BADGES.map(badge => ({
    ...badge,
    unlocked: profile.completed.includes(missionByBadge[badge.id]),
  }));
  const earned = badges.filter(badge => badge.unlocked).length;
  const completion = Math.min(100, Math.round((profile.completed.length / 19) * 100));
  const credentialId = `CO-${String(profile.name).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8) || 'CADET'}-26`;

  // Get or compute mission history records
  const allMissionHistory = useMemo(() => {
    const records = getProfileMissionHistory(
      profile.completed,
      profile.missionHistory || [],
      profile.registeredAt || '2026-10-25T14:30:00Z'
    );
    if (records.length === 0 && demoLoaded) {
      return SAMPLE_NASA_SIMULATED_FLIGHTS;
    }
    return records;
  }, [profile.completed, profile.missionHistory, profile.registeredAt, demoLoaded]);

  // Categories list
  const categories = useMemo(() => {
    const set = new Set<string>();
    allMissionHistory.forEach(m => set.add(m.category));
    return ['ALL', ...Array.from(set)];
  }, [allMissionHistory]);

  // Filtered mission history
  const filteredHistory = useMemo(() => {
    return allMissionHistory.filter(item => {
      const matchesSearch =
        item.missionTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.telemetry.vehicle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.telemetry.destination.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCat = selectedCategory === 'ALL' || item.category === selectedCategory;
      return matchesSearch && matchesCat;
    });
  }, [allMissionHistory, searchQuery, selectedCategory]);

  // Handle mini-game telemetry re-tuning in mission debrief
  const handleTweakSim = (missionId: number, val: number) => {
    setSimAdjustments(prev => ({ ...prev, [missionId]: val }));
    playTone(400 + val * 4, 0.05, 'sine');
    // If dialed into 95-100%, trigger optimization success
    if (val >= 94) {
      if (!simOptimized[missionId]) {
        setSimOptimized(prev => ({ ...prev, [missionId]: true }));
        playSuccessChime();
      }
    } else {
      if (simOptimized[missionId]) {
        setSimOptimized(prev => ({ ...prev, [missionId]: false }));
      }
    }
  };

  return (
    <main className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 py-7 md:py-10 space-y-7 animate-in fade-in duration-300">
      {/* Top action bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 no-print">
        <button
          onClick={() => {
            playUiClick();
            onBackToDeck();
          }}
          className="group inline-flex items-center gap-2 text-xs font-mono tracking-wider text-[#9fb1a6] hover:text-[#d9f36a] transition-colors cursor-pointer"
        >
          <ArrowLeft size={15} className="transition-transform group-hover:-translate-x-1" /> FLIGHT DECK
        </button>

        <div className="flex flex-wrap items-center gap-2">
          {/* Emergency Drill Button */}
          <button
            onClick={() => {
              playUiClick();
              setIsEmergencyModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 rounded-xl border border-[#ef7144]/40 bg-[#1f100b] hover:bg-[#2d160f] px-3.5 py-2 text-xs font-mono font-bold tracking-wide text-[#ef7144] transition cursor-pointer shadow-md group"
          >
            <AlertTriangle size={14} className="text-[#ef7144] group-hover:animate-bounce" />
            <span>EMERGENCY DRILL</span>
          </button>

          {/* NASA Mission Patch Studio Button */}
          <button
            onClick={() => {
              playUiClick();
              setIsPatchModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 rounded-xl border border-[#ffc93c]/40 bg-[#1f1a0b] hover:bg-[#2d240f] px-3.5 py-2 text-xs font-mono font-bold tracking-wide text-[#ffc93c] transition cursor-pointer shadow-md"
          >
            <Award size={14} />
            <span>PATCH STUDIO</span>
          </button>

          {/* Astronaut Lexicon Button */}
          <button
            onClick={() => {
              playUiClick();
              setIsGlossaryModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 rounded-xl border border-[#72d1d6]/30 bg-[#0c252b] hover:bg-[#10343a] px-3.5 py-2 text-xs font-mono font-bold tracking-wide text-[#a7edf0] transition cursor-pointer shadow-md"
          >
            <BookOpen size={14} />
            <span>ASTRONAUT LEXICON</span>
          </button>

          {/* Print Credential Button */}
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-3.5 py-2 text-xs font-mono font-bold tracking-wide text-[#bdc9c0] transition cursor-pointer"
          >
            <Printer size={14} />
            <span>PRINT</span>
          </button>
        </div>
      </div>

      {/* Header Banner */}
      <header className="relative overflow-hidden rounded-[28px] border border-[#72d1d6]/25 bg-[radial-gradient(ellipse_at_80%_0%,rgba(45,166,181,.19),transparent_40%),linear-gradient(130deg,#0b2026,#071519_65%,#0b1e25)] p-6 sm:p-9 shadow-[0_24px_70px_rgba(0,0,0,.28)]">
        <div className="pointer-events-none absolute -right-10 -top-24 h-72 w-72 rounded-full border border-[#72d1d6]/10 after:absolute after:inset-5 after:rounded-full after:border after:border-dashed after:border-[#72d1d6]/15 before:absolute before:inset-12 before:rounded-full before:border before:border-[#d9f36a]/10" />
        <div className="relative grid gap-7 lg:grid-cols-[1.2fr_.8fr] lg:items-end">
          <div>
            <div className="flex items-center gap-2 text-[10px] font-mono font-bold tracking-[.24em] text-[#72d1d6]">
              <Orbit size={14} /> COSMORA ACADEMY <span className="text-white/25">/</span> PERSONNEL FILE
            </div>
            <h1 className="mt-4 font-display text-4xl sm:text-5xl font-bold tracking-tight text-[#eef4e6]">
              Cadet <span className="text-[#d9f36a]">Dossier</span>
            </h1>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-[#9fb1a6]">
              Your official academy flight record, mission performance history, real NASA telemetry logs, and certified astronaut honors.
            </p>
          </div>
          <div className="grid grid-cols-3 gap-2 sm:gap-3">
            <div className="rounded-2xl border border-white/8 bg-black/20 p-3 sm:p-4">
              <div className="text-[9px] font-mono tracking-widest text-[#829b96]">FLIGHTS</div>
              <div className="mt-1 text-2xl font-bold text-white">
                {profile.completed.length}
                <span className="text-sm text-white/35"> / 19</span>
              </div>
            </div>
            <div className="rounded-2xl border border-white/8 bg-black/20 p-3 sm:p-4">
              <div className="text-[9px] font-mono tracking-widest text-[#829b96]">EXPERIENCE</div>
              <div className="mt-1 text-2xl font-bold text-[#d9f36a]">
                {profile.points}
                <span className="text-sm"> XP</span>
              </div>
            </div>
            <div className="rounded-2xl border border-white/8 bg-black/20 p-3 sm:p-4">
              <div className="text-[9px] font-mono tracking-widest text-[#829b96]">HONORS</div>
              <div className="mt-1 text-2xl font-bold text-[#ffc93c]">
                {earned}
                <span className="text-sm text-white/35"> / {badges.length}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="relative mt-7 flex items-center gap-3">
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#72d1d6] via-[#d9f36a] to-[#ffc93c] transition-all duration-500"
              style={{ width: `${completion}%` }}
            />
          </div>
          <span className="text-[10px] font-mono tracking-wider text-[#d9f36a]">{completion}% FLIGHT LOG</span>
        </div>
      </header>

      {/* Main Grid: Left Column (ID Badge & Certificate) and Right Column (Tabs: Mission History & Distinction Archive) */}
      <div className="grid items-start gap-6 lg:grid-cols-[minmax(290px,.75fr)_minmax(0,1.55fr)]">
        {/* Left Column: Cadet ID & Graduation Progress */}
        <section className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <div className="text-[10px] font-mono font-bold tracking-[.2em] text-[#9fb1a6]">01 / IDENTITY CREDENTIAL</div>
            <span className="flex items-center gap-1 text-[9px] font-mono text-[#66d17a]">
              <i className="h-1.5 w-1.5 rounded-full bg-[#66d17a] shadow-[0_0_8px_#66d17a]" /> VERIFIED
            </span>
          </div>

          <article className="relative isolate overflow-hidden rounded-[26px] border border-[#72d1d6]/45 bg-[radial-gradient(ellipse_at_50%_12%,rgba(75,202,211,.22),transparent_34%),linear-gradient(160deg,#102a31,#07171c_55%,#0d2429)] p-5 shadow-[0_0_42px_rgba(66,193,202,.10)]">
            <div className="pointer-events-none absolute inset-0 opacity-25 [background-image:linear-gradient(120deg,transparent_30%,rgba(120,230,231,.16)_50%,transparent_68%),radial-gradient(circle_at_10%_90%,rgba(217,243,106,.16),transparent_35%)]" />
            <div className="relative flex items-center justify-between border-b border-white/10 pb-3 text-[9px] font-mono tracking-[.16em] text-[#a6c2c3]">
              <span className="flex items-center gap-1.5">
                <ShieldCheck size={13} className="text-[#d9f36a]" /> COSMORA / CREW ID
              </span>
              <span>CLASS · CADET</span>
            </div>
            <div className="relative mt-5 flex items-center gap-4">
              <div className="relative h-24 w-24 shrink-0 rounded-2xl border border-[#72d1d6]/70 bg-[#0d3037] p-1 shadow-[0_0_22px_rgba(114,209,214,.18)]">
                <div className="h-full overflow-hidden rounded-xl">
                  <AvatarVisual avatar={profile.avatar} alt={`${profile.name} astronaut portrait`} className="h-full w-full" />
                </div>
                <div className="absolute -bottom-2 -right-2 rounded-full border border-[#071519] bg-[#d9f36a] p-1 text-[#061211]">
                  <BadgeCheck size={13} />
                </div>
              </div>
              <div className="min-w-0">
                <div className="text-[9px] font-mono tracking-[.18em] text-[#72d1d6]">FLIGHT CALLSIGN</div>
                <h2 className="mt-1 break-words font-display text-2xl font-bold leading-tight text-white">{profile.name}</h2>
                <div className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-[#d9f36a]/25 bg-[#d9f36a]/8 px-2.5 py-1 text-[10px] font-mono font-bold text-[#d9f36a]">
                  <Sparkles size={12} /> {rank.title} <span className="text-white/45">· {rank.grade}</span>
                </div>
              </div>
            </div>
            <div className="relative mt-5 grid grid-cols-2 gap-2">
              <div className="rounded-xl border border-white/8 bg-black/20 p-3">
                <div className="text-[9px] font-mono tracking-widest text-[#819b98]">FLIGHT HOURS</div>
                <div className="mt-1 font-mono text-sm font-bold text-white">{profile.completed.length.toString().padStart(2, '0')} MISSIONS</div>
              </div>
              <div className="rounded-xl border border-white/8 bg-black/20 p-3">
                <div className="text-[9px] font-mono tracking-widest text-[#819b98]">ACADEMY XP</div>
                <div className="mt-1 font-mono text-sm font-bold text-[#d9f36a]">{profile.points.toLocaleString()} XP</div>
              </div>
            </div>
            <div className="relative mt-4 flex items-center gap-3 border-t border-white/10 pt-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-[#72d1d6]">
                <QrCode size={24} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-[8px] font-mono tracking-[.16em] text-[#819b98]">PERSONNEL ACCESS CODE</div>
                <div className="truncate text-[10px] font-mono font-bold tracking-wider text-[#dce7de]">{credentialId}</div>
              </div>
              <Fingerprint size={21} className="text-[#72d1d6]/65" />
            </div>
            <div className="relative mt-4 flex items-center justify-between text-[8px] font-mono tracking-[.13em] text-white/35">
              <span>ACADEMY MISSION CONTROL</span>
              <span>SECURE · 2026</span>
            </div>
          </article>

          {/* Graduation Track Box */}
          <div className="rounded-2xl border border-[#ffc93c]/20 bg-[linear-gradient(120deg,rgba(255,201,60,.09),rgba(114,209,214,.06))] p-4 sm:p-5">
            <div className="flex items-center gap-2 text-[10px] font-mono font-bold tracking-[.16em] text-[#ffc93c]">
              <Award size={15} /> GRADUATION TRACK
            </div>
            <h3 className="mt-2 font-display text-lg font-bold text-white">Space Readiness Certificate</h3>
            <p className="mt-1 text-xs leading-relaxed text-[#a9bbb0]">
              {profile.completed.length >= 4
                ? 'Your academy flight record meets the graduation threshold.'
                : `${4 - profile.completed.length} more mission${4 - profile.completed.length === 1 ? '' : 's'} to unlock your official diploma.`}
            </p>
            <button
              onClick={() => {
                playUiClick();
                onOpenCertificate();
              }}
              className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-[#ffc93c]/35 bg-[#ffc93c] px-4 py-3 text-xs font-bold tracking-wide text-[#101710] hover:bg-[#ffdb71] transition cursor-pointer"
            >
              OPEN CERTIFICATE STUDIO <ChevronRight size={15} />
            </button>
          </div>
        </section>

        {/* Right Column: Multi-Tab Panel (Mission History & Distinction Archive) */}
        <section className="overflow-hidden rounded-[26px] border border-white/10 bg-[linear-gradient(145deg,#0b2025,#071519)] shadow-[0_20px_60px_rgba(0,0,0,.2)]">
          {/* Tabs Top Header */}
          <div className="border-b border-white/8 px-5 py-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  playUiClick();
                  setActiveTab('history');
                }}
                className={`relative px-4 py-2 rounded-xl text-xs font-mono font-bold tracking-wide transition-all cursor-pointer flex items-center gap-2 ${
                  activeTab === 'history'
                    ? 'bg-[#d9f36a] text-[#061211] shadow-[0_0_20px_rgba(217,243,106,0.3)]'
                    : 'text-[#9fb1a6] hover:text-white hover:bg-white/5'
                }`}
              >
                <Clock size={14} />
                <span>MISSION HISTORY</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                  activeTab === 'history' ? 'bg-[#061211] text-[#d9f36a]' : 'bg-white/10 text-white'
                }`}>
                  {allMissionHistory.length}
                </span>
              </button>

              <button
                onClick={() => {
                  playUiClick();
                  setActiveTab('badges');
                }}
                className={`relative px-4 py-2 rounded-xl text-xs font-mono font-bold tracking-wide transition-all cursor-pointer flex items-center gap-2 ${
                  activeTab === 'badges'
                    ? 'bg-[#72d1d6] text-[#061211] shadow-[0_0_20px_rgba(114,209,214,0.3)]'
                    : 'text-[#9fb1a6] hover:text-white hover:bg-white/5'
                }`}
              >
                <Award size={14} />
                <span>DISTINCTION ARCHIVE</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                  activeTab === 'badges' ? 'bg-[#061211] text-[#72d1d6]' : 'bg-white/10 text-white'
                }`}>
                  {earned}/{badges.length}
                </span>
              </button>
            </div>

            <div className="text-[10px] font-mono text-[#859b93] flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#d9f36a] animate-pulse" />
              <span>NASA ARCHIVE SYNC · 2026</span>
            </div>
          </div>

          {/* =============================================================== */}
          {/* TAB 1: MISSION HISTORY (SCROLLABLE LIST, GRADES, ANIMATIONS) */}
          {/* =============================================================== */}
          {activeTab === 'history' && (
            <div className="p-4 sm:p-6 space-y-4 animate-in fade-in duration-200">
              {/* Filter and Search Bar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pb-2">
                <div className="relative flex-1">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9fb1a6]" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="Search by mission, NASA vehicle, destination…"
                    className="w-full bg-[#051113] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs font-mono text-[#eef4e6] placeholder-[#9fb1a6]/50 focus:outline-none focus:border-[#d9f36a]"
                  />
                </div>

                {categories.length > 2 && (
                  <div className="flex items-center gap-1.5 overflow-x-auto py-1">
                    {categories.slice(0, 4).map(cat => (
                      <button
                        key={cat}
                        onClick={() => {
                          playUiClick();
                          setSelectedCategory(cat);
                        }}
                        className={`px-2.5 py-1.5 rounded-lg text-[10px] font-mono font-bold tracking-wider shrink-0 transition-all ${
                          selectedCategory === cat
                            ? 'bg-[#d9f36a]/20 border border-[#d9f36a] text-[#d9f36a]'
                            : 'bg-white/5 border border-white/5 text-[#9fb1a6] hover:bg-white/10'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Visual Star Awards Legend */}
              <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] font-mono text-[#9fb1a6] border-t border-white/5">
                <span className="text-[#859b93] font-bold text-[10px] uppercase tracking-wider">AWARDS LEGEND:</span>
                <span className="inline-flex items-center gap-1.5 text-[#ffd700]">
                  <Star size={12} className="fill-[#ffd700] text-[#ffd700]" /> Gold Star (S · 95%+)
                </span>
                <span className="inline-flex items-center gap-1.5 text-[#e2e8f0]">
                  <Star size={12} className="fill-[#e2e8f0] text-[#94a3b8]" /> Silver Star (A+ · 82%+)
                </span>
                <span className="inline-flex items-center gap-1.5 text-[#f59e0b]">
                  <Star size={12} className="fill-[#f59e0b] text-[#b45309]" /> Bronze Star (A · 65%+)
                </span>
                <span className="inline-flex items-center gap-1.5 text-[#38bdf8]">
                  <Star size={12} className="fill-[#38bdf8] text-[#0284c7]" /> Cadet Star (B · 50%+)
                </span>
              </div>

              {/* Scrollable List of Mission History Records */}
              {filteredHistory.length > 0 ? (
                <div className="space-y-3 max-h-[580px] overflow-y-auto pr-1.5 focus:outline-none scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
                  {filteredHistory.map((item, idx) => {
                    const isExpanded = expandedMissionId === item.missionId;
                    const simScore = simAdjustments[item.missionId] ?? 85;
                    const isOptimal = simOptimized[item.missionId] || item.grade === 'S';

                    const formattedDate = new Date(item.completedAt).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                      timeZoneName: 'short',
                    });

                    return (
                      <article
                        key={`${item.missionId}-${idx}`}
                        className={`group relative rounded-2xl border transition-all duration-200 overflow-hidden ${
                          isExpanded
                            ? 'border-[#d9f36a] bg-[radial-gradient(ellipse_at_top,rgba(217,243,106,.08),transparent_60%),linear-gradient(145deg,#0e262b,#07171a)] shadow-xl'
                            : 'border-white/10 bg-[#091e23]/90 hover:border-white/25 hover:bg-[#0c2429]'
                        }`}
                      >
                        {/* Summary Header Row */}
                        <div
                          onClick={() => {
                            playUiClick();
                            setExpandedMissionId(isExpanded ? null : item.missionId);
                          }}
                          className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer select-none"
                        >
                          <div className="flex items-start gap-3.5">
                            {/* Mission Icon with Visual Star Medal Badge Pin */}
                            <div className="relative shrink-0">
                              <div className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-[#061211] text-2xl shadow-inner group-hover:scale-105 transition-transform">
                                {item.icon}
                              </div>
                              <div
                                className={`absolute -bottom-1.5 -right-1.5 rounded-full p-1 border shadow-lg flex items-center justify-center ${
                                  item.grade === 'S'
                                    ? 'bg-[#1a1705] border-[#ffd700] shadow-[0_0_8px_rgba(255,215,0,0.6)]'
                                    : item.grade === 'A+'
                                    ? 'bg-[#0f172a] border-[#e2e8f0] shadow-[0_0_8px_rgba(226,232,240,0.5)]'
                                    : item.grade === 'A'
                                    ? 'bg-[#1c1206] border-[#f59e0b] shadow-[0_0_6px_rgba(245,158,11,0.5)]'
                                    : 'bg-[#081f2c] border-[#38bdf8]'
                                }`}
                                title={`Grade Award: ${item.gradeTitle}`}
                              >
                                <GradeStarIcon grade={item.grade} size={11} />
                              </div>
                            </div>

                            <div>
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="text-[10px] font-mono tracking-widest text-[#72d1d6] uppercase font-bold">
                                  {item.category}
                                </span>
                                <span className="text-white/20 text-xs">/</span>
                                <span className="text-[10px] font-mono text-[#9fb1a6]">
                                  FLIGHT #{String(item.missionId).padStart(2, '0')}
                                </span>
                              </div>

                              {/* Mission Title with Visual Badge Icon */}
                              <div className="flex flex-wrap items-center gap-2 mt-0.5">
                                <h3 className="font-display font-bold text-base sm:text-lg text-[#eef4e6] group-hover:text-[#d9f36a] transition-colors">
                                  {item.missionTitle}
                                </h3>
                                <GradeBadge grade={item.grade} compact={true} />
                              </div>

                              {/* Timestamps */}
                              <div className="mt-1 flex flex-wrap items-center gap-3 text-[11px] font-mono text-[#9fb1a6]">
                                <span className="flex items-center gap-1 text-[#bdc9c0]">
                                  <Clock size={12} className="text-[#72d1d6]" />
                                  {formattedDate}
                                </span>
                                <span className="text-white/20">|</span>
                                <span className="px-1.5 py-0.5 rounded bg-black/40 border border-white/5 text-[#d9f36a]">
                                  {item.metTime}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Grade Badge & XP Callout */}
                          <div className="flex items-center gap-3 self-end sm:self-center">
                            <GradeBadge grade={item.grade} compact={false} />

                            <div className="text-right">
                              <span className="block text-[11px] font-mono font-bold text-[#d9f36a]">
                                +{item.score} XP
                              </span>
                            </div>

                            {onReFlyMission && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  playUiClick();
                                  onReFlyMission(item.missionId);
                                }}
                                className="px-2.5 py-1.5 rounded-lg bg-[#d9f36a]/15 hover:bg-[#d9f36a] text-[#d9f36a] hover:text-[#061211] border border-[#d9f36a]/30 text-[10px] font-mono font-bold uppercase transition flex items-center gap-1 cursor-pointer"
                                title="Re-fly mission trajectory to upgrade score"
                              >
                                <RotateCcw size={11} />
                                <span className="hidden sm:inline">Re-Fly</span>
                              </button>
                            )}

                            <button
                              aria-label={isExpanded ? 'Collapse telemetry debrief' : 'Expand telemetry debrief'}
                              className="p-2 rounded-xl bg-white/5 border border-white/10 text-[#9fb1a6] group-hover:text-white transition-colors"
                            >
                              {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                            </button>
                          </div>
                        </div>

                        {/* Quick Telemetry Bar */}
                        <div className="px-4 py-2 bg-black/30 border-t border-white/5 flex flex-wrap items-center justify-between gap-2 text-[10px] font-mono text-[#9fb1a6]">
                          <span className="flex items-center gap-1.5">
                            <Rocket size={11} className="text-[#72d1d6]" />
                            <strong className="text-[#dce7de]">{item.telemetry.vehicle}</strong>
                          </span>
                          <span className="flex items-center gap-1">
                            <Activity size={11} className="text-[#ff9838]" />
                            <span>V-MAX:</span>
                            <span className="text-[#eef4e6]">{item.telemetry.maxVelocity}</span>
                          </span>
                          <span className="flex items-center gap-1">
                            <Flame size={11} className="text-[#d9f36a]" />
                            <span>G-PEAK:</span>
                            <span className="text-[#eef4e6]">{item.telemetry.peakGForce}</span>
                          </span>
                        </div>

                        {/* ========================================================= */}
                        {/* EXPANDED TELEMETRY DEBRIEF & NASA GAMING SIMULATOR */}
                        {/* ========================================================= */}
                        {isExpanded && (
                          <div className="p-5 border-t border-[#d9f36a]/30 bg-[#051316] space-y-5 animate-in slide-in-from-top-2 duration-200">
                            {/* Debrief Top Notes */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="p-3.5 bg-black/40 rounded-xl border border-white/10 space-y-1.5">
                                <span className="text-[10px] font-mono font-bold text-[#d9f36a] tracking-wider uppercase block">
                                  CAPCOM FLIGHT PERFORMANCE EVALUATION:
                                </span>
                                <p className="text-xs text-[#bdc9c0] leading-relaxed">
                                  {item.feedback}
                                </p>
                              </div>

                              <div className="p-3.5 bg-black/40 rounded-xl border border-white/10 space-y-1.5">
                                <span className="text-[10px] font-mono font-bold text-[#72d1d6] tracking-wider uppercase block">
                                  OFFICIAL NASA SCIENTIFIC DISCOVERY:
                                </span>
                                <p className="text-xs text-[#9fb1a6] leading-relaxed">
                                  {item.telemetry.discoveryNote}
                                </p>
                              </div>
                            </div>

                            {/* NASA Data Grid */}
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                              <div className="p-2.5 rounded-lg bg-white/5 border border-white/5">
                                <span className="text-[9px] text-[#9fb1a6] block">TRAJECTORY</span>
                                <span className="text-[#eef4e6] font-bold text-[11px] truncate block mt-0.5">
                                  {item.telemetry.trajectoryType}
                                </span>
                              </div>
                              <div className="p-2.5 rounded-lg bg-white/5 border border-white/5">
                                <span className="text-[9px] text-[#9fb1a6] block">ALTITUDE</span>
                                <span className="text-[#eef4e6] font-bold text-[11px] truncate block mt-0.5">
                                  {item.telemetry.altitude}
                                </span>
                              </div>
                              <div className="p-2.5 rounded-lg bg-white/5 border border-white/5">
                                <span className="text-[9px] text-[#9fb1a6] block">DELTA-V EXPENDED</span>
                                <span className="text-[#d9f36a] font-bold text-[11px] truncate block mt-0.5">
                                  {item.telemetry.deltaV}
                                </span>
                              </div>
                              <div className="p-2.5 rounded-lg bg-white/5 border border-white/5">
                                <span className="text-[9px] text-[#9fb1a6] block">NASA SOURCE DOC</span>
                                <span className="text-[#72d1d6] font-bold text-[11px] truncate block mt-0.5">
                                  {item.telemetry.nasaRefDoc}
                                </span>
                              </div>
                            </div>

                            {/* NASA Interactive Trajectory Replay & Telemetry Gaming Simulator */}
                            <div className="p-4 rounded-xl bg-gradient-to-r from-[#0b2227] to-[#071619] border border-[#72d1d6]/30 space-y-3">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <Sparkles size={14} className="text-[#d9f36a]" />
                                  <span className="text-xs font-mono font-bold text-[#eef4e6] uppercase">
                                    NASA Trajectory Optimization Simulator
                                  </span>
                                </div>
                                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                                  isOptimal ? 'bg-[#d9f36a] text-[#061211]' : 'bg-[#ff9838]/20 text-[#ff9838]'
                                }`}>
                                  {isOptimal ? 'OPTIMAL TRAJECTORY ACHIEVED (GRADE S)' : `TELEMETRY TUNED: ${simScore}%`}
                                </span>
                              </div>

                              {/* Interactive SVG Trajectory Curve with animated flight vehicle */}
                              <div className="relative h-24 bg-black/60 rounded-lg border border-white/10 overflow-hidden flex items-center justify-center p-2">
                                <svg viewBox="0 0 500 80" className="w-full h-full">
                                  {/* Coordinate Grid lines */}
                                  <line x1="0" y1="20" x2="500" y2="20" stroke="rgba(255,255,255,0.06)" strokeDasharray="4 4" />
                                  <line x1="0" y1="40" x2="500" y2="40" stroke="rgba(255,255,255,0.06)" strokeDasharray="4 4" />
                                  <line x1="0" y1="60" x2="500" y2="60" stroke="rgba(255,255,255,0.06)" strokeDasharray="4 4" />

                                  {/* Orbital Baseline Curve */}
                                  <path
                                    d={`M 10 70 Q 150 ${70 - (simScore / 100) * 45} 280 ${50 - (simScore / 100) * 30} T 490 20`}
                                    fill="none"
                                    stroke={isOptimal ? '#d9f36a' : '#72d1d6'}
                                    strokeWidth="2.5"
                                    strokeLinecap="round"
                                  />

                                  {/* Trajectory Shadow / Glow */}
                                  <path
                                    d={`M 10 70 Q 150 ${70 - (simScore / 100) * 45} 280 ${50 - (simScore / 100) * 30} T 490 20 L 490 75 L 10 75 Z`}
                                    fill={isOptimal ? 'rgba(217,243,106,0.08)' : 'rgba(114,209,214,0.06)'}
                                  />

                                  {/* Animated Flight Position Orb */}
                                  <circle
                                    cx={10 + (simScore / 100) * 450}
                                    cy={70 - (simScore / 100) * 45}
                                    r="5"
                                    fill={isOptimal ? '#d9f36a' : '#ff9838'}
                                    className="animate-pulse"
                                  />
                                </svg>

                                <div className="absolute top-2 left-3 text-[9px] font-mono text-[#9fb1a6]">
                                  LIFTOFF · T+00:00
                                </div>
                                <div className="absolute top-2 right-3 text-[9px] font-mono text-[#d9f36a]">
                                  INSERTION · {item.telemetry.destination.split('(')[0]}
                                </div>
                              </div>

                              {/* Interactive Telemetry Fine-Tuning Slider */}
                              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
                                <div className="flex items-center gap-2 flex-1 w-full">
                                  <SlidersHorizontal size={13} className="text-[#9fb1a6] shrink-0" />
                                  <span className="text-[11px] font-mono text-[#9fb1a6] shrink-0">
                                    Thrust Vector Guidance:
                                  </span>
                                  <input
                                    type="range"
                                    min="50"
                                    max="100"
                                    value={simScore}
                                    onChange={e => handleTweakSim(item.missionId, Number(e.target.value))}
                                    className="flex-1 accent-[#d9f36a] cursor-pointer"
                                  />
                                  <span className="text-xs font-mono font-bold text-[#d9f36a] w-12 text-right">
                                    {simScore}%
                                  </span>
                                </div>

                                <div className="flex items-center gap-2">
                                  <button
                                    onClick={() => handleTweakSim(item.missionId, 98)}
                                    className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-[10px] font-mono font-bold text-[#eef4e6] border border-white/10 shrink-0 flex items-center gap-1 cursor-pointer transition-all"
                                  >
                                    <Zap size={11} className="text-[#d9f36a]" />
                                    <span>Auto-Optimize</span>
                                  </button>

                                  {onReFlyMission && (
                                    <button
                                      onClick={() => {
                                        playUiClick();
                                        onReFlyMission(item.missionId);
                                      }}
                                      className="px-3 py-1.5 rounded-lg bg-[#d9f36a] hover:bg-[#cbf050] text-[#061211] text-[10px] font-mono font-bold uppercase tracking-wider shrink-0 flex items-center gap-1.5 cursor-pointer shadow-md transition-all"
                                      title="Re-fly this actual NASA mission to achieve higher score"
                                    >
                                      <RotateCcw size={11} />
                                      <span>Re-Fly Mission</span>
                                    </button>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </article>
                    );
                  })}
                </div>
              ) : (
                /* Empty State: If cadet hasn't completed missions yet */
                <div className="py-12 px-6 rounded-2xl border border-dashed border-white/15 bg-black/20 text-center space-y-4">
                  <div className="w-16 h-16 mx-auto rounded-2xl bg-white/5 border border-white/10 grid place-items-center text-3xl">
                    🛰️
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-display font-bold text-lg text-white">
                      No Recorded Flights in Dossier
                    </h3>
                    <p className="text-xs text-[#9fb1a6] max-w-md mx-auto">
                      Complete academy flight missions on the Flight Deck or the Astronaut Trainer to automatically record your flight telemetry, grades, and timestamps here.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                    <button
                      onClick={() => {
                        playUiClick();
                        setDemoLoaded(true);
                        playSuccessChime();
                      }}
                      className="px-4 py-2.5 rounded-xl bg-[#72d1d6] hover:bg-[#8ae0e5] text-[#061211] font-mono font-bold text-xs uppercase flex items-center gap-1.5 shadow-lg transition cursor-pointer"
                    >
                      <Sparkles size={14} />
                      <span>Load Sample NASA Flights</span>
                    </button>
                    <button
                      onClick={() => {
                        playUiClick();
                        onBackToDeck();
                      }}
                      className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono font-bold text-xs uppercase transition cursor-pointer"
                    >
                      <span>Return to Flight Deck</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* =============================================================== */}
          {/* TAB 2: DISTINCTION ARCHIVE (EXISTING HONORS BADGES) */}
          {/* =============================================================== */}
          {activeTab === 'badges' && (
            <div className="p-4 sm:p-5 space-y-4 animate-in fade-in duration-200">
              <div className="grid gap-2.5 sm:grid-cols-2">
                {badges.map((badge, index) => (
                  <article
                    key={badge.id}
                    className={`group relative flex min-h-[98px] items-start gap-3 overflow-hidden rounded-2xl border p-3.5 transition-all ${
                      badge.unlocked
                        ? 'border-[#d9f36a]/25 bg-[linear-gradient(115deg,rgba(217,243,106,.09),rgba(10,41,39,.62))] hover:border-[#d9f36a]/60 shadow-lg'
                        : 'border-white/6 bg-black/15 opacity-60 grayscale-[.65]'
                    }`}
                  >
                    <div
                      className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl border text-xl ${
                        badge.unlocked
                          ? 'border-[#d9f36a]/35 bg-[#d9f36a]/10 text-[#d9f36a]'
                          : 'border-white/10 bg-white/5 text-[#82928c]'
                      }`}
                    >
                      {badge.unlocked ? badge.icon : <Lock size={16} />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-display text-sm font-bold leading-snug text-[#eef4e6]">{badge.title}</h3>
                        <span className="pt-0.5 text-[8px] font-mono text-white/30">{String(index + 1).padStart(2, '0')}</span>
                      </div>
                      <p className="mt-1 text-[11px] leading-snug text-[#9fb1a6]">{badge.description}</p>
                      <div
                        className={`mt-2 text-[8px] font-mono font-bold tracking-[.16em] ${
                          badge.unlocked ? 'text-[#d9f36a]' : 'text-white/35'
                        }`}
                      >
                        {badge.unlocked ? '●  VERIFIED AWARD' : '○  AWAITING FLIGHT'}
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          )}

          {/* Footer Bar */}
          <div className="flex items-center justify-between border-t border-white/8 px-5 py-3 text-[9px] font-mono tracking-wider text-white/35 sm:px-6">
            <span>RECORD SYNC · CERTIFIED NASA FLIGHT TELEMETRY</span>
            <span>{allMissionHistory.length} MISSIONS LOGGED</span>
          </div>
        </section>
      </div>

      {/* Interactive Modals */}
      <MissionPatchGenerator
        isOpen={isPatchModalOpen}
        onClose={() => setIsPatchModalOpen(false)}
        profile={profile}
      />
      <EmergencyDrillModal
        isOpen={isEmergencyModalOpen}
        onClose={() => setIsEmergencyModalOpen(false)}
        profile={profile}
        onRewardXP={xp => {
          if (onRewardXP) onRewardXP(xp);
        }}
      />
      <AerospaceGlossaryModal
        isOpen={isGlossaryModalOpen}
        onClose={() => setIsGlossaryModalOpen(false)}
      />
    </main>
  );
};
