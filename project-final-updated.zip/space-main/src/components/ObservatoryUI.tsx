import React, { useState } from 'react';
import { ArrowLeft, Pause, Play, RotateCcw } from 'lucide-react';
import { BlackHoleBackground3D } from './BlackHoleBackground3D';

/**
 * Observatory — glass HUD over the ray-traced black hole.
 * Usage: <ObservatoryUI onBack={() => …} onQuiz={() => …} />
 */

interface Props {
  theme?: 'dark' | 'light';
  reduceMotion?: boolean;
  onBack?: () => void;
  onQuiz?: () => void;
}

const mono: React.CSSProperties = { fontFamily: "'JetBrains Mono', ui-monospace, monospace" };
const glass = 'bg-[rgba(10,14,28,0.62)] border border-white/10 backdrop-blur-xl';

const ANATOMY = [
  { r: '1.0', title: 'Event horizon', text: 'Nothing, not even light, escapes from inside.' },
  { r: '1.5', title: 'Photon sphere', text: 'Light can orbit here, forming the thin bright ring.' },
  { r: '3.0', title: 'Innermost stable orbit', text: 'The inner edge of the accretion disk.' },
  { r: '>3', title: 'Accretion disk', text: 'The side moving toward you looks brighter and bluer.' },
];

export const ObservatoryUI: React.FC<Props> = ({ theme = 'dark', reduceMotion, onBack, onQuiz }) => {
  const [angle, setAngle] = useState(78);
  const [rotation, setRotation] = useState(60);
  const [beaming, setBeaming] = useState(true);
  const [paused, setPaused] = useState(false);

  const reset = () => { setAngle(78); setRotation(60); setBeaming(true); setPaused(false); };

  return (
    <div className="relative min-h-[calc(100vh-4rem)] min-h-[calc(100dvh-4rem)] overflow-hidden bg-black text-[#e8ecf8]" style={{ fontFamily: "'Space Grotesk', system-ui, sans-serif" }}>
      <BlackHoleBackground3D
        theme={theme}
        reduceMotion={reduceMotion || paused}
        viewingAngle={angle}
        rotationSpeed={rotation / 100}
        dopplerBeaming={beaming}
      />

      <div className="relative z-10 flex min-h-screen flex-col px-5 pb-8 sm:px-12">
        <header className="flex flex-wrap items-center justify-between gap-4 py-7">
          <button onClick={onBack} className={`inline-flex min-h-11 items-center gap-2.5 rounded-full pl-3 pr-5 text-sm font-medium transition hover:bg-white/10 ${glass}`}>
            <ArrowLeft size={18} /> Mission Control
          </button>
          <div className="text-center">
            <div className="text-xs tracking-[0.22em] text-[#ffb454]" style={mono}>OBSERVATORY</div>
            <div className="mt-0.5 text-[22px] font-semibold">Schwarzschild Black Hole</div>
          </div>
          <button onClick={onQuiz} className="min-h-11 rounded-full border border-[#ffb454]/55 bg-[#ffb454]/15 px-5 text-sm font-semibold text-[#ffcf8a] transition hover:bg-[#ffb454]/25">
            Take the quiz
          </button>
        </header>

        <main className="flex flex-1 flex-wrap items-start justify-between gap-6 pt-6">
          {/* controls */}
          <aside className={`flex w-full max-w-[300px] flex-col gap-5 rounded-3xl p-6 ${glass}`}>
            <span className="text-[11px] tracking-[0.2em] text-[#9aa3bd]" style={mono}>SIMULATION</span>

            <div className="flex flex-col gap-2.5">
              <label htmlFor="bh-angle" className="flex justify-between text-sm font-medium">
                Viewing angle <span className="text-[#ffb454]" style={mono}>{angle}°</span>
              </label>
              <input id="bh-angle" type="range" min={0} max={90} value={angle} onChange={(e) => setAngle(+e.target.value)} className="w-full accent-[#ffb454]" />
            </div>

            <div className="flex flex-col gap-2.5">
              <label htmlFor="bh-rot" className="flex justify-between text-sm font-medium">
                Disk rotation <span className="text-[#ffb454]" style={mono}>{(rotation / 100).toFixed(1)}×</span>
              </label>
              <input id="bh-rot" type="range" min={0} max={100} value={rotation} onChange={(e) => setRotation(+e.target.value)} className="w-full accent-[#ffb454]" />
            </div>

            <button
              role="switch" aria-checked={beaming} onClick={() => setBeaming((v) => !v)}
              className="flex min-h-11 items-center justify-between rounded-xl border border-white/15 bg-white/5 px-4 text-sm font-medium transition hover:bg-white/10"
            >
              Doppler beaming
              <span className={`rounded-full px-2.5 py-0.5 text-[11px] ${beaming ? 'bg-[#ffb454] text-[#1a1205]' : 'bg-white/10 text-[#9aa3bd]'}`} style={mono}>{beaming ? 'ON' : 'OFF'}</span>
            </button>

            <div className="flex gap-2">
              <button onClick={() => setPaused((v) => !v)} className="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 text-sm font-medium transition hover:bg-white/10">
                {paused ? <Play size={16} /> : <Pause size={16} />} {paused ? 'Play' : 'Pause'}
              </button>
              <button onClick={reset} className="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 text-sm font-medium transition hover:bg-white/10">
                <RotateCcw size={16} /> Reset
              </button>
            </div>
          </aside>

          {/* anatomy */}
          <aside className={`w-full max-w-[340px] rounded-3xl p-6 ${glass}`}>
            <div className="mb-3 text-[11px] tracking-[0.2em] text-[#9aa3bd]" style={mono}>ANATOMY · RADII IN r<sub>s</sub></div>
            <ul className="m-0 list-none p-0">
              {ANATOMY.map((a) => (
                <li key={a.title} className="flex gap-3.5 border-t border-white/10 py-3.5">
                  <span className="w-10 shrink-0 text-sm text-[#ffb454]" style={mono}>{a.r}</span>
                  <div>
                    <div className="text-[15px] font-semibold">{a.title}</div>
                    <div className="mt-0.5 text-[13px] leading-relaxed text-[#b4bcd4]">{a.text}</div>
                  </div>
                </li>
              ))}
            </ul>
          </aside>
        </main>
      </div>
    </div>
  );
};

export default ObservatoryUI;
