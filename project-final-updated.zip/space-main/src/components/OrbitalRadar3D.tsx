import React, { useCallback, useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { ArrowLeft, Crosshair, Layers, Pause, Play, Satellite as SatIcon, X } from 'lucide-react';
import { eciToEcf, eciToGeodetic, degreesLat, degreesLong, gstime, propagate, type OMMJsonObject } from 'satellite.js';
import {
  CLASS_META, DEFAULT_CLASSES, GROUPS, ORBIT_CLASSES, RE, makeSat, simulatedElements,
  type GroupId, type OrbitClass, type Sat,
} from './nasa/orbitalRadarData';
import { EARTH_R, Labels, buildEarthTextures, createEarth, createSky, ecefToVec3, glowTexture, sunVector } from './3d/earthKit';

/**
 * Orbital Radar 3D — live satellites around a photoreal, day/night Earth.
 *
 * - Real orbital elements from your /api/orbits proxy (CelesTrak GP), SGP4-propagated with satellite.js.
 *   Falls back to the same deterministic offline constellation model as the 2D radar (marked SIM).
 * - Earth with real coastlines, city lights, clouds, twilight, ocean glint and atmosphere; sun position is exact.
 * - Click any satellite for its live altitude, speed and sub-point; its true orbit ring is drawn in space.
 * - Time warp up to 3600×, reference shells for LEO / GPS / GEO.
 */

interface Props {
  onBackToDeck?: () => void;
  className?: string;
}

type Status = 'idle' | 'loading' | 'live' | 'sim';
type FeedPayload = { fetchedAt: string; elements: OMMJsonObject[] };

const CACHE_TTL = 2 * 60 * 60 * 1000;
const cacheKey = (g: GroupId) => `cosmora:radar:gp:${g}:v1`; // shared with the 2D radar's cache

async function loadGroup(group: GroupId): Promise<FeedPayload | null> {
  try {
    const raw = localStorage.getItem(cacheKey(group));
    if (raw) {
      const parsed = JSON.parse(raw) as { t: number; data: FeedPayload };
      if (Date.now() - parsed.t < CACHE_TTL && parsed.data.elements?.length) return parsed.data;
    }
  } catch { /* storage unavailable */ }
  const ctl = new AbortController();
  const timer = window.setTimeout(() => ctl.abort(), 12_000);
  try {
    const res = await fetch(`/api/orbits?group=${group}`, { signal: ctl.signal, headers: { Accept: 'application/json' } });
    if (!res.ok) return null;
    const json = await res.json();
    if (!Array.isArray(json?.elements) || !json.elements.length) return null;
    const data: FeedPayload = { fetchedAt: json.fetchedAt, elements: json.elements };
    try { localStorage.setItem(cacheKey(group), JSON.stringify({ t: Date.now(), data })); } catch { /* quota */ }
    return data;
  } catch { return null; } finally { window.clearTimeout(timer); }
}

const mono: React.CSSProperties = { fontFamily: "'JetBrains Mono', ui-monospace, monospace" };
const panel = 'rounded-xl border border-white/10 bg-[#040e12]/80 backdrop-blur-md';
const WARPS = [1, 60, 600, 3600];
const MAX_POINTS = 24000;

const SAT_VERT = /* glsl */ `
  attribute vec3 aColor; attribute float aSize; uniform float uPR; varying vec3 vC;
  void main(){ vC = aColor; gl_PointSize = aSize * uPR; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
`;
const SAT_FRAG = /* glsl */ `
  precision highp float; varying vec3 vC;
  void main(){ float d = length(gl_PointCoord - 0.5); float halo = smoothstep(0.5, 0.0, d); float core = smoothstep(0.2, 0.0, d);
    gl_FragColor = vec4(vC * (halo * 0.85 + core * 1.3), halo); }
`;

interface SelInfo { alt: number; speed: number; lat: number; lon: number }
interface SceneApi { rebuild: () => void; focus: (uid: string) => void; resetView: () => void }

export const OrbitalRadar3D: React.FC<Props> = ({ onBackToDeck, className }) => {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const labelsHostRef = useRef<HTMLDivElement | null>(null);
  const tipRef = useRef<HTMLDivElement | null>(null);
  const apiRef = useRef<SceneApi | null>(null);

  const satsRef = useRef<Map<GroupId, Sat[]>>(new Map());
  const groupsOnRef = useRef<Record<GroupId, boolean>>(Object.fromEntries(GROUPS.map((g) => [g.id, g.defaultOn])) as Record<GroupId, boolean>);
  const classesOnRef = useRef<Record<OrbitClass, boolean>>({ ...DEFAULT_CLASSES });
  const selectedRef = useRef<Sat | null>(null);
  const warpRef = useRef(1);
  const pausedRef = useRef(false);
  const ringsRef = useRef(true);
  const simMsRef = useRef(Date.now());
  const onSelectRef = useRef<(uid: string | null) => void>(() => {});

  const [groupsOn, setGroupsOn] = useState(groupsOnRef.current);
  const [classesOn, setClassesOn] = useState(classesOnRef.current);
  const [status, setStatus] = useState<Record<GroupId, Status>>(() => Object.fromEntries(GROUPS.map((g) => [g.id, 'idle'])) as Record<GroupId, Status>);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [selected, setSelected] = useState<Sat | null>(null);
  const [info, setInfo] = useState<SelInfo | null>(null);
  const [warp, setWarp] = useState(1);
  const [paused, setPaused] = useState(false);
  const [rings, setRings] = useState(true);
  const [clock, setClock] = useState('');
  const [progress, setProgress] = useState(0);
  const [ready, setReady] = useState(false);
  const [showLayers, setShowLayers] = useState(false);
  const [total, setTotal] = useState(0);
  const [kp, setKp] = useState<number | null>(null);

  useEffect(() => { onSelectRef.current = (uid) => {
    const s = uid ? [...satsRef.current.values()].flat().find((x) => x.uid === uid) ?? null : null;
    selectedRef.current = s; setSelected(s); if (!s) setInfo(null);
  }; }, []);

  /* ---------- feeds: load a group the first time it is switched on ---------- */
  useEffect(() => {
    groupsOnRef.current = groupsOn;
    GROUPS.forEach((g) => {
      if (!groupsOn[g.id] || satsRef.current.has(g.id)) return;
      satsRef.current.set(g.id, []); // reserve → prevents double load
      setStatus((s) => ({ ...s, [g.id]: 'loading' }));
      void (async () => {
        const feed = await loadGroup(g.id);
        const sim = !feed;
        const elements = feed ? feed.elements : simulatedElements(g.id, Date.now());
        const sats = elements.map((e, i) => makeSat(e, g.id, sim, i)).filter((s): s is Sat => !!s);
        satsRef.current.set(g.id, sats);
        setCounts((c) => ({ ...c, [g.id]: sats.length }));
        setStatus((s) => ({ ...s, [g.id]: sim ? 'sim' : 'live' }));
        apiRef.current?.rebuild();
      })();
    });
    apiRef.current?.rebuild();
  }, [groupsOn]);

  useEffect(() => { classesOnRef.current = classesOn; apiRef.current?.rebuild(); }, [classesOn]);
  useEffect(() => { warpRef.current = warp; }, [warp]);
  useEffect(() => { pausedRef.current = paused; }, [paused]);
  useEffect(() => { ringsRef.current = rings; }, [rings]);

  /* ---------- NOAA Kp (same endpoint as the 2D radar) ---------- */
  useEffect(() => {
    let off = false;
    const pull = async () => {
      try {
        const r = await fetch('https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json');
        const rows = (await r.json()) as string[][];
        const v = parseFloat(rows[rows.length - 1][1]);
        if (!off && Number.isFinite(v)) setKp(v);
      } catch { /* optional */ }
    };
    void pull();
    const id = window.setInterval(pull, 5 * 60_000);
    return () => { off = true; window.clearInterval(id); };
  }, []);

  /* ---------- the 3D scene ---------- */
  useEffect(() => {
    const host = hostRef.current, labelHost = labelsHostRef.current;
    if (!host || !labelHost) return;
    let disposed = false;

    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' }); }
    catch { host.style.background = 'radial-gradient(circle at 50% 50%, #0a2236, #000 70%)'; return; }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
    renderer.domElement.style.cssText = 'width:100%;height:100%;display:block;touch-action:none;';
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(40, 1, 0.05, 6000);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true; controls.dampingFactor = 0.06;
    controls.minDistance = EARTH_R * 1.12; controls.maxDistance = 150; controls.rotateSpeed = 0.6; controls.zoomSpeed = 0.8;
    controls.autoRotate = true; controls.autoRotateSpeed = 0.25;
    controls.addEventListener('start', () => { controls.autoRotate = false; });

    const sky = createSky(); sky.setPixelRatio(renderer.getPixelRatio()); scene.add(sky.group);
    const disposables: Array<{ dispose: () => void }> = [];
    const track = <T extends { dispose: () => void }>(o: T) => { disposables.push(o); return o; };

    // Sun glare
    const sunTex = track(glowTexture('rgba(255,252,235,1)', 'rgba(255,210,140,0.5)'));
    const sunSprite = new THREE.Sprite(track(new THREE.SpriteMaterial({ map: sunTex, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true })));
    sunSprite.scale.setScalar(260); scene.add(sunSprite);

    scene.add(new THREE.AmbientLight(0x0b1220, 1));

    // Satellites
    const pos = new Float32Array(MAX_POINTS * 3), col = new Float32Array(MAX_POINTS * 3), siz = new Float32Array(MAX_POINTS);
    const pg = track(new THREE.BufferGeometry());
    const posAttr = new THREE.BufferAttribute(pos, 3).setUsage(THREE.DynamicDrawUsage);
    pg.setAttribute('position', posAttr);
    pg.setAttribute('aColor', new THREE.BufferAttribute(col, 3));
    const sizeAttr = new THREE.BufferAttribute(siz, 1); pg.setAttribute('aSize', sizeAttr);
    const uPR = { value: renderer.getPixelRatio() };
    const pm = track(new THREE.ShaderMaterial({ vertexShader: SAT_VERT, fragmentShader: SAT_FRAG, uniforms: { uPR }, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
    const points = new THREE.Points(pg, pm); points.frustumCulled = false; pg.setDrawRange(0, 0); scene.add(points);

    // Selection marker, orbit ring, nadir line
    const ringC = document.createElement('canvas'); ringC.width = ringC.height = 128;
    { const g = ringC.getContext('2d')!; g.strokeStyle = '#fff'; g.lineWidth = 6; g.beginPath(); g.arc(64, 64, 44, 0, Math.PI * 2); g.stroke();
      g.lineWidth = 4; for (let i = 0; i < 4; i++) { const a = (i * Math.PI) / 2; g.beginPath(); g.moveTo(64 + Math.cos(a) * 50, 64 + Math.sin(a) * 50); g.lineTo(64 + Math.cos(a) * 62, 64 + Math.sin(a) * 62); g.stroke(); } }
    const ringTex = track(new THREE.CanvasTexture(ringC));
    const marker = new THREE.Sprite(track(new THREE.SpriteMaterial({ map: ringTex, color: 0xd9f36a, depthTest: false, transparent: true, sizeAttenuation: false })));
    marker.scale.setScalar(0.05); marker.visible = false; marker.renderOrder = 10; scene.add(marker);

    const ORBIT_N = 240;
    const orbitGeo = track(new THREE.BufferGeometry()); orbitGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(ORBIT_N * 3), 3));
    const orbitMat = track(new THREE.LineBasicMaterial({ color: 0xd9f36a, transparent: true, opacity: 0.85 }));
    const orbitLine = new THREE.LineLoop(orbitGeo, orbitMat); orbitLine.visible = false; orbitLine.frustumCulled = false; scene.add(orbitLine);

    const nadirGeo = track(new THREE.BufferGeometry()); nadirGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6), 3));
    const nadir = new THREE.Line(nadirGeo, track(new THREE.LineBasicMaterial({ color: 0xd9f36a, transparent: true, opacity: 0.5 }))); nadir.visible = false; nadir.frustumCulled = false; scene.add(nadir);

    // Reference shells
    const labels = new Labels(labelHost);
    const shells = new THREE.Group(); scene.add(shells);
    const shellLabels: Array<[string, string, THREE.Vector3, string]> = []; let lastRings = true;
    ([[2000, 'LEO ≤ 2,000 km', CLASS_META.LEO.color], [20200, 'GPS · 20,200 km', CLASS_META.MEO.color], [35786, 'GEO · 35,786 km', CLASS_META.GEO.color]] as const).forEach(([alt, text, color], i) => {
      const r = (RE + alt) / 1000, p: number[] = [];
      for (let k = 0; k < 256; k++) { const a = (k / 256) * Math.PI * 2; p.push(Math.cos(a) * r, 0, Math.sin(a) * r); }
      const g = track(new THREE.BufferGeometry()); g.setAttribute('position', new THREE.Float32BufferAttribute(p, 3));
      shells.add(new THREE.LineLoop(g, track(new THREE.LineBasicMaterial({ color: new THREE.Color(color), transparent: true, opacity: 0.22 }))));
      const a = 0.6 + i * 0.5, lp = new THREE.Vector3(Math.cos(a) * r, 0, Math.sin(a) * r);
      shellLabels.push([`shell${i}`, text, lp, color]); labels.set(`shell${i}`, text, lp, color, 0);
    });

    /* ---- state used by the loop ---- */
    let earthRig: ReturnType<typeof createEarth> | null = null;
    let vis: Sat[] = [];
    const tmp = new THREE.Vector3(), sunDir = new THREE.Vector3(), proj = new THREE.Vector3();
    let lastTick = 0, lastInfo = 0, lastClock = 0, dirty = true;

    const colorOf = (s: Sat) => new THREE.Color(CLASS_META[s.cls].color);
    const rebuild = () => {
      vis = [];
      satsRef.current.forEach((arr, g) => { if (groupsOnRef.current[g]) for (const s of arr) if (classesOnRef.current[s.cls]) vis.push(s); });
      vis = vis.slice(0, MAX_POINTS);
      vis.forEach((s, i) => {
        const c = colorOf(s); col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
        siz[i] = /ISS|ZARYA|TIANHE|CSS/i.test(s.name) ? 13 : s.cls === 'GEO' ? 5 : s.group === 'STARLINK' ? 3.2 : 4.5;
      });
      (pg.getAttribute('aColor') as THREE.BufferAttribute).needsUpdate = true; sizeAttr.needsUpdate = true;
      pg.setDrawRange(0, vis.length); setTotal(vis.length); dirty = true;
    };

    const orbitFor = (s: Sat, date: Date) => {
      const gm = gstime(date), a = orbitGeo.getAttribute('position') as THREE.BufferAttribute;
      let ok = 0;
      for (let i = 0; i < ORBIT_N; i++) {
        const st = propagate(s.satrec, new Date(date.getTime() + (i / ORBIT_N) * s.periodMin * 60_000));
        if (!st || !st.position || typeof st.position === 'boolean') continue;
        const e = eciToEcf(st.position, gm); ecefToVec3(e.x, e.y, e.z, tmp); a.setXYZ(i, tmp.x, tmp.y, tmp.z); ok++;
      }
      a.needsUpdate = true; orbitLine.visible = ok > 10;
      orbitMat.color.set(CLASS_META[s.cls].color);
    };

    const stepSim = (date: Date) => {
      const gm = gstime(date);
      for (let i = 0; i < vis.length; i++) {
        const s = vis[i], st = propagate(s.satrec, date);
        if (!st || !st.position || typeof st.position === 'boolean') { s.ok = false; pos[i * 3] = pos[i * 3 + 1] = pos[i * 3 + 2] = 1e5; continue; }
        const e = eciToEcf(st.position, gm); ecefToVec3(e.x, e.y, e.z, tmp);
        pos[i * 3] = tmp.x; pos[i * 3 + 1] = tmp.y; pos[i * 3 + 2] = tmp.z; s.ok = true;
        if (s === selectedRef.current) {
          s.x = tmp.x; s.y = tmp.y; s.z = tmp.z;
          const geo = eciToGeodetic(st.position, gm);
          s.lat = degreesLat(geo.latitude); s.lon = degreesLong(geo.longitude); s.alt = geo.height;
          const v = st.velocity && typeof st.velocity !== 'boolean' ? st.velocity : null;
          s.speed = v ? Math.hypot(v.x, v.y, v.z) : 0;
        }
      }
      posAttr.needsUpdate = true;
      const sel = selectedRef.current;
      if (sel && sel.ok) {
        marker.visible = true; marker.position.set(sel.x, sel.y, sel.z);
        const n = tmp.set(sel.x, sel.y, sel.z).normalize().multiplyScalar(EARTH_R);
        const na = nadirGeo.getAttribute('position') as THREE.BufferAttribute; na.setXYZ(0, sel.x, sel.y, sel.z); na.setXYZ(1, n.x, n.y, n.z); na.needsUpdate = true; nadir.visible = true;
        labels.set('sel', sel.name, new THREE.Vector3(sel.x, sel.y, sel.z), '#d9f36a', -16);
        orbitFor(sel, date);
      } else { marker.visible = false; orbitLine.visible = false; nadir.visible = false; labels.remove('sel'); }
    };

    /* ---- picking ---- */
    const w2s = (i: number, w: number, h: number, out: { x: number; y: number; d: number }) => {
      proj.set(pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2]);
      if (proj.lengthSq() > 1e9) return false;
      const wp = proj.clone();
      proj.project(camera);
      if (proj.z > 1 || proj.z < -1) return false;
      // hide if behind Earth
      const cp = camera.position, d = wp.clone().sub(cp), L = d.length(); d.divideScalar(L);
      const t = -cp.dot(d);
      if (t > 0 && t < L && cp.clone().addScaledVector(d, t).length() < EARTH_R * 0.998) return false;
      out.x = (proj.x * 0.5 + 0.5) * w; out.y = (-proj.y * 0.5 + 0.5) * h; out.d = L; return true;
    };
    const pick = (px: number, py: number, radius: number) => {
      const w = host.clientWidth, h = host.clientHeight, o = { x: 0, y: 0, d: 0 };
      let best = -1, bd = radius * radius;
      for (let i = 0; i < vis.length; i++) {
        if (!w2s(i, w, h, o)) continue;
        const dd = (o.x - px) ** 2 + (o.y - py) ** 2;
        if (dd < bd) { bd = dd; best = i; }
      }
      return best >= 0 ? vis[best] : null;
    };
    let down: { x: number; y: number } | null = null, hoverRaf = 0, hx = 0, hy = 0;
    const tip = tipRef.current;
    const onDown = (e: PointerEvent) => { down = { x: e.clientX, y: e.clientY }; };
    const onUp = (e: PointerEvent) => {
      if (!down) return;
      const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y); down = null;
      if (moved > 5) return;
      const r = renderer.domElement.getBoundingClientRect();
      const s = pick(e.clientX - r.left, e.clientY - r.top, 18);
      onSelectRef.current(s ? s.uid : null);
    };
    const onMove = (e: PointerEvent) => {
      const r = renderer.domElement.getBoundingClientRect(); hx = e.clientX - r.left; hy = e.clientY - r.top;
      if (hoverRaf) return;
      hoverRaf = requestAnimationFrame(() => {
        hoverRaf = 0; if (!tip) return;
        const s = pick(hx, hy, 12);
        if (s) { tip.style.display = 'block'; tip.style.transform = `translate(${hx + 14}px, ${hy + 12}px)`; tip.textContent = s.name; renderer.domElement.style.cursor = 'pointer'; }
        else { tip.style.display = 'none'; renderer.domElement.style.cursor = 'grab'; }
      });
    };
    renderer.domElement.addEventListener('pointerdown', onDown);
    renderer.domElement.addEventListener('pointerup', onUp);
    renderer.domElement.addEventListener('pointermove', onMove);

    const resize = () => {
      const w = host.clientWidth || 800, h = host.clientHeight || 600;
      renderer.setSize(w, h, false); camera.aspect = w / h; camera.fov = w / h < 0.9 ? 55 : 40; camera.updateProjectionMatrix();
    };
    resize(); const ro = new ResizeObserver(resize); ro.observe(host);

    const setCamera = (dir: THREE.Vector3, dist: number) => { camera.position.copy(dir).multiplyScalar(dist); controls.update(); };
    const initialView = () => {
      sunVector(new Date(simMsRef.current), sunDir);
      const d = sunDir.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), -0.9); d.y += 0.28; d.normalize();
      setCamera(d, 24); controls.autoRotate = true;
    };

    apiRef.current = {
      rebuild,
      resetView: initialView,
      focus: (uid) => {
        const s = vis.find((v) => v.uid === uid); if (!s) return;
        const p = new THREE.Vector3(s.x || 1, s.y || 0, s.z || 0).normalize();
        setCamera(p, Math.max(14, new THREE.Vector3(s.x, s.y, s.z).length() * 2.6)); controls.autoRotate = false;
      },
    };

    /* ---- Earth (async texture bake) ---- */
    void (async () => {
      const tx = await buildEarthTextures(2048, (p) => { if (!disposed) setProgress(p); });
      if (disposed) { Object.values(tx).forEach((t) => (t as THREE.Texture).dispose()); return; }
      earthRig = createEarth(tx); scene.add(earthRig.group);
      setReady(true); initialView(); dirty = true;
    })();
    rebuild(); initialView();

    /* ---- loop ---- */
    const clock = new THREE.Timer(); clock.connect(document);
    let raf = 0, visible = true;
    const fmt = (ms: number) => new Date(ms).toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const frame = () => {
      if (!visible || disposed) return;
      raf = requestAnimationFrame(frame);
      clock.update();
      const dt = Math.min(clock.getDelta(), 0.1), nowMs = performance.now();
      if (!pausedRef.current) simMsRef.current += dt * 1000 * warpRef.current;
      const date = new Date(simMsRef.current);

      if (dirty || nowMs - lastTick > (warpRef.current > 1 ? 100 : 400)) {
        sunVector(date, sunDir); earthRig?.setSun(sunDir); sunSprite.position.copy(sunDir).multiplyScalar(900);
        stepSim(date); lastTick = nowMs; dirty = false;
        const sel = selectedRef.current;
        if (sel && sel.ok && nowMs - lastInfo > 400) { setInfo({ alt: sel.alt, speed: sel.speed, lat: sel.lat, lon: sel.lon }); lastInfo = nowMs; }
      }
      if (nowMs - lastClock > 500) { setClock(fmt(simMsRef.current)); lastClock = nowMs; }
      shells.visible = ringsRef.current; if (!ringsRef.current) labels.remove('hide');
      earthRig?.update(dt);
      controls.update();
      renderer.render(scene, camera);
      labels.update(camera, host.clientWidth, host.clientHeight, { radius: EARTH_R });
    };
    frame();
    const onVis = () => { visible = !document.hidden; if (visible) { clock.reset(); frame(); } };
    document.addEventListener('visibilitychange', onVis);

    return () => {
      disposed = true; cancelAnimationFrame(raf); cancelAnimationFrame(hoverRaf);
      document.removeEventListener('visibilitychange', onVis); ro.disconnect();
      renderer.domElement.removeEventListener('pointerdown', onDown); renderer.domElement.removeEventListener('pointerup', onUp); renderer.domElement.removeEventListener('pointermove', onMove);
      controls.dispose(); labels.dispose(); sky.dispose(); earthRig?.dispose(); disposables.forEach((d) => d.dispose());
      clock.dispose(); renderer.dispose(); renderer.domElement.remove(); apiRef.current = null;
    };
  }, []);

  /* ---------- HUD actions ---------- */
  const toggleGroup = (id: GroupId) => setGroupsOn((s) => ({ ...s, [id]: !s[id] }));
  const toggleClass = (c: OrbitClass) => setClassesOn((s) => ({ ...s, [c]: !s[c] }));
  const findIss = useCallback(() => {
    const all = [...satsRef.current.values()].flat();
    const iss = all.find((s) => /ISS \(ZARYA\)/i.test(s.name)) ?? all.find((s) => /ISS|ZARYA/i.test(s.name));
    if (iss) { onSelectRef.current(iss.uid); window.setTimeout(() => apiRef.current?.focus(iss.uid), 60); }
  }, []);
  const clearSel = () => onSelectRef.current(null);

  const statusDot = (st: Status) => st === 'live' ? 'bg-[#66d17a]' : st === 'sim' ? 'bg-[#ffb02e]' : st === 'loading' ? 'bg-[#72d1d6] animate-pulse' : 'bg-white/20';
  const kpColor = kp == null ? '#9fb1a6' : kp >= 7 ? '#ff4d4d' : kp >= 5 ? '#ffb02e' : kp >= 4 ? '#ffe066' : '#66d17a';

  return (
    <div className={`relative h-[72dvh] min-h-[460px] max-h-[680px] w-full overflow-hidden sm:h-[calc(100dvh-4rem)] sm:min-h-[560px] sm:max-h-none bg-black text-[#e6efe9] ${className ?? ''}`}>
      <div ref={hostRef} className="absolute inset-0" />
      <div ref={labelsHostRef} className="pointer-events-none absolute inset-0 overflow-hidden" />
      <div ref={tipRef} className="pointer-events-none absolute left-0 top-0 z-20 hidden rounded bg-black/80 px-2 py-1 text-[11px] text-[#d9f36a]" style={mono} />

      {!ready && (
        <div className="absolute inset-0 z-30 grid place-items-center bg-black/60 backdrop-blur-sm">
          <div className="w-64 text-center" style={mono}>
            <div className="mb-3 text-xs tracking-[0.2em] text-[#72d1d6]">CALIBRATING EARTH</div>
            <div className="h-1 overflow-hidden rounded bg-white/10"><div className="h-full bg-[#d9f36a] transition-all" style={{ width: `${Math.round(progress * 100)}%` }} /></div>
          </div>
        </div>
      )}

      {/* top bar */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex flex-wrap items-start justify-between gap-2 p-2.5 sm:gap-3 sm:p-4">
        <div className="pointer-events-auto flex min-w-0 items-start gap-2 sm:items-center sm:gap-3">
          {onBackToDeck && (
            <button onClick={onBackToDeck} className={`flex min-h-10 items-center gap-1.5 px-3 text-xs hover:text-[#d9f36a] ${panel}`} style={mono}><ArrowLeft size={14} /> RETURN</button>
          )}
          <div className={`min-w-0 px-2.5 py-2 sm:px-3 ${panel}`}>
            <div className="flex items-center gap-1.5 whitespace-nowrap text-[10px] sm:gap-2 sm:text-xs font-bold tracking-widest text-[#72d1d6]" style={mono}><SatIcon size={14} /> ORBITAL RADAR · 3D</div>
            <div className="mt-0.5 truncate text-[9px] tabular-nums text-[#9fb1a6] sm:text-[11px]" style={mono}>{clock} · {total.toLocaleString('en-US')} objects shown</div>
          </div>
        </div>
        <div className="pointer-events-auto flex items-center gap-2">
          {kp != null && <div className={`px-3 py-2 text-[11px] ${panel}`} style={mono}><span className="text-[#9fb1a6]">Kp </span><b style={{ color: kpColor }}>{kp.toFixed(1)}</b></div>}
          <button onClick={() => setShowLayers((v) => !v)} className={`flex min-h-10 items-center gap-1.5 px-3 text-xs lg:hidden ${panel}`} style={mono}><Layers size={14} /> LAYERS</button>
        </div>
      </div>

      {/* layers */}
      <aside className={`${showLayers ? 'flex' : 'hidden'} absolute left-4 top-24 z-10 max-h-[calc(100%-11rem)] w-[260px] flex-col gap-3 overflow-y-auto p-3 lg:flex ${panel}`}>
        <div className="text-[10px] tracking-[0.2em] text-[#9fb1a6]" style={mono}>CONSTELLATIONS</div>
        <div className="flex flex-col gap-1">
          {GROUPS.map((g) => (
            <button key={g.id} onClick={() => toggleGroup(g.id)} aria-pressed={groupsOn[g.id]}
              className={`flex min-h-10 items-center gap-2.5 rounded-lg border px-2.5 text-left transition ${groupsOn[g.id] ? 'border-[#d9f36a]/40 bg-[#d9f36a]/10' : 'border-white/10 hover:bg-white/5'}`}>
              <span className={`h-2 w-2 shrink-0 rounded-full ${groupsOn[g.id] ? statusDot(status[g.id]) : 'bg-white/20'}`} />
              <span className="flex-1 text-[13px]">{g.label}</span>
              {groupsOn[g.id] && counts[g.id] != null && <span className="text-[10px] text-[#9fb1a6]" style={mono}>{counts[g.id]}{status[g.id] === 'sim' ? ' SIM' : ''}</span>}
            </button>
          ))}
        </div>
        <div className="text-[10px] tracking-[0.2em] text-[#9fb1a6]" style={mono}>ORBIT CLASS</div>
        <div className="flex flex-wrap gap-1.5">
          {ORBIT_CLASSES.map((c) => (
            <button key={c} onClick={() => toggleClass(c)} aria-pressed={classesOn[c]} title={CLASS_META[c].label}
              className={`flex min-h-9 items-center gap-1.5 rounded-full border px-3 text-xs ${classesOn[c] ? 'border-white/30 bg-white/10' : 'border-white/10 opacity-50'}`} style={mono}>
              <span className="h-2 w-2 rounded-full" style={{ background: CLASS_META[c].color }} />{c}
            </button>
          ))}
        </div>
        <button onClick={() => setRings((v) => !v)} aria-pressed={rings} className={`min-h-9 rounded-lg border px-3 text-left text-xs ${rings ? 'border-white/30 bg-white/10' : 'border-white/10'}`} style={mono}>Altitude shells · {rings ? 'ON' : 'OFF'}</button>
        <div className="flex gap-2">
          <button onClick={findIss} className="flex min-h-9 flex-1 items-center justify-center gap-1.5 rounded-lg border border-[#72d1d6]/50 bg-[#72d1d6]/10 text-xs text-[#72d1d6]" style={mono}><Crosshair size={13} /> FIND ISS</button>
          <button onClick={() => apiRef.current?.resetView()} className="min-h-9 flex-1 rounded-lg border border-white/15 text-xs hover:bg-white/5" style={mono}>RESET VIEW</button>
        </div>
      </aside>

      {/* selection */}
      {selected && (
        <aside className={`absolute right-2 top-20 z-10 w-[290px] max-w-[calc(100%-1rem)] p-3 sm:right-4 sm:top-24 sm:p-4 ${panel}`} aria-live="polite">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="text-[10px] tracking-[0.2em] text-[#9fb1a6]" style={mono}>{GROUPS.find((g) => g.id === selected.group)?.label.toUpperCase()}</div>
              <h2 className="mt-1 text-lg font-bold leading-tight">{selected.name}</h2>
            </div>
            <button onClick={clearSel} aria-label="Clear selection" className="grid h-8 w-8 place-items-center rounded-full hover:bg-white/10"><X size={16} /></button>
          </div>
          <div className="mt-2 flex items-center gap-2 text-[11px]" style={mono}>
            <span className="rounded-full border px-2 py-0.5" style={{ borderColor: CLASS_META[selected.cls].color, color: CLASS_META[selected.cls].color }}>{selected.cls}</span>
            <span className="text-[#9fb1a6]">NORAD {selected.norad}</span>
            {selected.sim && <span className="text-[#ffb02e]">SIMULATED</span>}
          </div>
          <dl className="mt-3 grid grid-cols-2 gap-2">
            {([
              ['ALTITUDE', info ? `${Math.round(info.alt).toLocaleString('en-US')} km` : '—'],
              ['SPEED', info ? `${info.speed.toFixed(2)} km/s` : '—'],
              ['LATITUDE', info ? `${info.lat.toFixed(2)}°` : '—'],
              ['LONGITUDE', info ? `${info.lon.toFixed(2)}°` : '—'],
              ['PERIOD', `${selected.periodMin.toFixed(1)} min`],
              ['INCLINATION', `${selected.incl.toFixed(1)}°`],
            ] as const).map(([k, v]) => (
              <div key={k} className="rounded-lg bg-white/5 p-2.5">
                <dt className="text-[10px] text-[#9fb1a6]" style={mono}>{k}</dt>
                <dd className="m-0 mt-0.5 text-[15px] font-semibold tabular-nums">{v}</dd>
              </div>
            ))}
          </dl>
        </aside>
      )}

      {/* time controls */}
      <div className={`absolute bottom-4 left-1/2 z-10 flex -translate-x-1/2 flex-wrap items-center justify-center max-w-[calc(100%-1rem)] gap-1.5 overflow-x-auto px-2 py-2 sm:gap-2 sm:px-3 ${panel}`}>
        <button onClick={() => setPaused((v) => !v)} aria-label={paused ? 'Play' : 'Pause'} className="grid h-10 w-10 place-items-center rounded-full bg-[#d9f36a] text-[#0b1200]">{paused ? <Play size={16} /> : <Pause size={16} />}</button>
        {WARPS.map((w) => (
          <button key={w} onClick={() => setWarp(w)} aria-pressed={warp === w}
            className={`min-h-10 rounded-full border px-3.5 text-xs ${warp === w ? 'border-[#d9f36a] bg-[#d9f36a]/15 text-[#d9f36a]' : 'border-white/15 hover:bg-white/5'}`} style={mono}>{w}×</button>
        ))}
        <button onClick={() => { simMsRef.current = Date.now(); setWarp(1); setPaused(false); }} className="min-h-10 rounded-full border border-white/15 px-3.5 text-xs hover:bg-white/5" style={mono}>NOW</button>
      </div>
    </div>
  );
};

export default OrbitalRadar3D;
