import * as THREE from 'three';
import { Noise3 } from './earthKit';

/**
 * Procedural surface maps for the other worlds (seamless, generated once in the browser, no downloads):
 * Mercury, Venus, Mars, Jupiter (with Great Red Spot), Saturn (+ring system), Uranus, Neptune and the Moon.
 */

type RGB = [number, number, number];
const hex = (h: string): RGB => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const mix = (a: RGB, b: RGB, t: number): RGB => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const cl = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const sstep = (a: number, b: number, x: number) => { const t = cl((x - a) / (b - a)); return t * t * (3 - 2 * t); };
const tick = () => new Promise<void>((r) => setTimeout(r, 0));

function paint(w: number, h: number, fn: (x: number, y: number, z: number, lat: number) => RGB): HTMLCanvasElement {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const ctx = c.getContext('2d')!, img = ctx.createImageData(w, h);
  for (let j = 0; j < h; j++) {
    const lat = (0.5 - (j + 0.5) / h) * Math.PI, cy = Math.cos(lat), sy = Math.sin(lat);
    for (let i = 0; i < w; i++) {
      const lon = ((i + 0.5) / w) * Math.PI * 2, r = fn(cy * Math.cos(lon), sy, cy * Math.sin(lon), lat), k = (j * w + i) * 4;
      img.data[k] = r[0]; img.data[k + 1] = r[1]; img.data[k + 2] = r[2]; img.data[k + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return c;
}
const tex = (c: HTMLCanvasElement, srgb = true) => {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace; t.anisotropy = 8; t.wrapS = THREE.RepeatWrapping; t.needsUpdate = true; return t;
};

export interface PlanetTex { map: THREE.Texture; bump?: THREE.Texture }
export interface PlanetMaps { Mercury: PlanetTex; Venus: PlanetTex; Mars: PlanetTex; Jupiter: PlanetTex; Saturn: PlanetTex; Uranus: PlanetTex; Neptune: PlanetTex; Moon: PlanetTex; ring: THREE.Texture }

function rocky(seed: number, base: RGB, dark: RGB, light: RGB, craters: number, W: number, extra?: (x: number, y: number, z: number, c: RGB) => RGB): PlanetTex {
  const n = new Noise3(seed), n2 = new Noise3(seed + 99);
  const map = paint(W, W / 2, (x, y, z) => {
    const f = n.fbm(x * 2.2, y * 2.2, z * 2.2, 6), r = n.ridged(x * 5, y * 5, z * 5, 4), fine = n2.fbm(x * 34, y * 34, z * 34, 3);
    // crater-like pits and bright ejecta rays from layered ridged noise
    const pit = Math.pow(cl(n2.ridged(x * 11, y * 11, z * 11, 3) - 0.55, 0, 1), 2) * 3.2;
    const t = cl(0.5 + f * 1.4 + (r - 0.5) * 0.25 * craters - pit * 0.18 * craters);
    let c = t < 0.5 ? mix(dark, base, t * 2) : mix(base, light, (t - 0.5) * 2);
    const k = 1 + fine * 0.3; c = [c[0] * k, c[1] * k, c[2] * k];
    return extra ? extra(x, y, z, c) : c;
  });
  const bump = paint(W, W / 2, (x, y, z) => {
    const v = cl(0.5 + n.fbm(x * 3, y * 3, z * 3, 6) + n.ridged(x * 8, y * 8, z * 8, 3) * 0.2 + n2.fbm(x * 40, y * 40, z * 40, 2) * 0.15 - Math.pow(cl(n2.ridged(x * 11, y * 11, z * 11, 3) - 0.55), 2) * 0.6 * craters) * 255;
    return [v, v, v];
  });
  return { map: tex(map), bump: tex(bump, false) };
}

function gas(seed: number, palette: RGB[], bandFreq: number, turb: number, W: number, storm?: { lat: number; lon: number; size: number; color: RGB }): PlanetTex {
  const n = new Noise3(seed);
  return {
    map: tex(paint(W, W / 2, (x, y, z, lat) => {
      const wob = n.fbm(x * 3, y * 9, z * 3, 5) * turb, fine = n.fbm(x * 8, y * 40, z * 8, 4) * 0.5;
      let b = Math.sin((y + wob * 0.35) * bandFreq + fine * 1.4) * 0.5 + 0.5;
      b = cl(b + n.fbm(x * 16, y * 16, z * 16, 3) * 0.12);
      const idx = b * (palette.length - 1), i0 = Math.floor(idx), i1 = Math.min(palette.length - 1, i0 + 1);
      let c = mix(palette[i0], palette[i1], idx - i0);
      if (storm) {
        let dl = Math.atan2(z, x) - storm.lon; dl = Math.atan2(Math.sin(dl), Math.cos(dl));
        const d = Math.hypot(dl * Math.cos(lat), (lat - storm.lat) * 1.9) / storm.size, sw = n.fbm(x * 14 + dl * 3, y * 14, z * 14, 3) * 0.25;
        c = mix(c, storm.color, sstep(1.0, 0.55, d + sw));
      }
      const pol = 1 - Math.abs(y) * 0.28; return [c[0] * pol, c[1] * pol, c[2] * pol];
    })),
  };
}

function ringTex(seed: number): THREE.Texture {
  const W = 2048, c = document.createElement('canvas'); c.width = W; c.height = 4;
  const ctx = c.getContext('2d')!, img = ctx.createImageData(W, 4), n = new Noise3(seed);
  for (let i = 0; i < W; i++) {
    const t = i / (W - 1), rr = 1.24 + (2.27 - 1.24) * t, rel = (rr - 1.24) / (2.27 - 1.24);
    const v = cl(n.fbm(rr * 70, 0.5, 0.5, 5) * 1.4 + n.noise(rr * 400, 1, 1) * 0.3 + 0.5);
    const dens = (rel < 0.18 ? 0.35 : rel < 0.6 ? 1 : rel < 0.66 ? 0.05 : 0.85 * sstep(1.0, 0.93, rel)) * (Math.abs(rel - 0.93) < 0.008 ? 0.1 : 1);
    const a = cl(dens * (0.35 + v * 0.85)), shade = 0.72 + n.fbm(rr * 55, 2, 2, 3) * 0.5;
    for (let j = 0; j < 4; j++) { const k = (j * W + i) * 4; img.data[k] = Math.min(255, 226 * shade); img.data[k + 1] = Math.min(255, 204 * shade); img.data[k + 2] = Math.min(255, 160 * shade); img.data[k + 3] = a * 255; }
  }
  ctx.putImageData(img, 0, 0); return tex(c);
}

export async function buildPlanetTextures(onProgress?: (p: number) => void, W = 1024): Promise<PlanetMaps> {
  const step = async (p: number) => { onProgress?.(p); await tick(); };
  const Mercury = rocky(11, hex('#8c8884'), hex('#4a4745'), hex('#c9c4bc'), 1.2, W); await step(0.12);
  const Moon = rocky(222, hex('#9a9a9a'), hex('#4f4f54'), hex('#dcdcdc'), 1.8, W, (x, y, z, c) => { // dark maria
    const m = sstep(0.05, 0.22, new Noise3(7).fbm(x * 1.3, y * 1.3, z * 1.3, 4)); return [c[0] * (1 - m * 0.42), c[1] * (1 - m * 0.42), c[2] * (1 - m * 0.4)];
  }); await step(0.26);
  const mn = new Noise3(5);
  const Mars = rocky(5, hex('#b5532c'), hex('#5e2a17'), hex('#e3a06c'), 1.4, W, (x, y, z, c) => {
    const dk = sstep(0.08, 0.3, mn.fbm(x * 1.7 + 3, y * 1.7, z * 1.7, 4)); let o: RGB = [c[0] * (1 - dk * 0.45), c[1] * (1 - dk * 0.42), c[2] * (1 - dk * 0.38)];
    const cap = sstep(0.88, 0.96, Math.abs(y) + mn.fbm(x * 6, y * 6, z * 6, 3) * 0.06); return mix(o, hex('#f4f1ec'), cap);
  }); await step(0.4);
  const vn = new Noise3(909);
  const Venus: PlanetTex = { map: tex(paint(W, W / 2, (x, y, z) => { const w = vn.fbm(x * 2 + vn.fbm(x * 4, y * 4, z * 4, 3) * 0.8, y * 3.5, z * 2, 6); return mix(hex('#b8884a'), hex('#f0dcaa'), cl(0.5 + w * 1.3)); })) }; await step(0.5);
  const Jupiter = gas(21, [hex('#caa57a'), hex('#8a5a3a'), hex('#e6d2ae'), hex('#a8643f'), hex('#efe2c6'), hex('#b98456'), hex('#d9c19a')], 34, 0.3, W, { lat: -0.3, lon: 1.2, size: 0.09, color: hex('#b1441f') }); await step(0.62);
  const Saturn = gas(31, [hex('#e3cf9f'), hex('#caa96a'), hex('#efe0b3'), hex('#bfa070'), hex('#e8d6a6')], 22, 0.18, W); await step(0.74);
  const Uranus = gas(41, [hex('#a6dfe3'), hex('#8fd1d9'), hex('#b4e6e8')], 6, 0.25, W); await step(0.84);
  const Neptune = gas(51, [hex('#2a4fd0'), hex('#3a68ec'), hex('#1f3aa8'), hex('#4f80ff')], 12, 0.4, W, { lat: -0.35, lon: 2.2, size: 0.07, color: hex('#14257a') }); await step(0.93);
  const ring = ringTex(7); await step(1);
  return { Mercury, Venus, Mars, Jupiter, Saturn, Uranus, Neptune, Moon, ring };
}
