import * as THREE from 'three';
import { geoEquirectangular, geoPath } from 'd3-geo';
import { feature } from 'topojson-client';
import world from 'world-atlas/countries-110m.json';
import { subsolarPoint } from '../../utils/astro';

/**
 * Shared building blocks for the 3D NASA views:
 *  - a photoreal Earth (REAL coastlines from world-atlas, procedural biomes, bump, ocean glint,
 *    city lights, clouds, day/night terminator with twilight band, limb atmosphere)
 *  - starfield + deep-space sky
 *  - DOM label layer that tracks 3D points
 *
 * Coordinate convention (Earth-fixed): +X → lon 0°, +Y → north pole, −Z → lon 90°E.
 * ECEF (x,y,z) km → three (x, z, −y).
 */

/* eslint-disable @typescript-eslint/no-explicit-any */
const LAND: any = feature(world as any, (world as any).objects.land);

export const EARTH_R = 6.371; // 1 unit = 1000 km
export const D2R = Math.PI / 180;

export const latLonToVec3 = (latDeg: number, lonDeg: number, r = 1, out = new THREE.Vector3()) => {
  const la = latDeg * D2R, lo = lonDeg * D2R;
  return out.set(r * Math.cos(la) * Math.cos(lo), r * Math.sin(la), -r * Math.cos(la) * Math.sin(lo));
};
export const ecefToVec3 = (x: number, y: number, z: number, out = new THREE.Vector3()) => out.set(x / 1000, z / 1000, -y / 1000);
export const sunVector = (date: Date, out = new THREE.Vector3()) => {
  const s = subsolarPoint(date);
  return latLonToVec3(s.lat, s.lon, 1, out);
};

/* ───────────────────────── noise ───────────────────────── */
export function makeRng(seed: number) {
  let s = seed >>> 0;
  return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296);
}
export class Noise3 {
  private p = new Uint8Array(512);
  constructor(seed: number) {
    const r = makeRng(seed), a = Array.from({ length: 256 }, (_, i) => i);
    for (let i = 255; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    for (let i = 0; i < 512; i++) this.p[i] = a[i & 255];
  }
  private g(h: number, x: number, y: number, z: number) {
    const u = (h & 15) < 8 ? x : y, v = (h & 15) < 4 ? y : (h & 15) === 12 || (h & 15) === 14 ? x : z;
    return (h & 1 ? -u : u) + (h & 2 ? -v : v);
  }
  noise(x: number, y: number, z: number) {
    const X = Math.floor(x) & 255, Y = Math.floor(y) & 255, Z = Math.floor(z) & 255;
    x -= Math.floor(x); y -= Math.floor(y); z -= Math.floor(z);
    const f = (t: number) => t * t * t * (t * (t * 6 - 15) + 10), u = f(x), v = f(y), w = f(z), P = this.p;
    const A = P[X] + Y, AA = P[A] + Z, AB = P[A + 1] + Z, B = P[X + 1] + Y, BA = P[B] + Z, BB = P[B + 1] + Z;
    const l = (a: number, b: number, t: number) => a + t * (b - a);
    return l(
      l(l(this.g(P[AA], x, y, z), this.g(P[BA], x - 1, y, z), u), l(this.g(P[AB], x, y - 1, z), this.g(P[BB], x - 1, y - 1, z), u), v),
      l(l(this.g(P[AA + 1], x, y, z - 1), this.g(P[BA + 1], x - 1, y, z - 1), u), l(this.g(P[AB + 1], x, y - 1, z - 1), this.g(P[BB + 1], x - 1, y - 1, z - 1), u), v), w);
  }
  fbm(x: number, y: number, z: number, oct = 5, lac = 2.0, gain = 0.5) {
    let a = 0.5, s = 0, f = 1;
    for (let i = 0; i < oct; i++) { s += a * this.noise(x * f, y * f, z * f); f *= lac; a *= gain; }
    return s;
  }
  ridged(x: number, y: number, z: number, oct = 4) {
    let a = 0.5, s = 0, f = 1;
    for (let i = 0; i < oct; i++) { s += a * (1 - Math.abs(this.noise(x * f, y * f, z * f)) * 2); f *= 2.1; a *= 0.5; }
    return s;
  }
}

type RGB = [number, number, number];
const hex = (h: string): RGB => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const mix = (a: RGB, b: RGB, t: number): RGB => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const cl = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const sstep = (a: number, b: number, x: number) => { const t = cl((x - a) / (b - a)); return t * t * (3 - 2 * t); };

const mkTex = (c: HTMLCanvasElement, srgb: boolean) => {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  t.anisotropy = 8; t.wrapS = THREE.RepeatWrapping; t.needsUpdate = true;
  return t;
};
const tick = () => new Promise<void>((r) => setTimeout(r, 0));

export interface EarthTextures { day: THREE.Texture; night: THREE.Texture; spec: THREE.Texture; bump: THREE.Texture; clouds: THREE.Texture }

/** Builds all Earth maps (real coastlines + procedural biome detail). Async so the UI stays responsive. */
export async function buildEarthTextures(W = 2048, onProgress?: (p: number) => void): Promise<EarthTextures> {
  const H = W / 2;
  const maskC = document.createElement('canvas'); maskC.width = W; maskC.height = H;
  const mc = maskC.getContext('2d', { willReadFrequently: true })!;
  mc.fillStyle = '#000'; mc.fillRect(0, 0, W, H);
  const proj = geoEquirectangular().scale(W / (2 * Math.PI)).translate([W / 2, H / 2]);
  mc.fillStyle = '#fff'; mc.beginPath(); geoPath(proj, mc as any)(LAND); mc.fill();
  const land = mc.getImageData(0, 0, W, H).data;

  const blurC = document.createElement('canvas'); blurC.width = W; blurC.height = H;
  const bc = blurC.getContext('2d', { willReadFrequently: true })!;
  try { bc.filter = `blur(${Math.round(W / 340)}px)`; } catch { /* unsupported → shelf = coastline */ }
  bc.drawImage(maskC, 0, 0);
  const shelf = bc.getImageData(0, 0, W, H).data;

  const mk = () => { const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d')!; return { c, x, img: x.createImageData(W, H) }; };
  const D = mk(), N = mk(), S = mk(), B = mk();
  const nz = new Noise3(1337), nz2 = new Noise3(2468);

  const deep = hex('#021433'), mid = hex('#08407a'), shallow = hex('#1384a8'), coast = hex('#3fc0c0');
  const forest = hex('#1c4423'), grass = hex('#4a7634'), sav = hex('#8b8a47'), desert = hex('#c8a96c'), rock = hex('#6f655a'), tundra = hex('#7f8570'), snow = hex('#f1f6fb');

  for (let j = 0; j < H; j++) {
    const lat = (0.5 - (j + 0.5) / H) * Math.PI, cy = Math.cos(lat), sy = Math.sin(lat), latDeg = Math.abs(lat / D2R);
    for (let i = 0; i < W; i++) {
      const k = (j * W + i) * 4;
      const lon = ((i + 0.5) / W) * Math.PI * 2 - Math.PI;
      const x = cy * Math.cos(lon), z = cy * Math.sin(lon), y = sy;
      const isLand = land[k] > 127;
      const sh = shelf[k] / 255;
      let c: RGB, elev = 0, spec = 255, light = 0;

      if (!isLand) {
        const dn = nz.fbm(x * 3, y * 3, z * 3, 3);
        c = mix(deep, mid, cl(0.5 + dn * 1.4));
        c = mix(c, shallow, sstep(0.02, 0.5, sh) * 0.9);
        c = mix(c, coast, sstep(0.35, 0.8, sh) * 0.55);
        if (latDeg > 72) c = mix(c, hex('#a9c3d6'), sstep(72, 84, latDeg + nz.fbm(x * 8, y * 8, z * 8, 3) * 10) * 0.85); // sea ice
      } else {
        const e = nz.ridged(x * 3.2, y * 3.2, z * 3.2, 4) * 0.6 + nz.fbm(x * 1.4, y * 1.4, z * 1.4, 4) * 0.8;
        elev = cl(e * 0.8, 0, 1);
        const detail = nz2.fbm(x * 24, y * 24, z * 24, 3);
        const wet = cl(0.5 + nz2.fbm(x * 2.3 + 4, y * 2.3, z * 2.3, 4) * 1.5);
        const desertBelt = Math.exp(-Math.pow((latDeg - 24) / 11, 2)) * (0.45 + 0.9 * (1 - wet));
        const polar = sstep(60, 72, latDeg + nz.fbm(x * 6, y * 6, z * 6, 3) * 9);
        const temp = 1 - latDeg / 90;
        let b = mix(tundra, grass, sstep(0.25, 0.6, temp));
        b = mix(b, forest, sstep(0.45, 0.9, wet) * sstep(0.35, 0.7, temp) * 0.9);
        b = mix(b, sav, sstep(0.3, 0.6, desertBelt) * 0.6);
        b = mix(b, desert, sstep(0.55, 0.95, desertBelt));
        b = mix(b, rock, sstep(0.45, 0.78, elev));
        b = mix(b, snow, sstep(0.72, 0.95, elev) * 0.9);
        b = mix(b, snow, polar);
        const k2 = 1 + detail * 0.28;
        c = [b[0] * k2, b[1] * k2, b[2] * k2];
        spec = polar > 0.6 ? 40 : 14;
        const pop = sstep(0.1, 0.55, nz2.fbm(x * 5 + 9, y * 5, z * 5, 4) + 0.1) * (1 - polar) * (1 - sstep(0.25, 0.55, desertBelt) * 0.8) * sstep(0.62, 0.3, elev);
        const grain = sstep(0.62, 0.86, nz.fbm(x * 38, y * 38, z * 38, 3) + 0.5);
        light = pop * grain * (latDeg < 66 ? 1 : 0);
      }
      D.img.data[k] = c[0]; D.img.data[k + 1] = c[1]; D.img.data[k + 2] = c[2]; D.img.data[k + 3] = 255;
      const bv = (isLand ? 0.18 + elev * 0.82 : 0) * 255;
      B.img.data[k] = B.img.data[k + 1] = B.img.data[k + 2] = bv; B.img.data[k + 3] = 255;
      S.img.data[k] = S.img.data[k + 1] = S.img.data[k + 2] = spec; S.img.data[k + 3] = 255;
      N.img.data[k] = 255 * light; N.img.data[k + 1] = 190 * light; N.img.data[k + 2] = 105 * light; N.img.data[k + 3] = 255;
    }
    if (j % 48 === 47) { onProgress?.(j / H); await tick(); }
  }
  for (const m of [D, N, S, B]) m.x.putImageData(m.img, 0, 0);

  // clouds (separate smaller map)
  const CW = Math.min(W, 1024), CH = CW / 2;
  const cc = document.createElement('canvas'); cc.width = CW; cc.height = CH;
  const cx = cc.getContext('2d')!; const ci = cx.createImageData(CW, CH); const cn = new Noise3(77);
  for (let j = 0; j < CH; j++) {
    const lat = (0.5 - (j + 0.5) / CH) * Math.PI, cy = Math.cos(lat), sy = Math.sin(lat);
    for (let i = 0; i < CW; i++) {
      const lon = ((i + 0.5) / CW) * Math.PI * 2 - Math.PI, x = cy * Math.cos(lon), z = cy * Math.sin(lon);
      const warp = cn.fbm(x * 2 + 3, sy * 2, z * 2, 3) * 0.9;
      const v = cn.fbm(x * 2.6 + warp, sy * 3.6, z * 2.6 + warp, 6, 2.1, 0.55) + cn.fbm(x * 0.9, sy * 0.9 + 3, z * 0.9, 3) * 0.55;
      const a = sstep(0.04, 0.36, v) * 255, k = (j * CW + i) * 4;
      ci.data[k] = ci.data[k + 1] = ci.data[k + 2] = 255; ci.data[k + 3] = a;
    }
  }
  cx.putImageData(ci, 0, 0);
  onProgress?.(1);

  return { day: mkTex(D.c, true), night: mkTex(N.c, true), spec: mkTex(S.c, false), bump: mkTex(B.c, false), clouds: mkTex(cc, true) };
}

/* ───────────────────────── Earth ───────────────────────── */
const EARTH_VERT = /* glsl */ `
  varying vec2 vUv; varying vec3 vN; varying vec3 vP;
  void main(){ vUv = uv; vN = normalize(mat3(modelMatrix) * normal); vec4 wp = modelMatrix * vec4(position,1.0); vP = wp.xyz; gl_Position = projectionMatrix * viewMatrix * wp; }
`;
const EARTH_FRAG = /* glsl */ `
  precision highp float;
  varying vec2 vUv; varying vec3 vN; varying vec3 vP;
  uniform sampler2D uDay, uNight, uSpec, uBump, uClouds;
  uniform vec3 uSun; uniform float uBumpScale;
  vec3 perturb(vec3 N, vec3 P, float h){
    vec3 dpx = dFdx(P), dpy = dFdy(P); float dhx = dFdx(h), dhy = dFdy(h);
    vec3 r1 = cross(dpy, N), r2 = cross(N, dpx); float det = dot(dpx, r1);
    vec3 g = sign(det) * (dhx * r1 + dhy * r2);
    return normalize(abs(det) * N - g);
  }
  void main(){
    vec3 Ng = normalize(vN);
    vec3 V = normalize(cameraPosition - vP);
    float h = texture2D(uBump, vUv).r * uBumpScale;
    vec3 N = perturb(Ng, vP * 40.0, h);
    float geo = dot(Ng, uSun);
    float ndl = clamp(dot(N, uSun), 0.0, 1.0);
    float dayAmt = smoothstep(-0.10, 0.20, geo);
    vec3 day = texture2D(uDay, vUv).rgb;
    float cloud = texture2D(uClouds, vUv).a;
    vec3 col = day * (ndl * 1.12 + 0.012);
    col *= 1.0 - cloud * 0.30 * dayAmt;
    // ocean sun glint
    vec3 H = normalize(uSun + V);
    float sp = texture2D(uSpec, vUv).r;
    float gl = max(dot(N, H), 0.0);
    col += vec3(1.0, 0.93, 0.80) * pow(gl, 900.0) * sp * 2.2 * dayAmt * (1.0 - cloud);
    col += vec3(0.55, 0.7, 0.95) * pow(gl, 40.0) * sp * 0.12 * dayAmt * (1.0 - cloud);
    // city lights on the night side, dimmed by cloud
    vec3 night = texture2D(uNight, vUv).rgb * (1.0 - dayAmt) * (1.0 - cloud * 0.75) * 1.7;
    col += night;
    // twilight band
    float tw = smoothstep(-0.28, 0.0, geo) * (1.0 - smoothstep(0.0, 0.22, geo));
    col += vec3(0.95, 0.42, 0.18) * tw * 0.025;
    // limb brightening
    float fr = pow(1.0 - max(dot(Ng, V), 0.0), 3.2);
    col += vec3(0.28, 0.52, 1.0) * fr * 0.32 * (0.2 + 0.8 * smoothstep(-0.35, 0.4, geo));
    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;
const CLOUD_FRAG = /* glsl */ `
  precision highp float;
  varying vec2 vUv; varying vec3 vN; varying vec3 vP;
  uniform sampler2D uClouds; uniform vec3 uSun;
  void main(){
    vec3 Ng = normalize(vN); float geo = dot(Ng, uSun);
    float lit = smoothstep(-0.18, 0.35, geo);
    float a = texture2D(uClouds, vUv).a;
    vec3 col = mix(vec3(0.02, 0.025, 0.04), vec3(1.0), lit) * (0.35 + 0.75 * clamp(geo, 0.0, 1.0));
    float tw = smoothstep(-0.2, 0.0, geo) * (1.0 - smoothstep(0.0, 0.2, geo));
    col += vec3(0.9, 0.45, 0.2) * tw * 0.1;
    gl_FragColor = vec4(col, a * 0.92);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;
const ATMO_VERT = /* glsl */ `
  varying vec3 vN; varying vec3 vP;
  void main(){ vN = normalize(mat3(modelMatrix) * normal); vec4 wp = modelMatrix * vec4(position,1.0); vP = wp.xyz; gl_Position = projectionMatrix * viewMatrix * wp; }
`;
const ATMO_FRAG = /* glsl */ `
  precision highp float; varying vec3 vN; varying vec3 vP; uniform vec3 uSun;
  void main(){
    vec3 V = normalize(cameraPosition - vP); vec3 N = normalize(vN);
    float f = pow(1.0 - abs(dot(N, V)), 2.6);
    float geo = dot(N, uSun);
    float lit = smoothstep(-0.45, 0.45, geo);
    float tw = smoothstep(-0.3, 0.05, geo) * (1.0 - smoothstep(0.05, 0.35, geo));
    vec3 col = mix(vec3(0.18, 0.46, 1.0), vec3(1.0, 0.52, 0.22), tw * 0.85);
    gl_FragColor = vec4(col * f * 1.5 * (0.12 + 0.88 * lit), f * lit);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

export interface EarthRig {
  group: THREE.Group;
  sunDir: THREE.Vector3;
  setSun: (dir: THREE.Vector3) => void;
  update: (dt: number) => void;
  dispose: () => void;
}

export function createEarth(tx: EarthTextures): EarthRig {
  const sunDir = new THREE.Vector3(1, 0, 0);
  const uSun = { value: sunDir };
  const group = new THREE.Group();
  const geo = new THREE.SphereGeometry(EARTH_R, 160, 112);
  const earthMat = new THREE.ShaderMaterial({
    vertexShader: EARTH_VERT, fragmentShader: EARTH_FRAG,
    uniforms: { uDay: { value: tx.day }, uNight: { value: tx.night }, uSpec: { value: tx.spec }, uBump: { value: tx.bump }, uClouds: { value: tx.clouds }, uSun, uBumpScale: { value: 0.06 } },
  });
  const earth = new THREE.Mesh(geo, earthMat);
  group.add(earth);

  const cloudGeo = new THREE.SphereGeometry(EARTH_R * 1.006, 128, 96);
  const cloudMat = new THREE.ShaderMaterial({ vertexShader: EARTH_VERT, fragmentShader: CLOUD_FRAG, uniforms: { uClouds: { value: tx.clouds }, uSun }, transparent: true, depthWrite: false });
  const clouds = new THREE.Mesh(cloudGeo, cloudMat);
  group.add(clouds);

  const atmoGeo = new THREE.SphereGeometry(EARTH_R * 1.045, 96, 64);
  const atmoMat = new THREE.ShaderMaterial({ vertexShader: ATMO_VERT, fragmentShader: ATMO_FRAG, uniforms: { uSun }, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
  group.add(new THREE.Mesh(atmoGeo, atmoMat));

  return {
    group, sunDir,
    setSun: (d) => sunDir.copy(d).normalize(),
    update: (dt) => { clouds.rotation.y += dt * 0.004; }, // clouds drift slowly relative to the ground
    dispose: () => {
      [geo, cloudGeo, atmoGeo].forEach((g) => g.dispose());
      [earthMat, cloudMat, atmoMat].forEach((m) => m.dispose());
      Object.values(tx).forEach((t) => (t as THREE.Texture).dispose());
    },
  };
}

/* ───────────────────────── sky ───────────────────────── */
export function createSky(renderer?: THREE.WebGLRenderer) {
  void renderer;
  const group = new THREE.Group();
  const disposables: Array<{ dispose: () => void }> = [];

  // faint galactic dust sphere
  const W = 1024, H = 512, c = document.createElement('canvas'); c.width = W; c.height = H;
  const x = c.getContext('2d')!, img = x.createImageData(W, H), n = new Noise3(4242);
  for (let j = 0; j < H; j++) {
    const lat = (0.5 - (j + 0.5) / H) * Math.PI, cy = Math.cos(lat), sy = Math.sin(lat);
    for (let i = 0; i < W; i++) {
      const lon = ((i + 0.5) / W) * Math.PI * 2, px = cy * Math.cos(lon), pz = cy * Math.sin(lon);
      const band = Math.exp(-Math.pow((sy * 0.9 + 0.25 * px) * 3.5, 2));
      const d = n.fbm(px * 3 + 7, sy * 3, pz * 3, 5);
      const neb = cl(d * 2.2 + 0.1) * (0.3 + band * 0.9);
      const dark = sstep(0.1, 0.35, n.fbm(px * 5, sy * 5 + 2, pz * 5, 4)) * band;
      const k = (j * W + i) * 4, f = 1 - dark * 0.55;
      img.data[k] = (10 + 34 * neb + 20 * band) * f; img.data[k + 1] = (11 + 24 * neb + 15 * band) * f; img.data[k + 2] = (22 + 48 * neb + 20 * band) * f; img.data[k + 3] = 255;
    }
  }
  x.putImageData(img, 0, 0);
  const tex = mkTex(c, true);
  const sg = new THREE.SphereGeometry(1800, 48, 32);
  const sm = new THREE.MeshBasicMaterial({ map: tex, side: THREE.BackSide, depthWrite: false, fog: false });
  group.add(new THREE.Mesh(sg, sm));
  disposables.push(tex, sg, sm);

  // stars
  const N = 16000, pos = new Float32Array(N * 3), col = new Float32Array(N * 3), size = new Float32Array(N), rnd = makeRng(99);
  for (let i = 0; i < N; i++) {
    const u = rnd() * 2 - 1, a = rnd() * Math.PI * 2, uu = rnd() < 0.5 ? u * 0.35 : u, ss = Math.sqrt(1 - uu * uu), R = 1500;
    pos[i * 3] = Math.cos(a) * ss * R; pos[i * 3 + 1] = uu * R; pos[i * 3 + 2] = Math.sin(a) * ss * R;
    const t = rnd(), cc = new THREE.Color().setHSL(t < 0.2 ? 0.58 : t < 0.8 ? 0.12 : 0.04, 0.3 + rnd() * 0.4, 0.75 + rnd() * 0.25), b = Math.pow(rnd(), 3) * 0.9 + 0.1;
    col[i * 3] = cc.r * b; col[i * 3 + 1] = cc.g * b; col[i * 3 + 2] = cc.b * b; size[i] = 1 + Math.pow(rnd(), 6) * 3;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
  const uPR = { value: 1 };
  const m = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, vertexColors: true, uniforms: { uPR },
    vertexShader: `attribute float aSize; varying vec3 vC; uniform float uPR; void main(){ vC = color; gl_PointSize = aSize*uPR; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
    fragmentShader: `varying vec3 vC; void main(){ float d = length(gl_PointCoord-0.5); float a = smoothstep(0.5,0.0,d); gl_FragColor = vec4(vC*a*1.4, a); }`,
  });
  group.add(new THREE.Points(g, m));
  disposables.push(g, m);
  return { group, setPixelRatio: (r: number) => { uPR.value = r; }, dispose: () => disposables.forEach((d) => d.dispose()) };
}

export function glowTexture(inner = 'rgba(255,255,255,1)', mid = 'rgba(255,200,120,0.5)') {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const g = c.getContext('2d')!, gr = g.createRadialGradient(128, 128, 0, 128, 128, 128);
  gr.addColorStop(0, inner); gr.addColorStop(0.2, mid); gr.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 256, 256);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

/* ───────────────────────── DOM labels ───────────────────────── */
export class Labels {
  private items = new Map<string, { el: HTMLDivElement; pos: THREE.Vector3; dy: number }>();
  private v = new THREE.Vector3();
  constructor(private host: HTMLElement) {}
  set(id: string, text: string, pos: THREE.Vector3, color = '#d9f36a', dy = -14) {
    let it = this.items.get(id);
    if (!it) {
      const el = document.createElement('div');
      el.style.cssText = "position:absolute;left:0;top:0;pointer-events:none;white-space:nowrap;font:500 11px 'JetBrains Mono',ui-monospace,monospace;letter-spacing:.08em;text-shadow:0 0 6px #000,0 0 2px #000;will-change:transform";
      this.host.appendChild(el);
      it = { el, pos: pos.clone(), dy }; this.items.set(id, it);
    }
    it.el.textContent = text; it.el.style.color = color; it.pos.copy(pos); it.dy = dy;
  }
  remove(id: string) { const it = this.items.get(id); if (it) { it.el.remove(); this.items.delete(id); } }
  update(camera: THREE.Camera, w: number, h: number, occluder?: { radius: number }) {
    for (const it of this.items.values()) {
      this.v.copy(it.pos).project(camera);
      let hide = this.v.z > 1 || this.v.z < -1 || Math.abs(this.v.x) > 1.1 || Math.abs(this.v.y) > 1.1;
      if (!hide && occluder) { // hidden behind the planet?
        const cp = camera.position, d = it.pos.clone().sub(cp), L = d.length(); d.divideScalar(L);
        const t = -cp.dot(d); if (t > 0 && t < L && cp.clone().addScaledVector(d, t).length() < occluder.radius * 0.995) hide = true;
      }
      it.el.style.display = hide ? 'none' : 'block';
      if (!hide) it.el.style.transform = `translate(${(this.v.x * 0.5 + 0.5) * w + 10}px, ${(-this.v.y * 0.5 + 0.5) * h + it.dy}px)`;
    }
  }
  dispose() { this.items.forEach((i) => i.el.remove()); this.items.clear(); }
}
