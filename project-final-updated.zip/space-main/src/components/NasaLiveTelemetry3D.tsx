import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { ArrowLeft, Globe, Orbit, Radio, Satellite, Sun } from 'lucide-react';
import { issPropagate, julianDate, marsEarth, marsLs, marsSeasonNorth, perseveranceSol, simulatedIssAnchor, voyager1, type IssAnchor } from '../utils/astro';
import { D2R, EARTH_R, Labels, buildEarthTextures, createEarth, createSky, glowTexture, latLonToVec3, makeRng, sunVector, type EarthTextures } from './3d/earthKit';
import { buildPlanetTextures, type PlanetMaps } from './3d/planetKit';

/**
 * NASA Live Telemetry 3D
 *  EARTH view : live ISS (wheretheiss.at) with orbit track, visibility footprint and 3D station model,
 *               auroral ovals driven by NOAA's live planetary Kp, exact day/night terminator.
 *  SOLAR view : all eight planets on their real orbits (JPL Keplerian elements) with textured, lit surfaces,
 *               Saturn's rings, Earth's Moon, the asteroid belt and Kuiper belt, a glowing Sun with bloom,
 *               live Earth–Mars light-time beam and Voyager 1 on its bearing and range.
 *               Click a planet chip to fly to it; scrub time from live to one year per second.
 */

interface Props {
  onBackToDeck?: () => void;
  className?: string;
  initialView?: View;
  solarOnly?: boolean;
  title?: string;
}
type View = 'earth' | 'solar';
interface IssLive { lat: number; lon: number; alt: number; velKmh: number; vis: string; source: 'live' | 'stale' | 'simulated' }

const mono: React.CSSProperties = { fontFamily: "'JetBrains Mono', ui-monospace, monospace" };
const panel = 'rounded-xl border border-white/10 bg-[#040e12]/80 backdrop-blur-md';
const AU_KM = 149597870.7;
const LIGHT_MIN_PER_AU = AU_KM / 299792.458 / 60;

/* ───────── heliocentric positions (JPL approximate Keplerian elements, 1800–2050) ───────── */
interface Kep { a: number; e: number; I: number; L0: number; Lr: number; w: number; O: number }
const KEP: Record<string, Kep> = {
  Mercury: { a: 0.38709927, e: 0.20563593, I: 7.00497902, L0: 252.2503235, Lr: 149472.67411175, w: 77.45779628, O: 48.33076593 },
  Venus: { a: 0.72333566, e: 0.00677672, I: 3.39467605, L0: 181.9790995, Lr: 58517.81538729, w: 131.60246718, O: 76.67984255 },
  Earth: { a: 1.00000261, e: 0.01671123, I: -0.00001531, L0: 100.46457166, Lr: 35999.37244981, w: 102.93768193, O: 0 },
  Mars: { a: 1.52371034, e: 0.0933941, I: 1.84969142, L0: -4.55343205, Lr: 19140.30268499, w: -23.94362959, O: 49.55953891 },
  Jupiter: { a: 5.202887, e: 0.04838624, I: 1.30439695, L0: 34.39644051, Lr: 3034.74612775, w: 14.72847983, O: 100.47390909 },
  Saturn: { a: 9.53667594, e: 0.05386179, I: 2.48599187, L0: 49.95424423, Lr: 1222.49362201, w: 92.59887831, O: 113.66242448 },
  Uranus: { a: 19.18916464, e: 0.04725744, I: 0.77263783, L0: 313.23810451, Lr: 428.48202785, w: 170.9542763, O: 74.01692503 },
  Neptune: { a: 30.06992276, e: 0.00859048, I: 1.77004347, L0: -55.12002969, Lr: 218.45945325, w: 44.96476227, O: 131.78422574 },
};

interface PDef {
  name: string; r: number; tilt: number; dayD: number; color: string; kind: string; diam: string; period: string; dayTxt: string; blurb: string;
  atmo?: { color: number; power: number; intensity: number; scale: number };
}
const SIZE_BOOST = 1.35; // planets drawn larger than true scale
const PLANETS: PDef[] = ([
  { name: 'Mercury', r: 0.13, tilt: 0.03, dayD: 58.65, color: '#a39f9a', kind: 'ROCKY', diam: '4,879 km', period: '88 days', dayTxt: '58.6 days', blurb: 'The smallest planet and the closest to the Sun, with no real atmosphere.' },
  { name: 'Venus', r: 0.22, tilt: 177.4, dayD: -243, color: '#e0b46a', kind: 'ROCKY', diam: '12,104 km', period: '225 days', dayTxt: '243 days (retro)', blurb: 'Spins backwards, and its thick atmosphere makes it the hottest planet.', atmo: { color: 0xffd9a0, power: 2.4, intensity: 1.2, scale: 1.05 } },
  { name: 'Earth', r: 0.23, tilt: 23.44, dayD: 0.99727, color: '#4f8fe8', kind: 'ROCKY', diam: '12,742 km', period: '365.25 days', dayTxt: '23 h 56 m', blurb: 'The only world known to host life, with liquid oceans across most of its surface.', atmo: { color: 0x4d9bff, power: 2.6, intensity: 2.0, scale: 1.07 } },
  { name: 'Mars', r: 0.16, tilt: 25.19, dayD: 1.0275, color: '#d5643c', kind: 'ROCKY', diam: '6,779 km', period: '687 days', dayTxt: '24.6 h', blurb: 'A cold desert world with the tallest volcano in the solar system.', atmo: { color: 0xff9a6a, power: 4.0, intensity: 0.7, scale: 1.04 } },
  { name: 'Jupiter', r: 0.62, tilt: 3.13, dayD: 0.41354, color: '#c8935e', kind: 'GAS GIANT', diam: '139,820 km', period: '11.9 years', dayTxt: '9.9 h', blurb: 'The largest planet, wrapped in storm bands and the centuries-old Great Red Spot.', atmo: { color: 0xffd7a8, power: 3.2, intensity: 0.7, scale: 1.03 } },
  { name: 'Saturn', r: 0.5, tilt: 26.73, dayD: 0.44401, color: '#e3cf9f', kind: 'GAS GIANT', diam: '116,460 km', period: '29.4 years', dayTxt: '10.7 h', blurb: 'Less dense than water, wrapped in a ring system of ice and rock.', atmo: { color: 0xffe6b0, power: 3.2, intensity: 0.6, scale: 1.03 } },
  { name: 'Uranus', r: 0.34, tilt: 97.77, dayD: -0.71833, color: '#9fe0e6', kind: 'ICE GIANT', diam: '50,724 km', period: '84 years', dayTxt: '17.2 h (retro)', blurb: 'Rolls around the Sun on its side, tilted almost flat to its orbit.', atmo: { color: 0x9ff0f2, power: 2.6, intensity: 1.2, scale: 1.05 } },
  { name: 'Neptune', r: 0.33, tilt: 28.32, dayD: 0.67125, color: '#4f80ff', kind: 'ICE GIANT', diam: '49,244 km', period: '165 years', dayTxt: '16.1 h', blurb: 'The windiest planet and the farthest from the Sun.', atmo: { color: 0x5f8bff, power: 2.6, intensity: 1.5, scale: 1.05 } },
] as PDef[]).map((d) => ({ ...d, r: d.r * SIZE_BOOST }));

function orbitPoint(k: Kep, E: number, out = new THREE.Vector3()) {
  const I = k.I * D2R, O = k.O * D2R, om = (k.w - k.O) * D2R;
  const xp = k.a * (Math.cos(E) - k.e), yp = k.a * Math.sqrt(1 - k.e * k.e) * Math.sin(E);
  const cw = Math.cos(om), sw = Math.sin(om), cO = Math.cos(O), sO = Math.sin(O), cI = Math.cos(I), sI = Math.sin(I);
  return out.set(
    (cw * cO - sw * sO * cI) * xp + (-sw * cO - cw * sO * cI) * yp,
    (cw * sO + sw * cO * cI) * xp + (-sw * sO + cw * cO * cI) * yp,
    sw * sI * xp + cw * sI * yp,
  ); // ecliptic, AU
}
function helio(k: Kep, date: Date, out = new THREE.Vector3()) {
  const T = (julianDate(date) - 2451545.0) / 36525, L = k.L0 + k.Lr * T, M = ((((L - k.w) % 360) + 360) % 360) * D2R;
  let E = M + k.e * Math.sin(M);
  for (let i = 0; i < 8; i++) E -= (E - k.e * Math.sin(E) - M) / (1 - k.e * Math.cos(E));
  return orbitPoint(k, E, out);
}

/* ───────── shaders ───────── */
const SUN_VERT = /* glsl */ `varying vec3 vP; varying vec3 vV; varying vec3 vN;
  void main(){ vP = position; vN = normalize(normalMatrix*normal); vec4 mv = modelViewMatrix*vec4(position,1.0); vV = -mv.xyz; gl_Position = projectionMatrix*mv; }`;
const SUN_FRAG = /* glsl */ `
  precision highp float; varying vec3 vP; varying vec3 vV; varying vec3 vN; uniform float uTime;
  float h(vec3 p){ p = fract(p*0.3183099+.1); p*=17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
  float n(vec3 x){ vec3 i=floor(x), f=fract(x); f=f*f*(3.0-2.0*f);
    return mix(mix(mix(h(i),h(i+vec3(1,0,0)),f.x),mix(h(i+vec3(0,1,0)),h(i+vec3(1,1,0)),f.x),f.y),
               mix(mix(h(i+vec3(0,0,1)),h(i+vec3(1,0,1)),f.x),mix(h(i+vec3(0,1,1)),h(i+vec3(1,1,1)),f.x),f.y),f.z); }
  float fbm(vec3 p){ float a=.5,s=0.; for(int i=0;i<6;i++){ s+=a*n(p); p=p*2.1+3.3; a*=.5;} return s; }
  void main(){
    vec3 p = normalize(vP); float t = uTime*0.05;
    float v = fbm(p*9.0+vec3(t,-t,t*.5))*0.75 + fbm(p*28.0+vec3(-t*2.,t,t))*0.35;
    float spots = smoothstep(0.64, 0.8, fbm(p*3.0 + vec3(t*0.2)));
    vec3 col = mix(vec3(0.78,0.2,0.03), vec3(1.0,0.58,0.16), smoothstep(0.25,0.65,v));
    col = mix(col, vec3(1.0,0.93,0.62), smoothstep(0.55,0.95,v));
    col *= 1.0 - spots*0.5;
    float mu = clamp(dot(normalize(vN), normalize(vV)), 0.0, 1.0);
    col *= 0.55 + 0.75*pow(mu, 0.45);
    gl_FragColor = vec4(col*2.4, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;
const CORONA_FRAG = /* glsl */ `
  precision highp float; varying vec3 vP; varying vec3 vV; varying vec3 vN; uniform float uTime;
  void main(){
    float mu = abs(dot(normalize(vN), normalize(vV)));
    float f = pow(1.0 - mu, 1.8);
    float flick = 0.85 + 0.15*sin(uTime*0.6 + vP.x*9.0 + vP.y*7.0);
    gl_FragColor = vec4(vec3(1.0,0.55,0.18)*f*1.6*flick, f*0.85);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;
const ATMO_VERT = /* glsl */ `varying vec3 vN; varying vec3 vP;
  void main(){ vN = normalize(mat3(modelMatrix)*normal); vec4 wp = modelMatrix*vec4(position,1.0); vP = wp.xyz; gl_Position = projectionMatrix*viewMatrix*wp; }`;
const ATMO_FRAG = /* glsl */ `
  precision highp float; varying vec3 vN; varying vec3 vP; uniform vec3 uColor; uniform vec3 uSun; uniform float uPower; uniform float uIntensity;
  void main(){
    vec3 V = normalize(cameraPosition - vP); vec3 N = normalize(vN);
    float f = pow(1.0 - abs(dot(N, V)), uPower);
    float lit = smoothstep(-0.35, 0.5, dot(N, uSun));
    gl_FragColor = vec4(uColor * f * uIntensity * (0.12 + 0.88*lit), f * lit);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;
const AURORA_VERT = /* glsl */ `varying vec2 vUv; varying vec3 vPos; void main(){ vUv = uv; vPos = position; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }`;
const AURORA_FRAG = /* glsl */ `
  precision highp float; varying vec2 vUv; varying vec3 vPos; uniform vec3 uSun; uniform float uTime; uniform float uKp;
  void main(){
    float across = sin(3.14159 * vUv.y);
    float flick = 0.62 + 0.38 * sin(vUv.x * 62.83 + uTime * 0.7) * sin(vUv.x * 21.0 - uTime * 0.4);
    float night = 1.0 - smoothstep(-0.12, 0.28, dot(normalize(vPos), uSun));
    float a = across * across * flick * (0.22 + 0.78 * night) * (0.55 + 0.1 * uKp);
    vec3 c = mix(vec3(0.15, 1.0, 0.5), vec3(0.75, 0.25, 0.85), smoothstep(0.55, 1.0, vUv.y));
    gl_FragColor = vec4(c * a * 1.8, a);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

function auroraGeometry(pole: THREE.Vector3, boundaryMlat: number) {
  const up = Math.abs(pole.y) > 0.9 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 1, 0);
  const e1 = new THREE.Vector3().crossVectors(pole, up).normalize(), e2 = new THREE.Vector3().crossVectors(pole, e1).normalize();
  const N = 200, pos: number[] = [], uv: number[] = [], idx: number[] = [];
  const cOut = (90 - boundaryMlat) * D2R, cIn = (90 - boundaryMlat - 6) * D2R, R = EARTH_R * 1.0045;
  for (let i = 0; i <= N; i++) {
    const th = (i / N) * Math.PI * 2, dir = e1.clone().multiplyScalar(Math.cos(th)).addScaledVector(e2, Math.sin(th));
    ([[cIn, 0], [cOut, 1]] as const).forEach(([c, v]) => {
      const p = pole.clone().multiplyScalar(Math.cos(c)).addScaledVector(dir, Math.sin(c)).normalize().multiplyScalar(R);
      pos.push(p.x, p.y, p.z); uv.push(i / N, v);
    });
    if (i < N) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx);
  return g;
}

function buildIssModel() {
  const g = new THREE.Group();
  const white = new THREE.MeshStandardMaterial({ color: 0xe9ecef, roughness: 0.5, metalness: 0.4 });
  const truss = new THREE.MeshStandardMaterial({ color: 0xb9c0c8, roughness: 0.45, metalness: 0.7 });
  const panelM = new THREE.MeshStandardMaterial({ color: 0x1c3f86, roughness: 0.35, metalness: 0.6, emissive: 0x0a1a3c, emissiveIntensity: 0.6, side: THREE.DoubleSide });
  const gold = new THREE.MeshStandardMaterial({ color: 0xc9953a, roughness: 0.5, metalness: 0.6 });
  const add = (geo: THREE.BufferGeometry, m: THREE.Material, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.rotation.set(rx, ry, rz); g.add(o); return o; };
  add(new THREE.BoxGeometry(1.3, 0.035, 0.035), truss);
  for (const x of [-0.58, -0.36, 0.36, 0.58]) { add(new THREE.BoxGeometry(0.15, 0.004, 0.46), panelM, x, 0, 0.27); add(new THREE.BoxGeometry(0.15, 0.004, 0.46), panelM, x, 0, -0.27); add(new THREE.BoxGeometry(0.01, 0.01, 0.06), gold, x, 0, 0); }
  add(new THREE.CylinderGeometry(0.04, 0.04, 0.42, 14), white, 0, -0.03, 0, Math.PI / 2, 0, 0);
  add(new THREE.CylinderGeometry(0.03, 0.03, 0.22, 12), white, 0, -0.03, 0.3, Math.PI / 2, 0, 0);
  add(new THREE.CylinderGeometry(0.025, 0.025, 0.2, 12), white, 0.0, 0.05, 0.0, 0, 0, Math.PI / 2).scale.set(1, 0.5, 1);
  add(new THREE.BoxGeometry(0.09, 0.006, 0.12), white, 0.12, 0.09, 0.0);
  return g;
}

const WARPS: Array<{ label: string; k: number }> = [
  { label: 'LIVE', k: 1 }, { label: '1 DAY/s', k: 86400 }, { label: '1 MONTH/s', k: 2.63e6 }, { label: '1 YEAR/s', k: 3.156e7 },
];

export const NasaLiveTelemetry3D: React.FC<Props> = ({
  onBackToDeck,
  className,
  initialView = 'earth',
  solarOnly = false,
  title = 'NASA LIVE TELEMETRY · 3D',
}) => {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const labelsRef = useRef<HTMLDivElement | null>(null);
  const viewRef = useRef<View>(initialView);
  const linearRef = useRef(false);
  const followRef = useRef(true);
  const focusRef = useRef<string | null>(null);
  const warpRef = useRef(1);
  const simMsRef = useRef(Date.now());
  const resetFocusAt = useRef(0);
  const issRef = useRef<{ anchor: IssAnchor; live: IssLive | null }>({ anchor: simulatedIssAnchor(Date.now()), live: null });
  const kpRef = useRef<number | null>(null);

  const [view, setView] = useState<View>(initialView);
  const [linear, setLinear] = useState(false);
  const [follow, setFollow] = useState(true);
  const [focus, setFocusState] = useState<string | null>(null);
  const [warpIdx, setWarpIdx] = useState(0);
  const [iss, setIss] = useState<IssLive | null>(null);
  const [kp, setKp] = useState<number | null>(null);
  const [now, setNow] = useState(() => new Date());
  const [simDate, setSimDate] = useState(() => new Date());
  const [ready, setReady] = useState(false);
  const [planetsReady, setPlanetsReady] = useState(false);
  const [progress, setProgress] = useState(0);

  const setFocus = (name: string | null) => { focusRef.current = name; resetFocusAt.current = performance.now(); setFocusState(name); };

  useEffect(() => { viewRef.current = view; }, [view]);
  useEffect(() => { linearRef.current = linear; }, [linear]);
  useEffect(() => { followRef.current = follow; }, [follow]);
  useEffect(() => { warpRef.current = WARPS[warpIdx].k; }, [warpIdx]);
  useEffect(() => { const id = window.setInterval(() => setNow(new Date()), 1000); return () => window.clearInterval(id); }, []);

  /* ---------- live ISS ---------- */
  useEffect(() => {
    let stop = false, prev: { lat: number; lon: number; t: number } | null = null, asc = true, fails = 0, everLive = false;
    const pull = async () => {
      const ctl = new AbortController(), to = window.setTimeout(() => ctl.abort(), 4500);
      try {
        const r = await fetch('https://api.wheretheiss.at/v1/satellites/25544', { signal: ctl.signal });
        if (!r.ok) throw new Error(String(r.status));
        const j = await r.json();
        if (stop) return;
        const lat = Number(j.latitude), lon = Number(j.longitude), t = Number(j.timestamp) * 1000;
        if (!isFinite(lat) || !isFinite(lon)) throw new Error('bad');
        if (prev && t > prev.t && Math.abs(lat - prev.lat) > 0.0008) asc = lat > prev.lat;
        prev = { lat, lon, t };
        issRef.current.anchor = { lat, lon, ascending: asc, t };
        issRef.current.live = { lat, lon, alt: Number(j.altitude), velKmh: Number(j.velocity), vis: String(j.visibility), source: 'live' };
        fails = 0; everLive = true;
      } catch {
        if (stop) return;
        fails++;
        if (everLive) { if (issRef.current.live) issRef.current.live.source = fails > 2 ? 'stale' : 'live'; }
        else { issRef.current.anchor = simulatedIssAnchor(Date.now()); issRef.current.live = null; }
      } finally { window.clearTimeout(to); }
    };
    void pull();
    const t2 = window.setTimeout(pull, 2200), iv = window.setInterval(pull, 10000);
    const ui = window.setInterval(() => {
      const a = issRef.current.anchor, p = issPropagate(a, Date.now()), l = issRef.current.live;
      setIss({ lat: p.lat, lon: p.lon, alt: l?.alt ?? 420, velKmh: l?.velKmh ?? 27600, vis: l?.vis ?? 'n/a', source: l ? l.source : 'simulated' });
    }, 1000);
    return () => { stop = true; window.clearTimeout(t2); window.clearInterval(iv); window.clearInterval(ui); };
  }, []);

  /* ---------- live Kp ---------- */
  useEffect(() => {
    let off = false;
    const pull = async () => {
      try {
        const r = await fetch('https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json');
        const rows = (await r.json()) as string[][], v = parseFloat(rows[rows.length - 1][1]);
        if (!off && Number.isFinite(v)) { kpRef.current = v; setKp(v); }
      } catch { /* optional */ }
    };
    void pull(); const id = window.setInterval(pull, 5 * 60_000);
    return () => { off = true; window.clearInterval(id); };
  }, []);

  /* ---------- scene ---------- */
  useEffect(() => {
    const host = hostRef.current, lh = labelsRef.current;
    if (!host || !lh) return;
    let disposed = false;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' }); }
    catch { host.style.background = 'radial-gradient(circle, #0a2236, #000 70%)'; return; }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
    renderer.domElement.style.cssText = 'width:100%;height:100%;display:block;touch-action:none;';
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(40, 1, 0.02, 6000);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true; controls.dampingFactor = 0.06; controls.rotateSpeed = 0.6;
    controls.addEventListener('start', () => { setFollow(false); });

    // bloom for the Sun, used in the solar view only
    const composer = new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene, camera));
    const bloom = new UnrealBloomPass(new THREE.Vector2(512, 512), 0.7, 0.75, 0.92);
    composer.addPass(bloom); composer.addPass(new OutputPass());

    const sky = createSky(); sky.setPixelRatio(renderer.getPixelRatio()); scene.add(sky.group);
    const disposables: Array<{ dispose: () => void }> = [];
    const track = <T extends { dispose: () => void }>(o: T) => { disposables.push(o); return o; };
    const labels = new Labels(lh);

    const sunLight = new THREE.DirectionalLight(0xfff4e0, 3.2); scene.add(sunLight);
    const ambient = new THREE.AmbientLight(0x1a2438, 1.2); scene.add(ambient);
    const sunDir = new THREE.Vector3(1, 0, 0);

    /* ===== EARTH group ===== */
    const earthGroup = new THREE.Group(); scene.add(earthGroup);
    let earthRig: ReturnType<typeof createEarth> | null = null;
    let earthTx: EarthTextures | null = null;

    const issModel = buildIssModel(); earthGroup.add(issModel);
    const glowTex = track(glowTexture('rgba(255,236,170,1)', 'rgba(255,170,60,0.45)'));
    const issGlow = new THREE.Sprite(track(new THREE.SpriteMaterial({ map: glowTex, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, sizeAttenuation: false })));
    issGlow.scale.setScalar(0.07); earthGroup.add(issGlow);

    const mkLine = (color: number, opacity: number, n: number, parent: THREE.Object3D = earthGroup) => {
      const g = track(new THREE.BufferGeometry()); g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3));
      const l = new THREE.Line(g, track(new THREE.LineBasicMaterial({ color, transparent: true, opacity }))); l.frustumCulled = false; parent.add(l); return { g, l };
    };
    const past = mkLine(0x72d1d6, 0.35, 46), future = mkLine(0xd9f36a, 0.95, 61), foot = mkLine(0xffffff, 0.5, 129), nadir = mkLine(0xd9f36a, 0.5, 2);

    const auroraUniforms = { uSun: { value: sunDir }, uTime: { value: 0 }, uKp: { value: 2 } };
    const auroraMat = track(new THREE.ShaderMaterial({ vertexShader: AURORA_VERT, fragmentShader: AURORA_FRAG, uniforms: auroraUniforms, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
    const auroras = new THREE.Group(); earthGroup.add(auroras);
    let auroraKp = -1;
    const rebuildAurora = (k: number) => {
      auroras.children.slice().forEach((c) => { auroras.remove(c); (c as THREE.Mesh).geometry.dispose(); });
      const b = 67 - 2.0 * k; // equatorward edge of the oval (geomagnetic latitude)
      for (const pole of [latLonToVec3(80.65, -72.68, 1), latLonToVec3(-80.65, 107.32, 1)]) auroras.add(new THREE.Mesh(auroraGeometry(pole, b), auroraMat));
      auroraUniforms.uKp.value = k; auroraKp = k;
    };

    /* ===== SOLAR group ===== */
    const solarGroup = new THREE.Group(); solarGroup.visible = false; scene.add(solarGroup);
    const sunUniforms = { uTime: { value: 0 } };
    const sunMesh = new THREE.Mesh(track(new THREE.SphereGeometry(1, 96, 64)), track(new THREE.ShaderMaterial({ vertexShader: SUN_VERT, fragmentShader: SUN_FRAG, uniforms: sunUniforms })));
    solarGroup.add(sunMesh);
    const corona = new THREE.Mesh(track(new THREE.SphereGeometry(1.22, 64, 48)), track(new THREE.ShaderMaterial({ vertexShader: SUN_VERT, fragmentShader: CORONA_FRAG, uniforms: sunUniforms, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false })));
    solarGroup.add(corona);
    const sunTex = track(glowTexture('rgba(255,248,220,1)', 'rgba(255,190,90,0.5)'));
    const sunGlow = new THREE.Sprite(track(new THREE.SpriteMaterial({ map: sunTex, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.8 })));
    solarGroup.add(sunGlow);
    const sunPoint = new THREE.PointLight(0xfff0d8, 4.0, 0, 0); solarGroup.add(sunPoint);

    const mapR = (r: number) => (linearRef.current ? r * 4 : 6 * Math.log10(1 + r / 0.05));
    const toScene = (v: THREE.Vector3, out = new THREE.Vector3()) => {
      const r = v.length(); if (r < 1e-9) return out.set(0, 0, 0);
      const k = mapR(r) / r; return out.set(v.x * k, v.z * k, -v.y * k);
    };

    interface Body { def: PDef; group: THREE.Group; tilt: THREE.Group; mesh: THREE.Mesh; clouds?: THREE.Mesh; atmoU?: { uSun: { value: THREE.Vector3 } }; ring?: THREE.Mesh; orbitG: THREE.BufferGeometry; k: Kep; moon?: THREE.Mesh; spin: number }
    const bodies: Body[] = [];
    const ORB_N = 257, tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3();
    PLANETS.forEach((def) => {
      const group = new THREE.Group(), tilt = new THREE.Group(); tilt.rotation.z = def.tilt * D2R; group.add(tilt);
      const mesh = new THREE.Mesh(track(new THREE.SphereGeometry(def.r, 96, 64)), track(new THREE.MeshStandardMaterial({ color: new THREE.Color(def.color), roughness: 0.9, metalness: 0 })));
      tilt.add(mesh);
      let atmoU: Body['atmoU'];
      if (def.atmo) {
        atmoU = { uSun: { value: new THREE.Vector3(1, 0, 0) } };
        const u = { uColor: { value: new THREE.Color(def.atmo.color) }, uPower: { value: def.atmo.power }, uIntensity: { value: def.atmo.intensity }, uSun: atmoU.uSun };
        group.add(new THREE.Mesh(track(new THREE.SphereGeometry(def.r * def.atmo.scale, 64, 48)), track(new THREE.ShaderMaterial({ vertexShader: ATMO_VERT, fragmentShader: ATMO_FRAG, uniforms: u, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }))));
      }
      let ring: THREE.Mesh | undefined;
      if (def.name === 'Saturn') {
        const rIn = def.r * 1.24, rOut = def.r * 2.27, rg = track(new THREE.RingGeometry(rIn, rOut, 256, 1)), p = rg.attributes.position, uv = rg.attributes.uv;
        for (let i = 0; i < p.count; i++) uv.setXY(i, (Math.hypot(p.getX(i), p.getY(i)) - rIn) / (rOut - rIn), 0.5);
        ring = new THREE.Mesh(rg, track(new THREE.MeshStandardMaterial({ color: 0xe2cca0, transparent: true, side: THREE.DoubleSide, roughness: 0.9, depthWrite: false, opacity: 0.0 })));
        ring.rotation.x = -Math.PI / 2; tilt.add(ring);
      }
      let moon: THREE.Mesh | undefined;
      if (def.name === 'Earth') {
        moon = new THREE.Mesh(track(new THREE.SphereGeometry(0.06, 48, 32)), track(new THREE.MeshStandardMaterial({ color: 0xb9b9b9, roughness: 1 })));
        group.add(moon);
      }
      const og = track(new THREE.BufferGeometry()); og.setAttribute('position', new THREE.BufferAttribute(new Float32Array(ORB_N * 3), 3));
      const ol = new THREE.Line(og, track(new THREE.LineBasicMaterial({ color: new THREE.Color(def.color), transparent: true, opacity: 0.42 }))); ol.frustumCulled = false; solarGroup.add(ol);
      solarGroup.add(group);
      bodies.push({ def, group, tilt, mesh, atmoU, ring, orbitG: og, k: KEP[def.name], moon, spin: 0.35 / def.dayD });
    });
    const refreshOrbits = () => bodies.forEach((b) => {
      const a = b.orbitG.getAttribute('position') as THREE.BufferAttribute;
      for (let i = 0; i < ORB_N; i++) { orbitPoint(b.k, (i / (ORB_N - 1)) * Math.PI * 2, tmp); toScene(tmp, tmp2); a.setXYZ(i, tmp2.x, tmp2.y, tmp2.z); }
      a.needsUpdate = true;
    });

    // Earth–Mars beam + travelling pulse
    const beamG = track(new THREE.BufferGeometry()); beamG.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6), 3));
    const beam = new THREE.Line(beamG, track(new THREE.LineBasicMaterial({ color: 0xd9f36a, transparent: true, opacity: 0.5 }))); beam.frustumCulled = false; solarGroup.add(beam);
    const pulse = new THREE.Sprite(track(new THREE.SpriteMaterial({ map: glowTex, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, sizeAttenuation: false, color: 0xd9f36a })));
    pulse.scale.setScalar(0.035); solarGroup.add(pulse);

    // Asteroid belt + Kuiper belt (AU positions stored, remapped when the scale changes)
    const mkBelt = (n: number, r0: number, r1: number, zSpread: number, color: number, size: number, opacity: number, seed: number) => {
      const rnd = makeRng(seed), au = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) { const a = rnd() * Math.PI * 2, r = r0 + (r1 - r0) * Math.pow(rnd(), 0.9), z = (rnd() + rnd() + rnd() - 1.5) * zSpread * r; au[i * 3] = Math.cos(a) * r; au[i * 3 + 1] = Math.sin(a) * r; au[i * 3 + 2] = z; }
      const g = track(new THREE.BufferGeometry()); g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3));
      const pts = new THREE.Points(g, track(new THREE.PointsMaterial({ color, size, sizeAttenuation: false, transparent: true, opacity, depthWrite: false, blending: THREE.AdditiveBlending })));
      pts.frustumCulled = false; solarGroup.add(pts);
      const remap = () => { const a = g.getAttribute('position') as THREE.BufferAttribute; for (let i = 0; i < n; i++) { tmp.set(au[i * 3], au[i * 3 + 1], au[i * 3 + 2]); toScene(tmp, tmp2); a.setXYZ(i, tmp2.x, tmp2.y, tmp2.z); } a.needsUpdate = true; };
      return { pts, remap };
    };
    const asteroid = mkBelt(6500, 2.1, 3.3, 0.06, 0xa8987f, 1.15, 0.38, 31), kuiper = mkBelt(5000, 30, 50, 0.1, 0x8fa4c8, 1.1, 0.22, 77);

    // Heliopause ring + Voyager 1
    const heliG = track(new THREE.BufferGeometry()); heliG.setAttribute('position', new THREE.BufferAttribute(new Float32Array(129 * 3), 3));
    const heliLine = new THREE.Line(heliG, track(new THREE.LineBasicMaterial({ color: 0xd9f36a, transparent: true, opacity: 0.22 }))); heliLine.frustumCulled = false; solarGroup.add(heliLine);
    const refreshHelio = () => { const a = heliG.getAttribute('position') as THREE.BufferAttribute, R = mapR(121); for (let i = 0; i < 129; i++) { const t = (i / 128) * Math.PI * 2; a.setXYZ(i, Math.cos(t) * R, 0, Math.sin(t) * R); } a.needsUpdate = true; };
    const V1_LON = 256 * D2R, V1_LAT = 35 * D2R; // approximate ecliptic bearing
    const v1Dir = new THREE.Vector3(Math.cos(V1_LAT) * Math.cos(V1_LON), Math.cos(V1_LAT) * Math.sin(V1_LON), Math.sin(V1_LAT));
    const v1G = track(new THREE.BufferGeometry()); v1G.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6), 3));
    const v1Line = new THREE.Line(v1G, track(new THREE.LineBasicMaterial({ color: 0xffb454, transparent: true, opacity: 0.5 }))); v1Line.frustumCulled = false; solarGroup.add(v1Line);
    const v1Dot = new THREE.Sprite(track(new THREE.SpriteMaterial({ map: glowTex, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, sizeAttenuation: false, color: 0xffb454 })));
    v1Dot.scale.setScalar(0.05); solarGroup.add(v1Dot);

    let lastLinear: boolean | null = null;
    let planetMaps: PlanetMaps | null = null;
    const applyPlanetTextures = () => {
      if (!planetMaps) return;
      for (const b of bodies) {
        const name = b.def.name;
        if (name === 'Earth') {
          if (!earthTx) continue;
          b.mesh.material = track(new THREE.MeshStandardMaterial({ map: earthTx.day, bumpMap: earthTx.bump, bumpScale: 0.6, roughness: 0.85, metalness: 0 }));
          b.clouds = new THREE.Mesh(track(new THREE.SphereGeometry(b.def.r * 1.012, 64, 48)), track(new THREE.MeshStandardMaterial({ map: earthTx.clouds, transparent: true, depthWrite: false, roughness: 1, opacity: 0.9 })));
          b.tilt.add(b.clouds);
        } else {
          const t = planetMaps[name as keyof PlanetMaps] as { map: THREE.Texture; bump?: THREE.Texture };
          b.mesh.material = track(new THREE.MeshStandardMaterial({
            map: t.map,
            ...(t.bump ? { bumpMap: t.bump, bumpScale: 0.6 } : {}),
            roughness: 0.95,
            metalness: 0,
          }));
        }
        if (b.ring) { const m = b.ring.material as THREE.MeshStandardMaterial; m.map = planetMaps.ring; m.opacity = 1; m.color.set(0xffffff); m.needsUpdate = true; }
        if (b.moon) {
          const mm = b.moon.material as THREE.MeshStandardMaterial;
          mm.map = planetMaps.Moon.map; mm.bumpMap = planetMaps.Moon.bump ?? null; mm.bumpScale = 0.5; mm.color.set(0xffffff); mm.needsUpdate = true;
        }
      }
    };

    /* ===== view / camera ===== */
    let appliedView: View | null = null;
    const applyView = (v: View) => {
      appliedView = v;
      earthGroup.visible = v === 'earth'; solarGroup.visible = v === 'solar';
      ['iss', 'sun', 'beam', 'v1', 'helio', ...PLANETS.map((p) => p.name)].forEach((id) => labels.remove(id));
      sunLight.visible = v === 'earth'; ambient.intensity = v === 'earth' ? 1.2 : 0.55;
      if (v === 'earth') {
        controls.minDistance = EARTH_R * 1.1; controls.maxDistance = 90; controls.autoRotate = false; controls.target.set(0, 0, 0);
        const iss = issRef.current.anchor, p = latLonToVec3(iss.lat, iss.lon, 1); camera.position.copy(p).multiplyScalar(EARTH_R * 3.2); setFollow(true);
      } else {
        controls.minDistance = 0.5; controls.maxDistance = 400; controls.autoRotate = true; controls.autoRotateSpeed = 0.18; controls.target.set(0, 0, 0);
        camera.position.set(0, linearRef.current ? 9 : 17, linearRef.current ? 13 : 30); lastLinear = null;
      }
      controls.update();
    };

    const resize = () => {
      const w = host.clientWidth || 800, h = host.clientHeight || 600;
      renderer.setSize(w, h, false); composer.setSize(w, h); composer.setPixelRatio(renderer.getPixelRatio());
      camera.aspect = w / h; camera.fov = w / h < 0.9 ? 55 : 40; camera.updateProjectionMatrix();
    };
    resize(); const ro = new ResizeObserver(resize); ro.observe(host);

    void (async () => {
      const tx = await buildEarthTextures(1024, (p) => { if (!disposed) setProgress(p * 0.55); });
      if (disposed) { Object.values(tx).forEach((t) => (t as THREE.Texture).dispose()); return; }
      earthTx = tx; earthRig = createEarth(tx); earthGroup.add(earthRig.group); setReady(true);
      const maps = await buildPlanetTextures((p) => { if (!disposed) setProgress(0.55 + p * 0.45); }, 512);
      if (disposed) return;
      planetMaps = maps; applyPlanetTextures(); setPlanetsReady(true);
    })();

    /* ===== loop ===== */
    const clock = new THREE.Timer(); clock.connect(document);
    let raf = 0, visible = true, lastTrack = 0, lastText = 0, lastSimState = 0;
    const issPos = new THREE.Vector3(), e1 = new THREE.Vector3(), e2 = new THREE.Vector3();
    const posOf = new Map<string, THREE.Vector3>();
    const frame = () => {
      if (!visible || disposed) return;
      raf = requestAnimationFrame(frame);
      clock.update();
      const dt = Math.min(clock.getDelta(), 0.1), t = performance.now(), date = new Date();
      if (appliedView !== viewRef.current) applyView(viewRef.current);
      simMsRef.current += dt * 1000 * warpRef.current;
      const sdate = new Date(simMsRef.current);

      sunVector(date, sunDir); earthRig?.setSun(sunDir); sunLight.position.copy(sunDir).multiplyScalar(100);
      sunUniforms.uTime.value = t * 0.001 * 6; auroraUniforms.uTime.value = t * 0.001;

      if (viewRef.current === 'earth') {
        const k = kpRef.current ?? 2; if (k !== auroraKp) rebuildAurora(k);
        const a = issRef.current.anchor, p = issPropagate(a, date.getTime()), alt = issRef.current.live?.alt ?? 420;
        latLonToVec3(p.lat, p.lon, EARTH_R + alt / 1000, issPos);
        issModel.position.copy(issPos); issGlow.position.copy(issPos); issModel.lookAt(0, 0, 0);
        const camD = camera.position.distanceTo(issPos); issModel.scale.setScalar(Math.max(0.0005, camD * 0.045)); issModel.visible = camD < 14;

        if (t - lastTrack > 1500) {
          lastTrack = t;
          const pa = past.g.getAttribute('position') as THREE.BufferAttribute, fa = future.g.getAttribute('position') as THREE.BufferAttribute;
          for (let i = 0; i < 46; i++) { const q = issPropagate(a, date.getTime() - (45 - i) * 60_000); latLonToVec3(q.lat, q.lon, EARTH_R * 1.003, tmp); pa.setXYZ(i, tmp.x, tmp.y, tmp.z); }
          for (let i = 0; i < 61; i++) { const q = issPropagate(a, date.getTime() + i * 60_000); latLonToVec3(q.lat, q.lon, EARTH_R * 1.003, tmp); fa.setXYZ(i, tmp.x, tmp.y, tmp.z); }
          pa.needsUpdate = fa.needsUpdate = true;
          const rho = Math.acos(EARTH_R / (EARTH_R + alt / 1000)), sub = latLonToVec3(p.lat, p.lon, 1, tmp2).clone();
          const up = Math.abs(sub.y) > 0.95 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 1, 0);
          e1.crossVectors(sub, up).normalize(); e2.crossVectors(sub, e1).normalize();
          const ga = foot.g.getAttribute('position') as THREE.BufferAttribute;
          for (let i = 0; i < 129; i++) { const th = (i / 128) * Math.PI * 2; tmp.copy(sub).multiplyScalar(Math.cos(rho)).addScaledVector(e1, Math.cos(th) * Math.sin(rho)).addScaledVector(e2, Math.sin(th) * Math.sin(rho)).multiplyScalar(EARTH_R * 1.003); ga.setXYZ(i, tmp.x, tmp.y, tmp.z); }
          ga.needsUpdate = true;
        }
        const na = nadir.g.getAttribute('position') as THREE.BufferAttribute;
        tmp.copy(issPos).normalize().multiplyScalar(EARTH_R); na.setXYZ(0, issPos.x, issPos.y, issPos.z); na.setXYZ(1, tmp.x, tmp.y, tmp.z); na.needsUpdate = true;
        labels.set('iss', 'ISS · ZARYA', issPos, '#d9f36a', -18);

        if (followRef.current) {
          const dist = camera.position.length(), want = issPos.clone().normalize();
          camera.position.copy(camera.position.clone().normalize().lerp(want, Math.min(1, dt * 1.6)).normalize().multiplyScalar(dist));
        }
        earthRig?.update(dt);
        controls.update();
        renderer.render(scene, camera);
        labels.update(camera, host.clientWidth, host.clientHeight, { radius: EARTH_R });
      } else {
        const lin = linearRef.current;
        if (lin !== lastLinear) {
          lastLinear = lin; refreshOrbits(); asteroid.remap(); kuiper.remap(); refreshHelio();
          kuiper.pts.visible = !lin; heliLine.visible = !lin;
          const sr = lin ? 0.5 : 0.8; sunMesh.scale.setScalar(sr); corona.scale.setScalar(sr); sunGlow.scale.setScalar(sr * 9);
        }
        // planets
        const updateText = t - lastText > 500; if (updateText) lastText = t;
        const earthH = helio(KEP.Earth, sdate, new THREE.Vector3());
        let earthPos = tmp.clone();
        for (const b of bodies) {
          const h = b.k === KEP.Earth ? earthH : helio(b.k, sdate, new THREE.Vector3());
          toScene(h, tmp); b.group.position.copy(tmp); posOf.set(b.def.name, b.group.position.clone());
          if (b.def.name === 'Earth') earthPos = b.group.position.clone();
          b.mesh.rotation.y += dt * b.spin; if (b.clouds) b.clouds.rotation.y += dt * b.spin * 1.06;
          if (b.atmoU) b.atmoU.uSun.value.copy(b.group.position).negate().normalize();
          if (b.moon) { const ma = (simMsRef.current / 86400000 / 27.32) * Math.PI * 2; b.moon.position.set(Math.cos(ma) * 0.42, Math.sin(ma) * 0.04, -Math.sin(ma) * 0.42); }
          if (focusRef.current === b.def.name) labels.remove(b.def.name); else if (updateText) labels.set(b.def.name, `${b.def.name.toUpperCase()} · ${h.length().toFixed(h.length() < 10 ? 2 : 1)} AU`, b.group.position, b.def.color, -b.def.r * 28 - 10);
        }
        // Earth–Mars beam
        const mp = posOf.get('Mars') ?? new THREE.Vector3();
        const ba = beamG.getAttribute('position') as THREE.BufferAttribute; ba.setXYZ(0, earthPos.x, earthPos.y, earthPos.z); ba.setXYZ(1, mp.x, mp.y, mp.z); ba.needsUpdate = true;
        const ph = (t % 4000) / 4000, f = ph < 0.5 ? ph * 2 : 2 - ph * 2; pulse.position.lerpVectors(earthPos, mp, f);
        const me = marsEarth(sdate);
        labels.set('beam', `${me.lightMinutes.toFixed(1)} min light-time`, earthPos.clone().lerp(mp, 0.5), '#d9f36a', -44);
        labels.set('sun', 'SUN', new THREE.Vector3(0, sunMesh.scale.x * 1.4, 0), '#ffcf8a', -2);
        // Voyager 1
        const v1 = voyager1(sdate), vr = mapR(v1.au), vp = new THREE.Vector3(v1Dir.x, v1Dir.z, -v1Dir.y).multiplyScalar(vr);
        const va = v1G.getAttribute('position') as THREE.BufferAttribute; va.setXYZ(0, 0, 0, 0); va.setXYZ(1, vp.x, vp.y, vp.z); va.needsUpdate = true;
        v1Dot.position.copy(vp); v1Dot.visible = v1Line.visible = !lin;
        if (!lin) { labels.set('v1', `VOYAGER 1 · ${v1.au.toFixed(0)} AU`, vp, '#ffb454', -16); labels.set('helio', 'HELIOPAUSE ≈121 AU', new THREE.Vector3(Math.cos(0.7) * mapR(121), 0, Math.sin(0.7) * mapR(121)), '#d9f36a', 0); } else { labels.remove('v1'); labels.remove('helio'); }
        asteroid.pts.rotation.y = -(simMsRef.current / 86400000 / 365.25 / 4.4) * Math.PI * 2;
        kuiper.pts.rotation.y = -(simMsRef.current / 86400000 / 365.25 / 250) * Math.PI * 2;
        sunMesh.rotation.y += dt * 0.04;

        // focus camera
        const fname = focusRef.current, fb = fname ? bodies.find((b) => b.def.name === fname) : null;
        const goal = fb ? fb.group.position : tmp2.set(0, 0, 0);
        const prevT = controls.target.clone(); controls.target.lerp(goal, Math.min(1, dt * 4)); camera.position.add(controls.target.clone().sub(prevT));
        if (t - resetFocusAt.current < 1800) {
          const want = fb ? Math.max(1.0, fb.def.r * (fb.ring ? 7 : 5.2)) : (lin ? 15 : 32);
          const off = camera.position.clone().sub(controls.target), L = off.length();
          camera.position.copy(controls.target).add(off.setLength(THREE.MathUtils.lerp(L, want, Math.min(1, dt * 3.2))));
        }
        controls.autoRotate = !fb;

        if (t - lastSimState > 250) { lastSimState = t; setSimDate(sdate); }
        controls.update();
        composer.render();
        labels.update(camera, host.clientWidth, host.clientHeight);
      }
    };
    refreshOrbits();
    frame();
    const onVis = () => { visible = !document.hidden; if (visible) { clock.reset(); frame(); } };
    document.addEventListener('visibilitychange', onVis);

    return () => {
      disposed = true; cancelAnimationFrame(raf); document.removeEventListener('visibilitychange', onVis); ro.disconnect();
      controls.dispose(); labels.dispose(); sky.dispose(); earthRig?.dispose(); composer.dispose(); disposables.forEach((d) => d.dispose());
      auroras.children.forEach((c) => (c as THREE.Mesh).geometry.dispose());
      clock.dispose(); renderer.dispose(); renderer.domElement.remove();
    };
  }, []);

  /* ---------- derived telemetry ---------- */
  const dsDate = view === 'solar' ? simDate : now;
  const mars = marsEarth(dsDate), v1 = voyager1(dsDate), ls = marsLs(dsDate), sol = perseveranceSol(dsDate);
  const gScale = kp == null ? '—' : kp >= 9 ? 'G5' : kp >= 8 ? 'G4' : kp >= 7 ? 'G3' : kp >= 6 ? 'G2' : kp >= 5 ? 'G1' : 'G0';
  const kpColor = kp == null ? '#9fb1a6' : kp >= 7 ? '#ff4d4d' : kp >= 5 ? '#ffb02e' : kp >= 4 ? '#ffe066' : '#66d17a';
  const srcColor = iss?.source === 'live' ? '#66d17a' : '#ffb02e';
  const fdef = focus ? PLANETS.find((p) => p.name === focus) : null;
  let fSun = 0, fEarth = 0;
  if (fdef) { const p = helio(KEP[fdef.name], dsDate), e = helio(KEP.Earth, dsDate); fSun = p.length(); fEarth = p.clone().sub(e).length(); }

  const Stat = ({ k, v, c }: { k: string; v: string; c?: string }) => (
    <div className="rounded-lg bg-white/5 p-2.5"><dt className="text-[10px] text-[#9fb1a6]" style={mono}>{k}</dt><dd className="m-0 mt-0.5 text-[15px] font-semibold tabular-nums" style={c ? { color: c } : undefined}>{v}</dd></div>
  );
  const chip = (on: boolean) => `min-h-10 rounded-lg border text-xs ${on ? 'border-[#d9f36a] bg-[#d9f36a]/15 text-[#d9f36a]' : 'border-white/15 hover:bg-white/5'}`;

  return (
    <div className={`relative h-[calc(100dvh-4rem)] min-h-0 w-full overflow-hidden bg-black text-[#e6efe9] ${className ?? ''}`}>
      <div ref={hostRef} className="absolute inset-0" />
      <div ref={labelsRef} className="pointer-events-none absolute inset-0 overflow-hidden" />

      {(!ready || (view === 'solar' && !planetsReady)) && (
        <div className="absolute inset-0 z-30 grid place-items-center bg-black/60 backdrop-blur-sm">
          <div className="w-64 text-center" style={mono}>
            <div className="mb-3 text-xs tracking-[0.2em] text-[#72d1d6]">{ready ? 'PAINTING THE PLANETS' : 'CALIBRATING EARTH'}</div>
            <div className="h-1 overflow-hidden rounded bg-white/10"><div className="h-full bg-[#d9f36a] transition-all" style={{ width: `${Math.round(progress * 100)}%` }} /></div>
          </div>
        </div>
      )}

      {/* top bar */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex flex-wrap items-start justify-between gap-3 p-4">
        <div className="pointer-events-auto flex items-center gap-3">
          {onBackToDeck && <button onClick={onBackToDeck} className={`flex min-h-10 items-center gap-1.5 px-3 text-xs hover:text-[#d9f36a] ${panel}`} style={mono}><ArrowLeft size={14} /> RETURN</button>}
          <div className={`px-3 py-2 ${panel}`}>
            <div className="flex items-center gap-2 text-xs font-bold tracking-widest text-[#72d1d6]" style={mono}><Radio size={14} className="animate-pulse" /> {title}</div>
            <div className="mt-0.5 text-[11px] tabular-nums text-[#9fb1a6]" style={mono}>{dsDate.toISOString().replace('T', ' ').slice(0, 19)} UTC{view === 'solar' && warpIdx > 0 ? ' · SIMULATED' : ''}</div>
          </div>
        </div>
        {!solarOnly && <div className={`pointer-events-auto flex gap-1 p-1 ${panel}`} role="tablist" aria-label="View">
          {([['earth', 'EARTH · ISS', Globe], ['solar', 'SOLAR SYSTEM', Sun]] as const).map(([id, label, Icon]) => (
            <button key={id} role="tab" aria-selected={view === id} onClick={() => setView(id)}
              className={`flex min-h-10 items-center gap-1.5 rounded-lg px-4 text-xs transition ${view === id ? 'bg-[#d9f36a] font-bold text-[#0b1200]' : 'hover:bg-white/10'}`} style={mono}><Icon size={14} />{label}</button>
          ))}
        </div>}
      </div>

      {/* left panel */}
      {view === 'earth' ? (
        <aside className={`absolute left-4 top-24 z-10 flex w-[280px] max-w-[calc(100%-2rem)] flex-col gap-3 p-4 ${panel}`}>
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 text-[10px] tracking-[0.2em] text-[#9fb1a6]" style={mono}><Satellite size={13} /> INTERNATIONAL SPACE STATION</span>
            <span className="rounded-full border px-2 py-0.5 text-[10px]" style={{ ...mono, color: srcColor, borderColor: srcColor }}>{(iss?.source ?? 'sync').toUpperCase()}</span>
          </div>
          <dl className="m-0 grid grid-cols-2 gap-2">
            <Stat k="LATITUDE" v={iss ? `${iss.lat.toFixed(2)}°` : '—'} />
            <Stat k="LONGITUDE" v={iss ? `${iss.lon.toFixed(2)}°` : '—'} />
            <Stat k="ALTITUDE" v={iss ? `${Math.round(iss.alt)} km` : '—'} />
            <Stat k="VELOCITY" v={iss ? `${(iss.velKmh / 3600).toFixed(2)} km/s` : '—'} />
          </dl>
          <div className="text-[11px] text-[#9fb1a6]" style={mono}>Visibility: <span className="text-[#e6efe9]">{iss?.vis ?? '—'}</span></div>
          <button onClick={() => setFollow((f) => !f)} aria-pressed={follow} className={chip(follow)} style={mono}>TRACK ISS · {follow ? 'ON' : 'OFF'}</button>
          <div className="mt-1 border-t border-white/10 pt-3">
            <div className="text-[10px] tracking-[0.2em] text-[#9fb1a6]" style={mono}>SPACE WEATHER · AURORAL OVALS</div>
            <div className="mt-1.5 flex items-baseline gap-3"><span className="text-3xl font-bold tabular-nums" style={{ color: kpColor }}>{kp == null ? '—' : kp.toFixed(1)}</span><span className="text-xs text-[#9fb1a6]" style={mono}>Kp · NOAA {gScale}</span></div>
            <p className="m-0 mt-1 text-[11px] leading-relaxed text-[#9fb1a6]">The glowing ovals reach lower latitudes as the planetary Kp index rises.</p>
          </div>
        </aside>
      ) : (
        <aside className={`absolute left-4 top-24 z-10 flex max-h-[calc(100%-11rem)] w-[280px] max-w-[calc(100%-2rem)] flex-col gap-3 overflow-y-auto p-4 ${panel}`}>
          {fdef ? (
            <>
              <div className="flex items-center justify-between">
                <span className="text-[10px] tracking-[0.2em] text-[#9fb1a6]" style={mono}>SELECTED WORLD</span>
                <span className="rounded-full border px-2 py-0.5 text-[10px]" style={{ ...mono, color: fdef.color, borderColor: fdef.color }}>{fdef.kind}</span>
              </div>
              <h2 className="m-0 text-3xl font-bold tracking-tight">{fdef.name}</h2>
              <p className="m-0 text-[13px] leading-relaxed text-[#b4bcd4]">{fdef.blurb}</p>
              <dl className="m-0 grid grid-cols-2 gap-2">
                <Stat k="FROM SUN" v={`${fSun.toFixed(2)} AU`} />
                <Stat k="SUN LIGHT" v={`${(fSun * LIGHT_MIN_PER_AU).toFixed(fSun > 3 ? 0 : 1)} min`} c="#ffcf8a" />
                <Stat k="FROM EARTH" v={fdef.name === 'Earth' ? '—' : `${fEarth.toFixed(2)} AU`} />
                <Stat k="EARTH LIGHT" v={fdef.name === 'Earth' ? '—' : `${(fEarth * LIGHT_MIN_PER_AU).toFixed(fEarth > 3 ? 0 : 1)} min`} c="#d9f36a" />
                <Stat k="DIAMETER" v={fdef.diam} />
                <Stat k="YEAR" v={fdef.period} />
                <Stat k="DAY" v={fdef.dayTxt} />
                <Stat k="AXIAL TILT" v={`${fdef.tilt.toFixed(1)}°`} />
              </dl>
              <button onClick={() => setFocus(null)} className={chip(false)} style={mono}>BACK TO FULL SYSTEM</button>
            </>
          ) : (
            <>
              <div className="flex items-center gap-2 text-[10px] tracking-[0.2em] text-[#9fb1a6]" style={mono}><Orbit size={13} /> SCALE</div>
              <div className="grid grid-cols-2 gap-1.5">
                <button onClick={() => setLinear(false)} aria-pressed={!linear} className={chip(!linear)} style={mono}>WHOLE SYSTEM</button>
                <button onClick={() => setLinear(true)} aria-pressed={linear} className={chip(linear)} style={mono}>INNER PLANETS</button>
              </div>
              <p className="m-0 text-[11px] leading-relaxed text-[#9fb1a6]">{linear ? 'Linear distances: orbits at true relative spacing. Voyager 1 is far off this chart.' : 'Logarithmic distances so all eight planets, the Kuiper belt and Voyager 1 fit one view.'}</p>
              <p className="m-0 text-[10px] leading-relaxed text-[#9fb1a6]" style={mono}>Planets drawn larger than true scale. Positions: JPL approximate elements. Voyager 1 bearing is approximate.</p>
            </>
          )}
        </aside>
      )}

      {/* right: deep-space telemetry */}
      <aside className={`absolute right-4 top-24 z-10 hidden w-[290px] flex-col gap-3 p-4 md:flex ${panel}`}>
        <div className="text-[10px] tracking-[0.2em] text-[#9fb1a6]" style={mono}>DEEP SPACE · {view === 'solar' && warpIdx > 0 ? 'SIMULATED' : 'LIVE'} ESTIMATES</div>
        <div>
          <div className="mb-1.5 text-xs font-semibold text-[#ff9a72]">Mars</div>
          <dl className="m-0 grid grid-cols-2 gap-2">
            <Stat k="DISTANCE" v={`${mars.au.toFixed(2)} AU`} />
            <Stat k="LIGHT-TIME" v={`${mars.lightMinutes.toFixed(1)} min`} c="#d9f36a" />
            <Stat k="PERSEVERANCE" v={`Sol ${sol.toLocaleString('en-US')}`} />
            <Stat k="Ls" v={`${ls.toFixed(0)}°`} />
          </dl>
          <div className="mt-1.5 text-[11px] text-[#9fb1a6]" style={mono}>{marsSeasonNorth(ls)}</div>
        </div>
        <div className="border-t border-white/10 pt-3">
          <div className="mb-1.5 text-xs font-semibold text-[#ffb454]">Voyager 1</div>
          <dl className="m-0 grid grid-cols-2 gap-2">
            <Stat k="DISTANCE" v={`${v1.au.toFixed(1)} AU`} />
            <Stat k="ONE-WAY" v={`${(v1.oneWayS / 3600).toFixed(1)} h`} c="#ffb454" />
          </dl>
          <div className="mt-1.5 text-[11px] text-[#9fb1a6]" style={mono}>{(v1.km / 1e9).toFixed(2)} billion km from Earth</div>
        </div>
      </aside>

      {/* bottom: planet dock + time */}
      {view === 'solar' && (
        <div className="absolute inset-x-0 bottom-4 z-10 flex flex-col items-center gap-2 px-3">
          <div className={`flex max-w-full flex-wrap items-center justify-center gap-1.5 p-2 ${panel}`} role="tablist" aria-label="Planets">
            <button role="tab" aria-selected={!focus} onClick={() => setFocus(null)} className={`min-h-10 rounded-full border px-3.5 text-xs ${!focus ? 'border-[#d9f36a] bg-[#d9f36a]/15 text-[#d9f36a]' : 'border-white/15 hover:bg-white/5'}`} style={mono}>ALL</button>
            {PLANETS.map((p) => (
              <button key={p.name} role="tab" aria-selected={focus === p.name} onClick={() => setFocus(p.name)}
                className={`flex min-h-10 items-center gap-2 rounded-full border px-3.5 text-xs ${focus === p.name ? 'border-[#d9f36a] bg-[#d9f36a]/15 text-[#d9f36a]' : 'border-white/15 hover:bg-white/5'}`} style={mono}>
                <span className="h-2.5 w-2.5 rounded-full" style={{ background: p.color }} />{p.name}
              </button>
            ))}
          </div>
          <div className={`flex flex-wrap items-center justify-center gap-1.5 px-2 py-1.5 ${panel}`}>
            <span className="px-2 text-[10px] tracking-[0.2em] text-[#9fb1a6]" style={mono}>TIME</span>
            {WARPS.map((w, i) => (
              <button key={w.label} onClick={() => setWarpIdx(i)} aria-pressed={warpIdx === i} className={`min-h-9 rounded-full border px-3 text-[11px] ${warpIdx === i ? 'border-[#d9f36a] bg-[#d9f36a]/15 text-[#d9f36a]' : 'border-white/15 hover:bg-white/5'}`} style={mono}>{w.label}</button>
            ))}
            <button onClick={() => { simMsRef.current = Date.now(); setWarpIdx(0); }} className="min-h-9 rounded-full border border-white/15 px-3 text-[11px] hover:bg-white/5" style={mono}>NOW</button>
          </div>
        </div>
      )}
      {view === 'earth' && <div className="pointer-events-none absolute bottom-3 left-1/2 z-10 -translate-x-1/2 text-[10px] text-[#9fb1a6]" style={mono}>DRAG TO ROTATE · SCROLL TO ZOOM · {AU_KM.toLocaleString('en-US')} KM = 1 AU</div>}
    </div>
  );
};

export default NasaLiveTelemetry3D;
