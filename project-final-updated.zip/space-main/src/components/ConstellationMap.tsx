import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, Star, Telescope, Grid3x3, Tag, Spline, Orbit } from 'lucide-react';
import { playUiClick, playTone } from '../utils/audio';

/* -------------------------------------------------------------------------- */
/*  Data: real J2000 coordinates (RA in hours, Dec in degrees), V magnitudes    */
/* -------------------------------------------------------------------------- */

type SpecClass = 'O' | 'B' | 'A' | 'F' | 'G' | 'K' | 'M';
type SkyKind = 'star' | 'nebula' | 'bh' | 'snr';

interface SkyObject {
  name: string;
  kind: SkyKind;
  ra: number;
  dec: number;
  mag: number;
  distanceLy: number;
  spectral: string;
  cls?: SpecClass;
  color?: [number, number, number];
  note?: string;
  double?: boolean;
}

interface SkyConstellation {
  id: string;
  name: string;
  latinName: string;
  englishMeaning: string;
  brightestStar: string;
  season: string;
  mythology: string;
  astrophysicsFact: string;
  starsCount: number;
  objects: SkyObject[];
  lines: [string, string][];
  milky: { strength: number; angle: number; offset: number };
  density: number;
}

const hms = (h: number, m: number, s = 0) => h + m / 60 + s / 3600;
const dms = (d: number, m: number, s = 0) => (d < 0 ? -1 : 1) * (Math.abs(d) + m / 60 + s / 3600);

const CONSTELLATIONS: SkyConstellation[] = [
  {
    id: 'ursa-major',
    name: 'Ursa Major (The Great Bear)',
    latinName: 'Ursa Major',
    englishMeaning: 'The Greater Bear / Big Dipper',
    brightestStar: 'Alioth (Epsilon Ursae Majoris)',
    season: 'Circumpolar',
    mythology:
      'In Greek mythology, Zeus fell in love with the nymph Callisto. Hera transformed her into a bear, which Zeus placed in the stars along with her son Arcas (Ursa Minor).',
    astrophysicsFact:
      'The pointer stars Merak and Dubhe point directly toward Polaris, the North Star. Five of the seven stars in the Big Dipper share a common motion through space, originating from the same open cluster.',
    starsCount: 7,
    objects: [
      { name: 'Alkaid', kind: 'star', ra: hms(13, 47, 32), dec: dms(49, 18, 48), mag: 1.86, distanceLy: 104, spectral: 'B3V (Blue-White)', cls: 'B' },
      { name: 'Mizar', kind: 'star', ra: hms(13, 23, 56), dec: dms(54, 55, 31), mag: 2.04, distanceLy: 83, spectral: 'A2V (White Quadruple)', cls: 'A', note: 'The first telescopic double star ever discovered (1617).' },
      { name: 'Alioth', kind: 'star', ra: hms(12, 54, 2), dec: dms(55, 57, 35), mag: 1.76, distanceLy: 81, spectral: 'A1III-IV (White Subgiant)', cls: 'A' },
      { name: 'Megrez', kind: 'star', ra: hms(12, 15, 26), dec: dms(57, 1, 57), mag: 3.31, distanceLy: 80, spectral: 'A3V (White Main Seq)', cls: 'A', note: 'The faintest of the seven Dipper stars.' },
      { name: 'Phecda', kind: 'star', ra: hms(11, 53, 50), dec: dms(53, 41, 41), mag: 2.44, distanceLy: 83, spectral: 'A0V (White)', cls: 'A' },
      { name: 'Merak', kind: 'star', ra: hms(11, 1, 51), dec: dms(56, 22, 57), mag: 2.37, distanceLy: 79, spectral: 'A1V (Pointer)', cls: 'A' },
      { name: 'Dubhe', kind: 'star', ra: hms(11, 3, 44), dec: dms(61, 45, 3), mag: 1.79, distanceLy: 123, spectral: 'K0III (Orange Giant)', cls: 'K' },
      { name: 'Alcor', kind: 'star', ra: hms(13, 25, 13), dec: dms(54, 59, 17), mag: 4.01, distanceLy: 82, spectral: 'A5V (White)', cls: 'A', note: 'Mizar’s faint neighbour – a classic naked-eye eyesight test.' },
    ],
    lines: [['Alkaid', 'Mizar'], ['Mizar', 'Alioth'], ['Alioth', 'Megrez'], ['Megrez', 'Phecda'], ['Phecda', 'Merak'], ['Merak', 'Dubhe'], ['Dubhe', 'Megrez']],
    milky: { strength: 0.0, angle: 0, offset: 0 },
    density: 0.5,
  },
  {
    id: 'orion',
    name: 'Orion (The Celestial Hunter)',
    latinName: 'Orion',
    englishMeaning: 'The Hunter',
    brightestStar: 'Rigel (Beta Orionis)',
    season: 'Winter',
    mythology:
      'The mighty hunter of antiquity who boasted he could defeat any beast on Earth. The Earth goddess Gaia dispatched a giant scorpion (Scorpius) to duel him, and both were placed on opposite sides of the night sky.',
    astrophysicsFact:
      'Orion’s sword contains the Great Orion Nebula (M42), a colossal stellar nursery where hundreds of infant suns are actively forming right now just 1,344 light-years from Earth.',
    starsCount: 8,
    objects: [
      { name: 'Betelgeuse', kind: 'star', ra: hms(5, 55, 10), dec: dms(7, 24, 25), mag: 0.5, distanceLy: 642, spectral: 'M1-2Ia-ab (Red Supergiant)', cls: 'M', color: [255, 150, 95], note: 'Semi-regular variable (about mag 0.0 to 1.6). If placed at the Sun, it would swallow Mars’s orbit.' },
      { name: 'Bellatrix', kind: 'star', ra: hms(5, 25, 8), dec: dms(6, 20, 59), mag: 1.64, distanceLy: 250, spectral: 'B2III (Blue Giant)', cls: 'B' },
      { name: 'Meissa', kind: 'star', ra: hms(5, 35, 8), dec: dms(9, 56, 3), mag: 3.54, distanceLy: 1030, spectral: 'O8III (Blue Giant)', cls: 'O', note: 'The hunter’s head – a hot, young multiple star.' },
      { name: 'Alnitak', kind: 'star', ra: hms(5, 40, 46), dec: dms(-1, 56, 34), mag: 1.77, distanceLy: 1260, spectral: 'O9.5Ib (Blue Supergiant)', cls: 'O' },
      { name: 'Alnilam', kind: 'star', ra: hms(5, 36, 13), dec: dms(-1, 12, 7), mag: 1.69, distanceLy: 2000, spectral: 'B0Ia (Blue Supergiant)', cls: 'B' },
      { name: 'Mintaka', kind: 'star', ra: hms(5, 32, 0), dec: dms(-0, 17, 57), mag: 2.23, distanceLy: 1200, spectral: 'O9.5II (Blue-White)', cls: 'O' },
      { name: 'Saiph', kind: 'star', ra: hms(5, 47, 45), dec: dms(-9, 40, 11), mag: 2.09, distanceLy: 650, spectral: 'B0.5Ia (Blue Supergiant)', cls: 'B' },
      { name: 'Rigel', kind: 'star', ra: hms(5, 14, 32), dec: dms(-8, 12, 6), mag: 0.13, distanceLy: 860, spectral: 'B8Ia (Blue-White Supergiant)', cls: 'B' },
      { name: 'Orion Nebula (M42)', kind: 'nebula', ra: hms(5, 35, 17), dec: dms(-5, 23, 28), mag: 4.0, distanceLy: 1344, spectral: 'Emission nebula (H II region)', note: 'The nearest massive star-forming region. Visible to the naked eye as a fuzzy “star” in the sword.' },
    ],
    lines: [['Meissa', 'Betelgeuse'], ['Meissa', 'Bellatrix'], ['Betelgeuse', 'Alnitak'], ['Bellatrix', 'Mintaka'], ['Alnitak', 'Alnilam'], ['Alnilam', 'Mintaka'], ['Alnitak', 'Saiph'], ['Mintaka', 'Rigel']],
    milky: { strength: 0.28, angle: -0.5, offset: -0.12 },
    density: 1.0,
  },
  {
    id: 'cassiopeia',
    name: 'Cassiopeia (The Queen in the Throne)',
    latinName: 'Cassiopeia',
    englishMeaning: 'The Queen of Aethiopia ("W" Asterism)',
    brightestStar: 'Schedar (Alpha Cassiopeiae)',
    season: 'Autumn',
    mythology:
      'The vain queen who declared that she and her daughter Andromeda were more beautiful than all the Nereid sea nymphs, incurring the wrath of Poseidon.',
    astrophysicsFact:
      'Cassiopeia contains supernova remnant Cassiopeia A, the brightest extrasolar radio source in the sky, formed when a massive star exploded roughly 340 years ago.',
    starsCount: 5,
    objects: [
      { name: 'Caph', kind: 'star', ra: hms(0, 9, 11), dec: dms(59, 9, 1), mag: 2.27, distanceLy: 54, spectral: 'F2III (Yellow-White)', cls: 'F' },
      { name: 'Schedar', kind: 'star', ra: hms(0, 40, 31), dec: dms(56, 32, 14), mag: 2.24, distanceLy: 228, spectral: 'K0IIIa (Orange Giant)', cls: 'K' },
      { name: 'Gamma Cas', kind: 'star', ra: hms(0, 56, 43), dec: dms(60, 43, 0), mag: 2.47, distanceLy: 550, spectral: 'B0.5IVe (Variable)', cls: 'B', note: 'A rapidly spinning “Be” star that flings off a glowing disc of gas.' },
      { name: 'Ruchbah', kind: 'star', ra: hms(1, 25, 49), dec: dms(60, 14, 7), mag: 2.68, distanceLy: 99, spectral: 'A5V (White)', cls: 'A' },
      { name: 'Segin', kind: 'star', ra: hms(1, 54, 24), dec: dms(63, 40, 13), mag: 3.37, distanceLy: 460, spectral: 'B3III (Blue Giant)', cls: 'B' },
      { name: 'Cassiopeia A', kind: 'snr', ra: hms(23, 23, 24), dec: dms(58, 48, 0), mag: 99, distanceLy: 11000, spectral: 'Supernova remnant (radio / X-ray)', note: 'Invisible to the eye. Light from the explosion reached Earth around 1670 – no one recorded it.' },
    ],
    lines: [['Caph', 'Schedar'], ['Schedar', 'Gamma Cas'], ['Gamma Cas', 'Ruchbah'], ['Ruchbah', 'Segin']],
    milky: { strength: 0.85, angle: 0.18, offset: 0.1 },
    density: 1.25,
  },
  {
    id: 'cygnus',
    name: 'Cygnus (The Northern Cross)',
    latinName: 'Cygnus',
    englishMeaning: 'The Swan',
    brightestStar: 'Deneb (Alpha Cygni)',
    season: 'Summer',
    mythology:
      'The swan soaring down the Milky Way. Deneb forms the top corner of the celebrated Summer Triangle with Vega and Altair.',
    astrophysicsFact:
      'Cygnus hosts Cygnus X-1, the first widely accepted stellar-mass black hole discovered in modern astrophysics, actively siphoning matter from a companion blue supergiant star.',
    starsCount: 5,
    objects: [
      { name: 'Deneb', kind: 'star', ra: hms(20, 41, 26), dec: dms(45, 16, 49), mag: 1.25, distanceLy: 2615, spectral: 'A2Ia (Luminous Supergiant)', cls: 'A', note: 'One of the most luminous stars visible to the naked eye – around 200,000 Suns.' },
      { name: 'Sadr', kind: 'star', ra: hms(20, 22, 14), dec: dms(40, 15, 24), mag: 2.23, distanceLy: 1800, spectral: 'F8Ib (Yellow-White Supergiant)', cls: 'F' },
      { name: 'Albireo', kind: 'star', ra: hms(19, 30, 43), dec: dms(27, 57, 35), mag: 3.18, distanceLy: 430, spectral: 'K3II + B8V (Gold & Blue Binary)', cls: 'K', double: true, note: 'A small telescope splits it into a golden star and a blue companion.' },
      { name: 'Gienah', kind: 'star', ra: hms(20, 46, 13), dec: dms(33, 58, 13), mag: 2.46, distanceLy: 73, spectral: 'K0III (Orange Giant)', cls: 'K' },
      { name: 'Delta Cyg', kind: 'star', ra: hms(19, 44, 58), dec: dms(45, 7, 51), mag: 2.87, distanceLy: 165, spectral: 'B9.5IV (Blue Subgiant)', cls: 'B' },
      { name: 'Cygnus X-1', kind: 'bh', ra: hms(19, 58, 22), dec: dms(35, 12, 6), mag: 8.9, distanceLy: 7200, spectral: 'Black hole (~21 Suns) + O-type supergiant', note: 'Its blue companion HDE 226868 is just visible in binoculars; the black hole itself emits only X-rays.' },
    ],
    lines: [['Deneb', 'Sadr'], ['Sadr', 'Albireo'], ['Delta Cyg', 'Sadr'], ['Sadr', 'Gienah']],
    milky: { strength: 1.0, angle: 0.62, offset: 0.0 },
    density: 1.45,
  },
];

/* ------------------------------- colour helpers ------------------------------ */
const CLASS_RGB: Record<SpecClass, [number, number, number]> = {
  O: [150, 175, 255],
  B: [172, 192, 255],
  A: [208, 220, 255],
  F: [250, 246, 238],
  G: [255, 240, 205],
  K: [255, 207, 150],
  M: [255, 168, 112],
};
const CLASS_INFO: { cls: SpecClass; temp: string }[] = [
  { cls: 'O', temp: '30,000 K+' },
  { cls: 'B', temp: '10–30,000 K' },
  { cls: 'A', temp: '7.5–10,000 K' },
  { cls: 'F', temp: '6–7,500 K' },
  { cls: 'G', temp: '5–6,000 K' },
  { cls: 'K', temp: '3.5–5,000 K' },
  { cls: 'M', temp: '<3,500 K' },
];
const rgbOf = (o: SkyObject): [number, number, number] => o.color ?? (o.cls ? CLASS_RGB[o.cls] : [190, 210, 255]);
const rgba = (c: [number, number, number], a: number) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;

const D2R = Math.PI / 180;
const R2D = 180 / Math.PI;

/* ---------------------------------- projection --------------------------------- */
function centerOf(objs: SkyObject[]) {
  let x = 0, y = 0, z = 0;
  objs.forEach(o => {
    const a = o.ra * 15 * D2R, d = o.dec * D2R;
    x += Math.cos(d) * Math.cos(a);
    y += Math.cos(d) * Math.sin(a);
    z += Math.sin(d);
  });
  const ra = ((Math.atan2(y, x) * R2D) / 15 + 24) % 24;
  const dec = Math.atan2(z, Math.sqrt(x * x + y * y)) * R2D;
  return { ra, dec };
}

function stereo(ra: number, dec: number, ra0: number, dec0: number) {
  const a = (ra - ra0) * 15 * D2R, d = dec * D2R, d0 = dec0 * D2R;
  const cosc = Math.sin(d0) * Math.sin(d) + Math.cos(d0) * Math.cos(d) * Math.cos(a);
  const k = 2 / (1 + cosc);
  return {
    x: k * Math.cos(d) * Math.sin(a),
    y: k * (Math.cos(d0) * Math.sin(d) - Math.sin(d0) * Math.cos(d) * Math.cos(a)),
    ok: cosc > -0.9,
  };
}

interface View {
  ra0: number;
  dec0: number;
  scale: number;
  W: number;
  H: number;
  toScreen: (ra: number, dec: number) => { x: number; y: number; ok: boolean };
}

function makeView(c: SkyConstellation, W: number, H: number): View {
  const { ra: ra0, dec: dec0 } = centerOf(c.objects.filter(o => o.kind === 'star'));
  const pts = c.objects.map(o => stereo(o.ra, o.dec, ra0, dec0));
  const minX = Math.min(...pts.map(p => p.x)), maxX = Math.max(...pts.map(p => p.x));
  const minY = Math.min(...pts.map(p => p.y)), maxY = Math.max(...pts.map(p => p.y));
  const padX = Math.max(70, W * 0.1), padY = Math.max(60, H * 0.14);
  const spanX = Math.max(maxX - minX, 0.02), spanY = Math.max(maxY - minY, 0.02);
  const scale = Math.min((W - 2 * padX) / spanX, (H - 2 * padY) / spanY);
  const mx = (minX + maxX) / 2, my = (minY + maxY) / 2;
  const cx = W / 2, cy = H / 2;
  return {
    ra0, dec0, scale, W, H,
    toScreen: (ra, dec) => {
      const p = stereo(ra, dec, ra0, dec0);
      return { x: cx - (p.x - mx) * scale, y: cy - (p.y - my) * scale, ok: p.ok };
    },
  };
}

/* ------------------------------------- RNG ------------------------------------- */
function mulberry32(seed: number) {
  let a = seed | 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const hashStr = (s: string) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const gauss = (r: () => number) => { let u = 0; for (let i = 0; i < 4; i++) u += r(); return (u - 2) * 1.7; };

/* ------------------------------ static sky layer ------------------------------- */
interface Twinkler { x: number; y: number; r: number; c: [number, number, number]; a: number; ph: number; sp: number }

function buildStaticLayer(c: SkyConstellation, view: View, dpr: number, showGrid: boolean) {
  const W = view.W, H = view.H;
  const cv = document.createElement('canvas');
  cv.width = Math.round(W * dpr);
  cv.height = Math.round(H * dpr);
  const ctx = cv.getContext('2d')!;
  ctx.scale(dpr, dpr);
  const rnd = mulberry32(hashStr(c.id));

  const bg = ctx.createRadialGradient(W * 0.5, H * 0.45, 0, W * 0.5, H * 0.5, Math.max(W, H) * 0.75);
  bg.addColorStop(0, '#0a1626');
  bg.addColorStop(0.55, '#050c17');
  bg.addColorStop(1, '#010308');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  const mw = c.milky;
  if (mw.strength > 0.02) {
    const diag = Math.hypot(W, H);
    const dirT = { x: Math.cos(mw.angle), y: Math.sin(mw.angle) };
    const dirN = { x: -dirT.y, y: dirT.x };
    const sigma = H * (0.15 + 0.05 * mw.strength);
    const ox = W * 0.5 + dirN.x * mw.offset * H, oy = H * 0.5 + dirN.y * mw.offset * H;
    const place = (along: number, across: number) => {
      const wob = Math.sin(along * 0.006 + 1.3) * sigma * 0.45;
      return { x: ox + dirT.x * along + dirN.x * (across + wob), y: oy + dirT.y * along + dirN.y * (across + wob) };
    };
    for (let i = 0; i < 46; i++) {
      const p = place((rnd() - 0.5) * diag * 1.5, gauss(rnd) * sigma * 0.55);
      const rad = sigma * (0.7 + rnd() * 1.1);
      const warm = rnd() < 0.35;
      const col: [number, number, number] = warm ? [200, 160, 135] : [120, 155, 215];
      const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, rad);
      g.addColorStop(0, rgba(col, 0.05 * mw.strength + 0.004));
      g.addColorStop(1, rgba(col, 0));
      ctx.fillStyle = g;
      ctx.fillRect(p.x - rad, p.y - rad, rad * 2, rad * 2);
    }
    const n = Math.round(30000 * mw.strength * Math.min(1.4, (W * H) / 520000));
    for (let i = 0; i < n; i++) {
      const across = gauss(rnd) * sigma * 0.5;
      const p = place((rnd() - 0.5) * diag * 1.6, across);
      const fall = Math.exp(-Math.pow(across / sigma, 2) * 0.6);
      const a = (0.05 + rnd() * 0.18) * fall * mw.strength;
      ctx.fillStyle = rnd() < 0.3 ? `rgba(255,228,200,${a})` : `rgba(205,220,255,${a})`;
      const s = 0.5 + rnd() * 0.9;
      ctx.fillRect(p.x, p.y, s, s);
    }
    for (let i = 0; i < 18; i++) {
      const p = place((rnd() - 0.5) * diag * 1.2, gauss(rnd) * sigma * 0.28);
      const rad = sigma * (0.25 + rnd() * 0.5);
      const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, rad);
      g.addColorStop(0, `rgba(2,4,9,${0.42 * mw.strength})`);
      g.addColorStop(1, 'rgba(2,4,9,0)');
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(mw.angle + (rnd() - 0.5) * 0.5);
      ctx.scale(1.9, 0.7);
      ctx.translate(-p.x, -p.y);
      ctx.fillStyle = g;
      ctx.fillRect(p.x - rad, p.y - rad, rad * 2, rad * 2);
      ctx.restore();
    }
  }

  c.objects.forEach(o => {
    const p = view.toScreen(o.ra, o.dec);
    if (!p.ok) return;
    const pxDeg = view.scale * D2R;
    if (o.kind === 'nebula') {
      const R = Math.max(34, pxDeg * 1.25);
      const layers: [[number, number, number], number, number, number, number][] = [
        [[255, 100, 150], 0.7, 1.0, -0.15, 0.1],
        [[110, 160, 255], 0.55, 0.8, 0.25, -0.2],
        [[255, 215, 230], 0.75, 0.42, 0, 0],
      ];
      layers.forEach(([col, a, k, dx, dy]) => {
        const rr = R * k;
        const g = ctx.createRadialGradient(p.x + dx * R, p.y + dy * R, 0, p.x + dx * R, p.y + dy * R, rr);
        g.addColorStop(0, rgba(col, a));
        g.addColorStop(0.5, rgba(col, a * 0.35));
        g.addColorStop(1, rgba(col, 0));
        ctx.fillStyle = g;
        ctx.fillRect(p.x - R * 2, p.y - R * 2, R * 4, R * 4);
      });
    } else if (o.kind === 'snr') {
      const R = Math.max(10, pxDeg * 0.45);
      const g = ctx.createRadialGradient(p.x, p.y, R * 0.55, p.x, p.y, R);
      g.addColorStop(0, 'rgba(255,120,90,0)');
      g.addColorStop(0.7, 'rgba(255,120,90,0.35)');
      g.addColorStop(1, 'rgba(120,200,255,0)');
      ctx.fillStyle = g;
      ctx.fillRect(p.x - R * 1.4, p.y - R * 1.4, R * 2.8, R * 2.8);
    }
  });

  if (showGrid) {
    ctx.save();
    ctx.lineWidth = 0.8;
    ctx.strokeStyle = 'rgba(114,209,214,0.13)';
    ctx.fillStyle = 'rgba(114,209,214,0.55)';
    ctx.font = '10px ui-monospace, SFMono-Regular, Menlo, monospace';
    const inb = (x: number, y: number) => x > -60 && x < W + 60 && y > -60 && y < H + 60;
    const labelPts: { t: string; x: number; y: number }[] = [];
    for (let h = 0; h < 24; h++) {
      ctx.beginPath();
      let pen = false, bottom: { x: number; y: number } | null = null;
      for (let d = -88; d <= 88; d += 1) {
        const p = view.toScreen(h, d);
        if (p.ok && inb(p.x, p.y)) {
          if (!pen) { ctx.moveTo(p.x, p.y); pen = true; } else ctx.lineTo(p.x, p.y);
          if (p.y < H - 14 && p.x > 24 && p.x < W - 24 && (!bottom || p.y > bottom.y)) bottom = p;
        } else pen = false;
      }
      ctx.stroke();
      if (bottom) labelPts.push({ t: `${h}h`, x: bottom.x + 4, y: bottom.y - 3 });
    }
    for (let d = -80; d <= 80; d += 10) {
      ctx.beginPath();
      let pen = false, left: { x: number; y: number } | null = null;
      for (let r = 0; r <= 24.001; r += 0.04) {
        const p = view.toScreen(r % 24, d);
        if (p.ok && inb(p.x, p.y)) {
          if (!pen) { ctx.moveTo(p.x, p.y); pen = true; } else ctx.lineTo(p.x, p.y);
          if (p.x > 8 && p.y > 24 && p.y < H - 24 && (!left || p.x < left.x)) left = p;
        } else pen = false;
      }
      ctx.stroke();
      if (left) labelPts.push({ t: `${d > 0 ? '+' : ''}${d}°`, x: left.x + 4, y: left.y - 3 });
    }
    labelPts.forEach(l => ctx.fillText(l.t, l.x, l.y));
    ctx.restore();
  }

  const twinklers: Twinkler[] = [];
  const count = Math.round((c.density * W * H) / 780);
  const palette: [number, number, number][] = [CLASS_RGB.B, CLASS_RGB.A, CLASS_RGB.A, CLASS_RGB.F, CLASS_RGB.G, CLASS_RGB.K, CLASS_RGB.K, CLASS_RGB.M];
  for (let i = 0; i < count; i++) {
    const x = rnd() * W, y = rnd() * H;
    const b = Math.pow(rnd(), 4.2);
    const r = 0.35 + b * 1.25;
    const a = 0.22 + 0.78 * Math.pow(b, 0.7);
    const col = palette[Math.floor(rnd() * palette.length)];
    if (b > 0.5 && twinklers.length < 70) {
      twinklers.push({ x, y, r, c: col, a, ph: rnd() * 6.28, sp: 0.8 + rnd() * 2.2 });
      continue;
    }
    ctx.fillStyle = rgba(col, a);
    ctx.beginPath();
    ctx.arc(x, y, r, 0, 6.2832);
    ctx.fill();
    if (b > 0.35) {
      const g = ctx.createRadialGradient(x, y, 0, x, y, r * 5);
      g.addColorStop(0, rgba(col, 0.22 * a));
      g.addColorStop(1, rgba(col, 0));
      ctx.fillStyle = g;
      ctx.fillRect(x - r * 5, y - r * 5, r * 10, r * 10);
    }
  }

  const vg = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.72);
  vg.addColorStop(0, 'rgba(0,0,0,0)');
  vg.addColorStop(1, 'rgba(0,0,0,0.6)');
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);

  return { cv, twinklers };
}

/* --------------------------------- star painter -------------------------------- */
const coreRadius = (mag: number) => Math.max(1.5, Math.min(5.6, 1.7 + (3.2 - mag) * 1.05));

function paintStar(ctx: CanvasRenderingContext2D, x: number, y: number, o: SkyObject, t: number, boost: number, alpha: number) {
  const col = rgbOf(o);
  const tw = 1 + 0.045 * Math.sin(t * 2.1 + x * 0.05 + y * 0.03);
  const r = coreRadius(o.mag) * tw * (1 + boost * 0.18);
  const glowR = r * 7.5;
  ctx.save();
  ctx.globalAlpha = alpha;
  const g = ctx.createRadialGradient(x, y, 0, x, y, glowR);
  g.addColorStop(0, rgba(col, 0.55));
  g.addColorStop(0.18, rgba(col, 0.2));
  g.addColorStop(0.5, rgba(col, 0.05));
  g.addColorStop(1, rgba(col, 0));
  ctx.fillStyle = g;
  ctx.fillRect(x - glowR, y - glowR, glowR * 2, glowR * 2);

  if (o.mag < 2.6) {
    const L = r * (6 + (2.6 - o.mag) * 5);
    ctx.lineWidth = 0.9;
    [0, Math.PI / 2].forEach(rot => {
      const dx = Math.cos(rot) * L, dy = Math.sin(rot) * L;
      const lg = ctx.createLinearGradient(x - dx, y - dy, x + dx, y + dy);
      lg.addColorStop(0, rgba(col, 0));
      lg.addColorStop(0.5, rgba(col, 0.55));
      lg.addColorStop(1, rgba(col, 0));
      ctx.strokeStyle = lg;
      ctx.beginPath();
      ctx.moveTo(x - dx, y - dy);
      ctx.lineTo(x + dx, y + dy);
      ctx.stroke();
    });
  }

  const draw = (px: number, py: number, rr: number, cc: [number, number, number]) => {
    const cg = ctx.createRadialGradient(px, py, 0, px, py, rr * 1.6);
    cg.addColorStop(0, 'rgba(255,255,255,1)');
    cg.addColorStop(0.45, rgba(cc, 1));
    cg.addColorStop(1, rgba(cc, 0));
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.arc(px, py, rr * 1.6, 0, 6.2832);
    ctx.fill();
  };
  if (o.double) {
    draw(x - r * 1.2, y + r * 0.2, r * 0.95, [255, 196, 120]);
    draw(x + r * 1.7, y - r * 0.35, r * 0.62, [150, 185, 255]);
  } else {
    draw(x, y, r, col);
  }
  ctx.restore();
}

function paintSpecial(ctx: CanvasRenderingContext2D, x: number, y: number, o: SkyObject, t: number, alpha: number) {
  ctx.save();
  ctx.globalAlpha = alpha;
  if (o.kind === 'bh') {
    const pulse = 0.5 + 0.5 * Math.sin(t * 2.4);
    ctx.strokeStyle = `rgba(114,209,214,${0.55 + pulse * 0.35})`;
    ctx.lineWidth = 1.2;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.arc(x, y, 9 + pulse * 2, 0, 6.2832);
    ctx.stroke();
    ctx.setLineDash([]);
    const g = ctx.createRadialGradient(x, y, 0, x, y, 6);
    g.addColorStop(0, 'rgba(0,0,0,1)');
    g.addColorStop(0.6, 'rgba(0,0,0,0.9)');
    g.addColorStop(1, 'rgba(114,209,214,0.6)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, 5, 0, 6.2832);
    ctx.fill();
  } else if (o.kind === 'snr') {
    ctx.strokeStyle = 'rgba(255,140,110,0.8)';
    ctx.lineWidth = 1;
    ctx.setLineDash([2, 3]);
    ctx.beginPath();
    ctx.arc(x, y, 11, 0, 6.2832);
    ctx.stroke();
    ctx.setLineDash([]);
  } else if (o.kind === 'nebula') {
    ctx.strokeStyle = 'rgba(255,160,200,0.5)';
    ctx.lineWidth = 1;
    ctx.strokeRect(x - 14, y - 14, 28, 28);
  }
  ctx.restore();
}

/* ------------------------------------ canvas ----------------------------------- */
interface SkyCanvasProps {
  c: SkyConstellation;
  showLines: boolean;
  showGrid: boolean;
  showLabels: boolean;
  selected: string | null;
  onSelect: (name: string) => void;
  onMeta: (m: { ra: number; dec: number; fov: number }) => void;
}

const SkyCanvas: React.FC<SkyCanvasProps> = ({ c, showLines, showGrid, showLabels, selected, onSelect, onMeta }) => {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const live = useRef({ showLines, showLabels, selected, hover: null as string | null, t0: performance.now() });
  const redrawRef = useRef<() => void>(() => {});
  const onSelectRef = useRef(onSelect);
  const onMetaRef = useRef(onMeta);
  onSelectRef.current = onSelect;
  onMetaRef.current = onMeta;
  live.current.showLines = showLines;
  live.current.showLabels = showLabels;
  live.current.selected = selected;

  useEffect(() => {
    redrawRef.current();
  }, [showLines, showLabels, selected]);

  useEffect(() => {
    const wrap = wrapRef.current, canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    const ctx = canvas.getContext('2d')!;
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    live.current.t0 = performance.now();
    live.current.hover = null;
    let raf = 0, visible = true, disposed = false;
    let view: View | null = null;
    let layer: ReturnType<typeof buildStaticLayer> | null = null;
    let dpr = 1;
    let screenPts: { o: SkyObject; x: number; y: number }[] = [];
    const meteor = { on: false, x: 0, y: 0, vx: 0, vy: 0, life: 0, max: 0, next: performance.now() + 4000 };

    const build = () => {
      const W = wrap.clientWidth, H = wrap.clientHeight;
      if (W < 20 || H < 20) return;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
      view = makeView(c, W, H);
      layer = buildStaticLayer(c, view, dpr, showGrid);
      screenPts = c.objects.map(o => ({ o, ...view!.toScreen(o.ra, o.dec) }));
      const half = 2 * Math.atan(W / 2 / view.scale / 2) * R2D;
      onMetaRef.current({ ra: view.ra0, dec: view.dec0, fov: Math.round(half * 2) });
    };

    const frame = (now: number) => {
      if (disposed || !view || !layer) return;
      const L = live.current;
      const t = (now - L.t0) / 1000;
      const reveal = reduce ? 1 : Math.min(1, t / 1.3);
      const W = view.W, H = view.H;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      ctx.drawImage(layer.cv, 0, 0, W, H);

      layer.twinklers.forEach(s => {
        const k = reduce ? 1 : 0.65 + 0.35 * Math.sin(t * s.sp + s.ph);
        ctx.fillStyle = rgba(s.c, s.a * k);
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, 6.2832);
        ctx.fill();
        const g = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, s.r * 5);
        g.addColorStop(0, rgba(s.c, 0.3 * s.a * k));
        g.addColorStop(1, rgba(s.c, 0));
        ctx.fillStyle = g;
        ctx.fillRect(s.x - s.r * 5, s.y - s.r * 5, s.r * 10, s.r * 10);
      });

      if (!reduce) {
        if (!meteor.on && now > meteor.next) {
          meteor.on = true;
          meteor.x = Math.random() * W * 0.8 + W * 0.1;
          meteor.y = Math.random() * H * 0.35;
          const ang = Math.PI * (0.18 + Math.random() * 0.2);
          const sp = 520 + Math.random() * 300;
          meteor.vx = Math.cos(ang) * sp * (Math.random() < 0.5 ? 1 : -1);
          meteor.vy = Math.sin(ang) * sp;
          meteor.life = 0;
          meteor.max = 0.7;
        }
        if (meteor.on) {
          meteor.life += 1 / 60;
          meteor.x += meteor.vx / 60;
          meteor.y += meteor.vy / 60;
          const k = 1 - meteor.life / meteor.max;
          if (k <= 0) { meteor.on = false; meteor.next = now + 8000 + Math.random() * 9000; }
          else {
            const tx = meteor.x - meteor.vx * 0.09, ty = meteor.y - meteor.vy * 0.09;
            const g = ctx.createLinearGradient(tx, ty, meteor.x, meteor.y);
            g.addColorStop(0, 'rgba(255,255,255,0)');
            g.addColorStop(1, `rgba(255,255,255,${0.85 * k})`);
            ctx.strokeStyle = g;
            ctx.lineWidth = 1.4;
            ctx.beginPath();
            ctx.moveTo(tx, ty);
            ctx.lineTo(meteor.x, meteor.y);
            ctx.stroke();
          }
        }
      }

      const pts = screenPts;
      const byName = (n: string) => pts.find(p => p.o.name === n);

      if (L.showLines) {
        const n = c.lines.length;
        c.lines.forEach(([a, b], i) => {
          const A = byName(a), B = byName(b);
          if (!A || !B) return;
          const prog = Math.max(0, Math.min(1, reveal * (n + 1) - i));
          if (prog <= 0) return;
          const dx = B.x - A.x, dy = B.y - A.y;
          const len = Math.hypot(dx, dy) || 1;
          const ux = dx / len, uy = dy / len;
          const g1 = coreRadius(A.o.mag) + 7, g2 = coreRadius(B.o.mag) + 7;
          if (len < g1 + g2 + 4) return;
          const sx = A.x + ux * g1, sy = A.y + uy * g1;
          const ex = sx + ux * (len - g1 - g2) * prog, ey = sy + uy * (len - g1 - g2) * prog;
          ctx.lineCap = 'round';
          // Subtle celestial aura
          ctx.strokeStyle = 'rgba(114, 209, 214, 0.16)';
          ctx.lineWidth = 5;
          ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ex, ey); ctx.stroke();
          // Crisp laser thread
          ctx.strokeStyle = 'rgba(180, 240, 248, 0.7)';
          ctx.lineWidth = 1.2;
          ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ex, ey); ctx.stroke();

          // Leading sparkle head tracing the progressive path
          if (!reduce && prog > 0.02 && prog < 0.98) {
            const sparkGrad = ctx.createRadialGradient(ex, ey, 0, ex, ey, 6);
            sparkGrad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
            sparkGrad.addColorStop(0.4, 'rgba(114, 209, 214, 0.8)');
            sparkGrad.addColorStop(1, 'rgba(114, 209, 214, 0)');
            ctx.fillStyle = sparkGrad;
            ctx.beginPath();
            ctx.arc(ex, ey, 6, 0, Math.PI * 2);
            ctx.fill();
          }
        });
      }

      const cxm = W / 2, cym = H / 2;
      const placed: { x: number; y: number; w: number; h: number }[] = [];
      const order = [...pts].sort((p, q) => (L.selected === q.o.name ? 1 : 0) - (L.selected === p.o.name ? 1 : 0) || p.o.mag - q.o.mag);
      // sprites first, labels after (so labels sit on top and brighter stars claim space first)
      const labelQueue: (() => void)[] = [];
      order.forEach(p => {
        const isSel = L.selected === p.o.name, isHov = L.hover === p.o.name;
        const appear = Math.max(0, Math.min(1, reveal * 1.4));
        if (p.o.kind === 'star') paintStar(ctx, p.x, p.y, p.o, t, isSel || isHov ? 1 : 0, appear);
        else paintSpecial(ctx, p.x, p.y, p.o, t, appear);

        if (isSel || isHov) {
          const r = (p.o.kind === 'star' ? coreRadius(p.o.mag) : 12) + (isSel ? 12 : 9) + (isSel ? Math.sin(t * 3) * 1.5 : 0);
          ctx.save();
          ctx.strokeStyle = isSel ? 'rgba(217,243,106,0.95)' : 'rgba(255,255,255,0.45)';
          ctx.lineWidth = isSel ? 1.4 : 1;
          const k = r * 0.5;
          [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach(([sx, sy]) => {
            ctx.beginPath();
            ctx.moveTo(p.x + sx * r, p.y + sy * (r - k));
            ctx.lineTo(p.x + sx * r, p.y + sy * r);
            ctx.lineTo(p.x + sx * (r - k), p.y + sy * r);
            ctx.stroke();
          });
          ctx.restore();
        }

        if (L.showLabels || isSel || isHov) {
          const lab = p.o.name;
          ctx.font = `${isSel ? '600 ' : ''}11px ui-monospace, SFMono-Regular, Menlo, monospace`;
          const w = ctx.measureText(lab).width;
          let ox = p.x - cxm, oy = p.y - cym;
          const m = Math.hypot(ox, oy) || 1;
          ox /= m; oy /= m;
          const off = (p.o.kind === 'star' ? coreRadius(p.o.mag) : 14) + 12;
          let lx = p.x + ox * off - (ox < -0.3 ? w : ox > 0.3 ? 0 : w / 2);
          let ly = p.y + oy * off + (oy > 0 ? 8 : -2);
          lx = Math.max(6, Math.min(W - w - 6, lx));
          ly = Math.max(14, Math.min(H - 8, ly));
          // nudge away from labels (and the stars themselves) that are already placed
          const hit = (yy: number) => placed.some(r => lx < r.x + r.w + 4 && lx + w + 4 > r.x && yy - 11 < r.y + r.h && yy + 3 > r.y);
          const dirY = oy > 0.2 ? 1 : -1;
          for (let k = 0; k < 6 && hit(ly); k++) ly += dirY * 13;
          ly = Math.max(14, Math.min(H - 8, ly));
          placed.push({ x: lx, y: ly - 11, w, h: 14 });
          const fx = lx, fy = ly;
          labelQueue.push(() => {
            ctx.font = `${isSel ? '600 ' : ''}11px ui-monospace, SFMono-Regular, Menlo, monospace`;
            ctx.lineWidth = 3;
            ctx.strokeStyle = 'rgba(2,5,10,0.85)';
            ctx.strokeText(lab, fx, fy);
            ctx.fillStyle = isSel ? '#d9f36a' : isHov ? '#ffffff' : 'rgba(205,222,235,0.85)';
            ctx.fillText(lab, fx, fy);
          });
        }
      });
      labelQueue.forEach(fn => fn());

      // compass: celestial north + east
      const pole = view.toScreen(0, 89.9999);
      let nx = pole.x - W / 2, ny = pole.y - H / 2;
      const nm = Math.hypot(nx, ny) || 1;
      nx /= nm; ny /= nm;
      const ex = ny, ey = -nx;
      const ax = 44, ay = H - 44;
      ctx.save();
      ctx.strokeStyle = 'rgba(114,209,214,0.7)';
      ctx.fillStyle = 'rgba(114,209,214,0.9)';
      ctx.lineWidth = 1.2;
      ctx.font = '10px ui-monospace, monospace';
      ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(ax + nx * 24, ay + ny * 24); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(ax + ex * 15, ay + ey * 15); ctx.stroke();
      ctx.fillText('N', ax + nx * 31 - 3, ay + ny * 31 + 3);
      ctx.fillText('E', ax + ex * 22 - 3, ay + ey * 22 + 3);
      ctx.restore();

      if (!reduce && visible && !document.hidden) raf = requestAnimationFrame(frame);
      else raf = 0;
    };

    const kick = () => { if (!raf) raf = requestAnimationFrame(frame); };
    const redraw = () => {
      if (!view) return;
      if (reduce) { cancelAnimationFrame(raf); raf = 0; frame(performance.now()); } else kick();
    };
    redrawRef.current = redraw;

    build();
    redraw();

    const ro = new ResizeObserver(() => { build(); redraw(); });
    ro.observe(wrap);
    const io = new IntersectionObserver(e => { visible = e[0]?.isIntersecting ?? true; if (visible) kick(); });
    io.observe(wrap);
    const vis = () => { if (!document.hidden) kick(); };
    document.addEventListener('visibilitychange', vis);

    const pick = (ev: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      const mx = ev.clientX - rect.left, my = ev.clientY - rect.top;
      let best: string | null = null, bd = 24;
      screenPts.forEach(p => {
        const d = Math.hypot(p.x - mx, p.y - my);
        if (d < bd) { bd = d; best = p.o.name; }
      });
      return best;
    };
    const move = (ev: PointerEvent) => {
      const h = pick(ev);
      if (h !== live.current.hover) { live.current.hover = h; canvas.style.cursor = h ? 'pointer' : 'default'; redraw(); }
    };
    const leave = () => { live.current.hover = null; redraw(); };
    const click = (ev: PointerEvent) => { const h = pick(ev); if (h) onSelectRef.current(h); };
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerleave', leave);
    canvas.addEventListener('pointerdown', click);

    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      document.removeEventListener('visibilitychange', vis);
      canvas.removeEventListener('pointermove', move);
      canvas.removeEventListener('pointerleave', leave);
      canvas.removeEventListener('pointerdown', click);
    };
  }, [c, showGrid]);

  return (
    <div ref={wrapRef} className="absolute inset-0">
      <canvas ref={canvasRef} className="block w-full h-full" role="img" aria-label={`Star chart of ${c.latinName}`} />
    </div>
  );
};

/* -------------------------------- mini figure --------------------------------- */
const ConstellationThumb: React.FC<{ c: SkyConstellation; active: boolean }> = ({ c, active }) => {
  const { dots, segs } = useMemo(() => {
    const W = 64, H = 48;
    const stars = c.objects.filter(o => o.kind === 'star');
    const v = makeView({ ...c, objects: stars }, W, H);
    const pts: Record<string, { x: number; y: number; o: SkyObject }> = {};
    stars.forEach(o => { const p = v.toScreen(o.ra, o.dec); pts[o.name] = { x: p.x, y: p.y, o }; });
    return { dots: Object.values(pts), segs: c.lines.map(([a, b]) => [pts[a], pts[b]] as const).filter(([a, b]) => a && b) };
  }, [c]);
  return (
    <svg viewBox="0 0 64 48" className="w-16 h-12 shrink-0 rounded-md bg-[#02050a] border border-white/10">
      {segs.map(([a, b], i) => (
        <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={active ? '#d9f36a' : '#72d1d6'} strokeOpacity={0.55} strokeWidth="0.8" />
      ))}
      {dots.map(d => (
        <circle key={d.o.name} cx={d.x} cy={d.y} r={Math.max(0.9, 2.4 - d.o.mag * 0.4)} fill={rgba(rgbOf(d.o), 1)} />
      ))}
    </svg>
  );
};

/* ------------------------------------ view ------------------------------------- */
const fmtRA = (h: number) => { const hh = Math.floor(h), mm = Math.round((h - hh) * 60); return `${hh}h ${String(mm).padStart(2, '0')}m`; };
const fmtDec = (d: number) => `${d >= 0 ? '+' : '−'}${Math.abs(d).toFixed(0)}°`;
const lightLeft = (ly: number) => {
  const y = new Date().getFullYear() - Math.round(ly);
  return y > 0 ? `≈ AD ${y}` : `≈ ${1 - y} BCE`;
};

interface ConstellationMapProps {
  onBackToDeck: () => void;
}

export const ConstellationMap: React.FC<ConstellationMapProps> = ({ onBackToDeck }) => {
  const [sel, setSel] = useState<SkyConstellation>(CONSTELLATIONS[0]);
  const [showLines, setShowLines] = useState(true);
  const [showGrid, setShowGrid] = useState(false);
  const [showLabels, setShowLabels] = useState(true);
  const [selectedName, setSelectedName] = useState<string | null>(null);
  const [meta, setMeta] = useState({ ra: 0, dec: 0, fov: 0 });

  const selectedObj = sel.objects.find(o => o.name === selectedName) ?? null;
  const maxDist = Math.max(...sel.objects.map(o => o.distanceLy));

  const pickConstellation = (c: SkyConstellation) => {
    playTone(520, 0.08);
    setSel(c);
    setSelectedName(null);
  };
  const pickStar = (name: string) => {
    const idx = sel.objects.findIndex(o => o.name === name);
    playTone(650 + idx * 50, 0.1);
    setSelectedName(name);
  };

  const toggle = (fn: React.Dispatch<React.SetStateAction<boolean>>) => () => { playUiClick(); fn(v => !v); };
  const btn = (on: boolean) =>
    `flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[10px] font-mono font-bold transition-all cursor-pointer ${
      on ? 'border-[#d9f36a] bg-[#12362f] text-[#d9f36a]' : 'border-white/10 bg-black/40 text-gray-400 hover:border-white/30'
    }`;

  return (
    <div className="relative z-10 max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-5 md:py-8 space-y-6 md:space-y-8">
      <div className="absolute pointer-events-none -z-10 inset-x-0 top-0 h-[520px] bg-[radial-gradient(ellipse_at_50%_0%,rgba(37,105,129,0.17),transparent_68%)]" />
      <div className="flex items-center justify-between gap-4 border-b border-white/[0.08] pb-4">
        <button
          onClick={() => { playUiClick(); onBackToDeck(); }}
          className="flex items-center gap-1.5 text-xs font-mono text-[#9fb1a6] hover:text-[#d9f36a] transition-colors cursor-pointer"
        >
          <ArrowLeft size={14} />
          <span>RETURN TO FLIGHT PLAN</span>
        </button>
        <div className="flex items-center gap-2 text-xs font-mono text-[#ffc93c] font-bold">
          <Star size={14} />
          <span>STELLAR CARTOGRAPHY & CONSTELLATION MAP</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-8 rounded-2xl border border-[#d9f36a]/40 bg-[#020509] p-4 sm:p-6 space-y-4 shadow-2xl relative overflow-hidden">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
            <div>
              <span className="text-[10px] font-mono tracking-widest text-[#ef7144] uppercase font-bold">{sel.season} SKY</span>
              <h2 className="font-display font-bold text-2xl sm:text-3xl text-white mt-0.5">{sel.name}</h2>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button onClick={toggle(setShowLines)} className={btn(showLines)}><Spline size={12} />LINES</button>
              <button onClick={toggle(setShowLabels)} className={btn(showLabels)}><Tag size={12} />NAMES</button>
              <button onClick={toggle(setShowGrid)} className={btn(showGrid)}><Grid3x3 size={12} />RA/DEC GRID</button>
            </div>
          </div>

          <div className="relative h-[380px] sm:h-[540px] rounded-[1.1rem] border border-[#72d1d6]/20 overflow-hidden select-none bg-[#02050b] shadow-[inset_0_0_50px_rgba(35,104,140,0.10),0_12px_40px_rgba(0,0,0,0.35)] ring-1 ring-white/[0.025]">
            <SkyCanvas
              c={sel}
              showLines={showLines}
              showGrid={showGrid}
              showLabels={showLabels}
              selected={selectedName}
              onSelect={pickStar}
              onMeta={m => setMeta(prev => (prev.fov === m.fov && Math.abs(prev.ra - m.ra) < 0.001 ? prev : m))}
            />
            <div className="pointer-events-none absolute top-3 left-3 space-y-0.5 text-[10px] font-mono tracking-widest text-[#72d1d6]/85">
              <div>CENTER · RA {fmtRA(meta.ra)} · DEC {fmtDec(meta.dec)}</div>
              <div className="text-[#9fb1a6]">FIELD OF VIEW ≈ {meta.fov}° · STEREOGRAPHIC · J2000</div>
            </div>
            <div className="pointer-events-none absolute top-3 right-3 text-[10px] font-mono tracking-widest text-[#9fb1a6] flex items-center gap-1.5">
              <Telescope size={12} className="text-[#d9f36a]" /> NAKED-EYE VIEW
            </div>
            <div className="pointer-events-none absolute bottom-3 right-3 flex flex-col items-end gap-1 text-[9px] font-mono text-[#9fb1a6]">
              <span className="tracking-widest">STAR COLOUR = SURFACE TEMPERATURE</span>
              <div className="flex gap-2 bg-black/55 border border-white/10 rounded-md px-2 py-1">
                {CLASS_INFO.map(ci => (
                  <span key={ci.cls} className="flex items-center gap-1" title={ci.temp}>
                    <i className="w-2 h-2 rounded-full inline-block" style={{ background: rgba(CLASS_RGB[ci.cls], 1), boxShadow: `0 0 6px ${rgba(CLASS_RGB[ci.cls], 0.9)}` }} />
                    {ci.cls}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {sel.objects.map(o => (
              <button
                key={o.name}
                onClick={() => pickStar(o.name)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-mono transition-all cursor-pointer ${
                  selectedName === o.name ? 'border-[#d9f36a] bg-[#12362f] text-[#d9f36a]' : 'border-white/10 bg-[#07191e] text-[#bdc9c0] hover:border-white/30'
                }`}
              >
                {o.kind === 'star' ? (
                  <i className="w-2 h-2 rounded-full inline-block" style={{ background: rgba(rgbOf(o), 1), boxShadow: `0 0 6px ${rgba(rgbOf(o), 0.9)}` }} />
                ) : (
                  <Orbit size={11} className="text-[#ff9ec4]" />
                )}
                {o.name}
              </button>
            ))}
          </div>

          {selectedObj ? (
            <div className="p-4 rounded-xl bg-[#091f24] border border-[#d9f36a]/40 space-y-3 text-xs font-mono animate-fadeIn">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div>
                  <span className="text-[10px] text-[#ef7144] font-bold">INSPECTED {selectedObj.kind === 'star' ? 'STAR' : 'OBJECT'}:</span>
                  <div className="text-lg font-bold text-white mt-0.5 flex items-center gap-2">
                    {selectedObj.kind === 'star' && (
                      <i className="w-3 h-3 rounded-full inline-block" style={{ background: rgba(rgbOf(selectedObj), 1), boxShadow: `0 0 10px ${rgba(rgbOf(selectedObj), 1)}` }} />
                    )}
                    {selectedObj.name}
                  </div>
                  <div className="text-[#9fb1a6] mt-0.5">
                    {selectedObj.kind === 'star' ? 'Spectral class' : 'Type'}: <span className="text-[#d9f36a]">{selectedObj.spectral}</span>
                  </div>
                </div>
                <div className="sm:text-right">
                  <span className="text-[10px] text-[#9fb1a6]">DISTANCE FROM SOLAR SYSTEM</span>
                  <div className="text-lg font-bold text-[#72d1d6]">{selectedObj.distanceLy.toLocaleString()} Light-Years</div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="p-2 rounded-lg bg-[#040e12] border border-white/5">
                  <div className="text-[9px] text-[#9fb1a6]">APPARENT MAGNITUDE</div>
                  <div className="text-sm font-bold text-white">{selectedObj.mag < 30 ? selectedObj.mag.toFixed(2) : 'Invisible'}</div>
                </div>
                <div className="p-2 rounded-lg bg-[#040e12] border border-white/5">
                  <div className="text-[9px] text-[#9fb1a6]">LIGHT YOU SEE LEFT</div>
                  <div className="text-sm font-bold text-[#ffc93c]">{lightLeft(selectedObj.distanceLy)}</div>
                </div>
                <div className="p-2 rounded-lg bg-[#040e12] border border-white/5">
                  <div className="text-[9px] text-[#9fb1a6]">RIGHT ASCENSION</div>
                  <div className="text-sm font-bold text-white">{fmtRA(selectedObj.ra)}</div>
                </div>
                <div className="p-2 rounded-lg bg-[#040e12] border border-white/5">
                  <div className="text-[9px] text-[#9fb1a6]">DECLINATION</div>
                  <div className="text-sm font-bold text-white">{fmtDec(selectedObj.dec)}</div>
                </div>
              </div>

              <div>
                <div className="text-[9px] text-[#9fb1a6] mb-1">DEPTH IN SPACE (relative to farthest object in this pattern)</div>
                <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full rounded-full bg-gradient-to-r from-[#72d1d6] to-[#d9f36a]" style={{ width: `${Math.max(3, (selectedObj.distanceLy / maxDist) * 100)}%` }} />
                </div>
              </div>
              {selectedObj.note && <p className="text-[#bdc9c0] leading-relaxed font-sans">{selectedObj.note}</p>}
            </div>
          ) : (
            <div className="p-3 rounded-lg bg-[#07191e] border border-white/5 text-xs text-[#9fb1a6] font-mono text-center">
              Hover and click any star on the sky chart to reveal its spectral class, magnitude and light-year distance.
            </div>
          )}

          <div className="p-4 rounded-xl bg-[#07191e] border border-white/10 space-y-1.5 text-xs">
            <span className="font-mono text-[10px] text-[#ffc93c] font-bold uppercase">✦ MODERN ASTROPHYSICS TELEMETRY</span>
            <p className="text-[#bdc9c0] leading-relaxed">{sel.astrophysicsFact}</p>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-4">
          <div className="text-xs font-mono font-bold tracking-widest text-[#9fb1a6] uppercase px-1">CELESTIAL CATALOG (SELECT PATTERN)</div>
          <div className="space-y-2">
            {CONSTELLATIONS.map(c => {
              const isSelected = sel.id === c.id;
              return (
                <button
                  key={c.id}
                  onClick={() => pickConstellation(c)}
                  className={`w-full p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
                    isSelected ? 'border-[#d9f36a]/70 bg-[linear-gradient(110deg,rgba(24,61,53,0.95),rgba(7,25,30,0.96))] text-white shadow-[0_8px_28px_rgba(0,0,0,0.24)]' : 'border-white/[0.09] bg-[linear-gradient(110deg,rgba(7,22,31,0.92),rgba(5,14,23,0.94))] text-[#9fb1a6] hover:bg-[#0c262c] hover:border-[#72d1d6]/30'
                  }`}
                >
                  <ConstellationThumb c={c} active={isSelected} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-display font-bold text-sm text-[#eef4e6] truncate">{c.latinName}</span>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded shrink-0 ${isSelected ? 'bg-[#d9f36a] text-[#061211] font-bold' : 'text-gray-400'}`}>
                        {c.starsCount} STARS
                      </span>
                    </div>
                    <div className="text-[11px] text-[#9fb1a6] mt-0.5 truncate">{c.englishMeaning}</div>
                    <div className="text-[10px] text-[#9fb1a6]/80 mt-0.5 truncate">Brightest: {c.brightestStar}</div>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="p-4 rounded-xl bg-[#0a2327] border border-[#72d1d6]/30 space-y-2 text-xs">
            <span className="font-mono text-[10px] text-[#72d1d6] font-bold uppercase">✦ ANCIENT SKY LORE & ORIGINS</span>
            <p className="text-[#bdc9c0] leading-relaxed">{sel.mythology}</p>
          </div>

          <div className="p-4 rounded-xl bg-[#07191e] border border-white/10 space-y-1.5 text-[11px] text-[#9fb1a6] leading-relaxed">
            <span className="font-mono text-[10px] text-[#d9f36a] font-bold uppercase">✦ ABOUT THIS CHART</span>
            <p>
              Named stars sit at their real J2000 sky positions and are drawn by brightness and colour. The faint star field and the
              Milky Way glow are procedurally generated for atmosphere – they are not a catalogue.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
