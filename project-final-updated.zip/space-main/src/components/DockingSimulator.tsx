import React, { useState, useEffect, useRef } from 'react';
import {
  Compass,
  Crosshair,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Maximize2,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Zap,
} from 'lucide-react';
import {
  playRcsThrusterSound,
  playDockingLatchSound,
  playErrorAlert,
  playSuccessChime,
  playQuindarTone,
} from '../utils/audio';
import { fireMissionConfetti } from '../utils/confetti';

interface DockingSimulatorProps {
  onSuccess?: (score: number) => void;
  onExit?: () => void;
}

export const DockingSimulator: React.FC<DockingSimulatorProps> = ({ onSuccess, onExit }) => {
  // State variables for 3D alignment
  const [distance, setDistance] = useState(25.0); // meters
  const [approachSpeed, setApproachSpeed] = useState(0.28); // m/s
  const [posX, setPosX] = useState(8.5); // meters offset X
  const [posY, setPosY] = useState(-6.0); // meters offset Y
  const [roll, setRoll] = useState(7.2); // degrees
  const [pitch, setPitch] = useState(-3.5); // degrees
  const [yaw, setYaw] = useState(4.0); // degrees
  const [fuel, setFuel] = useState(100); // %

  const [dockingState, setDockingState] = useState<'approaching' | 'captured' | 'aborted'>(
    'approaching'
  );
  const [statusMessage, setStatusMessage] = useState('RANGE 25.0M · ALIGN RETICLE AND CONTROL VELOCITY');

  // Simulation loop
  useEffect(() => {
    if (dockingState !== 'approaching') return;

    const interval = setInterval(() => {
      setDistance(prevDist => {
        const nextDist = prevDist - approachSpeed * 0.1;

        // Check if captured at contact
        if (nextDist <= 0.2) {
          // Check tolerances:
          // X/Y within 1.5m, pitch/yaw within 4 deg, approach speed < 0.25 m/s
          const aligned =
            Math.abs(posX) < 1.8 &&
            Math.abs(posY) < 1.8 &&
            Math.abs(pitch) < 5.0 &&
            Math.abs(yaw) < 5.0 &&
            approachSpeed <= 0.35 &&
            approachSpeed >= 0.02;

          if (aligned) {
            setDockingState('captured');
            playDockingLatchSound();
            playSuccessChime();
            fireMissionConfetti();
            setStatusMessage('CONTACT AND CAPTURE CONFIRMED · HARD DOCKING LATCHES ENGAGED');
            if (onSuccess) {
              const score = Math.max(10, Math.round(50 - Math.abs(posX) * 5 - Math.abs(posY) * 5));
              onSuccess(score);
            }
            return 0.0;
          } else {
            setDockingState('aborted');
            playErrorAlert();
            setStatusMessage('DOCKING ABORT · OFF-AXIS IMPACT EXCEEDED LATCH TOLERANCE');
            return 0.0;
          }
        }
        return nextDist;
      });

      // Natural minor drift in zero gravity
      setPosX(x => x + (Math.random() - 0.5) * 0.04);
      setPosY(y => y + (Math.random() - 0.5) * 0.04);
    }, 100);

    return () => clearInterval(interval);
  }, [dockingState, approachSpeed, posX, posY, pitch, yaw, onSuccess]);

  // Thrust controls
  const pulseThruster = (axis: 'X' | 'Y' | 'Z' | 'PITCH' | 'YAW', delta: number) => {
    if (dockingState !== 'approaching' || fuel <= 0) return;
    playRcsThrusterSound();
    setFuel(f => Math.max(0, f - 0.6));

    if (axis === 'X') setPosX(x => x + delta);
    if (axis === 'Y') setPosY(y => y + delta);
    if (axis === 'Z') setApproachSpeed(s => Math.max(0.01, Math.min(0.8, s + delta)));
    if (axis === 'PITCH') setPitch(p => p + delta);
    if (axis === 'YAW') setYaw(yw => yw + delta);

    if (axis === 'Z' && delta < 0) {
      setStatusMessage('RETRO-FIRE · CLOSURE RATE REDUCED');
    } else if (axis === 'Z' && delta > 0) {
      setStatusMessage('FORWARD TRANSLATION PULSE ENGAGED');
    }
  };

  const handleReset = () => {
    playQuindarTone('intro');
    setDistance(25.0);
    setApproachSpeed(0.28);
    setPosX(8.5);
    setPosY(-6.0);
    setRoll(7.2);
    setPitch(-3.5);
    setYaw(4.0);
    setFuel(100);
    setDockingState('approaching');
    setStatusMessage('SIMULATOR RECYCLED · APPROACH CORRIDOR OPEN');
  };

  // Tolerances
  const isAlignedX = Math.abs(posX) < 1.5;
  const isAlignedY = Math.abs(posY) < 1.5;
  const isSpeedSafe = approachSpeed < 0.25;

  return (
    <div className="relative rounded-2xl border border-[#72d1d6]/50 bg-[#040c0e] p-4 sm:p-6 shadow-2xl text-[#eef4e6] space-y-4">
      {/* Header HUD */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1b3834] pb-3 text-xs font-mono">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-[#72d1d6] animate-pulse" />
          <span className="font-bold text-[#72d1d6] tracking-wider">
            OPTICAL DOCKING GUIDANCE (IDSS-IDA2)
          </span>
        </div>
        <div className="flex items-center gap-4 text-[11px]">
          <span>
            RCS PROPELLANT: <strong className="text-[#d9f36a]">{fuel.toFixed(0)}%</strong>
          </span>
          <span className="text-gray-400">|</span>
          <span>
            TARGET: <strong className="text-white">ISS HARMONY NODE</strong>
          </span>
        </div>
      </div>

      {/* Main Optical Screen */}
      <div className="relative h-72 sm:h-96 rounded-xl bg-gradient-to-b from-[#020508] to-[#041217] border border-[#1b3834] overflow-hidden flex items-center justify-center select-none">
        {/* Background stars */}
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff18_1px,transparent_1px)] [background-size:24px_24px]" />

        {/* Earth horizon curve below in orbit */}
        <div className="absolute -bottom-36 -left-20 -right-20 h-64 rounded-[100%] bg-gradient-to-t from-[#023e8a]/40 via-[#0077b6]/20 to-transparent blur-[4px] pointer-events-none" />

        {/* ISS Target Docking Port (scales up as distance closes) */}
        <div
          className="relative transition-all duration-100 flex items-center justify-center"
          style={{
            transform: `translate(${(-posX * 12).toFixed(1)}px, ${(posY * 12).toFixed(
              1
            )}px) scale(${Math.max(0.6, (30 - distance) / 6)}) rotate(${roll}deg)`,
          }}
        >
          {/* Station Solar Panels in background */}
          <div className="absolute -left-48 w-36 h-12 bg-[#0d2847] border border-[#72d1d6]/30 grid grid-cols-6 opacity-60">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="border-r border-cyan-400/20" />
            ))}
          </div>
          <div className="absolute -right-48 w-36 h-12 bg-[#0d2847] border border-[#72d1d6]/30 grid grid-cols-6 opacity-60">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="border-r border-cyan-400/20" />
            ))}
          </div>

          {/* Docking Ring Petals */}
          <div className="relative w-32 h-32 rounded-full border-4 border-dashed border-[#72d1d6]/60 grid place-items-center shadow-[0_0_30px_rgba(114,209,214,0.3)]">
            <div className="w-24 h-24 rounded-full border-2 border-white/40 grid place-items-center">
              <div className="w-16 h-16 rounded-full bg-black/80 border border-[#72d1d6] grid place-items-center">
                <span className="text-[9px] font-mono font-bold text-[#72d1d6]">IDA-02</span>
              </div>
            </div>
            {/* Guide triangles */}
            <div className="absolute top-1 w-2 h-2 bg-[#d9f36a] rotate-45" />
            <div className="absolute bottom-1 w-2 h-2 bg-[#d9f36a] rotate-45" />
            <div className="absolute left-1 w-2 h-2 bg-[#d9f36a] rotate-45" />
            <div className="absolute right-1 w-2 h-2 bg-[#d9f36a] rotate-45" />
          </div>
        </div>

        {/* Flight HUD Overlay Crosshairs (SpaceX style) */}
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
          {/* Main Reticle */}
          <div className="w-28 h-28 border border-white/20 rounded-full flex items-center justify-center">
            <div className="w-12 h-12 border border-[#d9f36a]/60 rounded-full relative">
              <div className="absolute top-1/2 -left-4 w-3 h-[1px] bg-[#d9f36a]" />
              <div className="absolute top-1/2 -right-4 w-3 h-[1px] bg-[#d9f36a]" />
              <div className="absolute -top-4 left-1/2 w-[1px] h-3 bg-[#d9f36a]" />
              <div className="absolute -bottom-4 left-1/2 w-[1px] h-3 bg-[#d9f36a]" />
            </div>
          </div>

          {/* Left Telemetry HUD */}
          <div className="absolute top-4 left-4 bg-black/60 border border-white/10 rounded-lg p-2.5 font-mono text-[11px] space-y-1">
            <div className="text-[#9fb1a6]">RANGE TO PORT</div>
            <div className="text-xl font-bold text-[#d9f36a]">{distance.toFixed(2)} m</div>
            <div className="text-[#9fb1a6] pt-1">APPROACH RATE</div>
            <div
              className={`text-base font-bold ${
                isSpeedSafe ? 'text-[#66a75e]' : 'text-[#ef7144] animate-pulse'
              }`}
            >
              {approachSpeed.toFixed(2)} m/s
            </div>
          </div>

          {/* Right Attitude Alignment HUD */}
          <div className="absolute top-4 right-4 bg-black/60 border border-white/10 rounded-lg p-2.5 font-mono text-[11px] space-y-1 text-right">
            <div className="text-[#9fb1a6]">OFF-AXIS X / Y</div>
            <div className={`font-bold ${isAlignedX && isAlignedY ? 'text-[#66a75e]' : 'text-[#ef7144]'}`}>
              X: {posX.toFixed(1)}m | Y: {posY.toFixed(1)}m
            </div>
            <div className="text-[#9fb1a6] pt-1">ATTITUDE ANGLES</div>
            <div className="text-white">
              P: {pitch.toFixed(1)}° | Y: {yaw.toFixed(1)}°
            </div>
          </div>

          {/* Center Contact Notice */}
          {dockingState === 'captured' && (
            <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-6 text-center space-y-3 animate-fadeIn">
              <div className="w-16 h-16 rounded-full bg-[#66a75e]/20 border-2 border-[#66a75e] text-3xl grid place-items-center text-[#66a75e]">
                ✓
              </div>
              <h3 className="font-display font-bold text-2xl sm:text-3xl text-white">
                Hard Capture Confirmed!
              </h3>
              <p className="text-xs sm:text-sm text-[#bdc9c0] max-w-md">
                12 mechanical docking latches driven home. Hatch equalization valve unlocked.
                Welcome aboard the International Space Station!
              </p>
              <button
                onClick={handleReset}
                className="px-6 py-2.5 rounded-lg bg-[#d9f36a] text-[#061211] font-bold text-xs uppercase tracking-wider cursor-pointer"
              >
                Run Another Approach
              </button>
            </div>
          )}

          {dockingState === 'aborted' && (
            <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-6 text-center space-y-3 animate-fadeIn">
              <div className="w-16 h-16 rounded-full bg-red-900/40 border-2 border-red-500 text-3xl grid place-items-center text-red-400">
                ✕
              </div>
              <h3 className="font-display font-bold text-2xl text-red-300">Docking Aborted</h3>
              <p className="text-xs sm:text-sm text-[#bdc9c0] max-w-md">
                Alignment was off-center or approach velocity was excessive. Safety systems pushed
                capsule to retreat corridor.
              </p>
              <button
                onClick={handleReset}
                className="px-6 py-2.5 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-xs uppercase tracking-wider cursor-pointer"
              >
                Reset & Try Again
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Telemetry Status Bar */}
      <div className="p-2.5 rounded-lg bg-[#071a1d] border border-[#1b3834] flex items-center justify-between text-xs font-mono">
        <span className="text-[#9fb1a6]">FLIGHT DIRECTOR:</span>
        <span className="text-[#d9f36a] font-bold truncate pl-2">{statusMessage}</span>
      </div>

      {/* Manual RCS Thruster Control Panel */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
        {/* Panel 1: Translation X / Y */}
        <div className="p-3.5 rounded-xl bg-[#07191e] border border-white/10 space-y-2">
          <div className="text-[10px] font-mono text-[#9fb1a6] font-bold text-center">
            TRANSLATION RCS (X / Y)
          </div>
          <div className="grid grid-cols-3 gap-1.5 max-w-[160px] mx-auto pt-1">
            <div />
            <button
              onClick={() => pulseThruster('Y', -0.5)}
              className="p-2.5 rounded bg-[#102f34] hover:bg-[#18464d] text-cyan-300 grid place-items-center cursor-pointer border border-cyan-800"
              title="Thrust Up (+Y)"
            >
              <ArrowUp size={16} />
            </button>
            <div />
            <button
              onClick={() => pulseThruster('X', -0.5)}
              className="p-2.5 rounded bg-[#102f34] hover:bg-[#18464d] text-cyan-300 grid place-items-center cursor-pointer border border-cyan-800"
              title="Thrust Left (-X)"
            >
              <ArrowLeft size={16} />
            </button>
            <div className="grid place-items-center text-[9px] font-mono text-[#9fb1a6]">RCS</div>
            <button
              onClick={() => pulseThruster('X', 0.5)}
              className="p-2.5 rounded bg-[#102f34] hover:bg-[#18464d] text-cyan-300 grid place-items-center cursor-pointer border border-cyan-800"
              title="Thrust Right (+X)"
            >
              <ArrowRight size={16} />
            </button>
            <div />
            <button
              onClick={() => pulseThruster('Y', 0.5)}
              className="p-2.5 rounded bg-[#102f34] hover:bg-[#18464d] text-cyan-300 grid place-items-center cursor-pointer border border-cyan-800"
              title="Thrust Down (-Y)"
            >
              <ArrowDown size={16} />
            </button>
            <div />
          </div>
        </div>

        {/* Panel 2: Range & Forward / Retro Burn */}
        <div className="p-3.5 rounded-xl bg-[#07191e] border border-white/10 flex flex-col justify-between space-y-2">
          <div className="text-[10px] font-mono text-[#9fb1a6] font-bold text-center">
            CLOSURE RATE (Z-AXIS)
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => pulseThruster('Z', -0.08)}
              className="flex-1 py-3 px-2 rounded-lg bg-orange-950/40 hover:bg-orange-900/60 border border-orange-500/40 text-[#ef7144] font-mono font-bold text-xs flex flex-col items-center gap-1 cursor-pointer"
            >
              <span>RETRO BRAKE</span>
              <span className="text-[9px] text-gray-400">-0.08 m/s</span>
            </button>

            <button
              onClick={() => pulseThruster('Z', 0.08)}
              className="flex-1 py-3 px-2 rounded-lg bg-[#103b35] hover:bg-[#18544c] border border-[#d9f36a]/40 text-[#d9f36a] font-mono font-bold text-xs flex flex-col items-center gap-1 cursor-pointer"
            >
              <span>FORWARD BURN</span>
              <span className="text-[9px] text-gray-300">+0.08 m/s</span>
            </button>
          </div>
          <div className="text-[10px] font-mono text-center text-[#9fb1a6]">
            Keep rate below 0.20 m/s when range &lt; 5m
          </div>
        </div>

        {/* Panel 3: Attitude Pitch & Yaw */}
        <div className="p-3.5 rounded-xl bg-[#07191e] border border-white/10 space-y-2">
          <div className="text-[10px] font-mono text-[#9fb1a6] font-bold text-center">
            ATTITUDE CORRECTION
          </div>
          <div className="grid grid-cols-2 gap-2 pt-1 text-xs font-mono">
            <button
              onClick={() => pulseThruster('PITCH', 1.0)}
              className="p-2 rounded bg-[#0f282c] hover:bg-[#163c42] border border-white/10 text-center cursor-pointer"
            >
              PITCH UP +1°
            </button>
            <button
              onClick={() => pulseThruster('PITCH', -1.0)}
              className="p-2 rounded bg-[#0f282c] hover:bg-[#163c42] border border-white/10 text-center cursor-pointer"
            >
              PITCH DN -1°
            </button>
            <button
              onClick={() => pulseThruster('YAW', -1.0)}
              className="p-2 rounded bg-[#0f282c] hover:bg-[#163c42] border border-white/10 text-center cursor-pointer"
            >
              YAW LEFT -1°
            </button>
            <button
              onClick={() => pulseThruster('YAW', 1.0)}
              className="p-2 rounded bg-[#0f282c] hover:bg-[#163c42] border border-white/10 text-center cursor-pointer"
            >
              YAW RIGHT +1°
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
