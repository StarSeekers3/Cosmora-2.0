import React, { useState, useEffect, useRef } from 'react';
import { Flame, RotateCcw, AlertTriangle, CheckCircle2, Compass, Shield } from 'lucide-react';
import {
  playTone,
  playErrorAlert,
  playSuccessChime,
  playQuindarTone,
  playRocketLaunchSound,
} from '../utils/audio';
import { fireMissionConfetti } from '../utils/confetti';

interface LunarLanderProps {
  onSuccess?: (score: number) => void;
}

export const LunarLander: React.FC<LunarLanderProps> = ({ onSuccess }) => {
  // Lander Physics State
  const [alt, setAlt] = useState(250); // altitude in meters
  const [vy, setVy] = useState(-8.5); // vertical velocity (m/s, negative is downward)
  const [posX, setPosX] = useState(50); // horizontal position % across terrain
  const [vx, setVx] = useState(1.2); // horizontal velocity
  const [angle, setAngle] = useState(-4); // tilt degrees
  const [fuel, setFuel] = useState(100); // %
  const [throttle, setThrottle] = useState(0); // 0 to 100%
  const [landState, setLandState] = useState<'flying' | 'landed' | 'crashed'>('flying');
  const [message, setMessage] = useState('DESCENT IN PROGRESS · THROTTLE ENGINE TO CONTROL SINK RATE');

  const throttleRef = useRef(throttle);
  throttleRef.current = throttle;

  // Physics animation loop
  useEffect(() => {
    if (landState !== 'flying') return;

    const gravity = 1.62; // m/s^2 on Moon
    const dt = 0.08; // time step

    const interval = setInterval(() => {
      setFuel(prevFuel => {
        const curThrottle = throttleRef.current;
        const fuelConsumption = (curThrottle / 100) * 0.7;
        const newFuel = Math.max(0, prevFuel - fuelConsumption);
        return newFuel;
      });

      setAlt(prevAlt => {
        const curThrottle = fuel > 0 ? throttleRef.current : 0;
        // Max engine acceleration at 100% is 4.0 m/s^2, so net upward accel = (throttle/100)*4.0 - gravity
        const rad = (angle * Math.PI) / 180;
        const thrustAcc = (curThrottle / 100) * 3.8;
        const ay = thrustAcc * Math.cos(rad) - gravity;
        const ax = -thrustAcc * Math.sin(rad);

        setVy(curVy => {
          const nextVy = curVy + ay * dt;
          return nextVy;
        });

        setVx(curVx => curVx + ax * dt);

        setPosX(curX => {
          const nextX = curX + (vx * dt * 0.5);
          return Math.max(5, Math.min(95, nextX));
        });

        const nextAlt = prevAlt + vy * dt;

        // Check ground contact
        if (nextAlt <= 0) {
          const finalVy = Math.abs(vy);
          const finalVx = Math.abs(vx);
          const finalAngle = Math.abs(angle);

          // Pad is centered around posX 40% to 60%
          const onPad = posX >= 35 && posX <= 65;

          if (finalVy <= 2.8 && finalVx <= 1.5 && finalAngle <= 8 && onPad) {
            setLandState('landed');
            playSuccessChime();
            fireMissionConfetti();
            setMessage('TOUCHDOWN CONFIRMED! THE EAGLE HAS LANDED ON SHACKLETON CRATER.');
            if (onSuccess) {
              const score = Math.max(15, Math.round(50 - finalVy * 8 + fuel * 0.2));
              onSuccess(score);
            }
          } else {
            setLandState('crashed');
            playErrorAlert();
            if (!onPad) {
              setMessage('CRASH IN BOULDER FIELD · MISSED DESIGNATED LANDING SITE.');
            } else if (finalVy > 2.8) {
              setMessage(`HARD IMPACT (${finalVy.toFixed(1)} m/s) · GEAR STRUTS COLLAPSED.`);
            } else {
              setMessage('EXCESSIVE TILT · LANDER TOPPLED ON TOUCHDOWN.');
            }
          }
          return 0;
        }

        return nextAlt;
      });
    }, 80);

    return () => clearInterval(interval);
  }, [landState, vy, vx, angle, fuel, posX, onSuccess]);

  const handleTilt = (delta: number) => {
    if (landState !== 'flying') return;
    playTone(600, 0.05);
    setAngle(a => Math.max(-25, Math.min(25, a + delta)));
  };

  const setThrottleLevel = (val: number) => {
    if (landState !== 'flying') return;
    setThrottle(val);
    if (val > 40) {
      playTone(180 + val * 2, 0.1, 'sawtooth');
    }
  };

  const handleReset = () => {
    playQuindarTone('intro');
    setAlt(250);
    setVy(-8.5);
    setPosX(50);
    setVx(1.2);
    setAngle(-4);
    setFuel(100);
    setThrottle(0);
    setLandState('flying');
    setMessage('DESCENT IN PROGRESS · THROTTLE ENGINE TO CONTROL SINK RATE');
  };

  const isSinkSafe = Math.abs(vy) <= 2.8;

  return (
    <div className="relative rounded-2xl border border-[#ffc93c]/50 bg-[#071317] p-4 sm:p-6 shadow-2xl text-[#eef4e6] space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1b3834] pb-3 text-xs font-mono">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-[#ffc93c] animate-pulse" />
          <span className="font-bold text-[#ffc93c] tracking-wider">
            ARTEMIS LUNAR LANDING RADAR (DESCENT STAGE)
          </span>
        </div>
        <div className="flex items-center gap-4 text-[11px]">
          <span>
            PROPELLANT: <strong className="text-[#d9f36a]">{fuel.toFixed(0)}%</strong>
          </span>
          <span className="text-gray-400">|</span>
          <span>
            GRAVITY: <strong className="text-white">1.62 m/s²</strong>
          </span>
        </div>
      </div>

      {/* Main Radar Screen */}
      <div className="relative h-72 sm:h-96 rounded-xl bg-gradient-to-b from-[#020305] via-[#050b0f] to-[#0c1920] border border-[#1b3834] overflow-hidden select-none">
        {/* Dark Lunar Sky & Earth in sky */}
        <div className="absolute top-4 right-8 w-10 h-10 rounded-full bg-gradient-to-br from-[#0077b6] via-[#2a9d8f] to-[#023e8a] opacity-80 shadow-[0_0_15px_rgba(42,157,143,0.5)]">
          <div className="w-4 h-4 bg-white/20 rounded-full blur-[1px] m-1" />
        </div>

        {/* Lunar Surface Ground */}
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-[#1f2937] border-t-2 border-[#4b5563]">
          {/* Craters / Boulders */}
          <div className="absolute top-2 left-6 w-16 h-4 rounded-full bg-black/60 border border-white/10" />
          <div className="absolute top-4 right-12 w-24 h-6 rounded-full bg-black/60 border border-white/10" />

          {/* Designated Safe Landing Pad (40% to 60%) */}
          <div className="absolute top-0 left-[35%] right-[35%] h-3 bg-[#ffc93c]/30 border-t-2 border-[#ffc93c] flex items-center justify-between px-2">
            <span className="text-[9px] font-mono text-[#ffc93c] font-bold">▲ PAD-A</span>
            <span className="text-[9px] font-mono text-[#ffc93c] font-bold">PAD-A ▲</span>
          </div>
        </div>

        {/* Low-altitude surface regolith dust spray (thruster plume hitting lunar regolith) */}
        {alt < 50 && throttle > 0 && fuel > 0 && (
          <div
            className="absolute bottom-16 pointer-events-none transition-all duration-75 flex items-center justify-center -translate-x-1/2 z-10"
            style={{
              left: `${posX}%`,
              width: `${Math.min(140, 40 + (50 - alt) * 2)}px`,
              opacity: Math.min(0.85, (50 - alt) / 35),
            }}
          >
            <div className="w-full h-8 bg-gradient-to-t from-[#d4c8aa]/50 via-[#9e9278]/25 to-transparent blur-md rounded-full animate-pulse" />
          </div>
        )}

        {/* Touchdown settling dust puff */}
        {landState === 'landed' && (
          <div
            className="absolute bottom-16 pointer-events-none flex items-center justify-center -translate-x-1/2 z-10 dust-particle-puff"
            style={{ left: `${posX}%` }}
          >
            <div className="w-36 h-10 bg-gradient-to-t from-[#e0d6bd]/60 to-transparent blur-lg rounded-full" />
          </div>
        )}

        {/* Lunar Module Lander Vessel */}
        <div
          className="absolute z-20 transition-transform duration-75 flex flex-col items-center"
          style={{
            left: `${posX}%`,
            bottom: `${Math.min(84, 16 + (alt / 250) * 65)}%`,
            transform: `translateX(-50%) rotate(${angle}deg)`,
          }}
        >
          {/* Crew Ascent Cabin */}
          <div className="w-8 h-7 bg-gradient-to-b from-gray-200 to-gray-400 rounded-t-md border border-gray-700 relative flex items-center justify-center shadow-md">
            <div className="w-2 h-2 bg-[#ffc93c] rounded-full shadow-[0_0_6px_#ffc93c]" />
          </div>

          {/* Descent Base Stage (Gold foil) */}
          <div className="w-11 h-6 bg-gradient-to-r from-[#e5a93c] via-[#ffd166] to-[#b37a1f] border border-[#a16b12] relative flex justify-center shadow-lg">
            {/* Landing Struts */}
            <div className="absolute -bottom-2 -left-2 w-3 h-4 border-l-2 border-b-2 border-gray-400 rotate-[-25deg]" />
            <div className="absolute -bottom-2 -right-2 w-3 h-4 border-r-2 border-b-2 border-gray-400 rotate-[25deg]" />

            {/* Engine Rocket Flame */}
            {throttle > 0 && fuel > 0 && (
              <div
                className="absolute top-full w-4 bg-gradient-to-b from-[#ffffff] via-[#ffaa00] to-transparent rounded-b-full blur-[1px] animate-pulse"
                style={{ height: `${(throttle / 100) * 36}px` }}
              />
            )}
          </div>
        </div>

        {/* HUD Telemetry Gauges */}
        <div className="absolute top-4 left-4 bg-black/70 border border-white/10 rounded-lg p-2.5 font-mono text-[11px] space-y-1">
          <div className="text-[#9fb1a6]">RADAR ALTITUDE</div>
          <div className="text-xl font-bold text-[#ffc93c]">{alt.toFixed(1)} m</div>
          <div className="text-[#9fb1a6] pt-1">SINK RATE (VERT)</div>
          <div className={`text-base font-bold ${isSinkSafe ? 'text-[#66a75e]' : 'text-red-400 animate-pulse'}`}>
            {vy.toFixed(1)} m/s
          </div>
          <div className="text-[#9fb1a6] pt-1">DRIFT (HORIZ)</div>
          <div className="text-white">{vx.toFixed(1)} m/s</div>
        </div>

        {/* Landed / Crashed Screen */}
        {landState === 'landed' && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-6 text-center space-y-3 animate-fadeIn">
            <div className="w-16 h-16 rounded-full bg-[#66a75e]/20 border-2 border-[#66a75e] text-3xl grid place-items-center text-[#66a75e]">
              ✓
            </div>
            <h3 className="font-display font-bold text-2xl text-white">Touchdown Successful!</h3>
            <p className="text-xs text-[#bdc9c0] max-w-sm">
              Engines shut down. Welcome to Shackleton Crater at the Moon&apos;s South Pole!
            </p>
            <button
              onClick={handleReset}
              className="px-6 py-2 rounded-lg bg-[#d9f36a] text-[#061211] font-bold text-xs uppercase cursor-pointer"
            >
              Fly Another Descent
            </button>
          </div>
        )}

        {landState === 'crashed' && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-6 text-center space-y-3 animate-fadeIn">
            <div className="w-16 h-16 rounded-full bg-red-900/40 border-2 border-red-500 text-3xl grid place-items-center text-red-400">
              ✕
            </div>
            <h3 className="font-display font-bold text-2xl text-red-400">Hard Landing</h3>
            <p className="text-xs text-[#bdc9c0] max-w-sm">{message}</p>
            <button
              onClick={handleReset}
              className="px-6 py-2 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-xs uppercase cursor-pointer"
            >
              Reset Simulation
            </button>
          </div>
        )}
      </div>

      {/* Flight Director Message */}
      <div className="p-2.5 rounded-lg bg-[#071a1d] border border-[#1b3834] text-xs font-mono flex items-center justify-between">
        <span className="text-[#9fb1a6]">FLIGHT DIRECTOR:</span>
        <span className="text-[#d9f36a] font-bold truncate pl-2">{message}</span>
      </div>

      {/* Controls */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
        {/* Throttle slider */}
        <div className="sm:col-span-7 p-4 rounded-xl bg-[#07191e] border border-white/10 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-[#9fb1a6]">MAIN DESCENT THROTTLE</span>
            <span className="text-[#ffc93c] font-bold font-mono text-base">{throttle}%</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setThrottleLevel(0)}
              className="px-3 py-1.5 rounded bg-gray-800 hover:bg-gray-700 text-xs font-mono cursor-pointer"
            >
              IDLE (0%)
            </button>
            <button
              onClick={() => setThrottleLevel(50)}
              className="px-3 py-1.5 rounded bg-[#102f34] hover:bg-[#18464d] text-cyan-300 text-xs font-mono cursor-pointer"
            >
              HOVER (~50%)
            </button>
            <button
              onClick={() => setThrottleLevel(100)}
              className="px-3 py-1.5 rounded bg-[#3b2010] hover:bg-[#573017] text-orange-300 text-xs font-mono cursor-pointer"
            >
              FULL (100%)
            </button>
          </div>

          <input
            type="range"
            min="0"
            max="100"
            step="5"
            value={throttle}
            onChange={e => setThrottleLevel(Number(e.target.value))}
            className="w-full accent-[#ffc93c] cursor-pointer"
          />
        </div>

        {/* Tilt attitude */}
        <div className="sm:col-span-5 p-4 rounded-xl bg-[#07191e] border border-white/10 space-y-2">
          <div className="text-xs font-mono text-[#9fb1a6] text-center">ATTITUDE TILT CONTROL</div>
          <div className="flex items-center justify-center gap-3 pt-1">
            <button
              onClick={() => handleTilt(-3)}
              className="flex-1 py-2 rounded bg-[#102f34] hover:bg-[#18464d] text-cyan-300 font-mono text-xs font-bold cursor-pointer"
            >
              ◄ TILT LEFT
            </button>
            <span className="text-xs font-mono font-bold w-12 text-center text-white">
              {angle}°
            </span>
            <button
              onClick={() => handleTilt(3)}
              className="flex-1 py-2 rounded bg-[#102f34] hover:bg-[#18464d] text-cyan-300 font-mono text-xs font-bold cursor-pointer"
            >
              TILT RIGHT ►
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
