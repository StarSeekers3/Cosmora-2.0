import React, { lazy, Suspense, useState, useEffect } from 'react';
import { Header, AppView } from './components/Header';
import { CrewIntake } from './components/CrewIntake';
import { FlightDeck } from './components/FlightDeck';
import { AstronautProfile, Mission } from './types';
import { MISSIONS } from './data/missionsData';
import {
  loadProfile,
  saveProfile,
  resetProfileData,
  completeMissionInStorage,
  getStoredTheme,
  setStoredTheme,
  getStoredReduceMotion,
  setStoredReduceMotion,
  getStoredDayNightCycle,
  setStoredDayNightCycle,
} from './utils/storage';
import { setSoundMuted } from './utils/audio';

const BlackHoleBackground3D = lazy(() => import('./components/BlackHoleBackground3D').then(m => ({ default: m.BlackHoleBackground3D })));
const SolarSystemBackground3D = lazy(() => import('./components/SolarSystemBackground3D').then(m => ({ default: m.SolarSystemBackground3D })));
const MissionControlUI = lazy(() => import('./components/MissionControlUI').then(m => ({ default: m.MissionControlUI })));
const ObservatoryUI = lazy(() => import('./components/ObservatoryUI').then(m => ({ default: m.ObservatoryUI })));
const MissionRunner = lazy(() => import('./components/MissionRunner').then(m => ({ default: m.MissionRunner })));
const Certificate = lazy(() => import('./components/Certificate').then(m => ({ default: m.Certificate })));
const SolarOrrery = lazy(() => import('./components/SolarOrrery').then(m => ({ default: m.SolarOrrery })));
const ConstellationMap = lazy(() => import('./components/ConstellationMap').then(m => ({ default: m.ConstellationMap })));
const NasaLiveTelemetry = lazy(() => import('./components/NasaLiveTelemetry').then(m => ({ default: m.NasaLiveTelemetry })));
const CadetDossier = lazy(() => import('./components/CadetDossier').then(m => ({ default: m.CadetDossier })));
const AstronautTrainer = lazy(() => import('./components/AstronautTrainer').then(m => ({ default: m.AstronautTrainer })));
import { CapComRadioBar } from './components/CapComRadioBar';

export default function App() {
  const [profile, setProfile] = useState<AstronautProfile | null>(() => loadProfile());
  const [currentView, setCurrentView] = useState<AppView>(() =>
    loadProfile() ? 'flightdeck' : 'intake'
  );
  const [activeMission, setActiveMission] = useState<Mission | null>(null);
  const [theme, setTheme] = useState<'dark' | 'light'>(() => getStoredTheme());
  const [soundMuted, setSoundMutedState] = useState<boolean>(false);
  const [bgMode, setBgMode] = useState<'solar' | 'blackhole'>('solar');
  const [reduceMotion, setReduceMotion] = useState(() => getStoredReduceMotion());
  const [dayNightCycle, setDayNightCycle] = useState(() => getStoredDayNightCycle());

  // Initialize theme on load
  useEffect(() => {
    setStoredTheme(theme);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
    setStoredReduceMotion(reduceMotion);
  }, [reduceMotion]);

  useEffect(() => {
    setStoredDayNightCycle(dayNightCycle);
  }, [dayNightCycle]);

  // Handle theme toggle
  const handleToggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
    setStoredTheme(nextTheme);
    document.documentElement.setAttribute('data-theme', nextTheme);
  };

  // Handle sound toggle
  const handleToggleSound = () => {
    const nextMuted = !soundMuted;
    setSoundMutedState(nextMuted);
    setSoundMuted(nextMuted);
  };

  // Handle save profile from crew intake
  const handleSaveProfile = (newProfile: AstronautProfile) => {
    setProfile(newProfile);
    saveProfile(newProfile);
  };

  // Handle mission completion
  const handleMissionComplete = (missionId: number, pointsEarned: number) => {
    const updated = completeMissionInStorage(missionId, pointsEarned);
    setProfile(updated);
  };

  // Handle starting a mission
  const handleSelectMission = (mission: Mission) => {
    setActiveMission(mission);
    setCurrentView('mission');
  };

  // Proceed to next mission
  const handleNextMission = (nextId: number) => {
    const nextMission = MISSIONS.find(m => m.id === nextId);
    if (nextMission) {
      setActiveMission(nextMission);
      setCurrentView('mission');
    } else {
      setCurrentView('flightdeck');
    }
  };

  return (
    <div
      data-theme={theme}
      className={`cosmora-app min-h-screen relative flex flex-col selection:bg-[#d9f36a] selection:text-[#061211] ${
        theme === 'light' ? 'bg-[#f5f3e8] text-[#17251f]' : 'bg-[#061211] text-[#eef4e6]'
      }`}
    >
      {/* Background Visualizer: the dedicated 3D views render their own backgrounds. */}
      {currentView !== 'missioncontrol' && currentView !== 'blackhole' && (
        <Suspense fallback={null}>
          {bgMode === 'solar' ? (
            <SolarSystemBackground3D
              theme={theme}
              speed={dayNightCycle ? 1 : 0}
              reduceMotion={reduceMotion}
            />
          ) : (
            <BlackHoleBackground3D
              interactive={currentView === 'observatory'}
              theme={theme}
              reduceMotion={reduceMotion}
            />
          )}
        </Suspense>
      )}

      {/* Top Navbar */}
      <Header
        profile={profile}
        currentView={currentView}
        onNavigate={view => {
          if (view === 'flightdeck' && !profile) {
            setCurrentView('intake');
          } else {
            setCurrentView(view);
          }
        }}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        soundMuted={soundMuted}
        onToggleSound={handleToggleSound}
        bgMode={bgMode}
        onToggleBgMode={() => setBgMode(prev => (prev === 'solar' ? 'blackhole' : 'solar'))}
        reduceMotion={reduceMotion}
        onToggleReduceMotion={() => setReduceMotion(prev => !prev)}
        dayNightCycle={dayNightCycle}
        onToggleDayNightCycle={() => setDayNightCycle(prev => !prev)}
        backgroundToggleEnabled={currentView !== 'missioncontrol' && currentView !== 'blackhole'}
      />

      {/* Main Dynamic View Content */}
      <main id="main-content" tabIndex={-1} className="flex-1 relative z-10 outline-none">
        <Suspense
          fallback={
            <div className="min-h-[50vh] grid place-items-center px-6 text-center font-mono text-xs tracking-widest text-[#9fb1a6]">
              LOADING FLIGHT SYSTEMS…
            </div>
          }
        >
          <div key={currentView} className="view-enter">
            {currentView === 'missioncontrol' && (
              <MissionControlUI
                theme={theme}
                reduceMotion={reduceMotion}
                cadetName={profile?.name}
                onNavigate={view => {
                  if (view === 'orrery') setCurrentView('observatory');
                  else if (view === 'missions') setCurrentView('flightdeck');
                  else if (view === 'starmap') setCurrentView('starmap');
                  else setCurrentView('blackhole');
                }}
                onOpenMission={planet => {
                  const missionId = planet === 'Mars' ? 8 : 11;
                  const mission = MISSIONS.find(item => item.id === missionId);
                  if (!mission) {
                    console.error(`[MissionControlUI] No mission is configured for ${planet}.`);
                    return;
                  }
                  handleSelectMission(mission);
                }}
              />
            )}

            {currentView === 'blackhole' && (
              <ObservatoryUI
                theme={theme}
                reduceMotion={reduceMotion}
                onBack={() => setCurrentView('missioncontrol')}
                onQuiz={() => {
                  const mission = MISSIONS.find(item => item.id === 17);
                  if (!mission) {
                    console.error('[ObservatoryUI] Black-hole mission 17 is not configured.');
                    return;
                  }
                  handleSelectMission(mission);
                }}
              />
            )}

            {currentView === 'intake' && (
              <CrewIntake
                currentProfile={profile}
                onSaveProfile={handleSaveProfile}
                onStartTraining={() => setCurrentView('flightdeck')}
              />
            )}

        {currentView === 'flightdeck' && profile && (
          <FlightDeck
            profile={profile}
            onSelectMission={handleSelectMission}
            onOpenCertificate={() => setCurrentView('certificate')}
            onChangeAstronaut={() => setCurrentView('intake')}
            onOpenTrainer={() => setCurrentView('trainer')}
            onOpenSpaceData={() => setCurrentView('spacedata')}
            onOpenObservatory={() => setCurrentView('observatory')}
            onOpenMissionControl={() => setCurrentView('missioncontrol')}
            onOpenStarMap={() => setCurrentView('starmap')}
            onOpenTelemetry={() => setCurrentView('telemetry')}
            onOpenRadar={() => setCurrentView('radar')}
            onOpenDossier={() => setCurrentView('dossier')}
            onResetProfile={() => {
              resetProfileData();
              setProfile(null);
              setCurrentView('intake');
            }}
          />
        )}

        {currentView === 'trainer' && (
          <AstronautTrainer
            profile={profile}
            onUpdateProfile={handleSaveProfile}
            onBackToDeck={() => setCurrentView('flightdeck')}
          />
        )}

        {currentView === 'mission' && activeMission && profile && (
          <MissionRunner
            mission={activeMission}
            profile={profile}
            onComplete={handleMissionComplete}
            onBackToDeck={() => setCurrentView('flightdeck')}
            onNextMission={handleNextMission}
          />
        )}

        {currentView === 'certificate' && profile && (
          <Certificate
            profile={profile}
            onBackToDeck={() => setCurrentView('flightdeck')}
          />
        )}

        {currentView === 'observatory' && (
          <SolarOrrery onBackToDeck={() => setCurrentView('flightdeck')} dayNightCycle={dayNightCycle} />
        )}

        {currentView === 'radar' && (
          <NasaLiveTelemetry onBackToDeck={() => setCurrentView('flightdeck')} initialTab="radar" />
        )}

        {currentView === 'starmap' && (
          <ConstellationMap onBackToDeck={() => setCurrentView('flightdeck')} />
        )}

        {currentView === 'telemetry' && (
          <NasaLiveTelemetry onBackToDeck={() => setCurrentView('flightdeck')} initialTab="orbits" />
        )}

        {currentView === 'spacedata' && (
          <NasaLiveTelemetry onBackToDeck={() => setCurrentView('flightdeck')} initialTab="weather" />
        )}

            {currentView === 'dossier' && profile && (
              <CadetDossier
                profile={profile}
                onBackToDeck={() => setCurrentView('flightdeck')}
                onOpenCertificate={() => setCurrentView('certificate')}
                onReFlyMission={handleNextMission}
                onRewardXP={(xp) => handleSaveProfile({ ...profile, points: profile.points + xp })}
              />
            )}
          </div>
        </Suspense>
      </main>

      {/* Global CapCom Radio Transmission HUD Bar */}
      {currentView !== 'missioncontrol' && currentView !== 'blackhole' && <CapComRadioBar />}

      {/* Global Minimal Footer */}
      {currentView !== 'missioncontrol' && currentView !== 'blackhole' && <footer className="relative z-20 py-4 px-6 border-t border-[#1b3834]/40 bg-[#061211]/80 backdrop-blur-sm text-center text-[11px] font-mono text-[#9fb1a6] flex flex-col sm:flex-row items-center justify-between gap-2 no-print">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#d9f36a]" />
          <span>COSMORA · TRAIN. EXPLORE. DISCOVER. · POWERED BY NASA OPEN SCIENCE & JPL</span>
        </div>
        <div className="flex items-center gap-3">
          <span>CREW FLIGHT RECORDS SAVED TO LOCAL TERMINAL</span>
          <span className="text-[#d9f36a]">✦ KEEP LOOKING UP</span>
        </div>
      </footer>}
    </div>
  );
}
