import type { EpicFrame, EpicSource, NasaApodData, NasaImageItem, NtrsRecord } from '../types';
import { EPIC_HOST, EPIC_MIRROR, normalizeEpic } from './epic';
import { EPIC_SAMPLE_RAW } from '../data/epicSample';
import { ntrsUrl } from '../data/ntrsSources';

/**
 * One module for every NASA open-data call the app makes.
 *
 *  - api.nasa.gov   EPIC (metadata) and APOD            -> needs an API key
 *  - images-api.nasa.gov   NASA Image & Video Library    -> no key
 *  - ntrs.nasa.gov   NASA Technical Reports Server       -> no key (500 requests / 15 min)
 *
 * Set VITE_NASA_API_KEY (free at https://api.nasa.gov) to lift the very small DEMO_KEY limits
 * (30 requests/hour per IP). Without it the app still works: results are cached for the session and
 * every feature has a graceful fallback.
 */

export const NASA_API_KEY: string = (import.meta.env?.VITE_NASA_API_KEY as string | undefined)?.trim() || 'DEMO_KEY';
export const IS_DEMO_KEY = NASA_API_KEY === 'DEMO_KEY';

export class NasaApiError extends Error {
  constructor(message: string, readonly status?: number) {
    super(message);
    this.name = 'NasaApiError';
  }
}

// ---------------------------------------------------------------------------
// Small cache: memory + sessionStorage, with in-flight de-duplication
// ---------------------------------------------------------------------------

type Entry = { exp: number; value: unknown };
const memory = new Map<string, Entry>();
const inflight = new Map<string, Promise<unknown>>();
const PREFIX = 'cosmora:nasa:';

function readCache<T>(key: string, allowStale = false): T | undefined {
  const hit = memory.get(key);
  if (hit && (allowStale || hit.exp > Date.now())) return hit.value as T;
  try {
    const raw = sessionStorage.getItem(PREFIX + key);
    if (raw) {
      const parsed = JSON.parse(raw) as Entry;
      if (allowStale || parsed.exp > Date.now()) {
        memory.set(key, parsed);
        return parsed.value as T;
      }
    }
  } catch {
    /* storage unavailable or corrupt: behave as a cache miss */
  }
  return undefined;
}

function writeCache(key: string, value: unknown, ttlMs: number) {
  const entry: Entry = { exp: Date.now() + ttlMs, value };
  memory.set(key, entry);
  try {
    sessionStorage.setItem(PREFIX + key, JSON.stringify(entry));
  } catch {
    /* quota or private mode: memory cache still works */
  }
}

async function cached<T>(key: string, ttlMs: number, load: () => Promise<T>): Promise<T> {
  const fresh = readCache<T>(key);
  if (fresh !== undefined) return fresh;
  const pending = inflight.get(key) as Promise<T> | undefined;
  if (pending) return pending;

  const promise = load()
    .then(value => {
      writeCache(key, value, ttlMs);
      return value;
    })
    .catch(err => {
      // A stale answer beats an error when the network or a rate limit fails us.
      const stale = readCache<T>(key, true);
      if (stale !== undefined) return stale;
      throw err;
    })
    .finally(() => inflight.delete(key));
  inflight.set(key, promise);
  return promise;
}

async function getJson<T>(url: string, timeoutMs = 8000): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) throw new NasaApiError(res.status === 429 ? 'NASA rate limit reached' : `NASA returned HTTP ${res.status}`, res.status);
    const type = res.headers.get('content-type') ?? '';
    // A static host with an SPA fallback answers unknown /api paths with HTML; treat that as a miss.
    if (type && !type.includes('json')) throw new NasaApiError('Unexpected non-JSON response');
    return (await res.json()) as T;
  } finally {
    clearTimeout(timer);
  }
}

// ---------------------------------------------------------------------------
// APOD: Astronomy Picture of the Day (mission-end reward)
// ---------------------------------------------------------------------------

export interface ApodResult extends NasaApodData {
  /** The page on apod.nasa.gov for this date. */
  pageUrl: string;
}

const apodPage = (date: string) => {
  const [y, m, d] = date.split('-');
  return y && m && d ? `https://apod.nasa.gov/apod/ap${y.slice(2)}${m}${d}.html` : 'https://apod.nasa.gov/apod/astropix.html';
};

export function fetchApod(): Promise<ApodResult> {
  // New picture daily; a 3 h cache keeps repeat visits off the (small) DEMO_KEY quota.
  return cached('apod', 3 * 60 * 60 * 1000, async () => {
    const data = await getJson<Partial<NasaApodData>>(
      `https://api.nasa.gov/planetary/apod?api_key=${encodeURIComponent(NASA_API_KEY)}&thumbs=true`,
    );
    if (!data || typeof data.title !== 'string' || typeof data.url !== 'string') {
      throw new NasaApiError('APOD response missing fields');
    }
    const date = typeof data.date === 'string' ? data.date : '';
    return {
      title: data.title,
      explanation: data.explanation ?? '',
      url: data.url,
      hdurl: data.hdurl,
      date,
      copyright: data.copyright?.replace(/\s+/g, ' ').trim() || undefined,
      media_type: data.media_type,
      thumbnail_url: data.thumbnail_url,
      pageUrl: apodPage(date),
    };
  });
}

/** The image to show: APOD is sometimes a video, in which case use its thumbnail (or none). */
export const apodImageSrc = (a: NasaApodData): string | undefined =>
  a.media_type === 'video' ? a.thumbnail_url : a.url;

// ---------------------------------------------------------------------------
// EPIC: DSCOVR full-disc Earth imagery (observation mission)
// ---------------------------------------------------------------------------

export interface EpicResult {
  frames: EpicFrame[];
  source: EpicSource;
  fetchedAt: string;
}

export function fetchEpic(): Promise<EpicResult> {
  // EPIC publishes a new imaging day roughly daily; 30 min is plenty.
  return cached('epic:latest', 30 * 60 * 1000, async () => {
    const attempts: { source: EpicSource; url: string }[] = [
      { source: 'api.nasa.gov', url: `${EPIC_MIRROR}/api/natural?api_key=${encodeURIComponent(NASA_API_KEY)}` },
      { source: 'epic.gsfc.nasa.gov', url: `${EPIC_HOST}/api/natural` },
    ];
    let lastError: unknown;
    for (const attempt of attempts) {
      try {
        const frames = normalizeEpic(await getJson<unknown>(attempt.url), NASA_API_KEY);
        if (frames.length) return { frames, source: attempt.source, fetchedAt: new Date().toISOString() };
        lastError = new NasaApiError('EPIC returned no usable frames');
      } catch (err) {
        lastError = err;
      }
    }
    throw lastError instanceof Error ? lastError : new NasaApiError('EPIC unavailable');
  });
}

/** Real archived EPIC metadata (2026-11-03) for when live data cannot be reached. */
export function epicArchivedSample(): EpicResult {
  return {
    frames: normalizeEpic(EPIC_SAMPLE_RAW, NASA_API_KEY),
    source: 'archived-sample',
    fetchedAt: new Date().toISOString(),
  };
}

// ---------------------------------------------------------------------------
// NASA Image & Video Library (checklist mission: training and ISS photography)
// ---------------------------------------------------------------------------

interface ImagesApiItem {
  data?: { nasa_id?: string; title?: string; description?: string; date_created?: string; center?: string }[];
  links?: { href?: string; rel?: string }[];
}

export function searchNasaImages(query: string, limit = 3): Promise<NasaImageItem[]> {
  return cached(`images:${query}:${limit}`, 24 * 60 * 60 * 1000, async () => {
    const url = `https://images-api.nasa.gov/search?q=${encodeURIComponent(query)}&media_type=image&page_size=${Math.max(limit * 4, 12)}`;
    const json = await getJson<{ collection?: { items?: ImagesApiItem[] } }>(url);
    const out: NasaImageItem[] = [];
    const seen = new Set<string>();
    for (const item of json.collection?.items ?? []) {
      const d = item.data?.[0];
      const thumb = item.links?.find(l => l.rel === 'preview')?.href ?? item.links?.[0]?.href;
      if (!d?.nasa_id || !thumb || seen.has(d.nasa_id)) continue;
      seen.add(d.nasa_id);
      out.push({
        nasaId: d.nasa_id,
        title: d.title ?? d.nasa_id,
        description: (d.description ?? '').replace(/\s+/g, ' ').trim(),
        dateCreated: d.date_created?.slice(0, 10) ?? '',
        center: d.center ?? 'NASA',
        thumbUrl: thumb,
        mediumUrl: thumb.replace('~thumb.jpg', '~medium.jpg'),
        detailsUrl: `https://images.nasa.gov/details/${encodeURIComponent(d.nasa_id)}`,
      });
      if (out.length >= limit) break;
    }
    if (!out.length) throw new NasaApiError('No images matched');
    return out;
  });
}

// ---------------------------------------------------------------------------
// NTRS: NASA Technical Reports Server (source for quiz claims)
// ---------------------------------------------------------------------------

interface NtrsRaw {
  id?: number | string;
  title?: string;
  abstract?: string;
  center?: { name?: string };
  authorAffiliations?: { sequence?: number; meta?: { author?: { name?: string } } }[];
  publications?: { publicationDate?: string }[];
  distributionDate?: string;
  otherReportNumbers?: string[];
}

function mapNtrs(r: NtrsRaw): NtrsRecord | null {
  if (r.id === undefined || !r.title) return null;
  const id = String(r.id);
  const date = r.publications?.[0]?.publicationDate ?? r.distributionDate;
  const year = date ? Number(date.slice(0, 4)) : undefined;
  const authors = [...(r.authorAffiliations ?? [])]
    .sort((a, b) => (a.sequence ?? 0) - (b.sequence ?? 0))
    .map(a => a.meta?.author?.name)
    .filter((n): n is string => Boolean(n));
  return {
    id,
    title: r.title.replace(/\s+/g, ' ').trim(),
    authors: authors.slice(0, 4),
    year: year && Number.isFinite(year) ? year : undefined,
    center: r.center?.name,
    reportNumber: r.otherReportNumbers?.[0],
    abstract: r.abstract?.replace(/\s+/g, ' ').trim(),
    url: ntrsUrl(id),
  };
}

export interface NtrsSearchResult {
  total: number;
  records: NtrsRecord[];
}

/**
 * Keyword search on NTRS. Tries the public API directly (it is CORS-enabled for browsers if NASA
 * allows it) and falls back to this project's /api/ntrs proxy. Throws if neither works; callers show
 * a deep link to ntrs.nasa.gov instead.
 */
export function searchNtrs(query: string, size = 3): Promise<NtrsSearchResult> {
  const q = query.trim();
  if (!q) return Promise.reject(new NasaApiError('Empty NTRS query'));
  return cached(`ntrs:${q.toLowerCase()}:${size}`, 24 * 60 * 60 * 1000, async () => {
    const params = `q=${encodeURIComponent(q)}`;
    const endpoints = [
      `https://ntrs.nasa.gov/api/citations/search?${params}&page.size=${size}`,
      `/api/ntrs?${params}&size=${size}`,
    ];
    let lastError: unknown;
    for (const endpoint of endpoints) {
      try {
        const json = await getJson<{ stats?: { total?: number }; results?: NtrsRaw[] }>(endpoint, 9000);
        const records = (json.results ?? []).map(mapNtrs).filter((r): r is NtrsRecord => r !== null);
        return { total: json.stats?.total ?? records.length, records };
      } catch (err) {
        lastError = err;
      }
    }
    throw lastError instanceof Error ? lastError : new NasaApiError('NTRS unavailable');
  });
}
