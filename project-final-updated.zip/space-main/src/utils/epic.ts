import type { EpicFrame, Vec3Km } from '../types';

/** Pure helpers for DSCOVR/EPIC data. No network, no React: safe to unit test. */

export const EPIC_HOST = 'https://epic.gsfc.nasa.gov';
export const EPIC_MIRROR = 'https://api.nasa.gov/EPIC';
export const C_KM_S = 299_792.458;
export const AU_KM = 149_597_870.7;

const isNum = (n: unknown): n is number => typeof n === 'number' && Number.isFinite(n);
const isVec = (v: unknown): v is Vec3Km =>
  !!v && typeof v === 'object' && isNum((v as Vec3Km).x) && isNum((v as Vec3Km).y) && isNum((v as Vec3Km).z);

export const vecLength = (v: Vec3Km) => Math.hypot(v.x, v.y, v.z);

/** EPIC dates look like "2026-11-03 00:31:45" and are UTC. */
export const parseEpicDate = (date: string): number => Date.parse(`${date.trim().replace(' ', 'T')}Z`);

/**
 * Turn the raw EPIC API array into validated frames, oldest first. Anything malformed is dropped
 * rather than guessed at, so downstream maths only ever sees real numbers.
 */
export function normalizeEpic(raw: unknown, apiKey: string): EpicFrame[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Set<string>();
  const frames: EpicFrame[] = [];

  for (const r of raw as Record<string, any>[]) {
    if (!r || typeof r.image !== 'string' || typeof r.date !== 'string') continue;
    const c = r.centroid_coordinates;
    if (!c || !isNum(c.lat) || !isNum(c.lon)) continue;
    if (!isVec(r.dscovr_j2000_position) || !isVec(r.lunar_j2000_position) || !isVec(r.sun_j2000_position)) continue;

    const ms = parseEpicDate(r.date);
    if (!Number.isFinite(ms)) continue;

    // The archive folder is the image's own UTC day, which is encoded in its file name.
    const parts = /_(\d{4})(\d{2})(\d{2})\d{6}$/.exec(r.image) ?? /^(\d{4})-(\d{2})-(\d{2})/.exec(r.date);
    if (!parts) continue;
    const dir = `${parts[1]}/${parts[2]}/${parts[3]}`;

    const identifier = String(r.identifier ?? r.image);
    if (seen.has(identifier)) continue;
    seen.add(identifier);

    frames.push({
      identifier,
      image: r.image,
      caption: typeof r.caption === 'string' ? r.caption : 'NASA EPIC / NOAA DSCOVR',
      capturedAt: new Date(ms).toISOString(),
      capturedMs: ms,
      lat: c.lat,
      lon: c.lon,
      dscovrKm: r.dscovr_j2000_position,
      moonKm: r.lunar_j2000_position,
      sunKm: r.sun_j2000_position,
      // Imagery is read from the EPIC archive host (no key, no quota). The api.nasa.gov mirror is a fallback.
      imageUrl: `${EPIC_HOST}/archive/natural/${dir}/jpg/${r.image}.jpg`,
      thumbUrl: `${EPIC_HOST}/archive/natural/${dir}/thumbs/${r.image}.jpg`,
      mirrorUrl: `${EPIC_MIRROR}/archive/natural/${dir}/jpg/${r.image}.jpg?api_key=${encodeURIComponent(apiKey)}`,
    });
  }
  return frames.sort((a, b) => a.capturedMs - b.capturedMs);
}

// ---------------------------------------------------------------------------
// Orbital maths from the real J2000 vectors
// ---------------------------------------------------------------------------

/** DSCOVR distance from Earth's centre, km (the vectors are geocentric). */
export const earthDistanceKm = (f: EpicFrame) => vecLength(f.dscovrKm);
/** Earth-Moon distance, km. */
export const moonDistanceKm = (f: EpicFrame) => vecLength(f.moonKm);
/** Earth-Sun distance, astronomical units. */
export const sunDistanceAu = (f: EpicFrame) => vecLength(f.sunKm) / AU_KM;
/** One-way radio light time, seconds. */
export const lightTimeSeconds = (km: number) => km / C_KM_S;

export const wrapLon = (lon: number) => ((((lon + 180) % 360) + 360) % 360) - 180;

export interface RotationMeasurement {
  /** Magnitude of the apparent drift of the disc-centre longitude, degrees per hour. */
  degPerHour: number;
  direction: 'westward' | 'eastward';
  /** Hours of frame-to-frame baseline the measurement is built from. */
  baselineHours: number;
}

/**
 * Measure Earth's rotation from consecutive frames: how fast does the longitude at the centre of
 * the disc move? Each step is wrapped across the antimeridian. Gaps longer than 4 h are skipped
 * (the wrap would be ambiguous). Needs at least 3 h of baseline or returns null.
 */
export function measureRotation(frames: EpicFrame[]): RotationMeasurement | null {
  let sumLon = 0;
  let sumHours = 0;
  for (let i = 1; i < frames.length; i++) {
    const hours = (frames[i].capturedMs - frames[i - 1].capturedMs) / 3_600_000;
    if (!(hours > 0) || hours > 4) continue;
    sumLon += wrapLon(frames[i].lon - frames[i - 1].lon);
    sumHours += hours;
  }
  if (sumHours < 3) return null;
  const rate = sumLon / sumHours;
  return { degPerHour: Math.abs(rate), direction: rate < 0 ? 'westward' : 'eastward', baselineHours: sumHours };
}

export function formatLatLon(lat: number, lon: number): string {
  return `${Math.abs(lat).toFixed(2)}° ${lat < 0 ? 'S' : 'N'} · ${Math.abs(lon).toFixed(2)}° ${lon < 0 ? 'W' : 'E'}`;
}

export const formatKm = (km: number) => Math.round(km).toLocaleString('en-US');

export const formatUtc = (ms: number) => new Date(ms).toISOString().replace('T', ' ').slice(0, 19) + ' UTC';

// ---------------------------------------------------------------------------
// Deterministic quiz choices (so a re-render never reshuffles the answers)
// ---------------------------------------------------------------------------

export interface Choice {
  id: string;
  label: string;
  correct: boolean;
}

function hashSeed(seed: string): number {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function seededShuffle<T>(items: T[], seed: string): T[] {
  const rand = mulberry32(hashSeed(seed));
  const out = [...items];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

/** "How far is DSCOVR from Earth?" The correct label is computed from the frame's real vector. */
export function rangeChoices(distanceKm: number, seed: string): Choice[] {
  const millions = (distanceKm / 1_000_000).toFixed(2);
  return seededShuffle<Choice>(
    [
      { id: 'l1', label: `About ${millions} million km (Sun-Earth Lagrange point L1)`, correct: true },
      { id: 'iss', label: 'About 400 km (the ISS altitude)', correct: false },
      { id: 'geo', label: 'About 36,000 km (geostationary orbit)', correct: false },
      { id: 'moon', label: 'About 384,000 km (the distance to the Moon)', correct: false },
    ],
    `range:${seed}`,
  );
}

/** "How fast does Earth turn?" Correct is the physical truth; the measured value is shown in feedback. */
export function rotationChoices(seed: string): Choice[] {
  return seededShuffle<Choice>(
    [
      { id: '15', label: 'About 15° per hour (one full turn in a day)', correct: true },
      { id: '7', label: 'About 7.5° per hour', correct: false },
      { id: '30', label: 'About 30° per hour', correct: false },
      { id: '1', label: 'About 1° per hour', correct: false },
    ],
    `rot:${seed}`,
  );
}
