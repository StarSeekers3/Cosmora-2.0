import { geoArea, geoCentroid, geoContains, geoDistance } from 'd3-geo';
import type { Feature, Geometry } from 'geojson';
import { seededShuffle, type Choice } from './epic';

export type CountryFeature = Feature<Geometry, { name?: string }>;

export interface Located {
  label: string;
  kind: 'country' | 'ocean';
}

/** world-atlas uses abbreviated names ("Dem. Rep. Congo"); spell them out for learners. */
export function prettyCountry(name: string): string {
  const direct: Record<string, string> = {
    'United States of America': 'United States',
    'Dem. Rep. Congo': 'Democratic Republic of the Congo',
    'Central African Rep.': 'Central African Republic',
    'Dominican Rep.': 'Dominican Republic',
    'Eq. Guinea': 'Equatorial Guinea',
    'S. Sudan': 'South Sudan',
    'Bosnia and Herz.': 'Bosnia and Herzegovina',
    'W. Sahara': 'Western Sahara',
    'Solomon Is.': 'Solomon Islands',
    'Falkland Is.': 'Falkland Islands',
  };
  return direct[name] ?? name;
}

/**
 * Ocean at a point, or null when the point is close to a boundary or a marginal sea where a single
 * ocean name would be debatable. Returning null lets the caller choose a different frame rather than
 * teach something doubtful.
 */
export function oceanAt(lat: number, lon: number): string | null {
  if (lat >= 70) return 'Arctic Ocean';
  if (lat <= -62) return 'Southern Ocean';
  if (lat < -45 || lat > 45) return null; // high-latitude basins blur together
  if (lon >= -50 && lon <= 5) return 'Atlantic Ocean';
  if (lon >= 60 && lon <= 95 && lat <= 8) return 'Indian Ocean';
  if (lon >= 155 || lon <= -115) return 'Pacific Ocean';
  return null;
}

const OCEAN_ANCHORS: Record<string, [number, number]> = {
  'Pacific Ocean': [-150, 0],
  'Atlantic Ocean': [-30, 5],
  'Indian Ocean': [78, -15],
};

/** What is directly under the centre of the disc? */
export function locateCentre(lat: number, lon: number, countries: CountryFeature[]): Located | null {
  for (const f of countries) {
    if (geoContains(f, [lon, lat])) {
      const name = f.properties?.name;
      return name ? { label: prettyCountry(name), kind: 'country' } : null;
    }
  }
  const ocean = oceanAt(lat, lon);
  return ocean ? { label: ocean, kind: 'ocean' } : null;
}

/** Minimum separation (radians, ~3,800 km) so a wrong option is clearly not at the centre. */
const MIN_SEPARATION = 0.6;
/** Only sizeable countries make fair distractors (steradians). */
const MIN_AREA = 0.02;

/**
 * Build a 4-option question whose correct answer is `located`. Distractors are far from the
 * centre, so there is exactly one defensible answer.
 */
export function centreChoices(
  lat: number,
  lon: number,
  located: Located,
  countries: CountryFeature[],
  seed: string,
): Choice[] {
  const here: [number, number] = [lon, lat];
  let distractors: string[];

  if (located.kind === 'ocean') {
    const otherOceans = Object.entries(OCEAN_ANCHORS)
      .filter(([name, anchor]) => name !== located.label && geoDistance(here, anchor) > MIN_SEPARATION)
      .map(([name]) => name);
    const farCountries = bigFarCountries(here, countries, located.label);
    distractors = [
      ...seededShuffle(otherOceans, `o:${seed}`).slice(0, 2),
      ...seededShuffle(farCountries, `c:${seed}`).slice(0, 3),
    ].slice(0, 3);
  } else {
    distractors = seededShuffle(bigFarCountries(here, countries, located.label), `c:${seed}`).slice(0, 3);
  }

  return seededShuffle<Choice>(
    [
      { id: 'answer', label: located.label, correct: true },
      ...distractors.map((label, i) => ({ id: `d${i}`, label, correct: false })),
    ],
    `centre:${seed}`,
  );
}

function bigFarCountries(here: [number, number], countries: CountryFeature[], exclude: string): string[] {
  const out: string[] = [];
  for (const f of countries) {
    const raw = f.properties?.name;
    if (!raw) continue;
    const name = prettyCountry(raw);
    if (name === exclude || name === 'Antarctica') continue;
    if (geoArea(f) < MIN_AREA) continue;
    if (geoDistance(here, geoCentroid(f)) < MIN_SEPARATION) continue;
    out.push(name);
  }
  return out;
}
