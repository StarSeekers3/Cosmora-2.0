/* Lightweight, dependency-free astronomy helpers used by the NASA Live and Star Map views. */

const D2R = Math.PI / 180;
const R2D = 180 / Math.PI;
const norm360 = (x: number) => ((x % 360) + 360) % 360;
const norm180 = (x: number) => ((((x + 180) % 360) + 360) % 360) - 180;

export const julianDate = (d: Date) => d.getTime() / 86400000 + 2440587.5;
/** Terrestrial Time offset (TT - UTC) in seconds, valid for 2017+ */
const TT_MINUS_UTC = 69.184;
export const julianDateTT = (d: Date) => julianDate(d) + TT_MINUS_UTC / 86400;

/* --------------------------- Keplerian ephemeris --------------------------- */
// JPL "Keplerian elements for approximate positions of the major planets" (1800-2050)
interface Elements { a: number; e: number; I: number; L: number; w: number; O: number; da: number; de: number; dI: number; dL: number; dw: number; dO: number }
const EARTH: Elements = { a: 1.00000261, e: 0.01671123, I: -0.00001531, L: 100.46457166, w: 102.93768193, O: 0, da: 0.00000562, de: -0.00004392, dI: -0.01294668, dL: 35999.37306329, dw: 0.32327364, dO: 0 };
const MARS: Elements = { a: 1.52371034, e: 0.0933941, I: 1.84969142, L: -4.55343205, w: -23.94362959, O: 49.55953891, da: 0.00001847, de: 0.00007882, dI: -0.00813131, dL: 19140.30268499, dw: 0.44441088, dO: -0.29257343 };

function solveKepler(M: number, e: number) {
  let E = M + e * Math.sin(M);
  for (let i = 0; i < 12; i++) E -= (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));
  return E;
}

function helio(el: Elements, jd: number) {
  const T = (jd - 2451545.0) / 36525;
  const a = el.a + el.da * T, e = el.e + el.de * T, I = (el.I + el.dI * T) * D2R;
  const L = el.L + el.dL * T, w = el.w + el.dw * T, O = (el.O + el.dO * T) * D2R;
  const argP = w * D2R - O;
  const M = norm180(L - w) * D2R;
  const E = solveKepler(M, e);
  const xp = a * (Math.cos(E) - e), yp = a * Math.sqrt(1 - e * e) * Math.sin(E);
  const cw = Math.cos(argP), sw = Math.sin(argP), cO = Math.cos(O), sO = Math.sin(O), cI = Math.cos(I), sI = Math.sin(I);
  const x = (cw * cO - sw * sO * cI) * xp + (-sw * cO - cw * sO * cI) * yp;
  const y = (cw * sO + sw * cO * cI) * xp + (-sw * sO + cw * cO * cI) * yp;
  const z = sw * sI * xp + cw * sI * yp;
  const nu = Math.atan2(Math.sqrt(1 - e * e) * Math.sin(E), Math.cos(E) - e);
  return { x, y, z, nu: nu * R2D, r: Math.sqrt(x * x + y * y + z * z) };
}

export const AU_KM = 149597870.7;
export const C_KM_S = 299792.458;

export function marsEarth(date: Date) {
  const jd = julianDate(date);
  const e = helio(EARTH, jd), m = helio(MARS, jd);
  const dx = m.x - e.x, dy = m.y - e.y, dz = m.z - e.z;
  const au = Math.sqrt(dx * dx + dy * dy + dz * dz);
  return { au, km: au * AU_KM, lightMinutes: (au * AU_KM) / C_KM_S / 60, marsSunAu: m.r };
}

/** Areocentric solar longitude Ls (0=N spring equinox, 90=N summer, 180=N autumn, 270=N winter) */
export function marsLs(date: Date) {
  const m = helio(MARS, julianDate(date));
  // Perihelion occurs at Ls ~ 251 deg
  return norm360(m.nu + 251);
}

export function marsSeasonNorth(ls: number) {
  if (ls < 90) return 'Northern Spring';
  if (ls < 180) return 'Northern Summer';
  if (ls < 270) return 'Northern Autumn';
  return 'Northern Winter';
}

/** Mars Sol Date and Coordinated Mars Time (Allison & McEwen 2000) */
export function marsTime(date: Date, eastLonDeg: number) {
  const jdTT = julianDateTT(date);
  const msd = (jdTT - 2451549.5) / 1.0274912517 + 44796.0 - 0.0009626;
  const mtc = 24 * (msd - Math.floor(msd));
  const lmst = (mtc + eastLonDeg / 15 + 24) % 24; // local mean solar time at longitude
  return { msd, mtc, lmst };
}

/** Perseverance landed 2021-02-18 ~20:55 UTC = Sol 0 (at Jezero, LMST ~15:50) */
export function perseveranceSol(date: Date) {
  const land = Date.UTC(2021, 1, 18, 20, 55, 0);
  return Math.floor((date.getTime() - land) / 1000 / 88775.244);
}

/* ------------------------------- Earth / Sun ------------------------------- */
/** Sub-solar point (lat, lon) in degrees, accurate to ~0.2 deg. */
export function subsolarPoint(date: Date) {
  const jd = julianDate(date);
  const n = jd - 2451545.0;
  const L = norm360(280.46 + 0.9856474 * n);
  const g = norm360(357.528 + 0.9856003 * n) * D2R;
  const lambda = (L + 1.915 * Math.sin(g) + 0.02 * Math.sin(2 * g)) * D2R;
  const eps = (23.439 - 0.0000004 * n) * D2R;
  const dec = Math.asin(Math.sin(eps) * Math.sin(lambda)) * R2D;
  const ra = Math.atan2(Math.cos(eps) * Math.sin(lambda), Math.cos(lambda)) * R2D;
  const gmst = norm360(280.46061837 + 360.98564736629 * n);
  return { lat: dec, lon: norm180(ra - gmst) };
}

/* --------------------------------- ISS model -------------------------------- */
export const ISS_INCL = 51.64 * D2R;
export const ISS_PERIOD_S = 92.9 * 60;
const OMEGA_E = 7.2921159e-5; // Earth rotation rad/s

export interface IssAnchor { lat: number; lon: number; ascending: boolean; t: number }

/** Great-circle ground track of a circular orbit anchored to a known (lat, lon, direction, time). */
export function issPropagate(anchor: IssAnchor, tMs: number) {
  const dt = (tMs - anchor.t) / 1000;
  const n = (2 * Math.PI) / ISS_PERIOD_S;
  const sI = Math.sin(ISS_INCL), cI = Math.cos(ISS_INCL);
  let u0 = Math.asin(Math.max(-1, Math.min(1, Math.sin(anchor.lat * D2R) / sI)));
  if (!anchor.ascending) u0 = Math.PI - u0;
  const lonNode0 = anchor.lon * D2R - Math.atan2(cI * Math.sin(u0), Math.cos(u0));
  const u = u0 + n * dt;
  const lat = Math.asin(sI * Math.sin(u));
  const lon = lonNode0 + Math.atan2(cI * Math.sin(u), Math.cos(u)) - OMEGA_E * dt;
  return { lat: lat * R2D, lon: norm180(lon * R2D) };
}

/** Offline fallback anchor: a plausible ISS phase derived from the clock (clearly labelled "simulated"). */
export function simulatedIssAnchor(now: number): IssAnchor {
  const phase = ((now / 1000) % ISS_PERIOD_S) / ISS_PERIOD_S;
  const u = phase * 2 * Math.PI;
  const lat = Math.asin(Math.sin(ISS_INCL) * Math.sin(u)) * R2D;
  const lon = norm180(Math.atan2(Math.cos(ISS_INCL) * Math.sin(u), Math.cos(u)) * R2D - ((now / 1000) * OMEGA_E * R2D) + 77);
  return { lat, lon, ascending: Math.cos(u) > 0, t: now };
}

/* -------------------------------- Voyager 1 --------------------------------- */
/** Estimated Earth-Voyager 1 range. Anchored to NASA's "one light-day" milestone (~15 Nov 2026). */
export function voyager1(date: Date) {
  const lightDayKm = C_KM_S * 86400; // 25.902 billion km
  const earthRelSpeed = 16.95; // km/s
  const milestone = Date.UTC(2026, 10, 15, 12, 0, 0);
  const km = lightDayKm + earthRelSpeed * ((date.getTime() - milestone) / 1000);
  return { km, au: km / AU_KM, oneWayS: km / C_KM_S, speedKmS: earthRelSpeed };
}

export function fmtDuration(totalSeconds: number) {
  const s = Math.max(0, Math.round(totalSeconds));
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  if (d > 0) return `${d}d ${h}h ${m}m ${sec}s`;
  if (h > 0) return `${h}h ${String(m).padStart(2, '0')}m ${String(sec).padStart(2, '0')}s`;
  if (m > 0) return `${m}m ${String(sec).padStart(2, '0')}s`;
  return `${sec}s`;
}
