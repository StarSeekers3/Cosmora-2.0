import type { QuizQuestion } from '../types';

/**
 * Return option indices in a randomized display order. If requested, avoid placing
 * the correct answer in the same position as it appeared on the previous question.
 * The source question is never mutated.
 */
export function shuffleQuizOptionOrder(
  question: QuizQuestion | undefined,
  previousCorrectPosition: number | null = null
): number[] {
  const options = question?.options ?? [];
  const order = options.map((_, index) => index);

  for (let index = order.length - 1; index > 0; index--) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [order[index], order[swapIndex]] = [order[swapIndex], order[index]];
  }

  if (!question || order.length < 2 || !Number.isInteger(question.answer)) return order;
  const correctPosition = order.indexOf(question.answer);
  if (correctPosition < 0 || previousCorrectPosition === null || correctPosition !== previousCorrectPosition) return order;

  const alternativePositions = order
    .map((_, index) => index)
    .filter(index => index !== previousCorrectPosition && index !== correctPosition);
  if (alternativePositions.length === 0) return order;

  const newCorrectPosition = alternativePositions[Math.floor(Math.random() * alternativePositions.length)];
  [order[correctPosition], order[newCorrectPosition]] = [order[newCorrectPosition], order[correctPosition]];
  return order;
}
