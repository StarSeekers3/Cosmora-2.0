export interface RankDefinition {
  title: string;
  grade: string;
  icon: string;
  color: string;
  detail: string;
  minXp: number;
}

export function getAstronautRank(xp: number): RankDefinition {
  if (xp >= 320) {
    return {
      title: 'CHIEF SPACE COMMANDER',
      grade: 'O-6',
      icon: '★',
      color: '#ffc93c',
      detail: 'Highest honor of the Cosmora Academy. Certified for interstellar command.',
      minXp: 320,
    };
  }
  if (xp >= 220) {
    return {
      title: 'FLIGHT DIRECTOR',
      grade: 'O-5',
      icon: '✹',
      color: '#d9f36a',
      detail: 'Mastered planetary defense, lunar descent, and deep space observatories.',
      minXp: 220,
    };
  }
  if (xp >= 140) {
    return {
      title: 'MISSION LEAD',
      grade: 'O-4',
      icon: '✦',
      color: '#72d1d6',
      detail: 'Certified to guide an interplanetary crew across orbital docking and EVA.',
      minXp: 140,
    };
  }
  if (xp >= 70) {
    return {
      title: 'FLIGHT SPECIALIST',
      grade: 'O-2',
      icon: '✧',
      color: '#bdc9c0',
      detail: 'Orbital mechanics, gravity free-fall, and planetary science systems verified.',
      minXp: 70,
    };
  }
  if (xp >= 25) {
    return {
      title: 'ORBIT CADET',
      grade: 'E-3',
      icon: '·',
      color: '#9fb1a6',
      detail: 'Initial launch countdown verified. Advancing to complex space flight.',
      minXp: 25,
    };
  }
  return {
    title: 'CADET RECRUIT',
    grade: 'E-1',
    icon: '·',
    color: '#9fb1a6',
    detail: 'Your first flight countdown awaits at Launch Complex 39.',
    minXp: 0,
  };
}
