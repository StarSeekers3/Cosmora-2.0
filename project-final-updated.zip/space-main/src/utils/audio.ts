// Web Audio API Synthesizer for Aerospace Mission Simulation & Telemetry

let audioCtx: AudioContext | null = null;
let isAudioMuted = false;

function getAudioContext(): AudioContext | null {
  if (isAudioMuted) return null;
  if (typeof window === 'undefined') return null;
  try {
    if (!audioCtx) {
      const AudioConstructor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioConstructor) {
        audioCtx = new AudioConstructor();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  } catch {
    return null;
  }
}

export function setSoundMuted(muted: boolean) {
  isAudioMuted = muted;
}

export function getSoundMuted(): boolean {
  return isAudioMuted;
}

/** Authentic Apollo Mission Quindar Beep (Intro: 2525Hz, Outro: 2475Hz) */
export function playQuindarTone(type: 'intro' | 'outro' = 'intro') {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const freq = type === 'intro' ? 2525 : 2475;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, ctx.currentTime);

    // Precise 250ms duration typical of NASA Apollo Quindar beeps
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.04, ctx.currentTime + 0.005);
    gain.gain.setValueAtTime(0.04, ctx.currentTime + 0.18);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.22);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.23);
  } catch {
    // Ignore
  }
}

/** Short UI blip or button click */
export function playUiClick() {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(650, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(950, ctx.currentTime + 0.04);

    gain.gain.setValueAtTime(0.035, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.04);
  } catch {
    // Ignore
  }
}

/** Tone with custom frequency */
export function playTone(frequency: number, duration = 0.12, type: OscillatorType = 'sine') {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(frequency, ctx.currentTime);

    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.05, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + duration + 0.02);
  } catch {
    // Ignore
  }
}

/** Gentle, airy shimmer for entering a planet's introduction stage. Respects the global sound mute. */
export function playPlanetArrivalSound(planetName: string) {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const now = ctx.currentTime;
    const notes: Record<string, [number, number]> = {
      Mercury: [659.25, 987.77],
      Venus: [587.33, 880],
      Earth: [523.25, 783.99],
      Mars: [493.88, 739.99],
      Jupiter: [392, 587.33],
      Saturn: [440, 659.25],
      Uranus: [554.37, 830.61],
      Neptune: [466.16, 698.46],
    };
    const [lowNote, highNote] = notes[planetName] ?? notes.Earth;

    // A very quiet filtered noise swell gives the visual planet movement a soft sense of arrival.
    const bufferLength = Math.floor(ctx.sampleRate * 0.82);
    const noiseBuffer = ctx.createBuffer(1, bufferLength, ctx.sampleRate);
    const noiseData = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferLength; i++) noiseData[i] = Math.random() * 2 - 1;
    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuffer;
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(280, now);
    filter.frequency.exponentialRampToValueAtTime(1250, now + 0.46);
    filter.frequency.exponentialRampToValueAtTime(620, now + 0.78);
    const wash = ctx.createGain();
    wash.gain.setValueAtTime(0.0001, now);
    wash.gain.linearRampToValueAtTime(0.012, now + 0.18);
    wash.gain.exponentialRampToValueAtTime(0.0001, now + 0.82);
    noise.connect(filter);
    filter.connect(wash);
    wash.connect(ctx.destination);
    noise.start(now);
    noise.stop(now + 0.84);

    // Two restrained sine partials bloom in after the whoosh and fade out cleanly.
    [[lowNote, 0.08, 0.7], [highNote, 0.23, 0.82]].forEach(([frequency, delay, length]) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const start = now + delay;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(frequency, start);
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.linearRampToValueAtTime(0.018, start + 0.09);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + length);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + length + 0.02);
    });
  } catch {
    // Audio is an enhancement; silently skip it when the browser has no usable audio context.
  }
}

/** Planet-specific selection cue. Each world has its own soft timbre and note pattern. */
export function playPlanetSelectSound(planetName: string) {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const cues: Record<string, { notes: number[]; type: OscillatorType; spacing: number; length: number; peak: number; glide: number }> = {
      Mercury: { notes: [1174.66, 1567.98], type: 'sine', spacing: 0.045, length: 0.13, peak: 0.018, glide: -0.035 },
      Venus: { notes: [659.25, 987.77], type: 'triangle', spacing: 0.095, length: 0.3, peak: 0.016, glide: 0.015 },
      Earth: { notes: [523.25, 659.25, 783.99], type: 'sine', spacing: 0.055, length: 0.27, peak: 0.019, glide: 0 },
      Mars: { notes: [196, 293.66], type: 'triangle', spacing: 0.12, length: 0.22, peak: 0.022, glide: -0.06 },
      Jupiter: { notes: [130.81, 196, 261.63], type: 'triangle', spacing: 0.065, length: 0.36, peak: 0.024, glide: -0.025 },
      Saturn: { notes: [392, 587.33, 880], type: 'sine', spacing: 0.09, length: 0.42, peak: 0.017, glide: 0.01 },
      Uranus: { notes: [880, 1174.66, 1396.91], type: 'sine', spacing: 0.04, length: 0.2, peak: 0.015, glide: 0.025 },
      Neptune: { notes: [174.61, 261.63], type: 'sine', spacing: 0.17, length: 0.48, peak: 0.022, glide: -0.015 },
    };
    const cue = cues[planetName] ?? cues.Earth;
    const now = ctx.currentTime;

    cue.notes.forEach((frequency, index) => {
      const start = now + index * cue.spacing;
      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();
      osc.type = cue.type;
      osc.frequency.setValueAtTime(frequency * (1 + cue.glide), start);
      osc.frequency.exponentialRampToValueAtTime(frequency, start + Math.min(0.07, cue.length * 0.3));
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(planetName === 'Jupiter' || planetName === 'Neptune' ? 900 : 3200, start);
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.linearRampToValueAtTime(cue.peak, start + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + cue.length);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + cue.length + 0.02);
    });
  } catch {
    // Audio is an enhancement; silently skip it when the browser has no usable audio context.
  }
}

/** RCS (Reaction Control System) Cold-Gas Thruster Pulse */
export function playRcsThrusterSound() {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const bufferSize = Math.floor(ctx.sampleRate * 0.15);
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1400, ctx.currentTime);
    filter.Q.setValueAtTime(1.5, ctx.currentTime);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.14);

    whiteNoise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    whiteNoise.start(ctx.currentTime);
    whiteNoise.stop(ctx.currentTime + 0.15);
  } catch {
    // Ignore
  }
}

/** Metallic Docking Clamp Lock Sound */
export function playDockingLatchSound() {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    // Heavy metallic clank
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(180, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(60, ctx.currentTime + 0.25);

    gain.gain.setValueAtTime(0.12, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);

    // High metal ring
    const ringOsc = ctx.createOscillator();
    const ringGain = ctx.createGain();
    ringOsc.type = 'sine';
    ringOsc.frequency.setValueAtTime(1840, ctx.currentTime);

    ringGain.gain.setValueAtTime(0.05, ctx.currentTime);
    ringGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);

    osc.connect(gain);
    gain.connect(ctx.destination);

    ringOsc.connect(ringGain);
    ringGain.connect(ctx.destination);

    osc.start(ctx.currentTime);
    ringOsc.start(ctx.currentTime);

    osc.stop(ctx.currentTime + 0.3);
    ringOsc.stop(ctx.currentTime + 0.45);
  } catch {
    // Ignore
  }
}

/** Error buzzer */
export function playErrorAlert() {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(150, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.22);

    gain.gain.setValueAtTime(0.06, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.25);
  } catch {
    // Ignore
  }
}

/** Success melody */
export function playSuccessChime() {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.08);

      gain.gain.setValueAtTime(0.0001, ctx.currentTime + idx * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.08, ctx.currentTime + idx * 0.08 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + idx * 0.08 + 0.26);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + idx * 0.08);
      osc.stop(ctx.currentTime + idx * 0.08 + 0.28);
    });
  } catch {
    // Ignore
  }
}

/** Rocket engine rumble */
export function playRocketLaunchSound() {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const bufferSize = ctx.sampleRate * 1.5;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(120, ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + 1.2);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.02, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.18, ctx.currentTime + 0.6);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.45);

    const subOsc = ctx.createOscillator();
    subOsc.type = 'sawtooth';
    subOsc.frequency.setValueAtTime(55, ctx.currentTime);
    subOsc.frequency.linearRampToValueAtTime(220, ctx.currentTime + 1.3);

    const subGain = ctx.createGain();
    subGain.gain.setValueAtTime(0.06, ctx.currentTime);
    subGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.3);

    whiteNoise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    subOsc.connect(subGain);
    subGain.connect(ctx.destination);

    whiteNoise.start(ctx.currentTime);
    subOsc.start(ctx.currentTime);

    whiteNoise.stop(ctx.currentTime + 1.5);
    subOsc.stop(ctx.currentTime + 1.5);
  } catch {
    // Ignore
  }
}

/** Grand Fanfare */
export function playGrandFanfare() {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const melody = [
      { f: 392.0, t: 0.0, d: 0.18 },
      { f: 523.25, t: 0.2, d: 0.18 },
      { f: 659.25, t: 0.4, d: 0.18 },
      { f: 783.99, t: 0.6, d: 0.38 },
      { f: 659.25, t: 1.0, d: 0.18 },
      { f: 783.99, t: 1.2, d: 0.6 },
    ];

    melody.forEach(n => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(n.f, ctx.currentTime + n.t);

      gain.gain.setValueAtTime(0.001, ctx.currentTime + n.t);
      gain.gain.exponentialRampToValueAtTime(0.12, ctx.currentTime + n.t + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + n.t + n.d);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + n.t);
      osc.stop(ctx.currentTime + n.t + n.d + 0.05);
    });
  } catch {
    // Ignore
  }
}

/** Authentic NASA Apollo / Shuttle Master Alarm Alternating Klaxon (1050 Hz / 820 Hz warble) */
export function playMasterAlarmKlaxon(pulses = 3) {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    for (let i = 0; i < pulses; i++) {
      const startTime = ctx.currentTime + i * 0.35;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      // Warble between 1050 Hz and 820 Hz
      osc.frequency.setValueAtTime(1050, startTime);
      osc.frequency.setValueAtTime(820, startTime + 0.15);

      gain.gain.setValueAtTime(0.001, startTime);
      gain.gain.linearRampToValueAtTime(0.09, startTime + 0.02);
      gain.gain.setValueAtTime(0.09, startTime + 0.28);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.32);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + 0.33);
    }
  } catch {
    // Ignore
  }
}

/** Radio transmission state */
let isSpeakingCapCom = false;

/**
 * NASA CapCom Voice Synthesizer
 * Uses Web Speech API with radio bandpass filter styling, Quindar tone intro & outro,
 * and broadcasts an event for UI radio subtitle HUD display.
 */
export function speakCapCom(phrase: string, onEnd?: () => void) {
  if (isAudioMuted || typeof window === 'undefined') {
    if (onEnd) onEnd();
    return;
  }

  // Play Quindar beep intro
  playQuindarTone('intro');

  // Broadcast to visual HUD listeners
  try {
    window.dispatchEvent(
      new CustomEvent('capcom-transmission', {
        detail: { text: phrase, active: true },
      })
    );
  } catch {
    // Ignore
  }

  if (!('speechSynthesis' in window)) {
    setTimeout(() => {
      playQuindarTone('outro');
      try {
        window.dispatchEvent(new CustomEvent('capcom-transmission', { detail: { text: phrase, active: false } }));
      } catch {}
      if (onEnd) onEnd();
    }, 2200);
    return;
  }

  try {
    // Stop any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(phrase);
    utterance.rate = 1.02;
    utterance.pitch = 0.92; // Slightly lower, authoritative flight director voice
    utterance.volume = 0.85;

    // Try to find a clear English voice
    const voices = window.speechSynthesis.getVoices();
    const enVoice = voices.find(v => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Samantha') || v.name.includes('Daniel') || v.name.includes('US')));
    if (enVoice) utterance.voice = enVoice;

    utterance.onend = () => {
      isSpeakingCapCom = false;
      playQuindarTone('outro');
      try {
        window.dispatchEvent(
          new CustomEvent('capcom-transmission', {
            detail: { text: phrase, active: false },
          })
        );
      } catch {
        // Ignore
      }
      if (onEnd) onEnd();
    };

    utterance.onerror = () => {
      isSpeakingCapCom = false;
      try {
        window.dispatchEvent(
          new CustomEvent('capcom-transmission', {
            detail: { text: phrase, active: false },
          })
        );
      } catch {}
      if (onEnd) onEnd();
    };

    isSpeakingCapCom = true;
    window.speechSynthesis.speak(utterance);
  } catch {
    if (onEnd) onEnd();
  }
}
