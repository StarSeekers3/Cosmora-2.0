import confetti from 'canvas-confetti';

export function fireMissionConfetti() {
  const count = 70;
  const defaults = {
    origin: { y: 0.7 },
    colors: ['#d9f36a', '#ef7144', '#72d1d6', '#fff4c7', '#ffbd6b', '#ffffff'],
    disableForReducedMotion: true,
  };

  function fire(particleRatio: number, opts: confetti.Options) {
    confetti({
      ...defaults,
      ...opts,
      particleCount: Math.floor(count * particleRatio),
    });
  }

  fire(0.25, {
    spread: 26,
    startVelocity: 55,
  });
  fire(0.2, {
    spread: 60,
  });
  fire(0.35, {
    spread: 100,
    decay: 0.91,
    scalar: 0.8,
  });
  fire(0.1, {
    spread: 120,
    startVelocity: 25,
    decay: 0.92,
    scalar: 1.2,
  });
  fire(0.1, {
    spread: 120,
    startVelocity: 45,
  });
}

export function fireRocketSparks(originX = 0.5, originY = 0.6) {
  confetti({
    particleCount: 40,
    angle: 270,
    spread: 50,
    origin: { x: originX, y: originY },
    colors: ['#ff7e29', '#ffcc00', '#ffffff', '#ef7144'],
    startVelocity: 35,
    ticks: 150,
    gravity: 1.2,
  });
}

export function fireCertificateGrandConfetti() {
  const end = Date.now() + 2.5 * 1000;
  const colors = ['#d9f36a', '#ef7144', '#72d1d6', '#ffc93c', '#ffffff'];

  (function frame() {
    confetti({
      particleCount: 4,
      angle: 60,
      spread: 55,
      origin: { x: 0 },
      colors: colors,
    });
    confetti({
      particleCount: 4,
      angle: 120,
      spread: 55,
      origin: { x: 1 },
      colors: colors,
    });

    if (Date.now() < end) {
      requestAnimationFrame(frame);
    }
  })();
}
