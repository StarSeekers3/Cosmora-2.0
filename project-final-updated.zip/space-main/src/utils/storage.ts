import { AstronautProfile, MissionHistoryRecord } from '../types';
import { MISSIONS } from '../data/missionsData';
import { calculateMissionGrade, NASA_MISSION_TELEMETRY } from '../data/missionTelemetryData';

const STORAGE_KEY = 'missionAcademyProfile';
const THEME_KEY = 'missionAcademyTheme';
const REDUCE_MOTION_KEY = 'missionAcademyReduceMotion';
const DAY_NIGHT_KEY = 'missionAcademyDayNightCycle';

export const COSMORA_STORAGE_VERSION = 2;

export function loadProfile(): AstronautProfile | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;

    // Schema version migration: version 1 -> 2
    const currentVersion = typeof parsed.version === 'number' ? parsed.version : 1;
    const completedList: number[] = Array.isArray(parsed.completed)
      ? Array.from(new Set(parsed.completed.filter((id: any) => typeof id === 'number' && Number.isFinite(id))))
      : [];

    const profile: AstronautProfile = {
      name: typeof parsed.name === 'string' && parsed.name.trim() ? parsed.name.trim() : 'Astronaut Cadet',
      avatar: typeof parsed.avatar === 'string' ? parsed.avatar : '👩‍🚀',
      points: Number.isFinite(parsed.points) && parsed.points >= 0 ? Math.round(parsed.points) : 0,
      completed: completedList,
      achievements: Array.isArray(parsed.achievements) ? parsed.achievements : [],
      registeredAt: typeof parsed.registeredAt === 'string' ? parsed.registeredAt : new Date().toISOString(),
      soundEnabled: parsed.soundEnabled ?? true,
      flightHours: Number.isFinite(parsed.flightHours) ? parsed.flightHours : completedList.length * 2,
      dockingScore: Number.isFinite(parsed.dockingScore) ? parsed.dockingScore : undefined,
      lunarLandings: Number.isFinite(parsed.lunarLandings) ? parsed.lunarLandings : undefined,
      missionHistory: Array.isArray(parsed.missionHistory) ? parsed.missionHistory : [],
      version: COSMORA_STORAGE_VERSION,
    };

    // If migrating from older version, write back upgraded schema
    if (currentVersion < COSMORA_STORAGE_VERSION) {
      saveProfile(profile);
    }

    return profile;
  } catch (err) {
    console.warn('Storage read failed or data corrupted, resetting to safe defaults', err);
    return null;
  }
}

export function saveProfile(profile: AstronautProfile) {
  try {
    const payload: AstronautProfile = {
      ...profile,
      version: COSMORA_STORAGE_VERSION,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  } catch (e) {
    console.warn('Could not save progress to localStorage', e);
  }
}

export function resetProfileData(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.warn('Could not reset profile in localStorage', e);
  }
}

export function completeMissionInStorage(missionId: number, pointsEarned: number): AstronautProfile {
  const current = loadProfile() || {
    name: 'Astronaut Cadet',
    avatar: '👩‍🚀',
    points: 0,
    completed: [],
    achievements: [],
    registeredAt: new Date().toISOString(),
    soundEnabled: true,
    missionHistory: [],
    version: COSMORA_STORAGE_VERSION,
  };

  const isFirstTime = !current.completed.includes(missionId);
  const completed = isFirstTime ? [...current.completed, missionId] : current.completed;

  // Prevent duplicate points reward:
  // If first time, award full points. If re-flying, only award upgrade delta if new score > previous score.
  const currentHistory = current.missionHistory || [];
  const existingRecord = currentHistory.find(h => h.missionId === missionId);
  let newPoints = current.points;

  if (isFirstTime) {
    newPoints += pointsEarned;
  } else if (existingRecord && pointsEarned > existingRecord.score) {
    // Re-flight bonus: only add the delta improvement
    newPoints += pointsEarned - existingRecord.score;
  }

  // Build new MissionHistoryRecord
  const missionMeta = MISSIONS.find(m => m.id === missionId);
  const grading = calculateMissionGrade(pointsEarned, missionMeta?.points || 50);
  const telemetry = NASA_MISSION_TELEMETRY[missionId] || {
    vehicle: 'NASA Multi-Purpose Exploration Vehicle',
    destination: 'Planetary Exploration Coordinates',
    maxVelocity: '28,000 km/h',
    peakGForce: '+3.0 G',
    altitude: '400 km orbital baseline',
    deltaV: 'Δv 2,400 m/s',
    nasaRefDoc: 'NASA-SP-2020-5001 Mission Archive',
    discoveryNote: 'Nominal flight performance logged to NASA mission archive.',
    trajectoryType: 'Orbital Keplerian Trajectory',
  };

  const now = new Date();
  const metHours = String(Math.floor(Math.random() * 8) + 1).padStart(2, '0');
  const metMins = String(Math.floor(Math.random() * 59)).padStart(2, '0');
  const metSecs = String(Math.floor(Math.random() * 59)).padStart(2, '0');

  const newRecord: MissionHistoryRecord = {
    missionId,
    missionTitle: missionMeta?.title || `Flight #${missionId}`,
    category: missionMeta?.category || 'AEROSPACE OPERATION',
    icon: missionMeta?.icon || '🚀',
    completedAt: now.toISOString(),
    metTime: `MET +${metHours}:${metMins}:${metSecs}`,
    score: pointsEarned,
    maxScore: missionMeta?.points || 50,
    grade: grading.grade,
    gradeTitle: grading.gradeTitle,
    feedback: grading.feedback,
    telemetry,
  };

  // Filter out older duplicate and prepend latest flight record
  const updatedHistory = [newRecord, ...currentHistory.filter(h => h.missionId !== missionId)];

  const updated: AstronautProfile = {
    ...current,
    completed,
    points: newPoints,
    flightHours: (current.flightHours || 0) + 1,
    missionHistory: updatedHistory,
    version: COSMORA_STORAGE_VERSION,
  };

  saveProfile(updated);
  return updated;
}

export function getStoredTheme(): 'dark' | 'light' {
  try {
    const theme = localStorage.getItem(THEME_KEY);
    return theme === 'light' ? 'light' : 'dark';
  } catch {
    return 'dark';
  }
}

export function setStoredTheme(theme: 'dark' | 'light') {
  try {
    localStorage.setItem(THEME_KEY, theme);
    document.documentElement.dataset.theme = theme;
    if (theme === 'light') {
      document.documentElement.classList.add('light-mode');
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.remove('light-mode');
      document.documentElement.classList.add('dark');
    }
  } catch (e) {
    console.warn('Could not save theme', e);
  }
}

export function getStoredReduceMotion(): boolean {
  try {
    const stored = localStorage.getItem(REDUCE_MOTION_KEY);
    if (stored !== null) return stored === 'true';
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    return false;
  } catch {
    return false;
  }
}

export function setStoredReduceMotion(reduce: boolean) {
  try {
    localStorage.setItem(REDUCE_MOTION_KEY, String(reduce));
    document.documentElement.dataset.reduceMotion = String(reduce);
  } catch {
    // Motion preference remains active for the current session if storage is unavailable.
  }
}

export function getStoredDayNightCycle(): boolean {
  try {
    return localStorage.getItem(DAY_NIGHT_KEY) !== 'false';
  } catch {
    return true;
  }
}

export function setStoredDayNightCycle(enabled: boolean) {
  try {
    localStorage.setItem(DAY_NIGHT_KEY, String(enabled));
  } catch {
    // The cycle preference remains active for the current session if storage is unavailable.
  }
}
