import type { NtrsRecord } from '../types';

/**
 * NTRS (NASA Technical Reports Server) sources for quiz claims.
 *
 * Two tiers:
 *  1. PINNED  - a specific NTRS record whose existence, title, authors and date were verified, with a note on what it does and does not support.
 *               Every ID here was verified against its ntrs.nasa.gov record (title, authors, date).
 *  2. LIVE    - any question without a pinned record gets a live NTRS keyword search at runtime
 *               (see components/nasa/NtrsSources.tsx), so no claim is ever shown with an invented ID.
 *
 * To pin another source: add the record to NTRS_PINNED and list its id under the question key
 * ("<missionId>:<questionIndex>", index is 0-based) in QUESTION_SOURCES. Do not add an ID you have
 * not opened on ntrs.nasa.gov.
 */

export const NTRS_ATTRIBUTION = 'Data provided by NASA Scientific and Technical Information Program (https://ntrs.nasa.gov/api/openapi/)';

export const ntrsUrl = (id: string) => `https://ntrs.nasa.gov/citations/${id}`;
export const ntrsSearchUrl = (query: string) => `https://ntrs.nasa.gov/search?q=${encodeURIComponent(query)}`;

export interface PinnedNtrs extends NtrsRecord {
  /** What this record does (and does not) support, in plain words, so the link is not over-claimed. */
  supports: string;
}

export const NTRS_PINNED: Record<string, PinnedNtrs> = {
  '19980223621': {
    id: '19980223621',
    title: 'Centrifuge Study of Pilot Tolerance to Acceleration and the Effects of Acceleration on Pilot Performance',
    authors: ['Creer, Brent Y.', 'Smedal, Harald A.', 'Wingrove, Rodney C.'],
    year: 1960,
    center: 'Ames Research Center',
    reportNumber: 'NASA-TN-D-337',
    url: ntrsUrl('19980223621'),
    supports:
      'Human centrifuge runs that established tolerance limits for acceleration fields like those on an orbital vehicle, and showed pilot control performance degrading above roughly 4 g in some conditions.',
  },
  '19980227853': {
    id: '19980227853',
    title: 'Physiological Effects of Acceleration Observed During a Centrifuge Study of Pilot Performance',
    authors: ['Smedal, Harald A.', 'Creer, Brent Y.', 'Wingrove, Rodney C.'],
    year: 1960,
    center: 'Ames Research Center',
    reportNumber: 'NASA-TN-D-345',
    url: ntrsUrl('19980227853'),
    supports:
      'Cardiovascular, respiratory and visual effects of sustained acceleration in centrifuge runs, including a run ended when the subject "grayed out". It does not cover the Anti-G Straining Maneuver technique itself.',
  },
  '19960020257': {
    id: '19960020257',
    title: 'First flight test results of the Simplified Aid For EVA Rescue (SAFER) propulsion unit',
    authors: ['Meade, Carl J.'],
    year: 1995,
    center: 'Johnson Space Center',
    url: ntrsUrl('19960020257'),
    supports:
      'SAFER is a small self-contained propulsive backpack for contingency self-rescue of a separated spacewalker; describes the 6.9-hour STS-64 flight test.',
  },
  '20050160460': {
    id: '20050160460',
    title: 'The Effects of Lunar Dust on EVA Systems During the Apollo Missions',
    authors: ['Gaier, James R.'],
    year: 2005,
    center: 'Glenn Research Center',
    reportNumber: 'NASA/TM-2005-213610',
    url: ntrsUrl('20050160460'),
    supports:
      'Catalogues dust effects from all six Apollo landings: vision obscuration, coating, clogging, abrasion, thermal-control problems, seal failures and inhalation/irritation.',
  },
};

/** "<missionId>:<questionIndex>" -> pinned NTRS ids. */
export const QUESTION_SOURCES: Record<string, string[]> = {
  // Mission 1 - Centrifuge: why blood flow to the head matters under +Gz, and gray-out progression
  '1:0': ['19980227853', '19980223621'],
  '1:2': ['19980227853'],
  // Mission 5 - EVA: SAFER emergency propulsion backpack
  '5:1': ['19960020257'],
  // Mission 7 - Lunar: regolith hazards to suits and equipment
  '7:2': ['20050160460'],
};

export const questionKey = (missionId: number, questionIndex: number) => `${missionId}:${questionIndex}`;

export const pinnedFor = (missionId: number, questionIndex: number): PinnedNtrs[] =>
  (QUESTION_SOURCES[questionKey(missionId, questionIndex)] ?? [])
    .map(id => NTRS_PINNED[id])
    .filter((r): r is PinnedNtrs => Boolean(r));

/**
 * Build a focused NTRS keyword query from a quiz prompt: drop question words and filler, keep the
 * technical nouns. A question can override this with `ntrsQuery`.
 */
const STOP = new Set(
  ('what why how which who does do did is are was were the a an of to in on at for from by with without and or but if then than that this these those ' +
    'it its their they them your you our we astronaut astronauts nasa during before after into out over under so as be can could would should will ' +
    'happen occurs occur most more less much many each every any only also use used using called named known call roughly about instead rather').split(' '),
);

export function deriveNtrsQuery(prompt: string, override?: string): string {
  if (override?.trim()) return override.trim();
  const tokens = prompt
    .replace(/[\u2018\u2019]s\b/g, '') // possessives
    .replace(/[^A-Za-z0-9\s-]/g, ' ')
    .split(/\s+/)
    .map((word, position) => ({ word, position }))
    // Numbers and number-led compounds ("6.2-million-gallon") make poor keywords.
    .filter(({ word }) => word.length > 2 && !/\d/.test(word) && !STOP.has(word.toLowerCase()));

  // Technical terms carry the topic: acronyms and proper nouns first, then long words.
  const score = ({ word, position }: { word: string; position: number }) =>
    (/^[A-Z]{2,}/.test(word) ? 3 : 0) + (position > 0 && /^[A-Z]/.test(word) ? 2 : 0) + (word.length >= 8 ? 1 : 0);

  const top = [...tokens].sort((a, b) => score(b) - score(a) || a.position - b.position).slice(0, 6);
  // Back to reading order; very long queries over-constrain the search.
  return top.sort((a, b) => a.position - b.position).map(t => t.word).join(' ');
}
