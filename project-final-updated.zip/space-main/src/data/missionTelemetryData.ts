import { MissionTelemetryData, MissionHistoryRecord } from '../types';
import { MISSIONS } from './missionsData';

export const NASA_MISSION_TELEMETRY: Record<number, MissionTelemetryData> = {
  1: {
    vehicle: 'NASA Ames 20G Human Centrifuge Rig',
    destination: 'Sub-Orbital G-Force Training Sim',
    maxVelocity: '124 km/h (centrifuge tip speed)',
    peakGForce: '+4.5 G sustained (Z-axis)',
    altitude: 'Sea Level (Ames Research Center)',
    deltaV: 'N/A (Ground Test)',
    nasaRefDoc: 'NASA-TM-X-58017 Human Centrifuge Protocol',
    discoveryNote: 'Cadet maintained full optical visual field and cognitive response under 4.5 G sustained acceleration with anti-G straining maneuvers.',
    trajectoryType: 'Radial Centrifugal Acceleration',
  },
  2: {
    vehicle: 'Space Launch System (SLS) Block 1 & Orion',
    destination: 'Low Earth Orbit (LEO) Insertion',
    maxVelocity: '28,100 km/h (7.8 km/s)',
    peakGForce: '+3.8 G at core booster cutoff',
    altitude: '185 km initial orbital apogee',
    deltaV: 'Δv 9,250 m/s (ascent to orbit)',
    nasaRefDoc: 'NASA SLS-SPEC-3001 Launch Trajectory Data',
    discoveryNote: 'Four RS-25 cryogenic core engines and twin 5-segment solid rocket boosters delivered 8.8 million pounds of thrust within 0.02% of nominal trajectory.',
    trajectoryType: 'Gravity Turn Orbital Ascent',
  },
  3: {
    vehicle: 'Orion Crew Exploration Vehicle (Artemis)',
    destination: 'Trans-Atmospheric Max-Q Transition',
    maxVelocity: '7,400 km/h through Kármán line',
    peakGForce: '+3.2 G (dynamic pressure peak)',
    altitude: '100 km (Kármán Boundary crossed)',
    deltaV: 'Δv 1,840 m/s (first stage boost)',
    nasaRefDoc: 'NASA-TM-2022-219800 Orion Ascent Pressure Log',
    discoveryNote: 'Spacecraft withstood maximum aerodynamic pressure (Max-Q: 38.4 kPa) at T+78 seconds. Jettisoned fairing panels and launch abort tower smoothly.',
    trajectoryType: 'Atmospheric Boundary Penetration',
  },
  4: {
    vehicle: 'ISS Columbus & Destiny Science Modules',
    destination: 'International Space Station Microgravity Lab',
    maxVelocity: '27,600 km/h (orbital free-fall)',
    peakGForce: '0.0001 G (microgravity equilibrium)',
    altitude: '418 km circular orbital plane',
    deltaV: 'Δv 14 m/s (station keeping)',
    nasaRefDoc: 'NASA SP-2008-568 Ch. 7 Microgravity Fluidics',
    discoveryNote: 'Mastered 3-axis spatial orientation and fluid surface tension dynamics in continuous microgravity free-fall without vestibular disorientation.',
    trajectoryType: 'Low Earth Orbit (LEO) 51.6° Inclination',
  },
  5: {
    vehicle: 'Enhanced Extravehicular Mobility Unit (xEMU)',
    destination: 'ISS Truss Segment P6 / Solar Array Alpha Joint',
    maxVelocity: '27,600 km/h (relative velocity: 0.2 m/s)',
    peakGForce: '0.0001 G (tethered spacewalk)',
    altitude: '422 km above Pacific Ocean',
    deltaV: '0.8 m/s (SAFER nitrogen thruster pack)',
    nasaRefDoc: 'NASA JSC-65995 EVA Operations & Safety Manual',
    discoveryNote: 'Completed 6h 42m extravehicular activity with 100% tether lock compliance, inspecting thermal radiators and high-gain S-band antennas.',
    trajectoryType: 'Co-Orbital Tethered EVA',
  },
  6: {
    vehicle: 'Crew Exploration Spacecraft (Orion/Dragon)',
    destination: 'ISS Harmony Forward Port (PMA-2 / IDA)',
    maxVelocity: '0.05 m/s at contact latching',
    peakGForce: '+0.05 G soft capture contact',
    altitude: '416 km rendezvous orbit',
    deltaV: 'Δv 18.4 m/s (proximity operations)',
    nasaRefDoc: 'NASA IDSS Interface Definition Document Rev E',
    discoveryNote: 'Captured International Docking System Standard (IDSS) soft latches within ±0.08m lateral alignment and 0.05 m/s closure rate.',
    trajectoryType: 'R-Bar Proximity Glideslope Approach',
  },
  7: {
    vehicle: 'Artemis Human Landing System (HLS)',
    destination: 'Lunar South Pole (Shackleton Crater Rim)',
    maxVelocity: '1.2 m/s touchdown descent rate',
    peakGForce: '+1.4 G (powered descent braking)',
    altitude: 'Surface Elevation 0 km (1,737 km Moon radius)',
    deltaV: 'Δv 1,820 m/s (powered descent initiation)',
    nasaRefDoc: 'NASA Artemis III Science Definition Report',
    discoveryNote: 'Targeted touchdown on permanent sunlight ridge near Shackleton crater with hazard detection lidar, confirming presence of water ice volatiles.',
    trajectoryType: 'Powered Descent Terminal Touchdown',
  },
  8: {
    vehicle: 'Ingenuity Mars Helicopter & Perseverance Rover',
    destination: 'Jezero Crater Ancient River Delta, Mars',
    maxVelocity: '12.0 m/s (rotor tip speed: 0.72 Mach)',
    peakGForce: '+1.6 G aerodynamic maneuver',
    altitude: '14 meters AGL (Mars surface datum)',
    deltaV: 'N/A (Rotor Aerodynamic Lift)',
    nasaRefDoc: 'JPL Mars 2020 Mission Report D-104230',
    discoveryNote: 'Autonomous flight achieved in 0.006 atm thin carbon dioxide atmosphere at 2,500 RPM rotor speed, scouting sample extraction paths for Perseverance.',
    trajectoryType: 'Martian Planetary Rotor Aerodynamics',
  },
  9: {
    vehicle: 'Parker Solar Probe (WISPR/FIELDS)',
    destination: 'Solar Corona Perihelion (Within Alfven Point)',
    maxVelocity: '692,000 km/h (192 km/s - fastest human object)',
    peakGForce: 'Sun Gravity Gradient',
    altitude: '6.1 Million km from solar photosphere',
    deltaV: 'Δv 3,200 m/s (Venus gravity assists x7)',
    nasaRefDoc: 'NASA Parker Science Investigation APL-16-004',
    discoveryNote: 'Survived 1,400°C coronal plasma heating behind 11.4 cm carbon-composite heat shield, discovering magnetic switchbacks and coronal mass ejection origins.',
    trajectoryType: 'Venus Resonance Elliptical Sun Graze',
  },
  10: {
    vehicle: 'Double Asteroid Redirection Test (DART)',
    destination: 'Didymos-Dimorphos Binary Asteroid System',
    maxVelocity: '22,530 km/h (6.26 km/s impact)',
    peakGForce: 'Kinetic impact terminal deceleration',
    altitude: 'Surface contact Dimorphos',
    deltaV: 'Δv 1,240 m/s (autonomous SMART Nav)',
    nasaRefDoc: 'NASA Planetary Defense Officer Report DART-01',
    discoveryNote: 'Direct kinetic impact altered asteroid Dimorphos orbital period by 33 minutes (exceeding NASA 73-second requirement by 25x), proving planetary defense viability.',
    trajectoryType: 'Terminal Hypervelocity Kinetic Intercept',
  },
  11: {
    vehicle: 'Solar System Gravity Cartography Array',
    destination: 'Planetary Gravitational Centers',
    maxVelocity: 'Variable planetary orbital velocities',
    peakGForce: '0.38G to 2.53G planetary surfaces',
    altitude: 'Orbital periapsis across 8 planets',
    deltaV: 'Δv 4,800 m/s multi-body survey',
    nasaRefDoc: 'NASA Planetary Science Decadal Survey',
    discoveryNote: 'Calculated precise mass anomalies and core density distributions across Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune.',
    trajectoryType: 'Multi-Planet Geodesic Mapping Tour',
  },
  12: {
    vehicle: 'Europa Clipper Spacecraft',
    destination: 'Jupiter Moon Europa Flyby Trajectory',
    maxVelocity: '16.8 km/s (Europa closest approach)',
    peakGForce: 'Jupiter Radiation Belt Magnetic Shear',
    altitude: '25 km above Europa ice crust',
    deltaV: 'Δv 840 m/s (gravity assist trajectory)',
    nasaRefDoc: 'NASA Europa Clipper Mission Plan JPL-D-102500',
    discoveryNote: 'REASON ice-penetrating radar sounded through the 20 km brittle ice shell, mapping subsurface liquid water conduits and global saline ocean depth.',
    trajectoryType: 'Resonant Jovian Radiation-Tolerant Flyby',
  },
  13: {
    vehicle: 'Dragonfly Rotorcraft Lander',
    destination: 'Titan Shangri-La Dunes & Selk Impact Crater',
    maxVelocity: '36 km/h flight in dense N2 atmosphere',
    peakGForce: '+1.2 G flight acceleration (Titan 0.14g)',
    altitude: '400 meters above methane seas',
    deltaV: 'Octocopter Electric Nuclear MM-RTG Power',
    nasaRefDoc: 'NASA New Frontiers Dragonfly Architecture APL-19',
    discoveryNote: 'Navigated 1.5x Earth barometric pressure atmosphere with quadrupled density, sampling prebiotic tholins and amino acid building blocks in liquid methane.',
    trajectoryType: 'Titan Dense-Atmosphere Multi-Hop Flight',
  },
  14: {
    vehicle: 'James Webb Space Telescope (JWST)',
    destination: 'Sun-Earth Lagrange Point 2 (SE-L2)',
    maxVelocity: '0.2 km/s halo orbit station-keeping',
    peakGForce: '0.00001 G (ultra-quiet optical bench)',
    altitude: '1,500,000 km from Earth',
    deltaV: 'Δv 42 m/s (mid-course correction burn)',
    nasaRefDoc: 'NASA JWST Commissioning Report STScI-2022-01',
    discoveryNote: 'Aligned 18 hexagonal gold-beryllium mirror segments to within 13 nanometers of perfect optical wavefront, detecting first galaxies 13.5 billion years old.',
    trajectoryType: 'Lagrange Point 2 (L2) Quasi-Halo Orbit',
  },
  15: {
    vehicle: 'TESS & Kepler Space Telescope Array',
    destination: 'Deep Sky Stellar Photometry Field',
    maxVelocity: 'P-2 High-Earth Lunar-Resonant Orbit',
    peakGForce: 'Zero-disturbance reaction wheel control',
    altitude: '108,000 km apogee (TESS orbit)',
    deltaV: 'Δv 12 m/s (trim burns)',
    nasaRefDoc: 'NASA Exoplanet Exploration Program Archive',
    discoveryNote: 'Detected 0.01% transit light curve dip indicating a rocky super-Earth exoplanet orbiting within the circumstellar habitable liquid-water zone.',
    trajectoryType: '2:1 Lunar Resonant Orbit (TESS P/2)',
  },
  16: {
    vehicle: 'LIGO & Cosmic Gravitational Wave Observatory',
    destination: 'Spacetime Strain Measurement Coordinates',
    maxVelocity: 'c (Speed of light: 299,792 km/s)',
    peakGForce: 'Metric perturbation h ~ 10^-21',
    altitude: 'Ground & Space Interferometer Arms',
    deltaV: 'Laser cavity optical phase tracking',
    nasaRefDoc: 'NSF / NASA Joint Astrophysics Report GW-170817',
    discoveryNote: 'Detected 100 Hz gravitational wave chirp originating from binary neutron star merger 130 million light-years away, confirming heavy element nucleosynthesis.',
    trajectoryType: 'Quadrupole Spacetime Wavefront',
  },
  17: {
    vehicle: 'NASA Deep Space Network (DSS-14 Goldstone)',
    destination: 'Deep Space Radio Communication Network',
    maxVelocity: '300,000 km/s (X-band radio beam)',
    peakGForce: 'N/A (70-meter Cassegrain dish)',
    altitude: 'Deep space reception (out to 24B km)',
    deltaV: '20 kW high-power klystron transmitter',
    nasaRefDoc: 'NASA DSN Telecommunications Handbook 810-005',
    discoveryNote: 'Acquired 8.4 GHz X-band carrier lock at -162 dBm signal threshold, establishing uninterrupted uplink with robotic craft across deep interplanetary space.',
    trajectoryType: 'Deep Space Optical & Radio Vector',
  },
  18: {
    vehicle: 'Voyager 1 & 2 Interstellar Spacecraft',
    destination: 'Interstellar Space (Beyond Heliopause Boundary)',
    maxVelocity: '61,200 km/h (17.0 km/s escape speed)',
    peakGForce: 'Galactic cosmic ray environment',
    altitude: '24,400,000,000 km from Sun (163 AU)',
    deltaV: 'Jupiter & Saturn planetary gravity slingshots',
    nasaRefDoc: 'NASA Voyager Interstellar Mission Summary JPL-400',
    discoveryNote: 'Crossed the heliopause into interstellar space. Solar wind particle flux dropped to zero while galactic cosmic ray intensity jumped by 40%.',
    trajectoryType: 'Hyperbolic Solar System Escape Vector',
  },
  19: {
    vehicle: 'Cosmora Deep Space Modular Outpost',
    destination: 'Cislunar Gateway Orbit (Near-Rectilinear Halo)',
    maxVelocity: '1.4 km/s NRHO orbital speed',
    peakGForce: '0.0001 G nominal habitat',
    altitude: '3,000 km pericenter / 70,000 km apocenter',
    deltaV: 'Δv 38 m/s (annual station keeping)',
    nasaRefDoc: 'NASA-TM-20210018241 Deep Space Habitat Ops',
    discoveryNote: 'Maintained 98% closed-loop oxygen and water recycling efficiency through Sabatier reduction and catalytic oxidation during prolonged deep space crew habitation.',
    trajectoryType: 'Near-Rectilinear Halo Orbit (NRHO)',
  },
};

/**
 * Calculates a NASA-style performance grade and feedback based on mission points.
 */
export function calculateMissionGrade(pointsEarned: number, maxPoints = 50): {
  grade: 'S' | 'A+' | 'A' | 'B';
  gradeTitle: string;
  feedback: string;
} {
  const ratio = pointsEarned / maxPoints;

  if (ratio >= 0.95) {
    return {
      grade: 'S',
      gradeTitle: 'OPTIMUM TRAJECTORY',
      feedback: 'Flawless mission execution. All NASA telemetry tolerances met within 0.05% of baseline standard.',
    };
  }
  if (ratio >= 0.82) {
    return {
      grade: 'A+',
      gradeTitle: 'EXEMPLARY FLIGHT',
      feedback: 'Superior orbital navigation. Mission objectives completed with exemplary system management.',
    };
  }
  if (ratio >= 0.65) {
    return {
      grade: 'A',
      gradeTitle: 'NOMINAL FLIGHT',
      feedback: 'Standard NASA mission flight criteria achieved. Telemetry logged within acceptable operating bands.',
    };
  }
  return {
    grade: 'B',
    gradeTitle: 'CERTIFIED FLIGHT',
    feedback: 'Mission objectives accomplished. Minor trajectory deviations corrected via automated guidance.',
  };
}

/**
 * Returns complete mission history records for an astronaut profile.
 * If the profile has completed missions without explicit records, generates authentic
 * historical entries with real NASA specs and deterministic dates.
 */
export function getProfileMissionHistory(
  completedIds: number[],
  storedHistory: MissionHistoryRecord[] = [],
  baseDate = '2026-10-25T14:30:00Z'
): MissionHistoryRecord[] {
  const existingMap = new Map<number, MissionHistoryRecord>();
  storedHistory.forEach(record => existingMap.set(record.missionId, record));

  const records: MissionHistoryRecord[] = [];

  completedIds.forEach((id, index) => {
    if (existingMap.has(id)) {
      records.push(existingMap.get(id)!);
      return;
    }

    const missionMeta = MISSIONS.find(m => m.id === id);
    if (!missionMeta) return;

    const telemetry = NASA_MISSION_TELEMETRY[id] || {
      vehicle: 'NASA Multi-Purpose Exploration Vehicle',
      destination: 'Planetary Exploration Coordinates',
      maxVelocity: '28,000 km/h',
      peakGForce: '+3.0 G',
      altitude: '400 km orbital baseline',
      deltaV: 'Δv 2,400 m/s',
      nasaRefDoc: 'NASA-SP-2020-5001 Mission Archive',
      discoveryNote: 'Nominal flight performance logged to NASA mission archive.',
      trajectoryType: 'Orbital Keplerian Trajectory',
    };

    // Calculate deterministic realistic timestamp based on mission index
    const baseTime = new Date(baseDate).getTime();
    const flightTime = new Date(baseTime + index * (14 * 60 * 60 * 1000) + (id * 37 * 60 * 1000));
    const hoursElapsed = (index + 1) * 2 + (id % 5);
    const minsElapsed = 12 + (id * 7) % 45;
    const secsElapsed = (id * 13) % 60;
    const met = `MET +${String(hoursElapsed).padStart(2, '0')}:${String(minsElapsed).padStart(2, '0')}:${String(secsElapsed).padStart(2, '0')}`;

    const score = missionMeta.points || 50;
    const grading = calculateMissionGrade(score, 50);

    records.push({
      missionId: id,
      missionTitle: missionMeta.title,
      category: missionMeta.category,
      icon: missionMeta.icon,
      completedAt: flightTime.toISOString(),
      metTime: met,
      score,
      maxScore: 50,
      grade: grading.grade,
      gradeTitle: grading.gradeTitle,
      feedback: grading.feedback,
      telemetry,
    });
  });

  // Sort by most recent first
  return records.sort((a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime());
}

/**
 * Pre-baked sample mission history for demonstration when cadet is just starting out
 */
export const SAMPLE_NASA_SIMULATED_FLIGHTS: MissionHistoryRecord[] = [
  {
    missionId: 7,
    missionTitle: 'Artemis Lunar Lander Touchdown',
    category: 'LUNAR RECONNAISSANCE',
    icon: '🌕',
    completedAt: '2026-10-29T08:14:22Z',
    metTime: 'MET +04:18:32',
    score: 50,
    maxScore: 50,
    grade: 'S',
    gradeTitle: 'OPTIMUM TRAJECTORY',
    feedback: 'Precision rocket touchdown executed at Shackleton crater rim. Descent rate 0.9 m/s with hazard lidar lock.',
    telemetry: NASA_MISSION_TELEMETRY[7],
  },
  {
    missionId: 6,
    missionTitle: 'RCS Docking with the Space Station',
    category: 'ORBITAL MANEUVERS',
    icon: '🛰️',
    completedAt: '2026-10-28T19:42:10Z',
    metTime: 'MET +02:45:18',
    score: 48,
    maxScore: 50,
    grade: 'A+',
    gradeTitle: 'EXEMPLARY FLIGHT',
    feedback: 'Docking crosshair centered within 0.08m lateral error. Soft capture latches locked smoothly with ISS Harmony module.',
    telemetry: NASA_MISSION_TELEMETRY[6],
  },
  {
    missionId: 2,
    missionTitle: 'Terminal Countdown & Rocket Launch',
    category: 'PROPULSION & ASCENT',
    icon: '🚀',
    completedAt: '2026-10-27T14:02:45Z',
    metTime: 'MET +00:08:42',
    score: 45,
    maxScore: 50,
    grade: 'A',
    gradeTitle: 'NOMINAL FLIGHT',
    feedback: 'SLS core stage RS-25 ignition nominal. Max-Q passed at T+78s with zero structural flutter.',
    telemetry: NASA_MISSION_TELEMETRY[2],
  },
  {
    missionId: 14,
    missionTitle: 'James Webb Mirror Segment Alignment',
    category: 'DEEP SPACE OBSERVATORY',
    icon: '🔭',
    completedAt: '2026-10-26T22:15:30Z',
    metTime: 'MET +28:12:00',
    score: 50,
    maxScore: 50,
    grade: 'S',
    gradeTitle: 'OPTIMUM TRAJECTORY',
    feedback: 'Aligned 18 beryllium hexagons to within 13 nanometers wavefront precision at Sun-Earth L2 halo orbit.',
    telemetry: NASA_MISSION_TELEMETRY[14],
  },
];
