export interface AvatarOption {
  icon: string;
  name: string;
  color: string;
  role: string;
  suitDescription: string;
}

export interface AchievementBadge {
  id: string;
  title: string;
  icon: string;
  description: string;
  unlocked: boolean;
  unlockedAt?: string;
}

export interface MissionTelemetryData {
  vehicle: string;
  destination: string;
  maxVelocity: string;
  peakGForce: string;
  altitude: string;
  deltaV: string;
  nasaRefDoc: string;
  discoveryNote: string;
  trajectoryType: string;
}

export interface MissionHistoryRecord {
  missionId: number;
  missionTitle: string;
  category: string;
  icon: string;
  completedAt: string; // ISO date string
  metTime: string; // e.g. "MET +04:18:32"
  score: number;
  maxScore: number;
  grade: 'S' | 'A+' | 'A' | 'B';
  gradeTitle: string;
  feedback: string;
  telemetry: MissionTelemetryData;
}

export interface AstronautProfile {
  name: string;
  avatar: string;
  points: number;
  completed: number[];
  achievements?: string[];
  registeredAt?: string;
  soundEnabled?: boolean;
  flightHours?: number;
  dockingScore?: number;
  lunarLandings?: number;
  missionHistory?: MissionHistoryRecord[];
  version?: number;
}

export interface QuizQuestion {
  prompt: string;
  options: string[];
  answer: number;
  explanation: string;
  funFact?: string;
  /**
   * Optional override for the NASA Technical Reports Server (NTRS) lookup that backs this
   * question's factual claim. If omitted, the lookup is derived from the question prompt.
   */
  ntrsQuery?: string;
}

export interface Mission {
  id: number;
  icon: string;
  category: string;
  title: string;
  subtitle: string;
  desc: string;
  points: number;
  briefing: string;
  objective: string;
  difficulty?: 'Beginner' | 'Intermediate' | 'Advanced';
  estimatedDuration?: string;
  scientificPrinciple?: string;
  interactiveType:
    | 'launch'
    | 'gravity'
    | 'planets'
    | 'eva'
    | 'blackhole'
    | 'docking'
    | 'lunar'
    | 'jwst'
    | 'clipper'
    | 'dart'
    | 'voyager'
    | 'centrifuge'
    | 'ascent'
    | 'perseverance'
    | 'parker'
    | 'dragonfly'
    | 'exoplanet'
    | 'gravwaves'
    | 'outpost'
    | 'quiz';
  questions: QuizQuestion[];
}

export interface PlanetInfo {
  name: string;
  tagline: string;
  type: 'Terrestrial' | 'Gas Giant' | 'Ice Giant' | 'Dwarf Planet';
  distanceFromSun: string;
  dayLength: string;
  yearLength: string;
  temperature: string;
  gravityVsEarth: number;
  moons: number;
  color: string;
  gradient: string;
  diameterKm: string;
  atmosphere: string;
  overview: string;
  funFact: string;
}

export interface NasaApodData {
  title: string;
  explanation: string;
  url: string;
  hdurl?: string;
  date: string;
  copyright?: string;
  media_type?: string;
  /** Present when APOD is a video and the request used thumbs=true. */
  thumbnail_url?: string;
}

export interface MarsWeatherRecord {
  sol: number;
  terrestrialDate: string;
  minTempC: number;
  maxTempC: number;
  pressurePa: number;
  windSpeedKmh: number;
  uvIndex: string;
  season: string;
  atmosphereStatus: string;
}

export interface NearEarthObject {
  id: string;
  name: string;
  estimatedDiameterMeters: { min: number; max: number };
  closeApproachDate: string;
  relativeVelocityKmh: number;
  missDistanceKm: number;
  isPotentiallyHazardous: boolean;
}

export interface Constellation {
  id: string;
  name: string;
  latinName: string;
  englishMeaning: string;
  brightestStar: string;
  season: 'Spring' | 'Summer' | 'Autumn' | 'Winter' | 'Circumpolar';
  mythology: string;
  astrophysicsFact: string;
  starsCount: number;
  majorStars: { name: string; distanceLy: number; spectralType: string; x: number; y: number }[];
  lines: [number, number][]; // pairs of star indices to connect
}

// ---------------------------------------------------------------------------
// NASA data-source types (EPIC · NASA Image Library · NTRS)
// ---------------------------------------------------------------------------

export interface Vec3Km {
  x: number;
  y: number;
  z: number;
}

/** One DSCOVR/EPIC full-disc Earth frame with real timestamp and positions. */
export interface EpicFrame {
  identifier: string;
  image: string;
  caption: string;
  /** Capture time, ISO-8601 UTC. */
  capturedAt: string;
  capturedMs: number;
  /** Geographic coordinates of the centre of the disc (degrees). */
  lat: number;
  lon: number;
  /** Geocentric J2000 positions, kilometres. */
  dscovrKm: Vec3Km;
  moonKm: Vec3Km;
  sunKm: Vec3Km;
  imageUrl: string;
  mirrorUrl: string;
  thumbUrl: string;
}

export type EpicSource = 'api.nasa.gov' | 'epic.gsfc.nasa.gov' | 'archived-sample';

export interface NasaImageItem {
  nasaId: string;
  title: string;
  description: string;
  dateCreated: string;
  center: string;
  thumbUrl: string;
  mediumUrl: string;
  detailsUrl: string;
}

export interface NtrsRecord {
  id: string;
  title: string;
  authors: string[];
  year?: number;
  center?: string;
  reportNumber?: string;
  abstract?: string;
  url: string;
}
